package com.valuelabs.nephele.cloud.acronis.datamodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class AcronisPricing {
	
	//private String mode_update_date;
	//private Long rating;
	private Boolean enabled;
	private Long mode;
	private Long price;
	private AcronisDiscounts[] discounts;
	//private Long storage_discount;
	private String currency;
	
}
