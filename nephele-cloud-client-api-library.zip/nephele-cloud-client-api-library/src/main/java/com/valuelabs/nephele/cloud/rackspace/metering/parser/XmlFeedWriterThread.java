package com.valuelabs.nephele.cloud.rackspace.metering.parser;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.valuelabs.nephele.admin.data.entity.CloudFeed;
import com.valuelabs.nephele.admin.data.entity.CloudFeedEntry;
import com.valuelabs.nephele.admin.data.repository.CloudFeedEntryRepository;
import com.valuelabs.nephele.admin.data.repository.CloudFeedRepository;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedEntryResources;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleCloudFeedResources;
import com.valuelabs.nephele.cloud.rackspace.metering.parser.support.BeanToEntityMapper;
import com.valuelabs.nephele.cloud.server.rackspace.RackspaceMeteringDataConnection;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class XmlFeedWriterThread implements Closeable, Runnable {

	private CloudFeedRepository feedRepo;
	private CloudFeedEntryRepository entryRep;
	private List<CloudFeedEntry> persistList;

	private static int BATCH_SIZE;
	private BeanToEntityMapper beanToEntityMapper;

	/** Parser object used for loading Feed objects into memory */
	private Parser parser;

	public XmlFeedWriterThread(Parser parser, CloudFeedRepository feedRepo,
			CloudFeedEntryRepository entryRep, BeanToEntityMapper beanToEntityMapper,
			RackspaceMeteringDataConnection rackspaceConnection) {
		this.parser = parser;
		persistList = new ArrayList<CloudFeedEntry>();
		BATCH_SIZE = 100;
		this.feedRepo = feedRepo;
		this.entryRep = entryRep;
		this.beanToEntityMapper = beanToEntityMapper;

	}

	@Override
	public void run() {
		log.debug("Streaming from Rackspace server and persisting into database, this may take a while...");
		Object bntBean;
		try {
			// Get data object for persisting
			while (parser.isReadingInProgress() || parser.sizeOfRecordsInMemory() > 0) {
				bntBean = parser.getDataObject();

				if (null != bntBean) {
					if (bntBean instanceof XmlFeedParserWrapper) {
						String accountNo = ((XmlFeedParserWrapper) bntBean).getAtomId();
						List<Object> listOfWrapperObjects = ((XmlFeedParserWrapper) bntBean).getParsedObjects();

						Object object = listOfWrapperObjects.get(0);
						if (object instanceof NepheleCloudFeedResources) {
							CloudFeed cloudFeed = beanToEntityMapper
									.parseFeed((NepheleCloudFeedResources) listOfWrapperObjects.get(0));

							feedRepo.save(cloudFeed);

						}
						if (object instanceof CloudFeedEntryResources) {
							CloudFeed cloudFeed = feedRepo.findByUuid(((CloudFeedEntryResources) object).getFeedUuid());
							while (null == cloudFeed) {
								cloudFeed = feedRepo.findByUuid(((CloudFeedEntryResources) object).getFeedUuid());
							}
							persistList = beanToEntityMapper.parseEntry(listOfWrapperObjects);

						}

					}
					if (persistList.size() == BATCH_SIZE) {
						entryRep.save(persistList);
						persistList = new ArrayList<CloudFeedEntry>();
					}
				}
				if (persistList.size() > 0) {
					performDBOperations();
				}
			}
		} catch (Exception e) {
			log.debug("Exception while saving records into database " + e.getMessage());
		}

	}

	private void performDBOperations() {
		log.debug("Total Records size Persisting into Database :  " + persistList.size());

		save(persistList);
		persistList.clear();
	}

	public void save(List<CloudFeedEntry> listOfbatchObjects) {

		if (listOfbatchObjects != null) {
			if (listOfbatchObjects.size() <= BATCH_SIZE) {
				// log.debug("Records size in Batch: " +
				// listOfbatchObjects.size());
				entryRep.save(listOfbatchObjects);

			} else {
				int listSize = listOfbatchObjects.size();
				int initialListSize = listSize;
				int startIndex = 0;
				int subIndex = 0;
				while (listSize > BATCH_SIZE) {
					subIndex = startIndex + BATCH_SIZE;
					List<CloudFeedEntry> subList = listOfbatchObjects.subList(startIndex, subIndex);
					// log.debug("Records size in Batch: " +
					// entitiesList.size());
					entryRep.save(subList);
					startIndex = subIndex;
					listSize = listSize - BATCH_SIZE;
				}
				List<CloudFeedEntry> subList = listOfbatchObjects.subList(initialListSize - listSize, initialListSize);
				// log.debug("Records size in Batch: " + entitiesList.size());
				entryRep.save(subList);
			}
		}
	}

	@Override
	public void close() throws IOException {
		// TODO Auto-generated method stub

	}

}
