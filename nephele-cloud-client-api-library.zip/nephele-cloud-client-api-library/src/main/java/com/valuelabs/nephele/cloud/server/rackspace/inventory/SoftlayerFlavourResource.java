package com.valuelabs.nephele.cloud.server.rackspace.inventory;

import java.util.List;

import com.valuelabs.nephele.admin.data.entity.CloudSoftlayerCPUConfiguration;
import com.valuelabs.nephele.admin.data.entity.CloudSoftlayerDiskConfiguration;
import com.valuelabs.nephele.admin.data.entity.CloudSoftlayerRAMConfiguration;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SoftlayerFlavourResource {

	private CloudSoftlayerRAMConfiguration ram;
	private CloudSoftlayerCPUConfiguration cpu;
	private CloudSoftlayerDiskConfiguration disk;
}
