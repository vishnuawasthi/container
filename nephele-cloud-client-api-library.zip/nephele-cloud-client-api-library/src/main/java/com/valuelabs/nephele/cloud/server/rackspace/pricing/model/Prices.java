package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;

public class Prices
{
private Price[] price;

private String unitOfMeasure;

public Price[] getPrice ()
{
return price;
}

public void setPrice (Price[] price)
{
this.price = price;
}

public String getUnitOfMeasure ()
{
return unitOfMeasure;
}

public void setUnitOfMeasure (String unitOfMeasure)
{
this.unitOfMeasure = unitOfMeasure;
}

@Override
public String toString()
{
return "ClassPojo [price = "+price+", unitOfMeasure = "+unitOfMeasure+"]";
}
}
		
			