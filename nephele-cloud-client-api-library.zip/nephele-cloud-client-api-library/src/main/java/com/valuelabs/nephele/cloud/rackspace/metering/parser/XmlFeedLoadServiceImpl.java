package com.valuelabs.nephele.cloud.rackspace.metering.parser;

import com.valuelabs.nephele.admin.data.api.JobName;
import com.valuelabs.nephele.admin.data.api.JobStatus;
import com.valuelabs.nephele.admin.data.entity.CloudBillingCycle;
import com.valuelabs.nephele.admin.data.entity.CloudFeedEntry;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.entity.CloudServiceCredential;
import com.valuelabs.nephele.admin.data.repository.CloudBillingCycleRepository;
import com.valuelabs.nephele.admin.data.repository.CloudFeedEntryRepository;
import com.valuelabs.nephele.admin.data.repository.CloudFeedRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceCredentialRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceRepository;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;
import com.valuelabs.nephele.admin.rest.lib.domain.JobDetails;
import com.valuelabs.nephele.admin.rest.lib.enumerated.CloudTypes;
import com.valuelabs.nephele.admin.rest.lib.event.RackspaceMeteringDataCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleCloudFeedResources;
import com.valuelabs.nephele.cloud.rackspace.metering.parser.support.BeanToEntityMapper;
import com.valuelabs.nephele.cloud.rackspace.metering.parser.support.XmlFeedParserService;
import com.valuelabs.nephele.cloud.server.rackspace.RackspaceMeteringDataConnection;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class XmlFeedLoadServiceImpl implements XmlFeedLoadService {

  int writerThreadPoolSize = 3;
  int timeInterval = 1;
  @Autowired
  private CloudFeedRepository feedRepo;
  @Autowired
  private CloudFeedEntryRepository entryRepo;
  @Autowired
  private BeanToEntityMapper beanToEntityMapper;
  @Autowired
  private RackspaceMeteringDataConnection rackspaceConnection;
  @Autowired
  private XmlFeedParserService.Impl xmlFeedParserService;
  @Autowired
  private CloudServiceRepository serviceRepository;
  
  @Autowired
  private CloudServiceCredentialRepository credentialServiceRepository;
  
  @Autowired
  private CloudBillingCycleRepository billingCycleRepository;
	@Value("${rackspace.resultsperpage}")
	private int resultsPerPage;
	
	@Value("${rackspace.lastpageurl}")
	private String lastpageUrl;

  private static String getHostName() {
    Map<String, String> env = System.getenv();
    if (env.containsKey("COMPUTERNAME"))
      return env.get("COMPUTERNAME");
    else if (env.containsKey("HOSTNAME"))
      return env.get("HOSTNAME");
    else
      return "Unknown Computer";
  }

	@SuppressWarnings("deprecation")
	@Override
	public RackspaceMeteringDataCreatedEvent loadRackspaceXmlFeed() throws Exception {

		boolean isCompleted=false;
		CloudBillingCycle currentBillCycle = null;
		RackspaceMeteringDataCreatedEvent response = null;
		Pageable recentRecord = new PageRequest(0, 1);
		String status = "";
		Date currDateInUtcZone = null;
		Date billingEndDate = null;
		Date billingStartDate = null;
		try {

			CloudService service = serviceRepository.findByIntegrationCode("rackspace");
			if(null == service)
				throw new ResourceNotFoundException("CloudService", "rackspace");
			Integer billingDay = service.getBillingDay();
			billingStartDate = DateFormatterUtility.getPreviousMonthUTCDateFromDay(billingDay);
		    billingEndDate = DateFormatterUtility.getUTCDateFromDay(billingDay-1);
		    billingEndDate.setHours(23);
		    billingEndDate.setMinutes(59);
		    billingEndDate.setSeconds(59);

		    /*SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss z");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

		    Date endDateInUtcZone = sdf.parse(sdf.format(billingEndDate));

		    Calendar currentUtcTime = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
		    Date currDateInUtcZone = sdf.parse(sdf.format(currentUtcTime.getTime()));*/

      SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
		    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

      SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");

      currDateInUtcZone = dateFormatLocal.parse(sdf.format(new Date()));

      if(billingCycleRepository.findAll().isEmpty()){
		    	currentBillCycle = CloudBillingCycle.builder().cloudService(service)
		    											  .nepheleMeteringStatus(JobStatus.NOT_YET_INITIATED)
														  .vendorMeteringStatus(JobStatus.INITIATED)
														  .invoiceStatus(JobStatus.NOT_YET_INITIATED)
														  .currentParseJobStatus(JobStatus.INITIATED)
														  .billingPeriodStartDate(billingStartDate)
														  .billingPeriodEndDate(billingEndDate)
														  .hostName(getHostName())
														  .build();

        billingCycleRepository.save(currentBillCycle);
		    }else{

        currentBillCycle = billingCycleRepository.getBillingCycleByCurrentDate(currDateInUtcZone);
		    	if(null == currentBillCycle){
		    		currentBillCycle = CloudBillingCycle.builder().cloudService(service)
																  .nepheleMeteringStatus(JobStatus.NOT_YET_INITIATED)
																  .vendorMeteringStatus(JobStatus.INITIATED)
																  .invoiceStatus(JobStatus.NOT_YET_INITIATED)
																  .currentParseJobStatus(JobStatus.INITIATED)
																  .billingPeriodStartDate(billingStartDate)
																  .billingPeriodEndDate(billingEndDate)
																  .hostName(getHostName())
																  .build();

            billingCycleRepository.save(currentBillCycle);
		    	}else {
		    		currentBillCycle.setCurrentParseJobStatus(JobStatus.INITIATED);
			    	billingCycleRepository.save(currentBillCycle);
		    	}
		    }
      CloudService cloudServiceRecord = serviceRepository.findByIntegrationCode(CloudTypes.rackspace.toString());
      if(cloudServiceRecord!=null){
      CloudServiceCredential credentialRecord= credentialServiceRepository.getCredentilsByServiceId(cloudServiceRecord.getId());
      
      
      if(entryRepo.findAll().isEmpty()) {
    	  lastpageUrl="https://syd.feeds.api.rackspacecloud.com/nova/events/"+credentialRecord.getAccountNo()+"?marker=last&limit=1000&direction=backward";
        isCompleted=loadXmlFeed(lastpageUrl);
			}else{
				isCompleted=true;
			}

      if(isCompleted){

        Page<CloudFeedEntry> recentEntry = entryRepo.findRecentEntry(recentRecord);

        String forwardEntriesLink = "https://syd.feeds.api.rackspacecloud.com/nova/events/"+credentialRecord.getAccountNo()+"/?marker="
					+ recentEntry.getContent().get(0).getEntryUuid() + "&limit=" + resultsPerPage + "&direction=forward";

			NepheleCloudFeedResources nextFeedData = xmlFeedParserService.readFromServer(forwardEntriesLink);

        while (null != nextFeedData && !nextFeedData.getEntries().isEmpty()) {

          //log.debug("Feed Entries size in Rackspace Stream ...." + nextFeedData.getEntries().size());

          if(loadXmlFeed(forwardEntriesLink)){

				Page<CloudFeedEntry> nextRecentEntry = entryRepo.findRecentEntry(recentRecord);

            forwardEntriesLink = "https://syd.feeds.api.rackspacecloud.com/nova/events/"+credentialRecord.getAccountNo()+"/?marker="
						+ nextRecentEntry.getContent().get(0).getEntryUuid() + "&limit=" + resultsPerPage + "&direction=forward";

            nextFeedData = null;

				nextFeedData = xmlFeedParserService.readFromServer(forwardEntriesLink);

			        }
			     }

      }
      }
			status = "Rackspace metering data parsing done for the date: " + currDateInUtcZone;

      // publish the event to trigger usage data
			Thread.sleep(2000);
			if(currDateInUtcZone.after(billingEndDate)){
				JobDetails jobDetails =null;
				if(currentBillCycle != null){
					currentBillCycle.setCurrentParseJobStatus(JobStatus.COMPLETED);
					currentBillCycle.setVendorMeteringStatus(JobStatus.COMPLETED);
					billingCycleRepository.save(currentBillCycle);

          jobDetails = JobDetails.builder().jobId(currentBillCycle.getId())
												      .jobName(JobName.VENDOR_METERING)
													  .jobStatus(JobStatus.COMPLETED)
              .cloudTypes(CloudTypes.rackspace)
              .build();
				}
				response = new RackspaceMeteringDataCreatedEvent();
				response.setStatus(status);
				response.setJobDetails(jobDetails);

      }else {
				currentBillCycle.setCurrentParseJobStatus(JobStatus.COMPLETED);
				billingCycleRepository.save(currentBillCycle);
			}

      return response;

    } catch (Exception e) {
			log.debug("Exception in loadRackspaceXmlFeed " + e.getMessage());
			if(currentBillCycle != null){
				currentBillCycle.setCurrentParseJobStatus(JobStatus.FAILED);
				currentBillCycle.setVendorMeteringStatus(JobStatus.FAILED);
			}

      billingCycleRepository.save(currentBillCycle);

      throw new Exception(e.getMessage());
		}


  }

  private Boolean loadXmlFeed(final String url) {

		log.debug("XmlFeedLoadServiceImpl :loadXmlFeed():  START");
		Boolean isCompleted = false;
		try {
			ExecutorService threadExecutor = Executors
					.newFixedThreadPool(1 * (writerThreadPoolSize + 1));


      XmlFeedParser parser = new XmlFeedParser(xmlFeedParserService, url);
				XmlFeedServiceThread readerThread = new XmlFeedServiceThread(parser);

				threadExecutor.execute(readerThread);

				for (int threadCnt = 0; threadCnt < writerThreadPoolSize; threadCnt++) {

					threadExecutor.execute(new XmlFeedWriterThread(parser, feedRepo, entryRepo,
							beanToEntityMapper, rackspaceConnection));

        }
			threadExecutor.shutdown();
			while (!threadExecutor.isTerminated()) {
				threadExecutor.awaitTermination(timeInterval, TimeUnit.MINUTES);
			}

			isCompleted = true;
		} catch (Exception e) {
			log.debug("Exception in XmlFeedLoadServiceImpl :loadXmlFeed()" + e.getMessage());
		}
		log.debug("XmlFeedLoadServiceImpl :loadXmlFeed(): END");
		return isCompleted;

	}

}
