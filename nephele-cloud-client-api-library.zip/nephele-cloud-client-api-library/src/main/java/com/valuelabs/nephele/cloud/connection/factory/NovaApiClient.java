/*package com.valuelabs.nephele.cloud.connection.factory;

import static com.valuelabs.nephele.cloud.server.rackspace.Constants.PROVIDER;

import java.io.IOException;

import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.ServerCreated;
import org.jclouds.openstack.nova.v2_0.features.ServerApi;

import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;
import com.valuelabs.nephele.cloud.server.rackspace.RackspaceNovaApi;

public class NovaApiClient {

	public static void main(String[] args) {

		String username="synnexadmin";
		String apiKey="cfb360bd7d9b4dc2a18fee65ec030690";
		
		String locationId ="SYD";
		String serverName ="nephele-qa";
		String imageId = "1229d02f-5189-4dfe-a255-7d285a2f0bc9";
		String flavorId = "performance1-4";
		Integer serverCount = 1 ;
		
		ServerCreated  serverCreated = null;
		AcquireServerDetails acquireServerDetails =new AcquireServerDetails().builder().locationCode(locationId).
																						serverName(serverName).
																						imageId(imageId).
																						flavorId(flavorId).
																						serverCount(serverCount).build();
		
		NovaApi novaApi  =RackspaceNovaApi.getInstance().initNovaApi(PROVIDER, username, apiKey);
		ServerApi serverApi = RackspaceNovaApi.getInstance().initServerApi(novaApi, locationId);
		
		try {
			serverCreated = RackspaceNovaApi.getInstance().createServer(serverApi, acquireServerDetails);
			log.debug("########## Nova Server : "+ serverCreated);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				RackspaceNovaApi.getInstance().close(novaApi);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
*/