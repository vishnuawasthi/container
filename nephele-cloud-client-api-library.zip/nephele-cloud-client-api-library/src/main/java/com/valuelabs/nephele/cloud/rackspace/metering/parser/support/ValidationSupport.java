package com.valuelabs.nephele.cloud.rackspace.metering.parser.support;

import java.util.Collections;

public class ValidationSupport {
	public static Iterable safe( Iterable list ) {
	    return list == null ? Collections.EMPTY_LIST : list;
	}
}
