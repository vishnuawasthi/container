package com.valuelabs.nephele.cloud.server.rackspace.inventory;

import org.springframework.stereotype.Component;

import com.valuelabs.nephele.admin.data.entity.CloudService;

@Component
public interface CloudInventoryDataLoadService {
	
	public void loadImageData(CloudService service) throws Exception;
	public void loadFlavorData(CloudService service) throws Exception;
	public void loadProducts(CloudService service);
	public void loadProductPlans(CloudService service) throws Exception;
	void loadLocations(CloudService service) throws Exception;
	public void loadAdditionalPrice();

}
