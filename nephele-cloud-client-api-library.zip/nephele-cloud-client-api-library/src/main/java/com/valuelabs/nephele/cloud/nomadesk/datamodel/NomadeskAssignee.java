package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Assignee")
public class NomadeskAssignee {
	
	 private String name;
	 private String email;
	 private String firstName;
	 private String lastName;
	 private String lastLoginDstamp;
	 
	@XmlElement(name = "Name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@XmlElement(name = "Email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@XmlElement(name = "FirstName")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@XmlElement(name = "LastName")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@XmlElement(name = "LastLoginDstamp")
	public String getLastLoginDstamp() {
		return lastLoginDstamp;
	}
	public void setLastLoginDstamp(String lastLoginDstamp) {
		this.lastLoginDstamp = lastLoginDstamp;
	}


}
