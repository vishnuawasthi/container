package com.valuelabs.nephele.cloud.connection.factory;

import java.util.List;

import javax.inject.Singleton;

import lombok.extern.slf4j.Slf4j;

import com.softlayer.api.ApiClient;
import com.softlayer.api.service.Account;
import com.softlayer.api.service.billing.Invoice;
import com.softlayer.api.service.billing.invoice.Item;
import com.softlayer.api.service.user.Customer;
import com.valuelabs.nephele.cloud.server.softlayer.SoftlayerApi;

@Slf4j
public class SoftlayerCloudClientImpl implements SoftlayerCloudClient {
	
	private static SoftlayerCloudClient instance = new SoftlayerCloudClientImpl();
	
	@Singleton
	public static SoftlayerCloudClient getInstance() {
		return instance;
	}

	@Override
	public ApiClient getCloudSoftLayerApiClientConnection(String username, String apiKey) {
		ApiClient apiClient = SoftlayerApi.getInstance().initSoftlayerApi(username, apiKey);
	    return apiClient;
	}

	@Override
	public Account createSoftlayerAccount(ApiClient client, Account account, Boolean bypassDuplicateAccountCheck) {
		Account accountDetails = SoftlayerApi.getInstance().createAccount(client, account, bypassDuplicateAccountCheck);
		return accountDetails;
	}
	
	@Override
	public Customer createUserCustomer(ApiClient apiClient, Customer customerDetails, String password, String vpnPassword) {
		Customer customerDetailsResponse = SoftlayerApi.getInstance().createUserCustomer(apiClient, customerDetails, password, vpnPassword);
		return customerDetailsResponse;
	}

	@Override
	public List<Invoice> getInvoices(ApiClient apiClient) {
		List<Invoice> invoices = SoftlayerApi.getInstance().getInvoices(apiClient);
		return invoices;
	}
	
	@Override
	public List<Item> getUsageItems(ApiClient apiClient, Long invoiceId) {
		List<Item> items = SoftlayerApi.getInstance().getUsageItems(apiClient, invoiceId);
		return items;
	}

	/*
	@Override
	public Server getCloudActiveServerPolling(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollActiveServerDetails(serverApi, serverId);
	    return serverDetails;
	}
	
	@Override
	public Server getCloudDeleteServerPolling(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollDeleteServerDetails(serverApi, serverId);
	    return serverDetails;
	}
	
	@Override
	public ServerCreated createServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception {
		ServerCreated serverDetails = RackspaceNovaApi.getInstance().createServer(serverApi, acquireServerDetails);
		return serverDetails;
	}

	@Override
	public Boolean destroyServer(ServerApi serverApi, String serverId) throws Exception {
		Boolean isServerDeleted = RackspaceNovaApi.getInstance().destroyServer(serverApi, serverId);
		return isServerDeleted;
	}

	@Override
	public void rebootServer(ServerApi serverApi, String serverId, RebootType rebootType) throws Exception {
		RackspaceNovaApi.getInstance().rebootServer(serverApi, serverId, rebootType);
	}
	
	@Override
	public Boolean resetServerPassword(ServerApi serverApi, String serverId, String password) throws Exception {
		return RackspaceNovaApi.getInstance().resetServerPassword(serverApi, serverId, password);
	}
	
	@Override
	public FluentIterable<Image> listImages(NovaApi novaApi) throws Exception {
		return RackspaceNovaApi.getInstance().listImages(novaApi);
	}
	
	@Override
	public FluentIterable<Flavor> listFlavours(NovaApi novaApi) throws Exception {
		return RackspaceNovaApi.getInstance().listFlavours(novaApi);
	}
	
	@Override
	public FlavorExtraSpecsApi getFlavorExtraSpecs(NovaApi novaApi) throws Exception {
		return RackspaceNovaApi.getInstance().getFlavorExtraSpecs(novaApi);
	}
	
	@Override
	public void close(NovaApi novaApi) throws IOException {
		RackspaceNovaApi.getInstance().close(novaApi);
	}

	@Override
	public Server verifyServerResize(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollVerifyResizeStatusServerDetails(serverApi, serverId);
	    return serverDetails;
	}
	
	@Override
	public Server confirmResizeServer(ServerApi serverApi, String serverId, Boolean isConfirmResize) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollResizeConfirmationServerDetails(serverApi, serverId, isConfirmResize);
	    return serverDetails;
	}

	@Override
	public Server syncServer(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().syncActiveServerDetails(serverApi, serverId);
		return serverDetails;
	}*/

}
