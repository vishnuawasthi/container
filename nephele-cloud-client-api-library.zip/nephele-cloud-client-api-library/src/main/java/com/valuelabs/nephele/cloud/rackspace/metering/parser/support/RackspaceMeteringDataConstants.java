package com.valuelabs.nephele.cloud.rackspace.metering.parser.support;

public class RackspaceMeteringDataConstants {
	public static final String DATA_CENTER = "dataCenter";
	public static final String END_TIME = "endTime";
	public static final String ENVIRONMENT = "environment";
	public static final String ID = "id";
	public static final String REGION = "region";
	public static final String RESOURCE_ID = "resourceId";
	public static final String RRSOURCE_NAME = "resourceName";
	public static final String START_TIME = "startTime";
	public static final String TENANT_ID = "tenantId";
	public static final String TYPE = "type";
	public static final String VERSION = "version";
	public static final String BANDWITH_IN = "bandwidthIn";
	public static final String BANDWITH_OUT = "bandwidthOut";
	public static final String FLAVOR_ID = "flavorId";
	public static final String FLAVOR_NAME = "flavorName";
	public static final String IS_MANAGED = "isManaged";
	public static final String OS_LICENCE_TYPE = "osLicenseType";
	public static final String RESOURCE_TYPE = "resourceType";
	public static final String RESOURCE_NAME=  "resourceName";
	public static final String SERVICE_CODE = "serviceCode";
	public static final String STATUS = "status";
	public static final String EVENT = "event";
	public static final String NOVA_PRODUCT = "nova:product";
}
