package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;

public class ProductOfferingPrice
{
private PriceDetails[] priceDetails;

private String description;

private String priceType;

public PriceDetails[] getPriceDetails ()
{
return priceDetails;
}

public void setPriceDetails (PriceDetails[] priceDetails)
{
this.priceDetails = priceDetails;
}

public String getDescription ()
{
return description;
}

public void setDescription (String description)
{
this.description = description;
}

public String getPriceType ()
{
return priceType;
}

public void setPriceType (String priceType)
{
this.priceType = priceType;
}

@Override
public String toString()
{
return "ClassPojo [priceDetails = "+priceDetails+", description = "+description+", priceType = "+priceType+"]";
}
}

