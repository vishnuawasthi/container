package com.valuelabs.nephele.cloud.rackspace.metering.parser;

import java.io.IOException;

import com.sun.syndication.io.FeedException;
import com.valuelabs.nephele.admin.rest.lib.event.RackspaceMeteringDataCreatedEvent;

public interface XmlFeedLoadService {

	RackspaceMeteringDataCreatedEvent loadRackspaceXmlFeed() throws IllegalArgumentException, FeedException, IOException, Exception;

}
