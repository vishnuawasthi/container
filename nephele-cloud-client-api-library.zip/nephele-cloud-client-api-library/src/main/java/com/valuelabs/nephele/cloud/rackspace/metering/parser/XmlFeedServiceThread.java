package com.valuelabs.nephele.cloud.rackspace.metering.parser;

public class XmlFeedServiceThread implements Runnable {

	private Parser parser;

	  XmlFeedServiceThread(Parser parser) {
	    this.parser = parser;

	  }

	  @Override
	  public void run() {
	    parser.loadDataObjects();
	  }
}
