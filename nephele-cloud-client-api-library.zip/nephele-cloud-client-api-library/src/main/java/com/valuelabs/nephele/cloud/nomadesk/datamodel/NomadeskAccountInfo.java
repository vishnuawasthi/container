package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


//@Data
@XmlRootElement(name = "AccountInfo")
public class NomadeskAccountInfo {	
	
	private String failedAttempts;

    private String telephone;

    private String firstBillingDate;

    private String removalDstamp;

    private String creationDstamp;

    private String lastName;

    private String  brandingID;

    private String confirmed;

    private String nextBillingDate;

    private String failedPaymentStatus;

    private String address2;

    private String firstName;
    private String password;
    private boolean extendedInfo;
    private boolean skipConfirm;

    private String confirmationExpiryDateSeconds;

    private String vatNumber;

    private String zip;

    private String company;

    private String currency;

    private String isTrial;

    private String recurringBillingStatus;

    private String trialExpiryDateSeconds;

    private String expiryDstamp;

    private String fax;

    private String trialExpiryDstamp;

    private String startTrialDstamp;

    private String country;

    private String province;

    private String city;

    private String title;

    private String removedDstamp;

    private String confirmedDstamp;

    private String email;

    private String state;

    private String endTrialDstamp;

    private String address;

    private String lastBillingDate;

    private String accountName;

    private String language;

    private String installStatus;

    @XmlElement(name = "FailedAttempts")
    public String getFailedAttempts ()
    {
        return failedAttempts;
    }

    public void setFailedAttempts (String failedAttempts)
    {
        this.failedAttempts = failedAttempts;
    }

    @XmlElement(name = "Telephone")
    public String getTelephone ()
    {
        return telephone;
    }

    public void setTelephone (String telephone)
    {
        this.telephone = telephone;
    }

    @XmlElement(name = "FirstBillingDate")
    public String getFirstBillingDate ()
    {
        return firstBillingDate;
    }

    public void setFirstBillingDate (String firstBillingDate)
    {
        this.firstBillingDate = firstBillingDate;
    }
    @XmlElement(name = "RemovalDstamp")
    public String getRemovalDstamp ()
    {
        return removalDstamp;
    }

    public void setRemovalDstamp (String removalDstamp)
    {
        this.removalDstamp = removalDstamp;
    }
    @XmlElement(name = "CreationDstamp")
    public String getCreationDstamp ()
    {
        return creationDstamp;
    }

    public void setCreationDstamp (String creationDstamp)
    {
        this.creationDstamp = creationDstamp;
    }
    @XmlElement(name = "LastName")
    public String getLastName ()
    {
        return lastName;
    }

    public void setLastName (String lastName)
    {
        this.lastName = lastName;
    }
    @XmlElement(name = "BrandingID")
    public String getBrandingID ()
    {
        return brandingID;
    }

    public void setBrandingID (String brandingID)
    {
        this.brandingID = brandingID;
    }
    @XmlElement(name = "Confirmed")
    public String getConfirmed ()
    {
        return confirmed;
    }

    public void setConfirmed (String confirmed)
    {
        this.confirmed = confirmed;
    }
    @XmlElement(name = "NextBillingDate")
    public String getNextBillingDate ()
    {
        return nextBillingDate;
    }

    public void setNextBillingDate (String nextBillingDate)
    {
        this.nextBillingDate = nextBillingDate;
    }

    @XmlElement(name = "FailedPaymentStatus")
    public String getFailedPaymentStatus ()
    {
        return failedPaymentStatus;
    }

    public void setFailedPaymentStatus (String failedPaymentStatus)
    {
        this.failedPaymentStatus = failedPaymentStatus;
    }
    @XmlElement(name = "Address2")
    public String getAddress2 ()
    {
        return address2;
    }

    public void setAddress2 (String address2)
    {
        this.address2 = address2;
    }
    @XmlElement(name = "FirstName")
    public String getFirstName ()
    {
        return firstName;
    }

    public void setFirstName (String firstName)
    {
        this.firstName = firstName;
    }
    @XmlElement(name = "ConfirmationExpiryDateSeconds")
    public String getConfirmationExpiryDateSeconds ()
    {
        return confirmationExpiryDateSeconds;
    }

    public void setConfirmationExpiryDateSeconds (String confirmationExpiryDateSeconds)
    {
        this.confirmationExpiryDateSeconds = confirmationExpiryDateSeconds;
    }
    @XmlElement(name = "VatNumber")
    public String getVatNumber ()
    {
        return vatNumber;
    }

    public void setVatNumber (String vatNumber)
    {
        this.vatNumber = vatNumber;
    }
    @XmlElement(name = "Zip")
    public String getZip ()
    {
        return zip;
    }

    public void setZip (String zip)
    {
        this.zip = zip;
    }
    @XmlElement(name = "Company")
    public String getCompany ()
    {
        return company;
    }

    public void setCompany (String company)
    {
        this.company = company;
    }
    @XmlElement(name = "Currency")
    public String getCurrency ()
    {
        return currency;
    }

    public void setCurrency (String currency)
    {
        this.currency = currency;
    }
    @XmlElement(name = "IsTrial")
    public String getIsTrial ()
    {
        return isTrial;
    }

    public void setIsTrial (String isTrial)
    {
        this.isTrial = isTrial;
    }
    @XmlElement(name = "RecurringBillingStatus")
    public String getRecurringBillingStatus ()
    {
        return recurringBillingStatus;
    }

    public void setRecurringBillingStatus (String recurringBillingStatus)
    {
        this.recurringBillingStatus = recurringBillingStatus;
    }
    @XmlElement(name = "TrialExpiryDateSeconds")
    public String getTrialExpiryDateSeconds ()
    {
        return trialExpiryDateSeconds;
    }

    public void setTrialExpiryDateSeconds (String trialExpiryDateSeconds)
    {
        this.trialExpiryDateSeconds = trialExpiryDateSeconds;
    }
    @XmlElement(name = "ExpiryDstamp")
    public String getExpiryDstamp ()
    {
        return expiryDstamp;
    }

    public void setExpiryDstamp (String expiryDstamp)
    {
        this.expiryDstamp = expiryDstamp;
    }

    @XmlElement(name = "Fax")
    public String getFax ()
    {
        return fax;
    }

    public void setFax (String fax)
    {
        this.fax = fax;
    }
    @XmlElement(name = "TrialExpiryDstamp")
    public String getTrialExpiryDstamp ()
    {
        return trialExpiryDstamp;
    }

    public void setTrialExpiryDstamp (String trialExpiryDstamp)
    {
        this.trialExpiryDstamp = trialExpiryDstamp;
    }
    @XmlElement(name = "StartTrialDstamp")
    public String getStartTrialDstamp ()
    {
        return startTrialDstamp;
    }

    public void setStartTrialDstamp (String startTrialDstamp)
    {
        this.startTrialDstamp = startTrialDstamp;
    }
    @XmlElement(name = "Country")
    public String getCountry ()
    {
        return country;
    }

    public void setCountry (String country)
    {
        this.country = country;
    }
    @XmlElement(name = "Province")
    public String getProvince ()
    {
        return province;
    }

    public void setProvince (String province)
    {
        this.province = province;
    }
    @XmlElement(name = "City")
    public String getCity ()
    {
        return city;
    }

    public void setCity (String city)
    {
        this.city = city;
    }
    @XmlElement(name = "Title")
    public String getTitle ()
    {
        return title;
    }

    public void setTitle (String title)
    {
        this.title = title;
    }
    @XmlElement(name = "RemovedDstamp")
    public String getRemovedDstamp ()
    {
        return removedDstamp;
    }

    public void setRemovedDstamp (String removedDstamp)
    {
        this.removedDstamp = removedDstamp;
    }
    @XmlElement(name = "ConfirmedDstamp")
    public String getConfirmedDstamp ()
    {
        return confirmedDstamp;
    }

    public void setConfirmedDstamp (String confirmedDstamp)
    {
        this.confirmedDstamp = confirmedDstamp;
    }
    @XmlElement(name = "Email")
    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }
    @XmlElement(name = "State")
    public String getState ()
    {
        return state;
    }

    public void setState (String state)
    {
        this.state = state;
    }
    @XmlElement(name = "EndTrialDstamp")
    public String getEndTrialDstamp ()
    {
        return endTrialDstamp;
    }

    public void setEndTrialDstamp (String endTrialDstamp)
    {
        this.endTrialDstamp = endTrialDstamp;
    }
    @XmlElement(name = "Address")
    public String getAddress ()
    {
        return address;
    }

    public void setAddress (String address)
    {
        this.address = address;
    }
    @XmlElement(name = "LastBillingDate")
    public String getLastBillingDate ()
    {
        return lastBillingDate;
    }

    public void setLastBillingDate (String lastBillingDate)
    {
        this.lastBillingDate = lastBillingDate;
    }
    @XmlElement(name = "AccountName")
    public String getAccountName ()
    {
        return accountName;
    }

    public void setAccountName (String accountName)
    {
        this.accountName = accountName;
    }
    @XmlElement(name = "Language")
    public String getLanguage ()
    {
        return language;
    }

    public void setLanguage (String language)
    {
        this.language = language;
    }
    @XmlElement(name = "InstallStatus")
    public String getInstallStatus ()
    {
        return installStatus;
    }

    public void setInstallStatus (String installStatus)
    {
        this.installStatus = installStatus;
    }

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean getExtendedInfo() {
		return extendedInfo;
	}

	public void setExtendedInfo(boolean extendedInfo) {
		this.extendedInfo = extendedInfo;
	}

	public boolean isSkipConfirm() {
		return skipConfirm;
	}

	public void setSkipConfirm(boolean skipConfirm) {
		this.skipConfirm = skipConfirm;
	}

 
}
			
