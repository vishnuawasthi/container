package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;


import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

/**
 * Created by snagaboina on 24/11/15.
 */
//@Component
public class MySimpleClientHttpRequestFactory extends SimpleClientHttpRequestFactory {

  
  private static SSLSocketFactory factory;

  private HostnameVerifier verifier;

  public MySimpleClientHttpRequestFactory(final HostnameVerifier verifier)
  {
    this.verifier = verifier;
  }

  @Override
  protected void prepareConnection(HttpURLConnection connection, String httpMethod) throws IOException {
    if (connection instanceof HttpsURLConnection) {
      try {
        factory = prepFactory((HttpsURLConnection)connection);
        ((HttpsURLConnection) connection).setHostnameVerifier(verifier);
        ((HttpsURLConnection) connection).setSSLSocketFactory(factory);
        ((HttpsURLConnection) connection).setAllowUserInteraction(true);
      } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
      } catch (KeyStoreException e) {
        e.printStackTrace();
      } catch (KeyManagementException e) {
        e.printStackTrace();
      } catch (Exception e) {
        e.printStackTrace();
      }

    }
    super.prepareConnection(connection, httpMethod);
  }

  static synchronized SSLSocketFactory prepFactory(HttpsURLConnection httpsConnection) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {

    if (factory == null) {
      SSLContext ctx = SSLContext.getInstance("TLSV1.1");
      ctx.init(null, new TrustManager[]{ new AlwaysTrustManager() }, null);
      factory = ctx.getSocketFactory();
    }
    return factory;
  }

  private static class AlwaysTrustManager implements X509TrustManager {
    public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException { }
    public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException { }
    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
  }

}