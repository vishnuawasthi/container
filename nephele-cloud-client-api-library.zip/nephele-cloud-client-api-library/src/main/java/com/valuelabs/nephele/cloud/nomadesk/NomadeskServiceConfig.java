package com.valuelabs.nephele.cloud.nomadesk;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class NomadeskServiceConfig {
	
	@Value("${nomadeskservice.uri}")
	private String url;

	@Value("${nomadeskservice.login}")
	private String loginPath;
	
	@Value("${nomadeskservice.logout}")
	private String logoutPath;	     

	@Value("${nomadeskservice.accounts}") 
	private String accountsPath;   
	
	@Value("${nomadeskservice.getaccount}") 
	private String getaccountPath;  
	
	@Value("${nomadeskservice.destroyaccount}") 
	private String destroyAcctPath;
	
	@Value("${nomadeskservice.forgotpwd}") 
	private String forgotpwdPath;
	
	@Value("${nomadeskservice.assignedlicenses}") 
	private String assignedLicensesPath;
	
	@Value("${nomadeskservice.unassignedlicenses}") 
	private String unAssignedLicensesPath;
	
	@Value("${nomadeskservice.getlicenses}") 
	private String getlicensesPath;	
	
	@Value("${nomadeskservice.reActivateAccount}") 
	private String reActivateAccountPath;	
	
	@Value("${nomadeskservice.checkAccountStatus}") 
	private String checkAccountStatusPath;
	
	@Value("${nomadeskservice.suspendAccount}") 
	private String suspendAccountPath;
	
	@Value("${nomadeskservice.cancelAccount}") 
	private String cancelAccountPath;
	                   
	@Bean(name="nomadeskRestTemplate")
	public RestTemplate getNomadeskServiceTemplate() {
		log.debug("Creating: RestTemplate nomadeskRestTemplate");
		HttpClient httpClient = HttpClientBuilder.create().build();

		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		RestTemplate restTemplate = new RestTemplate(requestFactory);

		return restTemplate;
	}

	@Bean(name="nomadeskLoginUrlTemplate")
	public String getNomadeskLoginUrlTemplate() {		
		return String.format("%s%s", url, loginPath);		
	}
	@Bean(name="nomadeskLogoutUrlTemplate")
	public String getNomadeskLogoutUrlTemplate() {	
		return String.format("%s%s", url, logoutPath);			
	}	
	@Bean(name="nomadeskAccountsUrlTemplate")                                                  
	public String getNomadeskAccountsUrlTemplate() {	
		return String.format("%s%s", url, accountsPath);				
	} 
	@Bean(name="nomadeskGetAcctUrlTemplate")                                                  
	public String getNomadeskGetAccountUrlTemplate() {	
		return String.format("%s%s", url, getaccountPath);				
	}	
	@Bean(name="nomadeskDestroyAcctUrlTemplate")                                                  
	public String getNomadeskDestroyAcctUrlTemplate() {	
		return String.format("%s%s", url, destroyAcctPath);				
	} 
	@Bean(name="nomadeskForgotPwdUrlTemplate")                                                  
	public String getNomadeskForgotPwdUrlTemplate() {	
		return String.format("%s%s", url, forgotpwdPath);				
	}
	@Bean(name="nomadeskAssignedLicensesUrlTemplate")                                                  
	public String getNomadeskAssignedLicensesUrlTemplate() {	
		return String.format("%s%s", url, assignedLicensesPath);				
	} 
	@Bean(name="nomadeskUnassignedLicensesUrlTemplate")                                                  
	public String getNomadeskUnassignedLicenseUrlTemplate() {	
		return String.format("%s%s", url, unAssignedLicensesPath);				
	} 
	@Bean(name="nomadeskGetLicensesUrlTemplate")                                                  
	public String getNomadeskGetLicensesUrlTemplate() {	
		return String.format("%s%s", url, getlicensesPath);				
	}
	
	@Bean(name="nomadeskCheckAccountStatusUrlTemplate")                                                  
	public String getNomadeskCheckAccountStatusUrlTemplate() {	
		return String.format("%s%s", url, checkAccountStatusPath);				
	}
	
	@Bean(name="nomadeskReActivateAccountUrlTemplate")                                                  
	public String getNomadeskReActivateAccountUrlTemplate() {	
		return String.format("%s%s", url, reActivateAccountPath);	
	}
	
	@Bean(name="nomadeskSuspendAccountUrlTemplate")                                                  
	public String getNomadeskSuspendAccountUrlTemplate() {	
		return String.format("%s%s", url, suspendAccountPath);				
	}
	
	@Bean(name="nomadeskCancelAccountUrlTemplate")                                                  
	public String getNomadeskCancelAccountUrlTemplate() {	
		return String.format("%s%s", url, cancelAccountPath);				
	}
	
}
