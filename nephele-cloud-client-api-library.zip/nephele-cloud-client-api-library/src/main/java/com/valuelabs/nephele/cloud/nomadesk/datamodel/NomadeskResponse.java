package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.valuelabs.nephele.admin.data.api.AccountStatus;
import com.valuelabs.nephele.admin.data.api.AuthMethod;


//@Data
@XmlRootElement(name = "Response")
public class NomadeskResponse {
	
	
	private String status;
	
	
	private String message;	
	
	
	private String token;	
	
	private MobileDeviceControlSettings mobileDeviceControlSettings;
	
	private NomadeskAccountInfo accountInfo;
	
	private NomadeskServerInfo serverInfo;
	
	private NomadeskBillingInfo billingInfo;
	
	private AccountStatus accountStatus;	
	
	private AuthMethod authMethod;
	
	@XmlElement(name = "Status")
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	@XmlElement(name = "Message")
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	@XmlElement(name = "Token")
	public String getToken() {
		return token;
	}
	
	public void setToken(String token) {
		this.token = token;
	}
	
	@XmlElement(name = "MobileDeviceControlSettings")
	public MobileDeviceControlSettings getMobileDeviceControlSettings() {
		return mobileDeviceControlSettings;
	}
	
	public void setMobileDeviceControlSettings(MobileDeviceControlSettings mobileDeviceControlSettings) {
		this.mobileDeviceControlSettings = mobileDeviceControlSettings;
	}
	
	@XmlElement(name = "AccountInfo")
	public NomadeskAccountInfo getAccountInfo() {
		return accountInfo;
	}
	
	public void setAccountInfo(NomadeskAccountInfo accountInfo) {
		this.accountInfo = accountInfo;
	}
	@XmlElement(name = "ServerInfo")
	public NomadeskServerInfo getServerInfo() {
		return serverInfo;
	}

	public void setServerInfo(NomadeskServerInfo serverInfo) {
		this.serverInfo = serverInfo;
	}
	@XmlElement(name = "BillingInfo")
	public NomadeskBillingInfo getBillingInfo() {
		return billingInfo;
	}

	public void setBillingInfo(NomadeskBillingInfo billingInfo) {
		this.billingInfo = billingInfo;
	}
	
	@XmlElement(name = "AccountStatus")
	public AccountStatus getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}
	
	@XmlElement(name = "AuthMethod")
	public AuthMethod getAuthMethod() {
		return authMethod;
	}

	public void setAuthMethod(AuthMethod authMethod) {
		this.authMethod = authMethod;
	}

}
