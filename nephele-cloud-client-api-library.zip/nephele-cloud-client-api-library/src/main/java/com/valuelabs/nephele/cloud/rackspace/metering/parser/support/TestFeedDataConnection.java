package com.valuelabs.nephele.cloud.rackspace.metering.parser.support;

import java.io.StringReader;

import org.xml.sax.InputSource;

import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.FeedException;
import com.sun.syndication.io.SyndFeedInput;
import com.valuelabs.nephele.cloud.server.rackspace.RackspaceMeteringDataConnection;

public class TestFeedDataConnection {

	public static void main(String[] args) {

		String url = "https://syd.feeds.api.rackspacecloud.com/nova/events/965965?marker=last&limit=1000&direction=backward";
		// String url=
		// "https://syd.feeds.api.rackspacecloud.com/nova/events/965965/?marker=urn:uuid:5cbc406e-1afb-401a-9fb4-bf74a29ac1c4&amp;limit=1000&amp;search=&amp;direction=forward";

		
		String data = RackspaceMeteringDataConnection.getTestCon(url);
		try {
			

			InputSource in = new InputSource(new StringReader(data));
			SyndFeedInput input = new SyndFeedInput();
			SyndFeed syndFeed = input.build(in);

			/*
			 * for (SyndEntryImpl impl :
			 * (List<SyndEntryImpl>)(syndFeed.getEntries())){
			 */

		}

		catch (IllegalArgumentException | FeedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
