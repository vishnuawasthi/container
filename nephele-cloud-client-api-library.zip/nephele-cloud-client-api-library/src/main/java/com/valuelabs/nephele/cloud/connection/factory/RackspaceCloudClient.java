package com.valuelabs.nephele.cloud.connection.factory;

import java.io.IOException;

import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.Flavor;
import org.jclouds.openstack.nova.v2_0.domain.Image;
import org.jclouds.openstack.nova.v2_0.domain.RebootType;
import org.jclouds.openstack.nova.v2_0.domain.Server;
import org.jclouds.openstack.nova.v2_0.domain.ServerCreated;
import org.jclouds.openstack.nova.v2_0.extensions.FlavorExtraSpecsApi;
import org.jclouds.openstack.nova.v2_0.features.ServerApi;

import com.google.common.collect.FluentIterable;
import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;

public interface RackspaceCloudClient {
	
	public NovaApi getCloudNovaConnection(String provider, String username, String apiKey);
	
	public ServerApi getCloudServerConnection(NovaApi novaApi, String locationId);
	
	public Server getCloudActiveServerPolling(ServerApi serverApi, String serverId);
	
	public Server getCloudDeleteServerPolling(ServerApi serverApi, String serverId);
	
	public ServerCreated createServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception;
	
	public Boolean destroyServer(ServerApi serverApi, String serverId) throws Exception;
	
	public void rebootServer(ServerApi serverApi, String serverId, RebootType rebootType) throws Exception;
	
	public void close(NovaApi novaApi) throws IOException;

	FluentIterable<Image> listImages(NovaApi novaApi) throws Exception;

	FluentIterable<Flavor> listFlavours(NovaApi novaApi) throws Exception;

	FlavorExtraSpecsApi getFlavorExtraSpecs(NovaApi novaApi) throws Exception;

	Boolean resetServerPassword(ServerApi serverApi, String serverId,
			String password) throws Exception;
	
	public Server verifyServerResize(ServerApi serverApi, String serverId);

	Server confirmResizeServer(ServerApi serverApi, String serverId,
			Boolean isConfirmResize);
	
	Server syncServer(ServerApi serverApi, String serverId);

}
