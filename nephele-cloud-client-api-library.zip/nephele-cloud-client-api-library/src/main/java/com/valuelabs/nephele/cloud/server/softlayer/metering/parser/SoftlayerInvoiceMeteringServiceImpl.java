package com.valuelabs.nephele.cloud.server.softlayer.metering.parser;

import com.softlayer.api.ApiClient;
import com.softlayer.api.service.billing.Invoice;
import com.softlayer.api.service.billing.invoice.Item;
import com.valuelabs.nephele.admin.data.api.BusinessRuleNames;
import com.valuelabs.nephele.admin.data.api.JobName;
import com.valuelabs.nephele.admin.data.api.JobStatus;
import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;
import com.valuelabs.nephele.admin.data.entity.*;
import com.valuelabs.nephele.admin.data.repository.*;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceCredentialDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.JobDetails;
import com.valuelabs.nephele.admin.rest.lib.enumerated.CloudTypes;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceCredentialEvent;
import com.valuelabs.nephele.admin.rest.lib.event.SoftlayerMeteringDataCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServiceCredentialQueryService;
import com.valuelabs.nephele.cloud.connection.factory.SoftlayerCloudClient;
import com.valuelabs.nephele.cloud.connection.factory.SoftlayerCloudClientImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static com.valuelabs.nephele.admin.data.repository.CloudBusinessRuleSpecifications.getBusinessRulesByRuleName;

@Slf4j
@Component
public class SoftlayerInvoiceMeteringServiceImpl implements SoftlayerInvoiceMeteringService {

	@Autowired
  private SoftlayerMeteringDataRepository softlayerMeteringDataRepository;

	@Autowired
	private CloudSoftlayerUsageDataRepository cloudSoftlayerUsageDataRepository;
	
	@Autowired
	private CloudAccountRepository cloudAccountRepository;

	@Autowired
	private CloudServiceCredentialQueryService cloudServiceCredentialQueryService;
	
	@Autowired
	private CloudBusinessRuleRepository cloudBusinessRuleRepository;
	
	@Autowired
	private CloudServiceRepository serviceRepository;

	@Override
	public SoftlayerMeteringDataCreatedEvent loadInvoiceDataFromSoftlayer() throws Exception {
		log.debug("In softlayer loadInvoiceDataFromSoftlayer()  - Start");

		SoftlayerCloudClient softlayerCloudClient = null;
		ApiClient mainClient = null;
		List<Invoice> invoices = null;
		SoftlayerMeteringDataCreatedEvent response = null;
		String status = "";
		Date currDateInUtcZone = null;
		try {

			/**
			 * Getting softlayer cloud service details.
			 */
			CloudService service = serviceRepository.findByIntegrationCode(CloudTypes.softlayer.name());
			if (null == service)
				throw new ResourceNotFoundException("CloudService", "softlayer");

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

			SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");

			currDateInUtcZone = dateFormatLocal.parse(sdf.format(new Date()));

			/**
			 * Getting softlayer cloud service credentials
			 */
			ReadServiceCredentialEvent credentialRequest = new ReadServiceCredentialEvent().setCloudServiceId(service.getId());
			EntityReadEvent<CloudServiceCredentialDetails> readEvent = cloudServiceCredentialQueryService.getServiceCredentialsByServiceId(credentialRequest);

			if (!readEvent.isFound()) {
				throw new ResourceNotFoundException("CloudServiceCredential", service.getId());
			}

			/**
			 * Getting the invoices for account by passing softlayer cloud
			 * service credentials.
			 */
			CloudServiceCredentialDetails credentialDetails = readEvent.getEntity();

			softlayerCloudClient = SoftlayerCloudClientImpl.getInstance();
			mainClient = softlayerCloudClient.getCloudSoftLayerApiClientConnection(credentialDetails.getUsername(), credentialDetails.getApiKey());

			invoices = softlayerCloudClient.getInvoices(mainClient);

			/**
			 * Storing invoices into softlayer metering data table.
			 */
			ArrayList<SoftlayerMeteringData> listSoftlayerMeteringData = new ArrayList<SoftlayerMeteringData>();
			for (Invoice invoice : invoices) {
				SoftlayerMeteringData softlayerMeteringData = SoftlayerMeteringData.builder().accountId(invoice.getAccountId()).address1(invoice.getAddress1()).city(invoice.getCity()).claimedTaxExemptTxFlag(invoice.getClaimedTaxExemptTxFlag()).closedDate(invoice.getClosedDate()).companyName(invoice.getCompanyName()).country(invoice.getCountry()).createDate(invoice.getCreateDate()).documentsGeneratedFlag(invoice.getDocumentsGeneratedFlag()).email(invoice.getEmail())
					.endingBalance(invoice.getEndingBalance()).firstName(invoice.getFirstName()).lastName(invoice.getLastName()).modifyDate(invoice.getModifyDate()).officePhone(invoice.getOfficePhone()).postalCode(invoice.getPostalCode()).state(invoice.getState()).statusCode(invoice.getStatusCode()).taxStatusId(invoice.getTaxStatusId()).taxTypeId(invoice.getTaxTypeId()).typeCode(invoice.getTypeCode()).build();
				listSoftlayerMeteringData.add(softlayerMeteringData);
			}
      if (!listSoftlayerMeteringData.isEmpty())
        softlayerMeteringDataRepository.save(listSoftlayerMeteringData);

			/**
			 * Storing invoice items into softlayer usage data table.
			 */
			for (Invoice invoice : invoices) {
				List<Item> items = softlayerCloudClient.getUsageItems(mainClient, invoice.getId());
        CloudAccount cloudAccount = cloudAccountRepository.getAccountByVendorAccountId(invoice.getAccountId().toString());
        CloudBusinessRule cloudBusinessRule = cloudBusinessRuleRepository.findOne(getBusinessRulesByRuleName(BusinessRuleNames.CURRENCY.name()));
				for (Item item : items) {
					SoftlayerUsageData softlayerUsageData = SoftlayerUsageData.builder()
																				 .cloudCustomerCompany(cloudAccount.getCloudCustomerCompany())
																				 .cloudAccount(cloudAccount)
              .productType(null != item.getCategory() ? item.getCategory().getName() : item.getCategoryCode())
              .serviceType(null != item.getCategory() ? item.getCategory().getName() : item.getCategoryCode())
              .cloudService(service)
              .quantity(null != item.getCategory() ? item.getCategory().getQuantityLimit() : 1)
              .currency(cloudBusinessRule.getRuleValue())
																				 .unitPrice(item.getHourlyRecurringFee().doubleValue())
																				 .recurringCharge(item.getRecurringFee().doubleValue())
																				 .setupCharge(item.getSetupFee().doubleValue())
																				 .laborCharge(item.getLaborFee().doubleValue())
																				 .onetimeCharge(item.getOneTimeFee().doubleValue())
																				 .description(item.getDescription())
																				 .totalPrice(calculateTotalPrice(item))
																				 .invoiceStatus(MeteringDataInvoiceStatus.PENDING)
																				 .eventStartDate(item.getCreateDate())
																				 .build();
					cloudSoftlayerUsageDataRepository.save(softlayerUsageData);
				}
			}
			status = "Softlayer metering data parsing done for the date: " + currDateInUtcZone;
      JobDetails jobDetails = JobDetails.builder().jobId(1L).jobName(JobName.NEPHELE_METERING).jobStatus(JobStatus.COMPLETED).cloudTypes(CloudTypes.softlayer).build();
      response = new SoftlayerMeteringDataCreatedEvent();
			response.setStatus(status);
			response.setJobDetails(jobDetails);

			return response;
		} catch (Exception e) {
			log.error("Exception in loadInvoiceDataFromSoftlayer " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
	}

	private Double calculateTotalPrice(Item item) {
		Double totalPrice = item.getHourlyRecurringFee().doubleValue() + item.getRecurringFee().doubleValue() + item.getSetupFee().doubleValue() + item.getLaborFee().doubleValue();
		return totalPrice;
	}

}
