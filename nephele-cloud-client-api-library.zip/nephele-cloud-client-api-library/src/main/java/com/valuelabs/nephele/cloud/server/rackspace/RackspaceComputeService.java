package com.valuelabs.nephele.cloud.server.rackspace;

import static org.jclouds.compute.predicates.NodePredicates.inGroup;

import java.io.IOException;
import java.util.Set;

import javax.inject.Singleton;

import org.jclouds.ContextBuilder;
import org.jclouds.compute.ComputeService;
import org.jclouds.compute.ComputeServiceContext;
import org.jclouds.compute.domain.NodeMetadata;
import org.jclouds.compute.domain.Template;
import org.jclouds.compute.domain.TemplateBuilder;
import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.Flavor;
import org.jclouds.openstack.nova.v2_0.domain.Image;
import org.jclouds.openstack.nova.v2_0.extensions.FlavorExtraSpecsApi;
import org.jclouds.openstack.nova.v2_0.features.FlavorApi;
import org.jclouds.openstack.nova.v2_0.features.ImageApi;

import com.google.common.base.Optional;
import com.google.common.collect.FluentIterable;
import com.google.common.io.Closeables;
import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;




public class RackspaceComputeService {
	
	private static RackspaceComputeService instance = new RackspaceComputeService();
	
	
	private NovaApi novaApi;

	private RackspaceComputeService() {
	}

	@Singleton
	public static RackspaceComputeService getInstance() {
		return instance;
	}
	
	
	/**
     * Create Cloud Compute Service Context. Requires you to specify the cloud provider string, the username and the API Key.
     * @param provider
     * @param username
     * @param apiKey
     */
	
	public ComputeService initComputeService(String provider, String username, String apiKey) { 
		 
		  // These properties control how often jclouds polls for a status update
	     /* Properties overrides = new Properties();
	      overrides.setProperty(POLL_INITIAL_PERIOD, POLL_PERIOD_TWENTY_SECONDS);
	      overrides.setProperty(POLL_MAX_PERIOD, POLL_PERIOD_TWENTY_SECONDS);*/
	 
	      ComputeServiceContext context = ContextBuilder.newBuilder(provider)
	              .credentials(username, apiKey)
	            //  .overrides(overrides)
	              .buildView(ComputeServiceContext.class);

	      novaApi = context.unwrapApi(NovaApi.class);
	                                              
	     // logger.info("Cloud Compute Service Context Created");
	      return context.getComputeService();
	} 
	
	
	
	
	/**
	* groupName: if you acquire multiple servers, all servers will have groupName as the prefix. This helps in identification and categorization.
	* OS: The name of the Operating System
	* osVersion: The version of the Operating System
	* ram: The size of RAM
	* count: Number of cloud servers required
	*/
	
	/**
	* Acquire Servers by specifying specs
	* @param groupName
	* @param os
	* @param osVersion
	* @param ram in megabytes
	* @param disk in gigabytes
	* @param count
	* @throws Exception
	*/
	//cloudService.aquireServer("my-test-servers","Ubuntu","12.04",512,2);
	
	//public NodeMetadata  aquireServer(ComputeService compute, String locationId, String groupName, String operatingSystem, String osVersion, Integer ram, Integer disk, Integer count) throws Exception {
	public NodeMetadata  aquireServer(ComputeService compute, AcquireServerDetails acquireServerDetails) throws Exception {
	     TemplateBuilder templateBuilder = compute.templateBuilder();
	    /* Template template = templateBuilder
	                         .locationId(acquireServerDetails.getLocationId())
	                         .os64Bit(true)
	                         .osDescriptionMatches(acquireServerDetails.getOperatingSystem())
	                         .osVersionMatches(acquireServerDetails.getOperatingSystemVersion())
	                         .minRam(acquireServerDetails.getRam())
	                         .minDisk(acquireServerDetails.getDisk())
	                         .build();*/
	     StringBuilder cspFlavorId = new StringBuilder();
	     cspFlavorId.append(acquireServerDetails.getLocationCode()).append("/").append(acquireServerDetails.getFlavorId());
         
         StringBuilder cspImageId = new StringBuilder();
         cspImageId.append(acquireServerDetails.getLocationCode()).append("/").append(acquireServerDetails.getImageId());
         
	     Template template = templateBuilder.locationId(acquireServerDetails.getLocationCode())
	                    					.hardwareId(cspFlavorId.toString())
	                    					.imageId(cspImageId.toString()).build();

	      //logger.info("Acquiring "+ count+ " server(s).");
	      Set<? extends NodeMetadata> nodes = compute.createNodesInGroup(acquireServerDetails.getGroupName(),acquireServerDetails.getServerCount(), template);
	      //logger.info(nodes.size() + " server(s) acquired!");
	      NodeMetadata nodeMetadata = nodes.iterator().next();
	      return nodeMetadata;
	}
	
	/**
	* This will delete all servers in group
	* @param groupName
	* @throws Exception
	*/
	public NodeMetadata releaseGroup(ComputeService computeService,String groupName, String serverId, String locationId) throws Exception {
	   // logger.info("Releasing server(s) from group " + groupName);
		 StringBuilder id = new StringBuilder();
         id.append(locationId).append("/").append(serverId);
         NodeMetadata nodeMetadata = null;
		 Set<? extends NodeMetadata> nodes = null;
		
	      if (serverId != null) {
		    //log(String.format("reboot id: %s",serverId));
		    computeService.destroyNode(id.toString());
		  }
		  else {
		    //log(String.format("reboot group: %s",groupName));
			 nodes = computeService.destroyNodesMatching(inGroup(groupName));
			 nodeMetadata = nodes.iterator().next();
		  }
	      return nodeMetadata;
	    
	}
	
	
	   public NodeMetadata rebootNode(ComputeService computeService,String groupName, String serverId, String locationId){
		  StringBuilder id = new StringBuilder();
	      id.append(locationId).append("/").append(serverId);
		  Set<? extends NodeMetadata> nodes = null;
		  NodeMetadata nodeMetadata = null;
		  if (serverId != null) {
		    //log(String.format("reboot id: %s",serverId));
		    computeService.rebootNode(id.toString());
		  }
		  else {
		    //log(String.format("reboot group: %s",groupName));
			 nodes = computeService.rebootNodesMatching(inGroup(groupName));
			 nodeMetadata = nodes.iterator().next();
		  }
	      return nodeMetadata;
		}
	
		
	
		public NodeMetadata suspendNode(ComputeService computeService,String groupName, String serverId, String locationId){
			  StringBuilder id = new StringBuilder();
		      id.append(locationId).append("/").append(serverId);
			  Set<? extends NodeMetadata> nodes = null;
			  NodeMetadata nodeMetadata = null;
			  if (serverId != null) {
			    //log(String.format("reboot id: %s",serverId));
			    computeService.suspendNode(id.toString());
			  }
			  else {
			    //log(String.format("reboot group: %s",groupName));
				 nodes = computeService.suspendNodesMatching(inGroup(groupName));
				 nodeMetadata = nodes.iterator().next();
			  }
		      return nodeMetadata;
		}
		
		
		public NodeMetadata resumeNode(ComputeService computeService,String groupName, String serverId, String locationId){
			  StringBuilder id = new StringBuilder();
		      id.append(locationId).append("/").append(serverId);
		      NodeMetadata nodeMetadata = null;
			  Set<? extends NodeMetadata> nodes = null;
			  if (serverId != null) {
			    //log(String.format("reboot id: %s",serverId));
			    computeService.resumeNode(id.toString());
			  }
			  else {
			    //log(String.format("reboot group: %s",groupName));
				 nodes = computeService.resumeNodesMatching(inGroup(groupName));
				 nodeMetadata = nodes.iterator().next();
			  }
		      return nodeMetadata;
		}
	   
	   @SuppressWarnings("deprecation")
	   public FluentIterable<Image> listImages() {
		   FluentIterable<Image> images = null;
		   if(null != novaApi){
			   Set<String> zones = novaApi.getConfiguredRegions();
			   for (String zone: zones) {
				   if(zone.equalsIgnoreCase("SYD")){
					   ImageApi  imageApi = novaApi.getImageApiForZone(zone);
		               images = imageApi.listInDetail().concat();
		          }
		       }
		   }
		   
		   
		   return images;

	   }
	   
	   public FluentIterable<Flavor> listFlavours() {
		   FluentIterable<Flavor> flavours = null;
		   if(null != novaApi){
			   Set<String> regions = novaApi.getConfiguredRegions();
			   for (String region: regions) {
				   if(region.equalsIgnoreCase("SYD")){
					   FlavorApi  flavourApi = novaApi.getFlavorApi(region);
					   flavours = flavourApi.listInDetail().concat();
					   
					   
		          }
		       }
		   }
		   
		   
		   return flavours;

	   }
	   
	   public FlavorExtraSpecsApi getFlavorExtraSpecs() {
		   FlavorExtraSpecsApi flavorExtraSpecsApi = null;
		   if(null != novaApi){
			   Set<String> regions = novaApi.getConfiguredRegions();
			   for (String region: regions) {
				   if(region.equalsIgnoreCase("SYD")){
					   Optional<FlavorExtraSpecsApi> optFlavorExtraSpecsApi = novaApi.getFlavorExtraSpecsApi(region);
					   flavorExtraSpecsApi = optFlavorExtraSpecsApi.get();
		          }
		       }
			   
		   }
		   return flavorExtraSpecsApi;
		   
	   }
	   
	   /**
	    * Always close your service when you're done with it.
	    */
	   public void close(ComputeService computeService) throws IOException {
	      Closeables.close(computeService.getContext(), true);
	   }


}
