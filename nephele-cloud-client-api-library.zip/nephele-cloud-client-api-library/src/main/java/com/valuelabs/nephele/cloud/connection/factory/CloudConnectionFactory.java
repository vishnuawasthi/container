package com.valuelabs.nephele.cloud.connection.factory;

import javax.inject.Singleton;

import com.valuelabs.nephele.cloud.server.rackspace.RackspaceCloudConnection;

public class CloudConnectionFactory<T> {

	// T type MUST have a default constructor
	private final Class<T> type;

	public CloudConnectionFactory(Class<T> type) {
		this.type = type;
	}

	/**
	 * Use the factory to get the next instance.
	 */
	@Singleton
	public T getInstance() {

		try {
			// assume type is a public class
			return type.newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Create the factory. Note that V can be T, but to demonstrate that generic
	 * method are not generic classes, I've called it V and not T. In using this
	 * method V becomes T.
	 */
	public static <V> CloudConnectionFactory<V> getInstance(Class<V> type) {

		return new CloudConnectionFactory<V>(type);
	}

	@SuppressWarnings("unchecked")
	public static <V> CloudConnectionFactory<V> getInstance(CloudTypes cloudType) {
		Class<V> type = null;
		if(cloudType.equals(CloudTypes.rackspace)){
			type = (Class<V>) RackspaceCloudConnection.class;
		}
		/* else if(cloudType.equals(CloudTypes.AZURE)){
			type = (Class<V>) AzureCloudConnection.class;
		} else if (cloudType.equals(CloudTypes.SOFTLAYER)){
			type = (Class<V>) SoftlayerCloudConnection.class;
		}*/
		return new CloudConnectionFactory<V>(type);
	}

}
