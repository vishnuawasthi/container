package com.valuelabs.nephele.cloud.connection.factory;

import java.util.List;

import com.softlayer.api.ApiClient;
import com.softlayer.api.service.Account;
import com.softlayer.api.service.billing.Invoice;
import com.softlayer.api.service.billing.invoice.Item;
import com.softlayer.api.service.user.Customer;

public interface SoftlayerCloudClient {
	
	public ApiClient getCloudSoftLayerApiClientConnection(String username, String apiKey);
	
	public Account createSoftlayerAccount(ApiClient client, Account account, Boolean flag);

	public Customer createUserCustomer(ApiClient apiClient, Customer customerDetails, String password, String vpnPassword);
	
	public List<Invoice> getInvoices(ApiClient apiClient);
	
	public List<Item> getUsageItems(ApiClient apiClient, Long invoiceId);

	/*public Server getCloudActiveServerPolling(ServerApi serverApi, String serverId);
	
	public Server getCloudDeleteServerPolling(ServerApi serverApi, String serverId);
	
	public ServerCreated createServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception;
	
	public Boolean destroyServer(ServerApi serverApi, String serverId) throws Exception;
	
	public void rebootServer(ServerApi serverApi, String serverId, RebootType rebootType) throws Exception;
	
	public void close(NovaApi novaApi) throws IOException;

	FluentIterable<Image> listImages(NovaApi novaApi) throws Exception;

	FluentIterable<Flavor> listFlavours(NovaApi novaApi) throws Exception;

	FlavorExtraSpecsApi getFlavorExtraSpecs(NovaApi novaApi) throws Exception;

	Boolean resetServerPassword(ServerApi serverApi, String serverId,
			String password) throws Exception;
	
	public Server verifyServerResize(ServerApi serverApi, String serverId);

	Server confirmResizeServer(ServerApi serverApi, String serverId,
			Boolean isConfirmResize);
	
	Server syncServer(ServerApi serverApi, String serverId);*/

}
