package com.valuelabs.nephele.cloud.server.rackspace;

import static org.jclouds.openstack.nova.v2_0.predicates.ServerPredicates.*;

import java.io.IOException;
import java.util.Properties;
import java.util.Set;

import javax.inject.Singleton;

import lombok.extern.slf4j.Slf4j;

import org.jclouds.Constants;
import org.jclouds.ContextBuilder;
import org.jclouds.logging.slf4j.config.SLF4JLoggingModule;
import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.Flavor;
import org.jclouds.openstack.nova.v2_0.domain.Image;
import org.jclouds.openstack.nova.v2_0.domain.RebootType;
import org.jclouds.openstack.nova.v2_0.domain.Server;
import org.jclouds.openstack.nova.v2_0.domain.Server.Status;
import org.jclouds.openstack.nova.v2_0.domain.ServerCreated;
import org.jclouds.openstack.nova.v2_0.extensions.FlavorExtraSpecsApi;
import org.jclouds.openstack.nova.v2_0.extensions.ServerAdminApi;
import org.jclouds.openstack.nova.v2_0.features.FlavorApi;
import org.jclouds.openstack.nova.v2_0.features.ImageApi;
import org.jclouds.openstack.nova.v2_0.features.ServerApi;
import org.jclouds.openstack.nova.v2_0.options.CreateServerOptions;
import org.jclouds.sshj.config.SshjSshClientModule;
import org.springframework.beans.factory.annotation.Value;

import com.google.common.base.Optional;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableSet;
import com.google.common.io.Closeables;
import com.google.inject.Module;
import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;

@Slf4j
public class RackspaceNovaApi {
	
	
private static RackspaceNovaApi instance = new RackspaceNovaApi();
	
	@Value("${nepheleServer.rackspaceServer.password}")
	private String serverPassword;

	private NovaApi novaApi;

	private RackspaceNovaApi() {
	}

	@Singleton
	public static RackspaceNovaApi getInstance() {
		return instance;
	}

	/**
     * Create NovaApi. Requires you to specify the cloud provider string, the username and the API Key.
     * @param provider
     * @param username
     * @param apiKey
     */
	
	public NovaApi initNovaApi(String provider, String username, String apiKey) { 
		
		  
	      Properties overrides = new Properties();
	      overrides.setProperty(Constants.PROPERTY_RELAX_HOSTNAME, "true");
	      overrides.setProperty(Constants.PROPERTY_TRUST_ALL_CERTS, "true");
	      
		// This module is responsible for enabling logging
	      Iterable<Module> modules = ImmutableSet.<Module> of(new SLF4JLoggingModule(),new SshjSshClientModule());
	    
	      novaApi = ContextBuilder.newBuilder(provider).credentials(username, apiKey)
          									 .modules(modules)
          									 .overrides(overrides)
          									 .buildApi(NovaApi.class);
	      return novaApi;
	} 
	
	/**
     * Create ServerApi. Requires you to specify the NovaAPI and RegionId.
     * @param novaApi
     * @param locationId
     */
	public ServerApi initServerApi(NovaApi novaApi, String locationId) { 
		 ServerApi serverApi = novaApi.getServerApi(locationId);
		 return serverApi;
	}
	
	/**
	* Acquire Servers by specifying specs
	* @param serverApi
	* @param ImageId
	* @param FlavorId
	* @param serverName
	* @throws Exception
	*/
	public ServerCreated  createServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception {
		  ServerCreated  serverCreated;
	 
	     StringBuilder cspFlavorId = new StringBuilder();
	     cspFlavorId.append(acquireServerDetails.getLocationCode()).append("/").append(acquireServerDetails.getFlavorId());
         
         StringBuilder cspImageId = new StringBuilder();
         cspImageId.append(acquireServerDetails.getLocationCode()).append("/").append(acquireServerDetails.getImageId());
         
                
	     //CreateServerOptions createServerOptions = CreateServerOptions.Builder.adminPass("Value*123");
	     serverCreated = serverApi.create(acquireServerDetails.getServerName(), cspImageId.toString(), cspFlavorId.toString());
	     return  serverCreated;

   }
	
	/**
	* Resize Server by specifying specs
	* @param serverApi
	* @param serverId
	* @param FlavorId
	* @throws Exception
	*/
	public void  resizeServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception {
	     StringBuilder cspFlavorId = new StringBuilder();
	     cspFlavorId.append(acquireServerDetails.getLocationCode()).append("/").append(acquireServerDetails.getFlavorId());
	     serverApi.resize(acquireServerDetails.getServerId(),cspFlavorId.toString());
    }
	
	/**
	* Polling Active Server Status by specifying specs
	* @param serverApi
	* @param serverId
	* @throws Exception
	*/
	public Server pollActiveServerDetails(ServerApi serverApi,String serverId){
		
		awaitActive(serverApi).apply(serverId);
        Server serverDetails = serverApi.get(serverId);
        return serverDetails;
   }
	
	/**
	* Polling resize server to verify resize is completed or not
	* @param serverApi
	* @param serverId
	* @throws Exception
	*/
	public Server pollVerifyResizeStatusServerDetails(ServerApi serverApi,String serverId){
		
		Server serverDetails = serverApi.get(serverId);
		awaitStatus(serverApi, Status.VERIFY_RESIZE, 2400, 5);
		
        serverDetails = serverApi.get(serverId);
        return serverDetails;
   }
	
	/**
	* Polling Active Server Status by specifying specs
	* @param serverApi
	* @param serverId
	* @param isConfirmResize
	* @throws Exception
	*/
	public Server pollResizeConfirmationServerDetails(ServerApi serverApi,String serverId, Boolean isConfirmResize){
		
		Server serverDetails = serverApi.get(serverId);
		if(isConfirmResize)
			serverApi.confirmResize(serverId);
		else
			serverApi.revertResize(serverId);
		
		awaitActive(serverApi).apply(serverId);
        serverDetails = serverApi.get(serverId);
        return serverDetails;
   }
	
	
	public Server syncActiveServerDetails(ServerApi serverApi,String serverId){
		
		Server serverDetails = serverApi.get(serverId);
        return serverDetails;
   }
	
	
	/**
	* Polling Delete Server Status by specifying specs
	* @param serverApi
	* @param serverId
	* @throws Exception
	*/
	public Server pollDeleteServerDetails(ServerApi serverApi,String serverId){
		awaitShutoff(serverApi).apply(serverId);
        Server serverDetails = serverApi.get(serverId);
        return serverDetails;
   }
	/**
	* Destroy Server Status by specifying specs
	* @param serverApi
	* @param serverId
	* @throws Exception
	*/
	public Boolean destroyServer(ServerApi serverApi,String serverId){
		Boolean isServerDestroyed;
		isServerDestroyed = serverApi.delete(serverId);
        return isServerDestroyed;
    }
	
	/**
	* Reboot Server Status by specifying specs
	* @param serverApi
	* @param serverId
	* @param RebootType
	* @throws Exception
	*/
	public void rebootServer(ServerApi serverApi,String serverId, RebootType rebootType){
		serverApi.reboot(serverId, rebootType);
    }
	
	/**
	* Polling Delete Server Status by specifying specs
	* @param serverApi
	* @param serverId
	* @throws Exception
	*/
	public Boolean resetServerPassword(ServerApi serverApi,String serverId, String newPassword) throws Exception{
		Boolean passwordChanged = false;
		try{
			serverApi.changeAdminPass(serverId, newPassword);
			passwordChanged = true;
		}catch(Exception e){
			throw new Exception(e.getMessage());
		}
        
        return passwordChanged;
   }
	
	 @SuppressWarnings("deprecation")
	   public FluentIterable<Image> listImages(NovaApi novaApi) {
		   FluentIterable<Image> images = null;
		   if(null != novaApi){
			   Set<String> zones = novaApi.getConfiguredRegions();
			   for (String zone: zones) {
				   if(zone.equalsIgnoreCase("SYD")){
					   ImageApi  imageApi = novaApi.getImageApiForZone(zone);
		               images = imageApi.listInDetail().concat();
		          }
		       }
		   }
		   return images;
	   }
	   
	   public FluentIterable<Flavor> listFlavours(NovaApi novaApi) {
		   FluentIterable<Flavor> flavours = null;
		   if(null != novaApi){
			   Set<String> regions = novaApi.getConfiguredRegions();
			   for (String region: regions) {
				   if(region.equalsIgnoreCase("SYD")){
					   FlavorApi  flavourApi = novaApi.getFlavorApi(region);
					   flavours = flavourApi.listInDetail().concat();
		          }
		       }
		   }
		   return flavours;
	   }
	   
	   public FlavorExtraSpecsApi getFlavorExtraSpecs(NovaApi novaApi) {
		   FlavorExtraSpecsApi flavorExtraSpecsApi = null;
		   if(null != novaApi){
			   Set<String> regions = novaApi.getConfiguredRegions();
			   for (String region: regions) {
				   if(region.equalsIgnoreCase("SYD")){
					   Optional<FlavorExtraSpecsApi> optFlavorExtraSpecsApi = novaApi.getFlavorExtraSpecsApi(region);
					   flavorExtraSpecsApi = optFlavorExtraSpecsApi.get();
		          }
		       }
			   
		   }
		   return flavorExtraSpecsApi;
		   
	   }
	
	public void listAllServers(NovaApi novaApi, String locationId){
		Optional<ServerAdminApi> serverAdminApiOptional = novaApi.getServerAdminApi(locationId);
		 ServerAdminApi  ServerAdminApi = serverAdminApiOptional.get();
	}
	
	
	 /**
	    * Always close your Nova API when you're done with it.
	 */
	 public void close(NovaApi novaApi) throws IOException {
	      Closeables.close(novaApi, true);
	 }
}
