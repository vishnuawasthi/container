package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;
public class Products
{
    private Product[] product;

    public Product[] getProduct ()
    {
        return product;
    }

    public void setProduct (Product[] product)
    {
        this.product = product;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [product = "+product+"]";
    }
}