package com.valuelabs.nephele.cloud.connection.factory;

import java.util.List;

import com.softlayer.api.ApiClient;
import com.softlayer.api.RestApiClient;
import com.softlayer.api.service.container.virtual.guest.configuration.Option;
import com.softlayer.api.service.product.item.Price;
import com.softlayer.api.service.virtual.Guest;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class GetRam {

public static void main(String[] args) throws InterruptedException {
		
		ApiClient client = new RestApiClient().withCredentials("SYN813085", "2fb2de36137f3e1849debb15d693c6531fa39b61d820dc575d50bf83418327d2");
		
		/*for (Hardware hardware : Account.service(client).getHardware()) {
		    log.debug("Hardware: " + hardware.getFullyQualifiedDomainName());
		}*/
		Guest.Service service = Guest.service(client);
		List<Option> osList = service.getCreateObjectOptions().getMemory();
		log.debug("Get all memory options....");
		for (Option option : osList) {
			Price price = option.getItemPrice();
			log.debug("HourlyRecurringFee::::"+price.getHourlyRecurringFee());
			log.debug("Description:::::"+price.getItem().getDescription());
			log.debug("MaxMemory:::::"+option.getTemplate().getMaxMemory());
		}
}
}
