package com.valuelabs.nephele.cloud.server.rackspace.inventory;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.valuelabs.nephele.admin.data.api.CloudPricingModel;
import com.valuelabs.nephele.admin.data.api.CloudRackspaceFlavorClass;
import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.data.api.OperatingSystemType;
import com.valuelabs.nephele.admin.data.api.ProductType;
import com.valuelabs.nephele.admin.data.dao.CsvExportDAO;
import com.valuelabs.nephele.admin.data.entity.*;
import com.valuelabs.nephele.admin.data.repository.*;
import com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceCredentialDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceCredentialEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.resource.ProductPlanDetailsResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAdditionalPriceCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServiceCredentialQueryService;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.admin.rest.lib.util.PlanCodeSequenceUtil;
import com.valuelabs.nephele.cloud.connection.factory.CloudTypes;
import com.valuelabs.nephele.cloud.connection.factory.RackspaceCloudClient;
import com.valuelabs.nephele.cloud.connection.factory.RackspaceCloudClientImpl;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.Flavor;
import org.jclouds.openstack.nova.v2_0.domain.Image;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.transaction.Transactional;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import static com.valuelabs.nephele.cloud.server.rackspace.Constants.PROVIDER;

@Slf4j
@Service
@Transactional
public class CloudInventoryDataLoadServiceImpl implements CloudInventoryDataLoadService{
	
	/*@Autowired
	CloudConfigurationDAO cloudConfigurationDao;*/
	
	@Autowired
	CloudRackspaceConfigurationRepository configurationRepository;
	
	/*@Autowired
	CloudOperatingSystemDAO cloudOperatingSystemDao;*/
	
	/*@Autowired
	CloudServiceDAO cloudServiceDAO;*/
	
	/*
	 * 
    @Autowired
	CloudProductDAO cloudProductDAO;
		
	@Autowired
	CloudConfigurationTypeDAO cloudConfigurationTypeDAO;
	
	
	@Autowired
	CloudProductCategoryDAO cloudProductCategoryDAO;
	
	@Autowired
	CloudProductPlanDAO cloudProductPlanDAO;
	
	@Autowired
	CloudLocationDAO cloudLocationDAO;\
	
	@Autowired
	CloudAdditionalPriceDAO additionalPriceDAO;
	
	*/
	
	@Autowired
	CloudOperatingSystemRepository operatingSystemRepository;

	
	@Autowired
	CloudServiceRepository serviceRepository;
	
	@Autowired
	CloudProductRepository productRepository;
	
	@Autowired
	CloudProductPlanRepository productPlanRepository;
	
	@Autowired
	CloudLocationRepository locationRepository;
	@Autowired
	CloudServiceCredentialQueryService cloudServiceCredentialQueryService;
	@Autowired
	CloudAdditionalPriceCommandService additionalPriceCommandService;
	@Autowired
	PlanCodeSequenceUtil sequenceUtil;
	@Autowired
	private CsvExportDAO csvDao;
	@Autowired
	private CloudAdditionalPriceRepository additionalRepository;
	@Value("${additionalPrice.Message}")
	private String additionalPriceMessage;
	@Autowired
	CloudLocationGeographiesMappingRepository locGeoMappingRepository;
	@Autowired
	CloudGeographyRepository geoRepository;
	@Autowired
	NepheleUtils nepheleUtils;

	@Override
	public void loadLocations(CloudService service) throws Exception {
		
		RackspaceCloudClient rackspaceCloudClient = null;
		NovaApi novaApi = null;
		CloudGeography geography = null;
		CloudLocationGeographiesMapping locGeoMapping = null;
		try{
			/*ReadServiceCredentialEvent credentialRequest = new ReadServiceCredentialEvent().setCloudServiceId(service.getId());
			EntityReadEvent<CloudServiceCredentialDetails> readEvent = cloudServiceCredentialQueryService.getServiceCredentialsByServiceId(credentialRequest);*/
			CloudServiceCredential credentialDetails = service.getCloudServiceCredential();
			
			rackspaceCloudClient = RackspaceCloudClientImpl.getInstance();
			novaApi = rackspaceCloudClient.getCloudNovaConnection(PROVIDER, credentialDetails.getUsername(), nepheleUtils.decrypt(credentialDetails.getApikey()));
			Set<String> regions = novaApi.getConfiguredRegions();
			List<CloudLocation> list = locationRepository.findAll();
			if(CollectionUtils.isEmpty(list)){
				for (String region : regions) {
					if(!StringUtils.isEmpty(region)){
						 locGeoMapping = locGeoMappingRepository.findByLocationCode(region);
						
						if(!StringUtils.isEmpty(locGeoMapping) && !StringUtils.isEmpty(locGeoMapping.getGeographyCode())){
							 geography = geoRepository.findByGeographyCode(locGeoMapping.getGeographyCode());
						}
						else{
							log.error("Geography mapping does not exist with the given location code.");
						}
						
						CloudLocation location=CloudLocation.builder().name(region)
																	  .locationCode(region)
																	  .status(InventoryStatus.DISCOVERED.name())
																	  .cloudGeography(geography)
																	  .cloudService(service).build();
						locationRepository.save(location);
					}
				}
			}else{
				ImmutableMap<String, CloudLocation> locationsMap = Maps.uniqueIndex(list.iterator(), new Function<CloudLocation, String> () {
				    public String apply(CloudLocation cloudLocation) {
				      return cloudLocation.getLocationCode();
				    }
				  });
				for (String region : regions) {
					locGeoMapping = locGeoMappingRepository.findByLocationCode(region);
					
					if(!StringUtils.isEmpty(locGeoMapping) && !StringUtils.isEmpty(locGeoMapping.getGeographyCode())){
						 geography = geoRepository.findByGeographyCode(locGeoMapping.getGeographyCode());
					}
					else{
						log.error("Geography mapping does not exist with the given location code.");
					}
						
					CloudLocation existLocation = locationsMap.get(region);
					if(null == existLocation){
						CloudLocation location=CloudLocation.builder().name(region)
																	  .locationCode(region)
																	  .status(InventoryStatus.DISCOVERED.name())
																	  .cloudGeography(geography)
																	  .cloudService(serviceRepository.findOne(1L)).build();
						locationRepository.save(location);
					}
				}
			}
		}catch(Exception e){
			throw new Exception(e.getMessage());
		}finally{
			if(null != novaApi){
				rackspaceCloudClient.close(novaApi);
			}
		}
		
	}

	@Override
	public void loadImageData(CloudService cloudService) throws Exception {
		
		RackspaceCloudClient rackspaceCloudClient = null;
		NovaApi novaApi = null;
		try{
			ObjectMapper mapper = new ObjectMapper();
			/*ReadServiceCredentialEvent credentialRequest = new ReadServiceCredentialEvent().setCloudServiceId(1L);
			EntityReadEvent<CloudServiceCredentialDetails> readEvent = cloudServiceCredentialQueryService.getServiceCredentialsByServiceId(credentialRequest);*/
			CloudServiceCredential credentialDetails = cloudService.getCloudServiceCredential();
			/*CloudService cloudService = serviceRepository.findByIntegrationCode("rackspace");*/
			/*if (null == cloudService)
				throw new NepheleException("Service with code softlayer was not found");*/
			rackspaceCloudClient = RackspaceCloudClientImpl.getInstance();
			novaApi = rackspaceCloudClient.getCloudNovaConnection(PROVIDER, credentialDetails.getUsername(), nepheleUtils.decrypt(credentialDetails.getApikey()));
			
			List<CloudOperatingSystem> osList = operatingSystemRepository.getByService(cloudService.getId());
			FluentIterable<Image> fluentIterableImages = rackspaceCloudClient.listImages(novaApi);
			if(null != fluentIterableImages){
				ImmutableList<Image> images =fluentIterableImages.toList();
				
				if(!osList.isEmpty() && null != images) {
					
					ImmutableMap<String, CloudOperatingSystem> operatingSystemMap = Maps.uniqueIndex(osList.iterator(), new Function<CloudOperatingSystem, String> () {
					    public String apply(CloudOperatingSystem cloudOperatingSystem) {
					      return cloudOperatingSystem.getImageId();
					    }
					  });
					
					syncNepheleImagesByCSP(mapper, images, operatingSystemMap);
					
					syncCSPImagesByNephele(osList, images);
					
				} else {
					
					populateImagesFromCSPForFirstTime(mapper, images);
				}
			}else {
				log.debug("There are no images from Rackspace!!!");
			}
			
		}catch(Exception e){
			throw new Exception(e.getMessage());
		}finally{
			if(null != novaApi){
				rackspaceCloudClient.close(novaApi);
			}
		}
		
	}

	
	/**
	 * Checking the our operating system table entry has the corresponding value in pulled inventory data. 
	 * If it's not present then marking OS entry as ARCHIVED. 
	 * @throws Exception 
	 */
	private void syncCSPImagesByNephele(List<CloudOperatingSystem> osList,ImmutableList<Image> images) throws Exception {
		
		try {
			ImmutableMap<String, Image> imageMapById = Maps.uniqueIndex(images.iterator(), new Function<Image, String> () {
			    public String apply(Image image) {
			      return image.getId();
			    }
			  });
			
			for (CloudOperatingSystem cloudOperatingSystem : osList) {
				if(!cloudOperatingSystem.getStatus().equalsIgnoreCase(InventoryStatus.ARCHIVED.name())) {
					Image image = imageMapById.get(cloudOperatingSystem.getImageId());
					if(null == image) {
						cloudOperatingSystem.setStatus(InventoryStatus.ARCHIVED.name());
						operatingSystemRepository.save(cloudOperatingSystem);
					}
				}
				
			}
		} catch(Exception e){
			throw new Exception(e.getMessage());
		}
		
	}

	/**
	 * First time we are populating CLOUD_OPERATING_SYSTEM table
	 * @throws Exception 
	 */
	private void populateImagesFromCSPForFirstTime(ObjectMapper mapper, ImmutableList<Image> images) throws Exception {
		if(null != images) {
			try {
				for (Image image: images) {
					if(image.getStatus().name().equalsIgnoreCase("ACTIVE") 
							&& (OperatingSystemType.windows.name().equalsIgnoreCase(image.getMetadata().get("os_type")) 
									|| (OperatingSystemType.linux.name().equalsIgnoreCase(image.getMetadata().get("os_type")) 
											&& image.getName().contains("PVHVM")))){
						
						String json = null;
						try {
							json = mapper.writeValueAsString(image);
						} catch (IOException e) {
							e.printStackTrace();
						}
						CloudOperatingSystem  cloudOperatingSystem = CloudOperatingSystem.builder().imageId(image.getId()).
																									name(image.getName()).
																									osType(image.getMetadata().get("os_type")).
																									options(image.getMetadata().get("com.rackspace__1__options")).
																									status(InventoryStatus.DISCOVERED.name()).
																									minRam(Long.valueOf(image.getMinRam())).
																									minDisk(Long.valueOf(image.getMinDisk())).
																									cspResource(json).
																									cloudService(serviceRepository.findOne(1L)).price(0D).build();
						operatingSystemRepository.save(cloudOperatingSystem);
						
					} else {
						log.debug("Either OS is not active: {} OR Current Image Type: {} is not Windows", image.getStatus().name(), image.getMetadata().get("os_type"));
					}
			     }
			} catch(Exception e){
				throw new Exception(e.getMessage());
			}
			
		} else {
			log.debug("unable to get images data for Rackspace");
		}
	}

	/**
	 * Checking the given image has the entry in operating system table. 
	 * If it's not yet created then adding new entry in operating system table for new inventory image from service provider 
	 * @throws Exception 
	 */
	private void syncNepheleImagesByCSP(ObjectMapper mapper,
			ImmutableList<Image> images,
			ImmutableMap<String, CloudOperatingSystem> operatingSystemMap) throws Exception {
		try {
			for (Image image : images) {
				if((OperatingSystemType.windows.name().equalsIgnoreCase(image.getMetadata().get("os_type")) 
						|| (OperatingSystemType.linux.name().equalsIgnoreCase(image.getMetadata().get("os_type")) 
								&& image.getName().contains("PVHVM")))){
					if(image.getStatus().name().equalsIgnoreCase("ACTIVE")){
						CloudOperatingSystem cloudOperatingSystem = operatingSystemMap.get(image.getId());
						if(null == cloudOperatingSystem) {
							String json = null;
							try {
								json = mapper.writeValueAsString(image);
							} catch (IOException e) {
								e.printStackTrace();
							}
							CloudOperatingSystem  newCloudOperatingSystem = CloudOperatingSystem.builder().imageId(image.getId()).
																										name(image.getName()).
																										osType(image.getMetadata().get("os_type")).
																										options(image.getMetadata().get("com.rackspace__1__options")).
																										status(InventoryStatus.DISCOVERED.name()).
																										minRam(Long.valueOf(image.getMinRam())).
																										minDisk(Long.valueOf(image.getMinDisk())).
																										cspResource(json).
																										cloudService(serviceRepository.findOne(1L)).price(0D).build();
									
							operatingSystemRepository.save(newCloudOperatingSystem);
						} else {
							if(InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudOperatingSystem.getStatus())) {
								cloudOperatingSystem.setStatus(InventoryStatus.DISCOVERED.name());
								operatingSystemRepository.save(cloudOperatingSystem);
							}
						}
					} else {
						CloudOperatingSystem cloudOperatingSystem = operatingSystemMap.get(image.getId());
						if(null != cloudOperatingSystem) {
							cloudOperatingSystem.setStatus(InventoryStatus.ARCHIVED.name());
							operatingSystemRepository.save(cloudOperatingSystem);
						}
					}
				}
			}
		} catch(Exception e){
			throw new Exception(e.getMessage());
		}
		
	}

	@Override
	public void loadFlavorData(CloudService service) throws Exception {
		//String username="synnexsandbox";
		//String apiKey="f259179f4a264711accfa8f26a6b32d5";
		
		RackspaceCloudClient rackspaceCloudClient = null;
		NovaApi novaApi = null;
		try{
			ObjectMapper mapper = new ObjectMapper();
			/*ReadServiceCredentialEvent credentialRequest = new ReadServiceCredentialEvent().setCloudServiceId(1L);
			EntityReadEvent<CloudServiceCredentialDetails> readEvent = cloudServiceCredentialQueryService.getServiceCredentialsByServiceId(credentialRequest);*/
			CloudServiceCredential credentialDetails = service.getCloudServiceCredential();
			
			rackspaceCloudClient = RackspaceCloudClientImpl.getInstance();
			novaApi = rackspaceCloudClient.getCloudNovaConnection(PROVIDER, credentialDetails.getUsername(), nepheleUtils.decrypt(credentialDetails.getApikey()));
			
			List<CloudRackspaceConfiguration> configList = configurationRepository.findAll();
			
			ImmutableList<Flavor> flavors = rackspaceCloudClient.listFlavours(novaApi).toList();
			
			if(!configList.isEmpty() && null != flavors) {
				log.debug("Existing configurations Size: {}", configList.size());
				log.debug("Inventory flavors Size: {}", flavors.size());
				ImmutableMap<String, CloudRackspaceConfiguration> configurationsMap = Maps.uniqueIndex(configList.iterator(), new Function<CloudRackspaceConfiguration, String> () {
				    public String apply(CloudRackspaceConfiguration CloudRackspaceConfiguration) {
				      return CloudRackspaceConfiguration.getFlavorId();
				    }
				  });
				
				syncNepheleFlavorsByCSP(rackspaceCloudClient, novaApi, mapper, flavors, configurationsMap);
				
				syncCSPFlavorsByNephele(configList, flavors);
				
				
			} else {
				
				populateFlavorsFromCSPForFirstTime(rackspaceCloudClient, novaApi, mapper, flavors);
			}
		}catch(Exception e){
			throw new Exception(e.getMessage());
		}finally{
			if(null != novaApi){
				rackspaceCloudClient.close(novaApi);
			}
		}
		
	}


	/**
	 * Checking the our operating system table entry has the corresponding value in pulled inventory data. 
	 * If it's not present then marking OS entry as ARCHIVED. 
	 * @throws Exception 
	 */
	private void syncCSPFlavorsByNephele(
			List<CloudRackspaceConfiguration> configList,
			ImmutableList<Flavor> flavors) throws Exception {
		try {
			ImmutableMap<String, Flavor> invFlavorsMap = Maps.uniqueIndex(flavors.iterator(), new Function<Flavor, String> () {
			    public String apply(Flavor flavor) {
			      return flavor.getId();
			    }
			  });
			
			for (CloudRackspaceConfiguration cloudRackspaceConfiguration : configList) {
				if(!cloudRackspaceConfiguration.getStatus().equalsIgnoreCase(InventoryStatus.ARCHIVED.name())) {
					Flavor flavor = invFlavorsMap.get(cloudRackspaceConfiguration.getFlavorId());
					if(null == flavor) {
						cloudRackspaceConfiguration.setStatus(InventoryStatus.ARCHIVED.name());
						configurationRepository.save(cloudRackspaceConfiguration);
						log.debug("Flavor Id: {} removed from service provider list.", cloudRackspaceConfiguration.getFlavorId());
					}
				}
				
			}
		}catch(Exception e){
			throw new Exception(e.getMessage());
		}
		
	}

	/**
	 * First time we are populating CLOUD_RACKSPACE_CONFIGURATION table
	 * @throws Exception 
	 */
	private void populateFlavorsFromCSPForFirstTime(RackspaceCloudClient rackspaceCloudClient, NovaApi novaApi,
			ObjectMapper mapper, ImmutableList<Flavor> flavors) throws Exception {
		if(null != flavors){
			try {
				for(Flavor flavor : flavors) {
					if(!rackspaceCloudClient.getFlavorExtraSpecs(novaApi).getMetadata(flavor.getId()).get("class").toLowerCase()
							.contains(CloudRackspaceFlavorClass.performance.name().toLowerCase())){
						String json = "";
						try {
							json = mapper.writeValueAsString(flavor);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						CloudRackspaceConfiguration  cloudConfiguration = CloudRackspaceConfiguration.builder().flavorId(flavor.getId()).
								  name(flavor.getName()).
								  flavor_class(rackspaceCloudClient.getFlavorExtraSpecs(novaApi).getMetadata(flavor.getId()).get("class")).
								  cpu(Long.valueOf(flavor.getVcpus())).
								  ram(Long.valueOf(flavor.getRam())).
								  disk(Long.valueOf(flavor.getDisk())).
								  status(InventoryStatus.DISCOVERED.name()).
								  cspResource(json).
								  //cloudConfigurationType(cloudConfigurationTypeDAO.findOne(1)).
								  cloudService(serviceRepository.findOne(1L)).
								  price(0.0).
								  build();
						configurationRepository.save(cloudConfiguration);
					}
					
				}
			}catch(Exception e){
				throw new Exception(e.getMessage());
			}
			
		}
	}

	/**
	 * Checking the given flavor has the entry in CLOUD_RACKSPACE_CONFIGURATION table. 
	 * If it's not yet created then adding new entry in it for new flavor from service provider 
	 * @throws Exception 
	 */
	private void syncNepheleFlavorsByCSP(RackspaceCloudClient rackspaceCloudClient, NovaApi novaApi, ObjectMapper mapper, ImmutableList<Flavor> flavors, 
			ImmutableMap<String, CloudRackspaceConfiguration> configurationsMap) throws Exception {
		try {
			for (Flavor flavor : flavors) {
				CloudRackspaceConfiguration cloudRackspaceConfiguration = configurationsMap.get(flavor.getId());
				if(null == cloudRackspaceConfiguration) {
					if(!rackspaceCloudClient.getFlavorExtraSpecs(novaApi).getMetadata(flavor.getId()).get("class").toLowerCase()
							.contains(CloudRackspaceFlavorClass.performance.name().toLowerCase())){
						String json = "";
						try {
							json = mapper.writeValueAsString(flavor);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						CloudRackspaceConfiguration  cloudConfiguration = CloudRackspaceConfiguration.builder().flavorId(flavor.getId()).
								  name(flavor.getName()).
								  flavor_class(rackspaceCloudClient.getFlavorExtraSpecs(novaApi).getMetadata(flavor.getId()).get("class")).
								  cpu(Long.valueOf(flavor.getVcpus())).
								  ram(Long.valueOf(flavor.getRam())).
								  disk(Long.valueOf(flavor.getDisk())).
								  status(InventoryStatus.DISCOVERED.name()).
								  cspResource(json).
								  //cloudConfigurationType(cloudConfigurationTypeDAO.findOne(1)).
								  cloudService(serviceRepository.findOne(1L)).
								  price(0.0).
								  build();
						log.debug("Creating new entry for new inventory flavor: {}", cloudConfiguration.getFlavorId());
						configurationRepository.save(cloudConfiguration);
					}
					
				} else {
					if(InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudRackspaceConfiguration.getStatus())) {
						cloudRackspaceConfiguration.setStatus(InventoryStatus.DISCOVERED.name());
						configurationRepository.save(cloudRackspaceConfiguration);
					}
				}
			}
		}catch(Exception e) {
			throw new Exception(e.getMessage());
		}
		
	}

	
	@Override
	public void loadProducts(CloudService cloudService) {
    try {
      log.debug("In loadProducts - Start");
      // will read all records from cloud OS table whose status = 'PUBLISHED'
     /* CloudService cloudService = serviceRepository.findByIntegrationCode(CloudTypes.rackspace.name());*/
      List<CloudOperatingSystem> osList = operatingSystemRepository.getByService(cloudService.getId());
      List<CloudProduct> productList = productRepository.findProductsByServiceId(cloudService.getId());
      if (productList.isEmpty()) {

        //Iterate through those records and get price and insert into Cloud_product table
        log.debug("cloudOSList in inventory loading: " + osList.size());
        for (CloudOperatingSystem cloudOperatingSystem : osList) {
          if (InventoryStatus.DISCOVERED.name().equalsIgnoreCase(cloudOperatingSystem.getStatus())) {

            // need to check in plans table is there at least one plan exist in STAGED status with price
            CloudProduct cloudProduct = CloudProduct.builder().name(cloudOperatingSystem.getName()).
                description(cloudOperatingSystem.getName()).
                type(ProductType.SERVER.name()).
                status(InventoryStatus.DISCOVERED.name()).
                cloudOperatingSystem(cloudOperatingSystem).
                cloudService(cloudOperatingSystem.getCloudService()).
                hasRelatedProducts(false).
                hasFreeTrial(false).
                //cloudProductCategory(categoryRepository.findOne(1L)).
                isFeatured(false).
                build();
            productRepository.save(cloudProduct);
            //loadProductPlans(cloudProduct, true);
            //pushProductDetailsToB2BService(cloudProduct);
          }
				}
      } else if (!productList.isEmpty()) {

        ImmutableMap<String, CloudProduct> productsMapWithImgKey = Maps.uniqueIndex(productList.iterator(), new Function<CloudProduct, String>() {
          public String apply(CloudProduct cloudProduct) {
            return cloudProduct.getCloudOperatingSystem().getImageId();
          }
        });
        for (CloudOperatingSystem cloudOperatingSystem : osList) {
          CloudProduct cloudProduct = productsMapWithImgKey.get(cloudOperatingSystem.getImageId());
          if (null == cloudProduct) {

            CloudProduct newCloudProduct = CloudProduct.builder().name(cloudOperatingSystem.getName()).
                description(cloudOperatingSystem.getName()).
                type(ProductType.SERVER.name()).
                status(cloudOperatingSystem.getStatus()).
                cloudOperatingSystem(cloudOperatingSystem).
                cloudService(cloudOperatingSystem.getCloudService()).
                hasRelatedProducts(false).
                isFeatured(false).
                hasFreeTrial(false).
                //cloudProductCategory(categoryRepository.findOne(1L)).
                build();
            productRepository.save(newCloudProduct);
            //loadProductPlans(newCloudProduct, true);
            //pushProductDetailsToB2BService(cloudProduct);


          } else {
            if (InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudOperatingSystem.getStatus())) {
              cloudProduct.setStatus(cloudOperatingSystem.getStatus());
              productRepository.save(cloudProduct);
            } else if (InventoryStatus.DISCOVERED.name().equalsIgnoreCase(cloudOperatingSystem.getStatus())
                && InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudProduct.getStatus())) {
              cloudProduct.setStatus(cloudOperatingSystem.getStatus());
              productRepository.save(cloudProduct);
            }
            //loadProductPlans(cloudProduct, false);
          }
        }

			}
      log.debug("In loadProducts - END!");
    } catch (Exception e) {
      log.error("Exception occurs while loading products: ", e.getMessage());
    }
	}

	@Override
	public void loadProductPlans(CloudService cloudService) throws Exception{
		log.debug("In loadPlans - Start");
    try {
      final ObjectMapper mapper = new ObjectMapper();
      /*CloudService cloudService = serviceRepository.findByIntegrationCode(cloudType.name());*/
		if (null == cloudService)
			throw new NepheleException("Service with code rackspace was not found");
      List<RackspaceComputePriceExportData> result = csvDao.csVExportFile(cloudService.getId());

      List<CloudProductPlan> productPlanList = productPlanRepository.getProdcutPlansByserviceId(cloudService.getId());
      if (CollectionUtils.isEmpty(productPlanList)) {
        for (RackspaceComputePriceExportData flavorCombination : result) {
          List<CloudLocation> list = locationRepository.findByServiceLocationCodeAndStatus(flavorCombination.getSERVICE_ID(), "SYD", InventoryStatus.DISCOVERED.name());
          //List<CloudLocation> list = locationRepository.findByStatus(InventoryStatus.DISCOVERED.name());
          for (CloudLocation cloudLocation : list) {
            createProductPlan(mapper, flavorCombination, cloudLocation);
          }
        }
      } else {
        ImmutableMap<String, CloudProductPlan> plansMapWithOsNFlvKey = Maps.uniqueIndex(productPlanList.iterator(), new Function<CloudProductPlan, String>() {
          public String apply(CloudProductPlan cloudProductPlan) {
            ProductPlanDetailsResource productPlanResource = null;
            try {
              productPlanResource = mapper.readValue(cloudProductPlan.getDetails(), ProductPlanDetailsResource.class);
            } catch (Exception e) {
              e.printStackTrace();
            }
            return productPlanResource.getOperatingSystemId() + "#" + productPlanResource.getFlavorId();
          }
        });

        for (RackspaceComputePriceExportData flavorCombination : result) {
          CloudProductPlan cloudProductPlan = plansMapWithOsNFlvKey.get(flavorCombination.getCLOUD_OPERATING_SYSTEM_ID() + "#" + flavorCombination.getCLOUD_RACKSPACE_CONFIGURATION_ID());
          if (null == cloudProductPlan) {
            List<CloudLocation> list = locationRepository.findByServiceLocationCodeAndStatus(flavorCombination.getSERVICE_ID(), "SYD", InventoryStatus.DISCOVERED.name());
            for (CloudLocation cloudLocation : list) {
              createProductPlan(mapper, flavorCombination, cloudLocation);
            }

          } else {
            CloudProduct product = productRepository.findOne(cloudProductPlan.getCloudProduct().getId());
            if (InventoryStatus.ARCHIVED.name().equalsIgnoreCase(flavorCombination.getVENDOR_FLAVOR_STATUS())
                || InventoryStatus.ARCHIVED.name().equalsIgnoreCase(product.getStatus())) {
              cloudProductPlan.setStatus(InventoryStatus.ARCHIVED.name());
              productPlanRepository.save(cloudProductPlan);
            } else if (InventoryStatus.DISCOVERED.name().equalsIgnoreCase(flavorCombination.getVENDOR_FLAVOR_STATUS())
                && InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudProductPlan.getStatus())) {
              cloudProductPlan.setStatus(InventoryStatus.DISCOVERED.name());
              productPlanRepository.save(cloudProductPlan);
            }
            //loadProductPlans(cloudProduct, false);
          }
        }
      }
    } catch (Exception e) {
      log.error("Exception occurs while loading product plans: ", e.getMessage());
    }
    log.debug("In loadPlans - END!");

	}

	/**
	 * @param mapper
	 * @param flavorCombination
	 */
	private void createProductPlan(final ObjectMapper mapper, RackspaceComputePriceExportData flavorCombination, CloudLocation cloudLocation) 
			throws ResourceNotFoundException{
		CloudProduct product = null;
		ProductPlanDetailsResource detailsResource = ProductPlanDetailsResource.builder().operatingSystemId(flavorCombination.getCLOUD_OPERATING_SYSTEM_ID())
																						 .flavorId(flavorCombination.getCLOUD_RACKSPACE_CONFIGURATION_ID())
																						 .build();
		String json = "";
		try {
			json = mapper.writeValueAsString(detailsResource);
		} catch (IOException e) {
			e.printStackTrace();
		}
		List<CloudProduct> productList = productRepository.findByServiceAndOs(flavorCombination.getSERVICE_ID(), flavorCombination.getCLOUD_OPERATING_SYSTEM_ID());
		if(!org.springframework.util.CollectionUtils.isEmpty(productList)){
			product = productList.get(0);
		}else {
			throw new ResourceNotFoundException("CloudProduct", flavorCombination.getSERVICE_ID()+ "-" + flavorCombination.getCLOUD_OPERATING_SYSTEM_ID());
		}
		
		CloudService cloudService = serviceRepository.findOne(flavorCombination.getSERVICE_ID());
		if(null == cloudService){
			throw new ResourceNotFoundException("CloudService", flavorCombination.getSERVICE_ID());
		}
		
		String planName = cloudLocation.getName() + "-" + product.getName() + "-" + flavorCombination.getVENDOR_FLAVOR_NAME();
		CloudProductPlan productPlan = CloudProductPlan.builder().planCode(sequenceUtil.getPlanCodePatternSequenceValue(cloudService))
																 .planName(planName)
																 .price(0.0)
																 .cloudService(cloudService)
																 .details(json)
																 .status(InventoryStatus.DISCOVERED.name())
																 .cloudLocation(cloudLocation)
																 .cloudProduct(product)
																 .flavorCategory(flavorCombination.getVENDOR_FLAVOR_CLASS())
																 .sortKey(flavorCombination.getVENDOR_RAM())
																 .pricingModel(CloudPricingModel.PER_UNIT)
																 .isTrialPlan(false)
																 .build();
		productPlanRepository.save(productPlan);
	}

	@Override
	public void loadAdditionalPrice() {
	CloudAdditionalPrice additionalPrice = null;
    try {
      CloudService service = serviceRepository.findByIntegrationCode(CloudTypes.rackspace.name());
      if(null == service)
    	  throw new ResourceNotFoundException("CloudService", CloudTypes.rackspace.name());
      
       additionalPrice = additionalRepository.findByServiceId(service.getId());
      if (null == additionalPrice) {
         additionalPrice = CloudAdditionalPrice.builder().cloudService(service).name(additionalPriceMessage)
            .description(additionalPriceMessage).location(locationRepository.findByServiceLocationCodeAndStatus(service.getId(), "SYD", "DISCOVERED").get(0).getName())
            .planCode(additionalPriceCommandService.getAdditionalPriceCodePatternSequenceValue(service))
            .status(InventoryStatus.STAGED.name())
            .price(0.0)
            .serviceType(NepheleConstants.CLOUD_BANDWIDTH)
            .build();
        additionalRepository.save(additionalPrice);
      }
    } catch (Exception e) {
      log.error("Exception occurs while loading additional price: ", e.getMessage());
    }
  }

}
