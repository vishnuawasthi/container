package com.valuelabs.nephele.cloud.acronis.datamodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class AcronisUsage {
	
	private Long workstation_count;
	private Long service_users;
	private Long slices_count;
	private Long vm_count;
	private Long server_count;
	private Long size_for_vms;
	private Long size_for_servers;
	private Long storage_size;
	private Long size_for_workstations;
	

}
