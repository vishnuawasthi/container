package com.valuelabs.nephele.cloud.rackspace.metering.parser;


import java.util.Collection;
import java.util.List;

/**
 * This Interface is used to provide needed methods for 'xml Feed parsing' and loads
 * each data record into memory as an object.
 *
 * 
 */
public interface Parser {
  /**
   * Loads Data objects into memory.
   *
   */
    <T> void loadDataObjects();

  /**
   * Returns POJO as an object.
   *
   * @return data object from file as a POJO.
   */
    <T> Object getDataObject();

  /**
   * Indicates whether loading objects are in process or not.
   *
   * @return <code>true</code> if loading of objects is in process
   */
  boolean isReadingInProgress();

  /**
  * Number of objects that are still in memory.
  *
  * @return count of records.
  */
  int sizeOfRecordsInMemory();

  /**
   * Gets Failed records as a list.
   *
   * @return the records that have not been parsed by the parser.
   */
  <T>List<Object> getFailedRecords();

  /**
   * Gets list of POJOs those need to be set with the data.
   * @return list of all POJO classes.
   */
  <T>Collection<T> getAllPojoClasses();
}

