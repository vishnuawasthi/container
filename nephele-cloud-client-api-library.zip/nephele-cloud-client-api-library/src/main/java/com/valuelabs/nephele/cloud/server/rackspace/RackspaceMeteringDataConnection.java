package com.valuelabs.nephele.cloud.server.rackspace;

import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.entity.CloudServiceCredential;
import com.valuelabs.nephele.admin.data.repository.CloudServiceCredentialRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceRepository;
import com.valuelabs.nephele.admin.rest.lib.enumerated.CloudTypes;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.MySimpleClientHttpRequestFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Service
public class RackspaceMeteringDataConnection {
	
	@Autowired
	CloudServiceCredentialRepository credentialRepo;

	@Autowired
	CloudServiceRepository serviceRepo;

	@Autowired
	NepheleUtils nepheleUtils;

	/*@Value("${rackspace.username}")
	String username;// = "synnexsandbox";
	@Value("${rackspace.password}")
	String password;// = "f259179f4a264711accfa8f26a6b32d5";
*/	@Value("${rackspace.lastpageurl}")
	String lastPageUrl;

	private static final HostnameVerifier PROMISCUOUS_VERIFIER = new HostnameVerifier() {
		@Override
		public boolean verify(String s, SSLSession sslSession) {
			return true;
		}
	};

	public String getConnection(String link) throws HttpClientErrorException,ResourceAccessException {

		RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<String> dataFromRackspace = null;

		if (link != null)
			lastPageUrl = link;
		
		String username = null;
		String password = null;

		CloudService service = serviceRepo.findByIntegrationCode(CloudTypes.rackspace.toString());
		CloudServiceCredential serviceCredential = null;
		if (service != null) {
			serviceCredential = credentialRepo.getCredentilsByServiceId(service.getId());
		}
		if (serviceCredential != null) {
			username = serviceCredential.getUsername();
			password = nepheleUtils.decrypt(serviceCredential.getApikey());
		} else {
			log.debug("No credentials found in Database please check ......");
		}

		String plainCreds = username + ":" + password;

		byte[] plainCredsBytes = plainCreds.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);

		List<MediaType> acceptableMediaTypes = new ArrayList<MediaType>();
		acceptableMediaTypes.add(new MediaType("application", "atom+xml"));

		// Bypass SSL handshake exception
		final MySimpleClientHttpRequestFactory factory = new MySimpleClientHttpRequestFactory(PROMISCUOUS_VERIFIER);
		restTemplate.setRequestFactory(factory);

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setAccept(acceptableMediaTypes);

		requestHeaders.set("Authorization", "Basic " + base64Creds);
		HttpEntity<?> requestEntity = new HttpEntity<Object>(requestHeaders);
		dataFromRackspace = restTemplate.exchange(lastPageUrl, HttpMethod.GET, requestEntity, String.class);

		return dataFromRackspace.getBody().toString();
	}
	
public static String getTestCon(String link) {
		
		RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<String> dataFromRackspace = null;
       
		
		try {
			
		
			String plainCreds = "synnexsandbox:f259179f4a264711accfa8f26a6b32d5";

			byte[] plainCredsBytes = plainCreds.getBytes();
			byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
			String base64Creds = new String(base64CredsBytes);

			List<MediaType> acceptableMediaTypes = new ArrayList<MediaType>();
			acceptableMediaTypes.add(new MediaType("application", "atom+xml"));

      //Bypass SSL handshake exception
      final MySimpleClientHttpRequestFactory factory = new MySimpleClientHttpRequestFactory(PROMISCUOUS_VERIFIER);
      restTemplate.setRequestFactory(factory);

			HttpHeaders requestHeaders = new HttpHeaders();
			requestHeaders.setAccept(acceptableMediaTypes);

			requestHeaders.set("Authorization", "Basic " + base64Creds);
			HttpEntity<?> requestEntity = new HttpEntity<Object>(requestHeaders);
			
			dataFromRackspace = restTemplate.exchange(link, HttpMethod.GET, requestEntity, String.class);
	
		}catch(NullPointerException e){
			log.error("Exception in Rackspace Connection" + e.getMessage());
			e.printStackTrace();
			return null;
		}
		catch(HttpClientErrorException e){
		    log.error("******Too Many Request increse time interval between calls " + e.getMessage());
		    return null;
		} catch (Exception e) {
			log.error("Exception in Rackspace Connection" + e.getMessage());
		}
		return dataFromRackspace.getBody();
	
	}


}
