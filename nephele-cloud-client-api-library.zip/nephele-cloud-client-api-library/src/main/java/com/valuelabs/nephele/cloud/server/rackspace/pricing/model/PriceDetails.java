package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;
public class PriceDetails
{
    private PriceCharacteristic[] priceCharacteristic;

    private Prices[] prices;

    public PriceCharacteristic[] getPriceCharacteristic ()
    {
        return priceCharacteristic;
    }

    public void setPriceCharacteristic (PriceCharacteristic[] priceCharacteristic)
    {
        this.priceCharacteristic = priceCharacteristic;
    }

    public Prices[] getPrices ()
    {
        return prices;
    }

    public void setPrices (Prices[] prices)
    {
        this.prices = prices;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [priceCharacteristic = "+priceCharacteristic+", prices = "+prices+"]";
    }
}
			
			