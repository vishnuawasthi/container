package com.valuelabs.nephele.cloud.rackspace.metering.parser;

import java.util.List;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoProperty;
import org.pojomatic.annotations.DefaultPojomaticPolicy;

@AutoProperty(policy = DefaultPojomaticPolicy.EQUALS_TO_STRING)
public class XmlFeedParserWrapper {

	  String atomId;
	  
	  List<Object> parsedObjects;

	  public String getAtomId() {
	    return atomId;
	  }
	  public void setAtomId(String accountNo) {
	    this.atomId = accountNo;
	  }
	  public List<Object> getParsedObjects() {
	    return parsedObjects;
	  }
	  public void setParsedObjects(List<Object> parsedObjects) {
	    this.parsedObjects = parsedObjects;
	  }

	  @Override
	  public boolean equals(Object other) {
	    return Pojomatic.equals(this, other);
	  }

	  @Override
	  public String toString() {
	    return Pojomatic.toString(this);
	  }

	  @Override
	  public int hashCode() {
	    return Pojomatic.hashCode(this);
	  }

}
