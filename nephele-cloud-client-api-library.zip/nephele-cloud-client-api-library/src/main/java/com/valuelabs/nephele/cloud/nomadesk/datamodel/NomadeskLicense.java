package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "License")
public class NomadeskLicense {	
	
	private String id;
	private String type;
	private String creationDstamp;
	private String status;
	private boolean active;
	private String gracePeriodStartDate;
	private String gracePeriodExpiryDate;
	private String gracePeriodEndDate;
	private NomadeskAssignee assignee;
	
	@XmlElement(name = "ID")
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@XmlElement(name = "Type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@XmlElement(name = "CreationDstamp")
	public String getCreationDstamp() {
		return creationDstamp;
	}
	public void setCreationDstamp(String creationDstamp) {
		this.creationDstamp = creationDstamp;
	}
	@XmlElement(name = "Status")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@XmlElement(name = "Active")
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	@XmlElement(name = "GracePeriodStartDate")
	public String getGracePeriodStartDate() {
		return gracePeriodStartDate;
	}
	public void setGracePeriodStartDate(String gracePeriodStartDate) {
		this.gracePeriodStartDate = gracePeriodStartDate;
	}
	@XmlElement(name = "GracePeriodExpiryDate")
	public String getGracePeriodExpiryDate() {
		return gracePeriodExpiryDate;
	}
	public void setGracePeriodExpiryDate(String gracePeriodExpiryDate) {
		this.gracePeriodExpiryDate = gracePeriodExpiryDate;
	}
	@XmlElement(name = "GracePeriodEndDate")
	public String getGracePeriodEndDate() {
		return gracePeriodEndDate;
	}
	public void setGracePeriodEndDate(String gracePeriodEndDate) {
		this.gracePeriodEndDate = gracePeriodEndDate;
	}
	@XmlElement(name = "Assignee")
	public NomadeskAssignee getAssignee() {
		return assignee;
	}
	public void setAssignee(NomadeskAssignee assignee) {
		this.assignee = assignee;
	}

}
