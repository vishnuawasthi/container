package com.valuelabs.nephele.cloud.connection.factory;

import java.io.IOException;

import javax.inject.Singleton;

import lombok.extern.slf4j.Slf4j;

import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.Flavor;
import org.jclouds.openstack.nova.v2_0.domain.Image;
import org.jclouds.openstack.nova.v2_0.domain.RebootType;
import org.jclouds.openstack.nova.v2_0.domain.Server;
import org.jclouds.openstack.nova.v2_0.domain.ServerCreated;
import org.jclouds.openstack.nova.v2_0.extensions.FlavorExtraSpecsApi;
import org.jclouds.openstack.nova.v2_0.features.ServerApi;

import com.google.common.collect.FluentIterable;
import com.valuelabs.nephele.admin.data.api.RackspaceServerStatus;
import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;
import com.valuelabs.nephele.cloud.server.rackspace.RackspaceNovaApi;

@Slf4j
public class RackspaceCloudClientImpl implements RackspaceCloudClient{
	
	private static RackspaceCloudClient instance = new RackspaceCloudClientImpl();
	
	@Singleton
	public static RackspaceCloudClient getInstance() {
		return instance;
	}

	@Override
	public NovaApi getCloudNovaConnection(String provider, String username, String apiKey) {
		NovaApi novaApi = RackspaceNovaApi.getInstance().initNovaApi(provider, username, apiKey);
	    return novaApi;
	}
	
	@Override
	public ServerApi getCloudServerConnection(NovaApi novaApi, String locationId) {
		ServerApi serverApi = RackspaceNovaApi.getInstance().initServerApi(novaApi, locationId);
	    return serverApi;
	}

	@Override
	public Server getCloudActiveServerPolling(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollActiveServerDetails(serverApi, serverId);
	    return serverDetails;
	}
	
	@Override
	public Server getCloudDeleteServerPolling(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollDeleteServerDetails(serverApi, serverId);
	    return serverDetails;
	}
	
	@Override
	public ServerCreated createServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception {
		ServerCreated serverDetails = RackspaceNovaApi.getInstance().createServer(serverApi, acquireServerDetails);
		return serverDetails;
	}

	@Override
	public Boolean destroyServer(ServerApi serverApi, String serverId) throws Exception {
		Boolean isServerDeleted = RackspaceNovaApi.getInstance().destroyServer(serverApi, serverId);
		return isServerDeleted;
	}

	@Override
	public void rebootServer(ServerApi serverApi, String serverId, RebootType rebootType) throws Exception {
		RackspaceNovaApi.getInstance().rebootServer(serverApi, serverId, rebootType);
	}
	
	@Override
	public Boolean resetServerPassword(ServerApi serverApi, String serverId, String password) throws Exception {
		return RackspaceNovaApi.getInstance().resetServerPassword(serverApi, serverId, password);
	}
	
	@Override
	public FluentIterable<Image> listImages(NovaApi novaApi) throws Exception {
		return RackspaceNovaApi.getInstance().listImages(novaApi);
	}
	
	@Override
	public FluentIterable<Flavor> listFlavours(NovaApi novaApi) throws Exception {
		return RackspaceNovaApi.getInstance().listFlavours(novaApi);
	}
	
	@Override
	public FlavorExtraSpecsApi getFlavorExtraSpecs(NovaApi novaApi) throws Exception {
		return RackspaceNovaApi.getInstance().getFlavorExtraSpecs(novaApi);
	}
	
	@Override
	public void close(NovaApi novaApi) throws IOException {
		RackspaceNovaApi.getInstance().close(novaApi);
	}

	@Override
	public Server verifyServerResize(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollVerifyResizeStatusServerDetails(serverApi, serverId);
	    return serverDetails;
	}
	
	@Override
	public Server confirmResizeServer(ServerApi serverApi, String serverId, Boolean isConfirmResize) {
		Server serverDetails = RackspaceNovaApi.getInstance().pollResizeConfirmationServerDetails(serverApi, serverId, isConfirmResize);
	    return serverDetails;
	}

	@Override
	public Server syncServer(ServerApi serverApi, String serverId) {
		Server serverDetails = RackspaceNovaApi.getInstance().syncActiveServerDetails(serverApi, serverId);
		return serverDetails;
	}

}
