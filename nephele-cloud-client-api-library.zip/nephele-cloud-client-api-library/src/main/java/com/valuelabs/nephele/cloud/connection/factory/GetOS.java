package com.valuelabs.nephele.cloud.connection.factory;

import java.util.ArrayList;
import java.util.List;

import com.softlayer.api.ApiClient;
import com.softlayer.api.RestApiClient;
import com.softlayer.api.service.container.virtual.guest.configuration.Option;
import com.softlayer.api.service.product.item.Price;
import com.softlayer.api.service.virtual.Guest;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class GetOS {

public static void main(String[] args) throws InterruptedException {
		
		ApiClient client = new RestApiClient().withCredentials("SYN813085", "2fb2de36137f3e1849debb15d693c6531fa39b61d820dc575d50bf83418327d2");
		
		/*for (Hardware hardware : Account.service(client).getHardware()) {
		    log.debug("Hardware: " + hardware.getFullyQualifiedDomainName());
		}*/
		//windows
		String windowsOS = "WIN_";
		//linux
		String centOS = "CENTOS_";
		//String linuxOS = "CLOUDLINUX_";
		String coreOs = "COREOS_";
		String debainOs = "DEBIAN_";
		String redhatOs = "REDHAT_";
		String ubuntuOS = "UBUNTU_";
		//String vyattaceOS = "VYATTACE_";
		Guest.Service service = Guest.service(client);
		List<Option> osList = service.getCreateObjectOptions().getOperatingSystems();
		for (Option option : osList) {
			if(option.getTemplate().getOperatingSystemReferenceCode().startsWith(windowsOS) && 
					!option.getTemplate().getOperatingSystemReferenceCode().contains("_LATEST"))
			{
			Price price = option.getItemPrice();
			log.debug("HourlyRecurringFee::::"+price.getHourlyRecurringFee());
			log.debug("Description:::::"+price.getItem().getDescription());
			log.debug("OperatingSystemReferenceCode:::::"+option.getTemplate().getOperatingSystemReferenceCode());
			}
			}
}
}
