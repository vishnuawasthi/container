package com.valuelabs.nephele.cloud.nomadesk.datamodel;

public class ResponseResource {

}
