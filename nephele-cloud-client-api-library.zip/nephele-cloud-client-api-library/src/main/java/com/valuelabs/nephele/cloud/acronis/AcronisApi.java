package com.valuelabs.nephele.cloud.acronis;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisGroup;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisGroupDetails;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisGroupEnableDisableRequest;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisGroupRequest;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisGroupUpdateRequest;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisLoginResource;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisUserDetails;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisUserDetailsList;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisUserUpdateRequest;
import com.valuelabs.nephele.cloud.acronis.datamodel.AcronisVersion;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
@Service
public class AcronisApi { 
	
	@Autowired
	private RestTemplate acronisRestTemplate;

	@Autowired
	private String loginUrlTemplate;
	
	@Autowired
	private String logoutUrlTemplate;
	
	@Autowired
	private String listOfAdminsFromGroupUrlTemplate;
	
	@Autowired
	private String groupsUrlTemplate;	
	
	@Autowired
	private String activatemailUrlTemplate;	
	
	@Autowired
	private String adminsUrlTemplate;	
	
	@Autowired
	private String accountsUrlTemplate;	
	
	@Autowired
	private String actionsUrlTemplate;
	
	/**
     * Acronis login Requires you to specify username and password as Object AcronisLoginResource.
     * @param username
     * @param password     
    */	
    public AcronisUserDetails login(AcronisLoginResource login) {
		
		log.debug("AcronisLoginApi Calling START : ", loginUrlTemplate);		
		HttpEntity<AcronisUserDetails> response = null;
		AcronisUserDetails result = null;			
		HttpEntity<AcronisLoginResource> requestEntity = new HttpEntity<AcronisLoginResource>(login);
		response = acronisRestTemplate.exchange(loginUrlTemplate, HttpMethod.POST, requestEntity, AcronisUserDetails.class);		
		result = response.getBody();
		HttpHeaders headers = response.getHeaders();			
		log.debug( headers.get("Set-Cookie")+".............kk.....");		
		log.debug(response+"....resultString");
		log.debug("AcronisLoginApi Calling END"); 
		return result;
	}
    
    /**
	* Acronis Logout
	*
	*/
    public Object logout() {		
		
		log.debug("AcronisLogoutApi Calling START : ", logoutUrlTemplate);
		String response = null;			
		response = acronisRestTemplate.getForObject(logoutUrlTemplate, String.class);	
		log.debug("AcronisLogoutApi Calling END");
		return response;	
	}
    
    /**
     * Acronis getListOfAdminsFromGroup Requires you to specify the groupId.It
     * will return all the admins details from that specified group
     * @param groupId        
    */	    
	public AcronisUserDetailsList getListOfAdminsFromGroup(String groupId) {
		String url = String.format("%s/%s/%s",listOfAdminsFromGroupUrlTemplate, groupId, "admins");
		log.debug("AcronisGetListOfAdminsFromGroup  Calling START : ", url);
		AcronisUserDetailsList response = null;			
		response = acronisRestTemplate.getForObject(url, AcronisUserDetailsList.class);		
		log.debug("AcronisGetListOfAdminsFromGroup  Calling END ");
		return response;		
	}	
	
	/**
     * Acronis getGroups Requires you to specify the groupId.
     * It will return specified group details
     * @param groupId        
    */
	public AcronisGroupDetails getGroups(String groupId) {
		String url = String.format("%s/%s",groupsUrlTemplate, groupId);
		log.debug("AcronisGetGroupsApi Calling START : ", url);
		AcronisGroupDetails response = null;		
		response = acronisRestTemplate.getForObject(url, AcronisGroupDetails.class);	
		log.debug("AcronisGetGroupsApi Calling END");
		return response;		
	}
	
	/**
     * Acronis GroupCreation Requires 
     * @param AcronisContact
	 * @param AcronisPricing			
	 * @param kind;	
	 * @param privileges;
	 * @param language;	
	 * @param customer_id;
	 * @param name;	
	 * @param storage;	
     * @param groupId  
     * send pricing only when pricing is enabled in parentGroup      
    */
	public AcronisGroupDetails createGroup(AcronisGroupRequest group, String groupId) {
		String url = String.format("%s/%s/%s",groupsUrlTemplate, groupId, "children");
		log.debug("Acronis createGroupApi Calling START :", url);
		AcronisGroupDetails response = null;		
		try{
			ObjectMapper mapper = new ObjectMapper();
			log.debug(mapper.writeValueAsString(group));
		}catch(Exception ex){
			ex.printStackTrace();
		}		
		response = acronisRestTemplate.postForObject(url, group,  AcronisGroupDetails.class);
		log.debug("Acronis createGroupApi Calling END");
		return response;
	}
	
	/**
     * Acronis updateGroup Requires 
     * @param AcronisContact
	 * @param AcronisPricing	 
	 * @param privileges
	 * @param language
	 * @param customer_id
	 * @param name	
	 * It will return the group version	   
    */	
	public AcronisVersion updateGroup(AcronisGroupUpdateRequest group, String groupId, String version) {
		String url = String.format("%s/%s/?%s=%s",groupsUrlTemplate, groupId, "version",version);
		log.debug("Acronis updateGroupApi Calling START : ", url);
		ResponseEntity<AcronisVersion> response  = null;
		try{
			ObjectMapper mapper = new ObjectMapper();
			log.debug(mapper.writeValueAsString(group));
		}catch(Exception ex){
			ex.printStackTrace();
		}
		HttpEntity<AcronisGroupUpdateRequest> requestEntity =  new HttpEntity<AcronisGroupUpdateRequest>(group);
		response = acronisRestTemplate.exchange(url, HttpMethod.PUT, requestEntity, AcronisVersion.class);		   
		log.debug("Acronis updateGroupApi Calling END");
		return response.getBody();
		
	}
	
	/**
     * Acronis createAdminForGroup Requires 
     * @param login
	 * @param firstname	 
	 * @param lastname
	 * @param email
	 * @param language;	
	 * @param brand;
	 * @param access_type;	
	 * @param AcronisGroup;	
	 * @param AcronisLinks;	
	 * It will return the Admin version	   
    */	
	public AcronisUserDetails createAdminForGroup(String groupId, AcronisUserDetails userDetails) {
		String url = String.format("%s/%s/%s",groupsUrlTemplate, groupId, "admins");
		log.debug("Acronis createAdminForGroupApi Calling START : ", url);
		AcronisUserDetails response = null;			
		response = acronisRestTemplate.postForObject(url, userDetails, AcronisUserDetails.class);			
		log.debug("Acronis createAdminForGroupApi Calling END"); 
		return response;
	}
	
	/**
     * Acronis activateEmail Requires      
	 * @param firstname	 
	 * @param lastname
	 * @param email
	 * @param language;	
	 * @param brand;
	 * @param access_type;	
	 * @param AcronisGroup;	
	 * @param AcronisLinks;	
	 * It will send an activate email to user, then user can set the password for account.
    */
	public Object activateEmail(AcronisUserDetails emailDetails) {
		
		log.debug("Acronis activateEmailApi Calling START : ", activatemailUrlTemplate);
		AcronisUserDetails response = null;			
		response = acronisRestTemplate.postForObject(activatemailUrlTemplate, emailDetails, AcronisUserDetails.class);		
		log.debug("Acronis activateEmailApi Calling END");
		return response;
		
	}
	

	/**
     * Acronis deleteAdmin Requires you to specify the adminId and version.
     * @param adminId
     * @param version        
    */
	public void deleteAdmin(String adminId, String version) {
		String url = String.format("%s%s/?%s=%s",adminsUrlTemplate, adminId, "version", version);
		log.debug("Acronis deleteAdminApi Calling START : ", url);		
		ResponseEntity<String> response = acronisRestTemplate.exchange(url, HttpMethod.DELETE, null, String.class);		
		log.debug("Acronis deleteAdminApi Calling END");
	}
	
	/**
     * Acronis enableOrDisableGroup Requires you to specify the groupId and version and status.
     * Based on status field it will enable or disable the group
     * @param groupId
     * @param version 
     * @param status       
    */
	public AcronisVersion enableOrDisableGroup(String groupId, String version, AcronisGroupEnableDisableRequest status) {
		String url = String.format("%s/%s/?%s=%s",groupsUrlTemplate, groupId, "version", version);
		log.debug("Acronis enableOrDisableGroupApi Calling START : ", url);	
		AcronisVersion result = null;
		try{
			ObjectMapper mapper = new ObjectMapper();
			log.debug(mapper.writeValueAsString(status.getGroup()));
		}catch(Exception ex){
			ex.printStackTrace();
		}	
		HttpEntity<AcronisGroup> requestEntity =  new HttpEntity<AcronisGroup>(status.getGroup());		
		ResponseEntity<AcronisVersion> response = acronisRestTemplate.exchange(url, HttpMethod.PUT, requestEntity, AcronisVersion.class);		
		result = response.getBody();	
		log.debug("Acronis enableOrDisableGroupApi Calling END");
		return result;
	}

	/**
     * Acronis deleteGroup Requires you to specify the groupId and version.
     * @param groupId
     * @param version        
    */
	public void deleteGroup(String groupId, String version) {
		String url = String.format("%s/%s/?%s=%s",groupsUrlTemplate, groupId, "version", version);
		log.debug("Acronis deleteGroupApi Calling START : ", url);			
		ResponseEntity<String> response = acronisRestTemplate.exchange(url, HttpMethod.DELETE, null, String.class);		
		log.debug("Acronis deleteGroupApi Calling END");
	}
	/**
     * Acronis updateAdminDetails Requires 
     * @param adminId
     * @param version    
	 * @param firstname	 
	 * @param lastname
	 * @param email
	 * @param brand;
	 * @param access_type;	
	 * @param AcronisGroup;	
	 * @param AcronisLinks;	
	 * It will return the Admin version.	   
    */		
	public AcronisVersion updateAdminDetails(String adminId, AcronisUserUpdateRequest	 userDetails, String version) {
		String url = String.format("%s%s/?%s=%s",adminsUrlTemplate, adminId, "version", version);
		log.debug("Acronis updateAdminDetailsApi Calling START : ", url);	
		AcronisVersion result = null;
		try{
			ObjectMapper mapper = new ObjectMapper();
			log.debug(mapper.writeValueAsString(userDetails));
		}catch(Exception ex){
			ex.printStackTrace();
		}
		HttpEntity<AcronisUserUpdateRequest> requestEntity =  new HttpEntity<AcronisUserUpdateRequest>(userDetails);
		ResponseEntity<AcronisVersion> response = acronisRestTemplate.exchange(url, HttpMethod.PUT, requestEntity, AcronisVersion.class);
		result = response.getBody();
		log.debug("Acronis updateAdminDetailsApi Calling END");
		return result;
	}

	
	/**
     * Acronis getAccountDetails Requires 
     * @param loginName
     * It used to check whether user exist or not.    
	 * It will return the AcronisUserDetails.	   
    */	
	public AcronisUserDetails getAccountDetails(String loginName) {
		String url = String.format("%s%s",accountsUrlTemplate, loginName);
		log.debug("Acronis getAccountDetailsApi Calling START : ", url);
		AcronisUserDetails response = null;				
		response = acronisRestTemplate.getForObject(url, AcronisUserDetails.class);			
		log.debug("Acronis getAccountDetailsApi Calling END");
		return response;
	}

	/**
     * Acronis sendResetPasswordLink Requires 
     * @param loginName
     * It will send an resetPasswordlink to registered emailid.
	 *    
    */
	public void sendResetPasswordLink(AcronisUserDetails loginName) {
		log.debug("Acronis sendResetPasswordLinkApi Calling START : ", actionsUrlTemplate);			
		acronisRestTemplate.postForObject(actionsUrlTemplate, loginName, String.class);	
		log.debug("Acronis sendResetPasswordLinkApi Calling END"); 
	}
	
	

}
