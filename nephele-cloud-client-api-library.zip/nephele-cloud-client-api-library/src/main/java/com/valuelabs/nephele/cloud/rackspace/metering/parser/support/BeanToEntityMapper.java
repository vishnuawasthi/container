package com.valuelabs.nephele.cloud.rackspace.metering.parser.support;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.valuelabs.nephele.admin.data.api.MeteringDataStatus;
import com.valuelabs.nephele.admin.data.entity.CloudFeed;
import com.valuelabs.nephele.admin.data.entity.CloudFeedEntry;
import com.valuelabs.nephele.admin.data.repository.CloudFeedEntryRepository;
import com.valuelabs.nephele.admin.data.repository.CloudFeedRepository;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedEntryResources;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedEventResources;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedLinksResources;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedProductResources;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleCloudFeedResources;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleSyndCategoryResources;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleSyndContentResources;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BeanToEntityMapper {

	@Autowired
	CloudFeedRepository feedRepo;

	@Autowired
	CloudFeedEntryRepository entryRep;

	public CloudFeed parseFeed(NepheleCloudFeedResources feed) {
		CloudFeed cloudFeed = new CloudFeed();
		cloudFeed.setUuid(feed.getUuid());
		// cloudFeed.setUuid(feed.getUuid().substring(feed.getUuid().lastIndexOf(":")
		// + 1).trim());
		cloudFeed.setTitle(feed.getTitle());
		cloudFeed.setCloudFeedPublishedDate(feed.getPublishedDate());
		cloudFeed.setCloudFeedUpdatedDate(feed.getUpdatedDate());

		List<CloudFeedLinksResources> links = feed.getLinks();

		cloudFeed.setEntrysSize((long) feed.getEntries().size());

		if (!links.isEmpty()) {
			for (CloudFeedLinksResources link : links) {
				String rel = link.getRel();
				switch (rel) {
				case "self":
					cloudFeed.setSelf(link.getHref());
					break;
				case "current":
					cloudFeed.setCurrent(link.getHref());
					break;
				case "previous":
					cloudFeed.setPrevious(link.getHref());
					break;
				case "next":
					cloudFeed.setNext(link.getHref());
					break;
				case "last":
					cloudFeed.setLast(link.getHref());
					break;

				default:
					break;

				}
			}
		}

		return cloudFeed;

	}

	public List<CloudFeedEntry> parseEntry(List<Object> objects) {

		List<CloudFeedEntry> feedEntryList = new ArrayList<CloudFeedEntry>();

		// for (Object object : objects) {

		for (int i = objects.size() - 1; i >= 0; i--) {
			CloudFeedEntry feedEntry = new CloudFeedEntry();
			CloudFeedEntryResources entry = (CloudFeedEntryResources) objects.get(i);
			StringBuilder categoriesList = new StringBuilder();
			//log.debug(feedRepo.findByUri(entry.getFeedUri()).getUri()+"****************");
			feedEntry.setEntryUuid(entry.getUuid());
			// feedEntry.setEntryUuid(entry.getUuid().substring(entry.getUuid().lastIndexOf(":")
			// + 1).trim());
			feedEntry.setTitle(entry.getTitle());
			feedEntry.setEntryPublished(entry.getPublishedDate());
			feedEntry.setEntryUpdated(entry.getUpdatedDate());

			List<CloudFeedLinksResources> links = (List<CloudFeedLinksResources>) entry.getLinks();
			for (CloudFeedLinksResources link : links)
				feedEntry.setEntryLink(link.getHref().toString());

			List<NepheleSyndCategoryResources> categories = entry.getCategories();
			for (NepheleSyndCategoryResources categ : categories)
				categoriesList = categoriesList.append(new StringBuilder(categ.getName().toString()) + " ");
			// feedEntry.setAtomEntryContent(categoriesList.toString());
			// log.debug(categoriesList.toString());
			/*
			 * feedEntry.setCategoryTID(categories.get(0).getName());
			 * feedEntry.setCategoryRGN(categories.get(1).getName());
			 * feedEntry.setCategoryDC(categories.get(2).getName());
			 * feedEntry.setCategoryRID(categories.get(3).getName());
			 * feedEntry.setCategoryStack(categories.get(4).getName());
			 * feedEntry.setCategoryType(categories.get(5).getName());
			 * feedEntry.setCategoryCompute(categories.get(6).getName());
			 * feedEntry.setCategoryOriginMsgId(categories.get(7).getName());
			 */

			List<NepheleSyndContentResources> nepheleSyndContents = (List<NepheleSyndContentResources>) entry.getContents();
			for (NepheleSyndContentResources content : nepheleSyndContents) {
				CloudFeedEventResources event = content.getEvent();
				feedEntry.setEventDataCenter(event.getDataCenter());
				feedEntry.setEventEndTime(DateFormatterUtility.formatStringToDateForAtomFeed(event.getEndTime()));
				feedEntry.setEventEnvironment(event.getEnvironment());
				feedEntry.setEventId(event.getId());
				feedEntry.setEventRegion(event.getRegion());
				feedEntry.setEventResourceId(event.getResourceId());
				feedEntry.setEventResourceName(event.getResourceName());
				feedEntry.setEventStartTime(DateFormatterUtility.formatStringToDateForAtomFeed(event.getStartTime()));
				feedEntry.setEventTenantId(event.getTenantId());
				feedEntry.setEventType(event.getType());
				feedEntry.setEventVersion(event.getVersion());
				Long usageHours = DateFormatterUtility.getDateDiff(
						DateFormatterUtility.formatStringToDateForAtomFeed(event.getStartTime()),
						DateFormatterUtility.formatStringToDateForAtomFeed(event.getEndTime()), TimeUnit.HOURS);
				feedEntry.setUpTimeHours(usageHours.doubleValue());
				feedEntry.setStatus(MeteringDataStatus.PENDING);

				CloudFeedProductResources product = event.getProduct();
				feedEntry.setProductBandwidthIn(Double.valueOf(product.getBandwidthIn()));
				feedEntry.setProductBandwidthOut(Double.valueOf(product.getBandwidthOut()));
				feedEntry.setProductFlavorId(product.getFlavorId());
				feedEntry.setProductFlavorName(product.getFlavorName());
				feedEntry.setProductIsManaged(product.getIsManaged());
				feedEntry.setProductOsLicenseType(product.getOsLicenseType());
				feedEntry.setProductResourceType(product.getResourceType());
				feedEntry.setProductServiceCode(product.getServiceCode());
				feedEntry.setProductStatus(product.getStatus());
				feedEntry.setProductVersion(product.getVersion());

			}
			feedEntry.setEntryContent(feedEntry.toString() + categoriesList.toString());
			feedEntry.setFeedUuid(entry.getFeedUuid());
			try {
				CloudFeed cloudFeed = feedRepo.findByUuid(feedEntry.getFeedUuid());
				feedEntry.setCloudFeed(cloudFeed);
			} catch (Exception e) {
				log.debug("Exception in parsing Entries" + e.getMessage());
			}
			feedEntryList.add(feedEntry);

		}
		return feedEntryList;
	}

}
