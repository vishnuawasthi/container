/**
 * 
 */
package com.valuelabs.nephele.cloud.connection.factory;

/**
 * @author rrsanepalle
 *
 */
public enum CloudTypes {
	
	rackspace,
	softlayer,
	azure,
	nomadesk

}
