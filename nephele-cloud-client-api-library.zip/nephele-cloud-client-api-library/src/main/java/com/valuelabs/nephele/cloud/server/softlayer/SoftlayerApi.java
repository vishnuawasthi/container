package com.valuelabs.nephele.cloud.server.softlayer;

import java.util.List;

import javax.inject.Singleton;

import com.softlayer.api.ApiClient;
import com.softlayer.api.RestApiClient;
import com.softlayer.api.service.Account;
import com.softlayer.api.service.Brand;
import com.softlayer.api.service.billing.Invoice;
import com.softlayer.api.service.billing.invoice.Item;
import com.softlayer.api.service.user.Customer;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SoftlayerApi {
	
	
private static SoftlayerApi instance = new SoftlayerApi();
	
	
	private SoftlayerApi() {
		
	}
	
	@Singleton
	public static SoftlayerApi getInstance() {
		return instance;
	}

	/**
     * Create ApiClient. Requires you to specify the  username and the API Key.    
     * @param username
     * @param apiKey
     */
	
	public ApiClient initSoftlayerApi(String username, String apiKey) { 
		
		ApiClient client = new RestApiClient().withCredentials(username, apiKey);
	    return client;
	} 
	
	/** 
	 * Create Account. Required you to specify the apiclient and accountDetails & flag
	 * @param apiClient
	 * @param acctDetails
	 * @param flag
	 * 
	 */
	
	public Account createAccount(ApiClient apiClient, Account acctDetails, Boolean bypassDuplicateAccountCheck){
		log.debug("createAccount - Start");
		Account account = Brand.service(apiClient).createCustomerAccount(acctDetails, bypassDuplicateAccountCheck);
		log.debug("createAccount - End");
		return account;
		
	}
	
	/**
	 * getAccount. Requires you to specify the apiClient
	 * @param apiClient
	 * @return
	 */
	
   public Account getAccountDetails(ApiClient apiClient)
   {		
		Account account = Brand.service(apiClient).getAccount();
		return account;
		
	}
   
   /** 
	 * Create Account. Required you to specify the apiclient and accountDetails & flag
	 * @param apiClient
	 * @param acctDetails
	 * @param flag
	 * 
	 */
	
	public Customer createUserCustomer(ApiClient apiClient, Customer customerDetails, String password, String vpnPassword){
		log.debug("createUserCustomer - Start");
		Customer newCustomer = Customer.service(apiClient).createObject(customerDetails, password, vpnPassword);
		log.debug("createUserCustomer - End");
		return newCustomer;
		
	}
	
	/** 
	 * get Invoices. Required you to specify the apiclient.
	 * @param apiClient 
	 */
	public List<Invoice> getInvoices(ApiClient apiClient){
		log.debug("getting Invoices - Start");
		List<Invoice> invoices = Account.service(apiClient).getInvoices();
		log.debug("getting Invoices - End");
		return invoices;		
	}

	/** 
	 * get Usage data. Required you to specify the apiclient.
	 * @param apiClient 
	 */
	public List<Item> getUsageItems(ApiClient apiClient, Long invoiceId){
		log.debug("getting Invoices - Start");
		List<Item> items = Invoice.service(apiClient, invoiceId).getItems();
		log.debug("getting Invoices - End");
		return items;		
	}
}
