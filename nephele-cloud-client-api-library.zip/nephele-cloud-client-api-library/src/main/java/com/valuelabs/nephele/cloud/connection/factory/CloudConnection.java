package com.valuelabs.nephele.cloud.connection.factory;

import java.io.IOException;

import org.jclouds.compute.ComputeService;
import org.jclouds.compute.domain.NodeMetadata;
import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.Flavor;
import org.jclouds.openstack.nova.v2_0.domain.Image;
import org.jclouds.openstack.nova.v2_0.domain.ServerCreated;
import org.jclouds.openstack.nova.v2_0.extensions.FlavorExtraSpecsApi;
import org.jclouds.openstack.nova.v2_0.features.ServerApi;

import com.google.common.collect.FluentIterable;
import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;

public interface CloudConnection {
	
	public NovaApi getNovaConnection(String userName, String apiKey) ;
	public ServerApi getServerConnection(NovaApi novaApi, String locationId) ;
	public FluentIterable<Image> listImages(NovaApi novaApi);
	public FluentIterable<Flavor> listFlavors(NovaApi novaApi);
	public FlavorExtraSpecsApi getFlavorExtraSpecs(NovaApi novaApi);
	public ServerCreated createServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception;
	public void close(NovaApi novaApi) throws IOException;

}
