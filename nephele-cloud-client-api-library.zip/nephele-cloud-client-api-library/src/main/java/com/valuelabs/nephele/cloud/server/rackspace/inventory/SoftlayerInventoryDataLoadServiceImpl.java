package com.valuelabs.nephele.cloud.server.rackspace.inventory;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.softlayer.api.ApiClient;
import com.softlayer.api.service.container.virtual.guest.configuration.Option;
import com.softlayer.api.service.product.item.Price;
import com.softlayer.api.service.virtual.Guest;
import com.valuelabs.nephele.admin.data.api.*;
import com.valuelabs.nephele.admin.data.dao.CsvExportDAO;
import com.valuelabs.nephele.admin.data.entity.*;
import com.valuelabs.nephele.admin.data.repository.*;
import com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.resource.ProductPlanDetailsResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAdditionalPriceCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudInvoiceService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServiceCredentialQueryService;
import com.valuelabs.nephele.admin.rest.lib.util.InvoiceUtility;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.admin.rest.lib.util.PlanCodeSequenceUtil;
import com.valuelabs.nephele.cloud.connection.factory.CloudTypes;
import com.valuelabs.nephele.cloud.connection.factory.SoftlayerCloudClient;
import com.valuelabs.nephele.cloud.connection.factory.SoftlayerCloudClientImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.*;

@Slf4j
@Service
@Transactional
public class SoftlayerInventoryDataLoadServiceImpl implements SoftlayerInventoryDataLoadService{
	
	
	@Autowired
	CloudOperatingSystemRepository operatingSystemRepository;

	
	@Autowired
	CloudServiceRepository serviceRepository;
	
	@Autowired
	CloudLocationRepository locationRepository;
	@Autowired
	CloudServiceCredentialQueryService cloudServiceCredentialQueryService;
	@Autowired
	CloudAdditionalPriceCommandService additionalPriceCommandService;
	@Autowired
	PlanCodeSequenceUtil sequenceUtil;
	
	@Autowired
	CloudLocationGeographiesMappingRepository locGeoMappingRepository;
	@Autowired
	CloudGeographyRepository geoRepository;
	@Autowired
	CloudSoftLayerRAMConfigurationRepository slRAMConfigurationRepository;
	@Autowired
	CloudSoftLayerCPUConfigurationRepository slCPUConfigurationRepository;
	@Autowired
	CloudSoftLayerDiskConfigurationRepository slDiskConfigurationRepository;
	@Autowired
	CloudRackspaceConfigurationRepository flavourRepository;
	
	@Autowired
	CloudProductRepository productRepository;
	@Autowired
	CloudProductPlanRepository productPlanRepository;
	@Autowired
    NepheleUtils nepheleUtils;
	@Autowired
	CloudAdditionalPriceRepository additionalPriceRepository;
  @Autowired
  private CsvExportDAO csvDao;
  @Value("${additionalPrice.Message}")
	private String additionalPriceMessage;

	@Autowired
	private CloudCurrencyConversionRateRepository conversionRateRepository;

	@Autowired
	private CloudInvoiceService invoiceService;

  @Autowired
  private CloudBusinessRuleRepository businessRuleRepository;
  
	@Override
	public void loadImageData(CloudService cloudService) throws Exception {
		
			SoftlayerCloudClient softlayerCloudClient = null;
			try {
				CloudServiceCredential serviceCredential = cloudService.getCloudServiceCredential();
				softlayerCloudClient = SoftlayerCloudClientImpl.getInstance();
				ApiClient client = softlayerCloudClient.getCloudSoftLayerApiClientConnection(serviceCredential.getUsername(), nepheleUtils.decrypt(serviceCredential.getApikey()));
				Guest.Service service = Guest.service(client);
				/*CloudService cloudService = serviceRepository.findByIntegrationCode("softlayer");*/
				/*if (null == cloudService)
					throw new NepheleException("Service with code softlayer was not found");*/
				List<Option> optionList = service.getCreateObjectOptions().getOperatingSystems();
				List<CloudOperatingSystem> osList = operatingSystemRepository.getByService(cloudService.getId());
				if (!CollectionUtils.isEmpty(optionList)) {

					if (!CollectionUtils.isEmpty(osList)) {
						syncNepheleOptionsWithCSPOptions(optionList, osList, cloudService);
						syncCSPOptionsWithNepheleOptions(optionList, osList);
					} else {
						saveSoftlayerOptionsForFirstTime(optionList, cloudService);
					}

				} else {
					log.error("There is no OS config from softlayer ");
				}
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
	}


	
	
	/**
	 * Checking the our operating system table entry has the corresponding value in pulled inventory data. 
	 * If it's not present then marking OS entry as ARCHIVED. 
	 * @throws Exception 
	 */
	private void syncCSPOptionsWithNepheleOptions(List<Option> optionList, List<CloudOperatingSystem> osList) {

		try {
			Map<String, Option> optionMap = new HashMap<>();
			for (Option option : optionList) {
				optionMap.put(option.getTemplate().getOperatingSystemReferenceCode(), option);
			}
			for (CloudOperatingSystem cloudOperatingSystem : osList) {
				if(!cloudOperatingSystem.getStatus().equalsIgnoreCase(InventoryStatus.ARCHIVED.name())) {
					Option option = optionMap.get(cloudOperatingSystem.getImageId());
					if(null == option) {
						cloudOperatingSystem.setStatus(InventoryStatus.ARCHIVED.name());
						operatingSystemRepository.save(cloudOperatingSystem);
					}
				}
				
			}
		} catch (Exception e) {
			log.error("Exception while syncCSPOptionsWithNepheleOptions() "+e.getMessage());
			e.printStackTrace();
		}
		
	}

	

	/**
	 * First time we are populating CLOUD_OPERATING_SYSTEM table
	 * @param cloudService 
	 * @throws Exception 
	 */
	private void saveSoftlayerOptionsForFirstTime(List<Option> optionList, CloudService cloudService) {

		for(Option option:optionList){
			saveNewSoftlayerOS(option, cloudService);
		}
		
	}
	
	/**
	 * Checking the given Option has the entry in operating system table. 
	 * If it's not yet created then adding new entry in operating system table for new inventory option from service provider 
	 * @param cloudService 
	 * @throws Exception 
	 */
	private void syncNepheleOptionsWithCSPOptions(List<Option> optionList, List<CloudOperatingSystem> osList, CloudService cloudService) {

		try {
			Map<String, CloudOperatingSystem> osMap = new HashMap<>();
			for (CloudOperatingSystem os : osList) {
				osMap.put(os.getImageId(), os);
			}
			for (Option option : optionList) {
				CloudOperatingSystem os = osMap.get(option.getTemplate().getOperatingSystemReferenceCode());
				if(null == os)
					saveNewSoftlayerOS(option,cloudService);
				else if(os.getPrice().doubleValue() != option.getItemPrice().getHourlyRecurringFee().doubleValue()){
					os.setPrice(option.getItemPrice().getHourlyRecurringFee().doubleValue());
					operatingSystemRepository.save(os);
				}
				}
		} catch (Exception e) {
			log.error("Exception while syncNepheleOptionsWithCSPOptions() "+e.getMessage());
			e.printStackTrace();
		}
	}
	


	private void saveNewSoftlayerOS(Option option, CloudService cloudService) {
		try {
			Map<String, String> osTypesMap = getSoftlayerOSMap();
			ObjectMapper mapper = new ObjectMapper();
			String[] osRefCodes = option.getTemplate().getOperatingSystemReferenceCode().split("_");
			String osType = osTypesMap.get(osRefCodes[0]);
			if(!StringUtils.isEmpty(osType) && 
					!option.getTemplate().getOperatingSystemReferenceCode().contains("_LATEST")){
			
			Price price = option.getItemPrice();
			String json = null;
			try {
				json = mapper.writeValueAsString(option);
			} catch (IOException e) {
				e.printStackTrace();
			}
			CloudOperatingSystem operatingSystem = CloudOperatingSystem.builder()
																		.imageId(option.getTemplate().getOperatingSystemReferenceCode())
																		.minDisk(OperatingSystemType.windows.name().equalsIgnoreCase(osType) ? 100l : 0l)
																		.minRam(0l)
																		.name(price.getItem().getDescription())
																		.status(InventoryStatus.DISCOVERED.name())
																		.cloudService(cloudService)
																		.osType(osType)
																		.cspResource(json)
																		.price(price.getHourlyRecurringFee().doubleValue())
																		.build();
			operatingSystemRepository.save(operatingSystem);
			}
		} catch (Exception e) {
			log.error("Exception while saveNewSoftlayerOS() "+e.getMessage());
			e.printStackTrace();
		}
		
	}

	public Map<String, String> getSoftlayerOSMap(){
		
		Map<String, String> osMap = new HashMap<>();
		
		osMap.put("WIN", "windows");
		osMap.put("CENTOS", "linux");
		osMap.put("COREOS", "linux");
		osMap.put("DEBIAN", "linux");
		osMap.put("REDHAT", "linux");
		osMap.put("UBUNTU", "linux");
		
		return osMap;
	}




	@Override
	public void loadRamConfiguration(CloudService cloudService) throws Exception {
		SoftlayerCloudClient softlayerCloudClient = null;
		try {
			CloudServiceCredential serviceCredential = cloudService.getCloudServiceCredential();
			softlayerCloudClient = SoftlayerCloudClientImpl.getInstance();
			ApiClient client = softlayerCloudClient.getCloudSoftLayerApiClientConnection(serviceCredential.getUsername(), nepheleUtils.decrypt(serviceCredential.getApikey()));
			Guest.Service service = Guest.service(client);
			List<Option> optionList = service.getCreateObjectOptions().getMemory();
			List<CloudSoftlayerRAMConfiguration> ramList = slRAMConfigurationRepository.findAll();
			if (!CollectionUtils.isEmpty(optionList)) {

				if (!CollectionUtils.isEmpty(ramList)) {
					syncNepheleRAMOptionsWithCSPRAMOptions(optionList, ramList);
					syncCSPRAMOptionsWithNepheleRAMOptions(optionList, ramList);
				} else {
					saveSoftlayerRAMOptionsForFirstTime(optionList);
				}

			} else {
				log.error("There is no OS config from softlayer ");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		
	}




	private void saveSoftlayerRAMOptionsForFirstTime(List<Option> optionList) {
		
		for(Option option:optionList){
			saveNewSoftLayerRAMOption(option);
		}
		
	}




	private void syncCSPRAMOptionsWithNepheleRAMOptions(List<Option> optionList, List<CloudSoftlayerRAMConfiguration> ramList) {
		try {
			Map<Long, Option> optionMap = new HashMap<>();
			for (Option option : optionList) {
				optionMap.put(option.getTemplate().getMaxMemory(), option);
			}
			for (CloudSoftlayerRAMConfiguration ramConfig : ramList) {
				if(!ramConfig.getStatus().equalsIgnoreCase(InventoryStatus.ARCHIVED.name())) {
					Option option = optionMap.get(ramConfig.getMaxMemory());
					if(null == option) {
						ramConfig.setStatus(InventoryStatus.ARCHIVED.name());
						slRAMConfigurationRepository.save(ramConfig);
					}
				}
				
			}
		} catch (Exception e) {
			log.error("Exception while syncCSPRAMOptionsWithNepheleRAMOptions() "+e.getMessage());
			e.printStackTrace();
		}
		
	}




	private void syncNepheleRAMOptionsWithCSPRAMOptions(List<Option> optionList, List<CloudSoftlayerRAMConfiguration> ramList) {
		try {
			Map<Long, CloudSoftlayerRAMConfiguration> ramMap = new HashMap<>();
			for (CloudSoftlayerRAMConfiguration ram : ramList) {
				ramMap.put(ram.getMaxMemory(), ram);
			}
			for (Option option : optionList) {
				CloudSoftlayerRAMConfiguration ram = ramMap.get(option.getTemplate().getMaxMemory());
				if(null == ram)
					saveNewSoftLayerRAMOption(option);
				}
		} catch (Exception e) {
			log.error("Exception while syncNepheleRAMOptionsWithCSPRAMOptions() "+e.getMessage());
			e.printStackTrace();
		}
		
	}

	private void saveNewSoftLayerRAMOption(Option option){
		try {
			if(null != option){
			Price price = option.getItemPrice();
			CloudSoftlayerRAMConfiguration ramConfig = CloudSoftlayerRAMConfiguration.builder()
																					 .description(price.getItem().getDescription())
																					 .hourlyRecurringFee(price.getHourlyRecurringFee().doubleValue())
																					 .maxMemory(option.getTemplate().getMaxMemory())
																					 .status(InventoryStatus.DISCOVERED.name())
																					 .build();
			slRAMConfigurationRepository.save(ramConfig);
			
			}
			else{
				log.error("Unable to fetch ram option");
			}
		} catch (Exception e) {
			log.error("Exception occured in saveNewSoftLayerRAMOption()"+e.getMessage());
			e.printStackTrace();
		}
	}




	@Override
	public void loadCpuConfiguration(CloudService cloudService) throws Exception {

		SoftlayerCloudClient softlayerCloudClient = null;
		try {
			CloudServiceCredential serviceCredential = cloudService.getCloudServiceCredential();
			softlayerCloudClient = SoftlayerCloudClientImpl.getInstance();
			ApiClient client = softlayerCloudClient.getCloudSoftLayerApiClientConnection(serviceCredential.getUsername(), nepheleUtils.decrypt(serviceCredential.getApikey()));
			Guest.Service service = Guest.service(client);
			List<Option> optionList = service.getCreateObjectOptions().getProcessors();
			List<CloudSoftlayerCPUConfiguration> cpuList = slCPUConfigurationRepository.findAll();
			if (!CollectionUtils.isEmpty(optionList)) {

				if (!CollectionUtils.isEmpty(cpuList)) {
					syncNepheleCPUOptionsWithCSPCPUOptions(optionList, cpuList);
					syncCSPCPUOptionsWithNepheleCPUOptions(optionList, cpuList);
				} else {
					saveSoftlayerCPUOptionsForFirstTime(optionList);
				}

			} else {
				log.error("There is no OS config from softlayer ");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		
	}




	private void syncNepheleCPUOptionsWithCSPCPUOptions(List<Option> optionList,
			List<CloudSoftlayerCPUConfiguration> cpuList) {
		try {
			Map<String, CloudSoftlayerCPUConfiguration> cpuMap = new HashMap<>();
			for (CloudSoftlayerCPUConfiguration cpu : cpuList) {
				cpuMap.put(cpu.getDescription(), cpu);
			}
			for (Option option : optionList) {
				CloudSoftlayerCPUConfiguration cpu = cpuMap.get(option.getItemPrice().getItem().getDescription());
				if(null == cpu)
					saveNewSoftLayerCPUOption(option);
				}
		} catch (Exception e) {
			log.error("Exception while syncNepheleCPUOptionsWithCSPCPUOptions() "+e.getMessage());
			e.printStackTrace();
		}
		
	}




	private void syncCSPCPUOptionsWithNepheleCPUOptions(List<Option> optionList,
			List<CloudSoftlayerCPUConfiguration> cpuList) {
		try {
			Map<String, Option> optionMap = new HashMap<>();
			for (Option option : optionList) {
				optionMap.put(option.getItemPrice().getItem().getDescription(), option);
			}
			for (CloudSoftlayerCPUConfiguration cpuConfig : cpuList) {
				if(!cpuConfig.getStatus().equalsIgnoreCase(InventoryStatus.ARCHIVED.name())) {
					Option option = optionMap.get(cpuConfig.getDescription());
					if(null == option) {
						cpuConfig.setStatus(InventoryStatus.ARCHIVED.name());
						slCPUConfigurationRepository.save(cpuConfig);
					}
				}
				
			}
		} catch (Exception e) {
			log.error("Exception while syncCSPRAMOptionsWithNepheleRAMOptions() "+e.getMessage());
			e.printStackTrace();
		}
		
		
	}




	private void saveSoftlayerCPUOptionsForFirstTime(List<Option> optionList) {
		for(Option option:optionList){
			saveNewSoftLayerCPUOption(option);
		}
		
	}
	
	private void saveNewSoftLayerCPUOption(Option option){
		try {
			if(null != option){
			Price price = option.getItemPrice();
			CloudSoftlayerCPUConfiguration cpuConfig = CloudSoftlayerCPUConfiguration.builder()
																					 .description(price.getItem().getDescription())
																					 .hourlyRecurringFee(price.getHourlyRecurringFee().doubleValue())
																					 .startCPUs(option.getTemplate().getStartCpus())
																					 .status(InventoryStatus.DISCOVERED.name())
																					 .build();
			if(null != option.getTemplate().getDedicatedAccountHostOnlyFlag())
				cpuConfig.setDedicatedAccountOnlyFlag(option.getTemplate().getDedicatedAccountHostOnlyFlag());
			else{
				cpuConfig.setDedicatedAccountOnlyFlag(false);
			}
			slCPUConfigurationRepository.save(cpuConfig);
			
			}
			else{
				log.error("Unable to fetch cpu option");
			}
		} catch (Exception e) {
			log.error("Exception occured in saveNewSoftLayerCPUOption()"+e.getMessage());
			e.printStackTrace();
		}
	}




	@Override
	public void loadDiskConfiguration(CloudService cloudService) throws Exception {
		
		SoftlayerCloudClient softlayerCloudClient = null;
		try {
			CloudServiceCredential serviceCredential = cloudService.getCloudServiceCredential();
			softlayerCloudClient = SoftlayerCloudClientImpl.getInstance();
			ApiClient client = softlayerCloudClient.getCloudSoftLayerApiClientConnection(serviceCredential.getUsername(), nepheleUtils.decrypt(serviceCredential.getApikey()));
			Guest.Service service = Guest.service(client);
			List<Option> optionList = service.getCreateObjectOptions().getBlockDevices();
			List<CloudSoftlayerDiskConfiguration> diskList = slDiskConfigurationRepository.findAll();
			if (!CollectionUtils.isEmpty(optionList)) {

				if (!CollectionUtils.isEmpty(diskList)) {
					syncNepheleDiskOptionsWithCSPDiskOptions(optionList, diskList);
					syncCSPDiskOptionsWithNepheleDiskOptions(optionList, diskList);
				} else {
					saveSoftlayerDiskOptionsForFirstTime(optionList);
				}

			} else {
				log.error("There is no Disk config from softlayer ");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}




	private void syncNepheleDiskOptionsWithCSPDiskOptions(List<Option> optionList,
			List<CloudSoftlayerDiskConfiguration> diskList) {
		try {
			Map<Long, CloudSoftlayerDiskConfiguration> diskMap = new HashMap<>();
			for (CloudSoftlayerDiskConfiguration disk : diskList) {
				diskMap.put(disk.getCapacity(), disk);
			}
			for (Option option : optionList) {
				CloudSoftlayerDiskConfiguration disk = diskMap.get(option.getTemplate().getBlockDevices().get(0).getDiskImage().getCapacity());
				if(null == disk)
					saveNewSoftLayerDiskOption(option);
				}
		} catch (Exception e) {
			log.error("Exception while syncNepheleDiskOptionsWithCSPDiskOptions() "+e.getMessage());
			e.printStackTrace();
		}
		
	}




	private void syncCSPDiskOptionsWithNepheleDiskOptions(List<Option> optionList,
			List<CloudSoftlayerDiskConfiguration> diskList) {
		try {
			Map<Long, Option> optionMap = new HashMap<>();
			for (Option option : optionList) {
				optionMap.put(option.getTemplate().getBlockDevices().get(0).getDiskImage().getCapacity(), option);
			}
			for (CloudSoftlayerDiskConfiguration diskConfig : diskList) {
				if(!diskConfig.getStatus().equalsIgnoreCase(InventoryStatus.ARCHIVED.name())) {
					Option option = optionMap.get(diskConfig.getCapacity());
					if(null == option) {
						diskConfig.setStatus(InventoryStatus.ARCHIVED.name());
						slDiskConfigurationRepository.save(diskConfig);
					}
				}
				
			}
		} catch (Exception e) {
			log.error("Exception while syncCSPDiskOptionsWithNepheleDiskOptions() "+e.getMessage());
			e.printStackTrace();
		}
		
	}




	private void saveSoftlayerDiskOptionsForFirstTime(List<Option> optionList) {
		for(Option option:optionList){
			if(null != option)
			  saveNewSoftLayerDiskOption(option);
			else{
				log.error("Unable to fetch disk option");
			}
		}
		
		
	}
	
	private void saveNewSoftLayerDiskOption(Option option){
		try {
			if((option.getTemplate().getBlockDevices().size() >0) && option.getTemplate().getBlockDevices().get(0).getDevice().equals("0")){
			Price price = option.getItemPrice();
			CloudSoftlayerDiskConfiguration diskConfig = CloudSoftlayerDiskConfiguration.builder()
																					 .description(price.getItem().getDescription())
																					 .hourlyRecurringFee(price.getHourlyRecurringFee().doubleValue())
																					 .capacity(option.getTemplate().getBlockDevices().get(0).getDiskImage().getCapacity())
																					 .localDiskFlag(option.getTemplate().getLocalDiskFlag())
																					 .status(InventoryStatus.DISCOVERED.name())
																					 .device(option.getTemplate().getBlockDevices().get(0).getDevice())
																					 .build();
			slDiskConfigurationRepository.save(diskConfig);
			
			}
			
		} catch (Exception e) {
			log.error("Exception occured in saveNewSoftLayerDiskOption()"+e.getMessage());
			e.printStackTrace();
		}
	}




	@Override
	public void loadLocations(CloudService cloudService) throws Exception {
		// TODO Auto-generated method stub
	}




	@Override
	public void loadFlavorData(CloudService cloudService) throws Exception {
		log.debug("loadFlavorData() -- start");
		List<CloudSoftlayerRAMConfiguration> ramList = slRAMConfigurationRepository.findAll();
		List<CloudSoftlayerCPUConfiguration> cpuList = slCPUConfigurationRepository.findAll();
		List<CloudSoftlayerDiskConfiguration> diskList = slDiskConfigurationRepository.findAll();
		/*CloudService cloudService = serviceRepository.findByIntegrationCode("softlayer");*/
		if (null == cloudService)
			throw new NepheleException("Service with code softlayer was not found");
		try {
			List<CloudRackspaceConfiguration> flavorList = flavourRepository.readByService(cloudService.getId());
			
			if(!flavorList.isEmpty()){
				syncCSPFlavorswithNepheleFlavors(ramList,cpuList,diskList,flavorList,cloudService);
				syncNepheleFlavorswithCSPFlavors(ramList,cpuList,diskList,flavorList,cloudService);
			}
			else{
				saveFlavorForTheFirstTime(ramList,cpuList,diskList,cloudService);
			}
		} catch (Exception e) {
			log.error("Exception occured while preparing flavour list");
			e.printStackTrace();
		}
		
		log.debug("loadFlavorData() -- end");
	}
	
	
	private void saveFlavorForTheFirstTime(List<CloudSoftlayerRAMConfiguration> ramList,
			List<CloudSoftlayerCPUConfiguration> cpuList, List<CloudSoftlayerDiskConfiguration> diskList,
			CloudService cloudService){
		ObjectMapper mapper = new ObjectMapper();
		List<CloudRackspaceConfiguration> flavourList = new ArrayList<>();
		try {
			if((ramList.size() > 0)&&(cpuList.size() > 0)&&(diskList.size() > 0)){
				for(CloudSoftlayerRAMConfiguration ram:ramList){
					
					for(CloudSoftlayerCPUConfiguration cpu:cpuList){
						if(!cpu.getDedicatedAccountOnlyFlag() && ((cpu.getStartCPUs() == 1l) || (cpu.getStartCPUs() == 2l))){
							log.debug("drop 1 core & 2 cores from Public Node plans");
							continue;
						}
						else{
							for(CloudSoftlayerDiskConfiguration disk:diskList){
								SoftlayerFlavourResource flavorResource = SoftlayerFlavourResource.builder()
																								  .ram(ram)
																								  .cpu(cpu)
																								  .disk(disk)
																								  .build();
								String json = mapper.writeValueAsString(flavorResource);
								// Flavor class building
								String flavorClass = "";
								if(cpu.getDedicatedAccountOnlyFlag() && disk.getLocalDiskFlag()){
									flavorClass = SoftlayerFlavorClass.PrivateLocal.getValue();
								}else if(cpu.getDedicatedAccountOnlyFlag() && !disk.getLocalDiskFlag()){
									flavorClass = SoftlayerFlavorClass.PrivateSAN.getValue();
								}else if(!cpu.getDedicatedAccountOnlyFlag() && disk.getLocalDiskFlag()){
									flavorClass = SoftlayerFlavorClass.PublicLocal.getValue();
								}else{
									flavorClass = SoftlayerFlavorClass.PublicSAN.getValue();
								}
								
								//StartCPUs#DedicatedAccountOnlyFlag#MaxMemory#Capacity#LocalDiskFlag
								String flavorId = cpu.getStartCPUs() + "#" + cpu.getDedicatedAccountOnlyFlag() + "#"+ ram.getMaxMemory() + "#" + disk.getCapacity() + "#" + disk.getLocalDiskFlag();
                StringBuilder flavorNameBuilder = new StringBuilder();
                flavorNameBuilder.append(flavorResource.getCpu().getDescription()).append("-");
                flavorNameBuilder.append(flavorResource.getRam().getDescription()).append("-");
                flavorNameBuilder.append(flavorResource.getDisk().getDescription());
                flavorNameBuilder.trimToSize();

								CloudRackspaceConfiguration flavour = CloudRackspaceConfiguration.builder()
																								 .cloudService(cloudService)
																								 .cpu(cpu.getStartCPUs())
																								 .cspResource(json)
																								 .disk(disk.getCapacity())
																								 .flavor_class(flavorClass)
																								 .flavorId(flavorId)
                    .name(flavorNameBuilder.toString())
                    .ram(ram.getMaxMemory())
																								 .status(InventoryStatus.DISCOVERED.name())
																								 .price( ram.getHourlyRecurringFee()+cpu.getHourlyRecurringFee()+disk.getHourlyRecurringFee())
																								 .build();
								flavourList.add(flavour);
							}
						}
					}
				}
				
				flavourRepository.save(flavourList);
			}else{
				log.error("Please check Ram,CPU,Disk config data");
			}
		} catch (Exception e) {
			log.error("Exception occured in saveFlavorForTheFirstTime()");
			e.printStackTrace();
		}
		
	}




	private void syncCSPFlavorswithNepheleFlavors(List<CloudSoftlayerRAMConfiguration> ramList,
			List<CloudSoftlayerCPUConfiguration> cpuList, List<CloudSoftlayerDiskConfiguration> diskList,
			List<CloudRackspaceConfiguration> flavorList, CloudService cloudService) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, CloudRackspaceConfiguration> flavorMapWithFlavorId = new HashMap<>();
		for (CloudRackspaceConfiguration flavor : flavorList) {

			flavorMapWithFlavorId.put(flavor.getFlavorId(), flavor);
		}
		try {
			if ((ramList.size() > 0) && (cpuList.size() > 0) && (diskList.size() > 0)) {
				for (CloudSoftlayerRAMConfiguration ram : ramList) {

					for (CloudSoftlayerCPUConfiguration cpu : cpuList) {
						
						if(!cpu.getDedicatedAccountOnlyFlag() && ((cpu.getStartCPUs() == 1l) || (cpu.getStartCPUs() == 2l))){
							continue;
						}
						else{
							for (CloudSoftlayerDiskConfiguration disk : diskList) {
								SoftlayerFlavourResource flavorResource = SoftlayerFlavourResource.builder().ram(ram).cpu(cpu)
										.disk(disk).build();
								String json = mapper.writeValueAsString(flavorResource);
								// Flavor class building
								String flavorClass = "";
								if(cpu.getDedicatedAccountOnlyFlag() && disk.getLocalDiskFlag()){
									flavorClass = SoftlayerFlavorClass.PrivateLocal.getValue();
								}else if(cpu.getDedicatedAccountOnlyFlag() && !disk.getLocalDiskFlag()){
									flavorClass = SoftlayerFlavorClass.PrivateSAN.getValue();
								}else if(!cpu.getDedicatedAccountOnlyFlag() && disk.getLocalDiskFlag()){
									flavorClass = SoftlayerFlavorClass.PublicLocal.getValue();
								}else{
									flavorClass = SoftlayerFlavorClass.PublicSAN.getValue();
								}
                StringBuilder flavorNameBuilder = new StringBuilder();
                flavorNameBuilder.append(flavorResource.getCpu().getDescription()).append("-");
                flavorNameBuilder.append(flavorResource.getRam().getDescription()).append("-");
                flavorNameBuilder.append(flavorResource.getDisk().getDescription());
                flavorNameBuilder.trimToSize();
                //StartCPUs#DedicatedAccountOnlyFlag#MaxMemory#Capacity#LocalDiskFlag
								String flavorId = cpu.getStartCPUs() + "#" + cpu.getDedicatedAccountOnlyFlag() + "#"+ ram.getMaxMemory() + "#" + disk.getCapacity() + "#" + disk.getLocalDiskFlag();
								if (null == flavorMapWithFlavorId.get(flavorId)) {
									CloudRackspaceConfiguration flavour = CloudRackspaceConfiguration.builder()
																									 .cloudService(cloudService)
																									 .cpu(cpu.getStartCPUs())
																									 .cspResource(json)
																									 .disk(disk.getCapacity())
																									 .flavor_class(flavorClass)
																									 .flavorId(cpu.getStartCPUs()+"#"+cpu.getDedicatedAccountOnlyFlag()+"#"+ram.getMaxMemory()+"#"+disk.getCapacity()+"#"+disk.getLocalDiskFlag())
                      .name(flavorNameBuilder.toString())
                      .ram(ram.getMaxMemory())
																									 .status(InventoryStatus.DISCOVERED.name())
																									 .price( ram.getHourlyRecurringFee()+cpu.getHourlyRecurringFee()+disk.getHourlyRecurringFee())
																									 .build();
									flavorList.add(flavour);
								}
							}
						}
					
					}
				}
				flavourRepository.save(flavorList);
			} else {
				log.error("Please check Ram,CPU,Disk config data");
			}
		} catch (Exception e) {
			log.error("Exception occured in syncCSPFlavorswithNepheleFlavors()");
			e.printStackTrace();
		} 

	}
	
	private void syncNepheleFlavorswithCSPFlavors(List<CloudSoftlayerRAMConfiguration> ramList,
			List<CloudSoftlayerCPUConfiguration> cpuList, List<CloudSoftlayerDiskConfiguration> diskList,
			 List<CloudRackspaceConfiguration> flavorList, CloudService cloudService) {

		try {
			Set<String> flavorSet = new HashSet<>();
			if((ramList.size() > 0)&&(cpuList.size() > 0)&&(diskList.size() > 0)){
				for(CloudSoftlayerRAMConfiguration ram:ramList){
					for(CloudSoftlayerCPUConfiguration cpu:cpuList){
						for(CloudSoftlayerDiskConfiguration disk:diskList){
							String flavorId = cpu.getStartCPUs()+"#"+cpu.getDedicatedAccountOnlyFlag()+"#"+ram.getMaxMemory()+"#"+disk.getCapacity()+"#"+disk.getLocalDiskFlag();
							flavorSet.add(flavorId);
						}
					}
				}
				for(CloudRackspaceConfiguration flavor:flavorList){
					if(!flavor.getStatus().equalsIgnoreCase(InventoryStatus.ARCHIVED.name())) {
						if(!flavorSet.contains(flavor.getFlavorId())){
						flavor.setStatus(InventoryStatus.ARCHIVED.name());
					}
				}
				}
				flavourRepository.save(flavorList);
			}else{
				log.error("Please check Ram,CPU,Disk config data");
			}
		} catch (Exception e) {
			log.error("Exception occured in syncNepheleFlavorswithCSPFlavors()");
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void loadProducts(CloudService cloudService) {
    try {
      log.debug("In loadProducts - Start");
      // will read all records from cloud OS table whose status = 'PUBLISHED'
      /*CloudService cloudService = serviceRepository.findByIntegrationCode(CloudTypes.softlayer.name());*/
      List<CloudOperatingSystem> osList = operatingSystemRepository.getByService(cloudService.getId());
      List<CloudProduct> productList = productRepository.findProductsByServiceId(cloudService.getId());
      if (productList.isEmpty()) {

        //Iterate through those records and get price and insert into Cloud_product table
        log.debug("cloudOSList in inventory loading: " + osList.size());
        for (CloudOperatingSystem cloudOperatingSystem : osList) {
          if (InventoryStatus.DISCOVERED.name().equalsIgnoreCase(cloudOperatingSystem.getStatus())) {

            // need to check in plans table is there at least one plan exist in STAGED status with price
            CloudProduct cloudProduct = CloudProduct.builder().name(cloudOperatingSystem.getName()).
                description(cloudOperatingSystem.getName()).
                type(ProductType.SERVER.name()).
                status(InventoryStatus.DISCOVERED.name()).
                cloudOperatingSystem(cloudOperatingSystem).
                cloudService(cloudOperatingSystem.getCloudService()).
                //cloudProductCategory(cloudOperatingSystem.getCloudService()).
                hasRelatedProducts(false).
                hasFreeTrial(false).
                isFeatured(false).
                build();
            productRepository.save(cloudProduct);
            //loadProductPlans(cloudProduct, true);
            //pushProductDetailsToB2BService(cloudProduct);
          }
				}
      } else if (!productList.isEmpty()) {

        ImmutableMap<String, CloudProduct> productsMapWithImgKey = Maps.uniqueIndex(productList.iterator(), new Function<CloudProduct, String>() {
          public String apply(CloudProduct cloudProduct) {
            return cloudProduct.getCloudOperatingSystem().getImageId();
          }
        });
        for (CloudOperatingSystem cloudOperatingSystem : osList) {
          CloudProduct cloudProduct = productsMapWithImgKey.get(cloudOperatingSystem.getImageId());
          if (null == cloudProduct) {

            CloudProduct newCloudProduct = CloudProduct.builder().name(cloudOperatingSystem.getName()).
                description(cloudOperatingSystem.getName()).
                type(ProductType.SERVER.name()).
                status(cloudOperatingSystem.getStatus()).
                cloudOperatingSystem(cloudOperatingSystem).
                cloudService(cloudOperatingSystem.getCloudService()).
                //cloudProductCategory(categoryRepository.findOne(1L)).
                hasRelatedProducts(false).
                isFeatured(false).
                hasFreeTrial(false).
                build();
            productRepository.save(newCloudProduct);
            //loadProductPlans(newCloudProduct, true);
            //pushProductDetailsToB2BService(cloudProduct);


          } else {
            if (InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudOperatingSystem.getStatus())) {
              cloudProduct.setStatus(cloudOperatingSystem.getStatus());
              productRepository.save(cloudProduct);
            } else if (InventoryStatus.DISCOVERED.name().equalsIgnoreCase(cloudOperatingSystem.getStatus())
                && InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudProduct.getStatus())) {
              cloudProduct.setStatus(cloudOperatingSystem.getStatus());
              productRepository.save(cloudProduct);
            }
            //loadProductPlans(cloudProduct, false);
          }
        }

			}
      log.debug("In loadProducts - END!");
    } catch (Exception e) {
      log.error("Exception occurs while loading products: ", e.getMessage());
    }
	}
	
	@Override
	public void loadProductPlans(CloudService cloudService) throws Exception{
		log.debug("In loadPlans - Start");
    try {
      final ObjectMapper mapper = new ObjectMapper();
      /*CloudService cloudService = serviceRepository.findByIntegrationCode(cloudType.name());*/
		if (null == cloudService)
			throw new NepheleException("Service with code softlayer was not found");
      List<RackspaceComputePriceExportData> result = csvDao.csVExportFile(cloudService.getId());
      List<CloudProductPlan> planList = new ArrayList<CloudProductPlan>();
      List<CloudProductPlan> productPlanList = productPlanRepository.getProdcutPlansByserviceId(cloudService.getId());
      if (CollectionUtils.isEmpty(productPlanList)) {
        for (RackspaceComputePriceExportData flavorCombination : result) {
          List<CloudLocation> list = locationRepository.findByServiceLocationCodeAndStatus(flavorCombination.getSERVICE_ID(), "syd01", InventoryStatus.DISCOVERED.name());
          //List<CloudLocation> list = locationRepository.findByStatus(InventoryStatus.DISCOVERED.name());
          for (CloudLocation cloudLocation : list) {
            planList.add(createProductPlan(mapper, flavorCombination, cloudLocation));
          }
        }
        if (!planList.isEmpty())
          bulkSave(planList);
      } else {
        ImmutableMap<String, CloudProductPlan> plansMapWithOsNFlvKey = Maps.uniqueIndex(productPlanList.iterator(), new Function<CloudProductPlan, String>() {
          public String apply(CloudProductPlan cloudProductPlan) {
            ProductPlanDetailsResource productPlanResource = null;
            try {
              productPlanResource = mapper.readValue(cloudProductPlan.getDetails(), ProductPlanDetailsResource.class);
            } catch (Exception e) {
              e.printStackTrace();
            }
            return productPlanResource.getOperatingSystemId() + "#" + productPlanResource.getFlavorId();
          }
        });

        for (RackspaceComputePriceExportData flavorCombination : result) {
          CloudProductPlan cloudProductPlan = plansMapWithOsNFlvKey.get(flavorCombination.getCLOUD_OPERATING_SYSTEM_ID() + "#" + flavorCombination.getCLOUD_RACKSPACE_CONFIGURATION_ID());
          if (null == cloudProductPlan) {
            List<CloudLocation> list = locationRepository.findByServiceLocationCodeAndStatus(flavorCombination.getSERVICE_ID(), "syd01", InventoryStatus.DISCOVERED.name());
            for (CloudLocation cloudLocation : list) {
              planList.add(createProductPlan(mapper, flavorCombination, cloudLocation));
            }
            // call bulk save TODO

          } else {
            CloudProduct product = productRepository.findOne(cloudProductPlan.getCloudProduct().getId());
            if (InventoryStatus.ARCHIVED.name().equalsIgnoreCase(flavorCombination.getVENDOR_FLAVOR_STATUS())
                || InventoryStatus.ARCHIVED.name().equalsIgnoreCase(product.getStatus())) {
              cloudProductPlan.setStatus(InventoryStatus.ARCHIVED.name());
              productPlanRepository.save(cloudProductPlan);
            } else if (InventoryStatus.DISCOVERED.name().equalsIgnoreCase(flavorCombination.getVENDOR_FLAVOR_STATUS())
                && InventoryStatus.ARCHIVED.name().equalsIgnoreCase(cloudProductPlan.getStatus())) {
              cloudProductPlan.setStatus(InventoryStatus.DISCOVERED.name());
              productPlanRepository.save(cloudProductPlan);
            }
            //loadProductPlans(cloudProduct, false);
          }
        }
        if (!planList.isEmpty())
          bulkSave(planList);
      }
    } catch (Exception e) {
      log.error("Exception occurs while loading product plans: ", e.getMessage());
    }
    log.debug("In loadPlans - END!");

	}


  
  private <T extends CloudProductPlan> Collection<T> bulkSave(Collection<T> entities) {
    final List<T> savedEntities = new ArrayList<T>(entities.size());
    int i = 0;
    for (T t : entities) {
      savedEntities.add(persistOrMerge(t));
      i++;
      if (i % 100 == 0) {
        // Flush a batch of inserts and release memory.
        productPlanRepository.flush();
        // clear();
        log.debug("Flush a batch of inserts and release memory in plans insert");
      }
    }
    return savedEntities;
  }

  @Transactional
  private <T extends CloudProductPlan> T persistOrMerge(T t) {
    return productPlanRepository.save(t);
  }

  /**
	 * @param mapper
	 * @param flavorCombination
	 */
  private CloudProductPlan createProductPlan(final ObjectMapper mapper, RackspaceComputePriceExportData flavorCombination, CloudLocation cloudLocation)
      throws ResourceNotFoundException{
		CloudProduct product = null;
		ProductPlanDetailsResource detailsResource = ProductPlanDetailsResource.builder().operatingSystemId(flavorCombination.getCLOUD_OPERATING_SYSTEM_ID())
																						 .flavorId(flavorCombination.getCLOUD_RACKSPACE_CONFIGURATION_ID())
																						 .build();
		String json = "";
		try {
			json = mapper.writeValueAsString(detailsResource);
		} catch (IOException e) {
			e.printStackTrace();
		}
		List<CloudProduct> productList = productRepository.findByServiceAndOs(flavorCombination.getSERVICE_ID(), flavorCombination.getCLOUD_OPERATING_SYSTEM_ID());
		if(!org.springframework.util.CollectionUtils.isEmpty(productList)){
			product = productList.get(0);
		}else {
			throw new ResourceNotFoundException("CloudProduct", flavorCombination.getSERVICE_ID()+ "-" + flavorCombination.getCLOUD_OPERATING_SYSTEM_ID());
		}
		
		CloudService cloudService = serviceRepository.findOne(flavorCombination.getSERVICE_ID());
		if(null == cloudService){
			throw new ResourceNotFoundException("CloudService", flavorCombination.getSERVICE_ID());
		}
		
		String planName = cloudLocation.getName() + "-" + product.getName() + "-" + flavorCombination.getVENDOR_FLAVOR_NAME();
    String synnexCurrency = invoiceService.getCloudBusinessRuleByRuleName(BusinessRuleNames.CURRENCY);
    Double conversionRate = 1D;
    if (InvoiceUtility.isNotEmpty(synnexCurrency) /* && flavorCombination.getCURRENCY().equals(synnexCurrency)*/) {
      CloudCurrencyConversionRate cloudCurrencyConversionRate = conversionRateRepository.getCloudCurrencyConversionRate(NepheleCurrency.valueOf(cloudService.getVendorCurrency()), NepheleCurrency.valueOf(synnexCurrency));
      if (null != cloudCurrencyConversionRate && InvoiceUtility.isNotEmpty(cloudCurrencyConversionRate.getConversionRate())) {
        conversionRate = cloudCurrencyConversionRate.getConversionRate();
      }
    }

		CloudProductPlan productPlan = CloudProductPlan.builder().planCode(sequenceUtil.getPlanCodePatternSequenceValue(cloudService))
																 .planName(planName)
        .price(NepheleUtils.calculateExchangeRate(flavorCombination.getPRICE(), conversionRate))
        //.vendorPrice(flavorCombination.getPRICE()*nepheleUtils.findExchangeRate("USD","AUD"))
        .vendorPrice(InvoiceUtility.ceilingDoubleForPrice(flavorCombination.getPRICE()))
        .cloudService(cloudService)
																 .details(json)
																 .status(InventoryStatus.DISCOVERED.name())
																 .cloudLocation(cloudLocation)
																 .cloudProduct(product)
																 .flavorCategory(flavorCombination.getVENDOR_FLAVOR_CLASS())
																 .sortKey(flavorCombination.getVENDOR_RAM())
																 .pricingModel(CloudPricingModel.PER_UNIT)
																 .isTrialPlan(false)
																 .build();
    //productPlanRepository.save(productPlan);
    return productPlan;
  }


	@Override
	public void loadAdditionalPrice(CloudService cloudService) {
		CloudAdditionalPrice additionalPrice = null;
    try {
      CloudService service = serviceRepository.findByIntegrationCode(CloudTypes.softlayer.name());
      
      if(null == service)
    	  throw new ResourceNotFoundException("CloudService", CloudTypes.softlayer.name());
      
       additionalPrice = additionalPriceRepository.findByServiceId(service.getId());
      if (null == additionalPrice) {
         additionalPrice = CloudAdditionalPrice.builder().cloudService(service).name(additionalPriceMessage)
            .description(additionalPriceMessage).location(locationRepository.findByServiceLocationCodeAndStatus(service.getId(), "syd01", "DISCOVERED").get(0).getName())
            .planCode(additionalPriceCommandService.getAdditionalPriceCodePatternSequenceValue(service))
            .status(InventoryStatus.STAGED.name())
            .price(0.0)
            .serviceType(NepheleConstants.CLOUD_BANDWIDTH)
            .build();
        additionalPriceRepository.save(additionalPrice);
      }
    } catch (Exception e) {
      log.error("Exception occurs while loading additional price: ", e.getMessage());
      e.printStackTrace();
    }
  }


}

