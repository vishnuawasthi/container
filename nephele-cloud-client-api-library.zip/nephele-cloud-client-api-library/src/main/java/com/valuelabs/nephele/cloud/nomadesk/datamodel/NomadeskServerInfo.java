package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import javax.xml.bind.annotation.XmlElement;

public class NomadeskServerInfo {
	
	private String userName;
	private String privateKey;
	
	@XmlElement(name = "Username")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@XmlElement(name = "PrivateKey")
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	

}
