package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;

public class ProductPriceDetails {
	
	private Products products;

	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}
	
	

}
