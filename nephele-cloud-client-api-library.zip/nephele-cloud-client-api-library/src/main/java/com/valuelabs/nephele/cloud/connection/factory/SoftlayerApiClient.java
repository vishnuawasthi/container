package com.valuelabs.nephele.cloud.connection.factory;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.softlayer.api.ApiClient;
import com.softlayer.api.RestApiClient;
import com.softlayer.api.service.Account;
import com.softlayer.api.service.Brand;
import com.softlayer.api.service.user.Customer;

public class SoftlayerApiClient {
	public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException {
		
		//ApiClient client = new RestApiClient().withCredentials("SL775479", "984e0b37658a37591b0796b7b813d11c359bd6d0e636405802494924c99c508d");
		ApiClient client = new RestApiClient().withCredentials("SYN820241", "545f3c7044772155a718bb2f9edb772bfc85611c19d5201ce0f69703ede571bf");
		
		/*Boolean bypassDuplicateAccountCheck = true;
		
		Account account = new Account();
		Brand br = new Brand();
		br.setId(65643l);
		account.setBrand(br);
		account.setCompanyName("Test Accounttwo");
		account.setFirstName("Test firstnametwo");
		account.setLastName("Test lastnametwo");
		account.setAddress1("92 Carroll Rd");
		account.setPostalCode("3168");
		account.setCity("Sydney");
		account.setState("OT");
		account.setCountry("AU");
		account.setOfficePhone("1234567891");
		account.setEmail("sivanaresh.bandarupalli@valuelabs.com");
		account.setLateFeeProtectionFlag(null);
		account.setClaimedTaxExemptTxFlag(false);
		account.setAllowedPptpVpnQuantity(1l);
		account.setIsReseller(0l);
		account.setAccountStatusId(1001l);
		Account custAccount = Brand.service(client).createCustomerAccount(account, bypassDuplicateAccountCheck);*/
		
		
		//custAccount.getBillingInfo().getAccount().getMasterUser().getApiAuthenticationKeys().get(0);
		
		
		/*Customer newCustomerRequest = new Customer();
		newCustomerRequest.setUsername("TestSivauserTwo");
		newCustomerRequest.setFirstName("TestSivauserFitst");
		newCustomerRequest.setLastName("TestSivauserLast");
		newCustomerRequest.setEmail("sivanaresh.bandarupalli@valuelabs.com");
		newCustomerRequest.setCompanyName("testcomp");
		newCustomerRequest.setAddress1("315 Capitol Street");
		newCustomerRequest.setCity("Test");
		newCustomerRequest.setCountry("AU");
		newCustomerRequest.setPostalCode("3167");
		newCustomerRequest.setUserStatusId(1001l);
		newCustomerRequest.setTimezoneId(107l);*/
		
		//Customer newCustomer = Customer.service(client).createObject(newCustomerRequest, "TestPassword@123", "TestVpnPassword@123");
		List<Customer> newCustomer = Account.service(client).getUsers();
		ObjectMapper mapper = new ObjectMapper();
		String customerList = mapper.writeValueAsString(newCustomer.get(1));
		/*for (Hardware hardware : Brand.service(client).getHardware()) {
		    log.debug("Hardware: " + hardware.getFullyQualifiedDomainName());
		}*/
		
	}
}
