package com.valuelabs.nephele.cloud.acronis.datamodel;

import java.io.Serializable;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class AcronisGroupDetails extends ResourceSupport implements Serializable {
	
	private Long version;
	private Long grade;
	private Long brand;
	private Boolean migration_enabled;
	private AcronisContact contact;
	private String external;
	private AcronisUsage usage;	
	private AcronisBilling billing;
	private AcronisPricing pricing;		
	private String migration_service;
	private Long kind;
	private Long parent_id;
	private AcronisPrivileges privileges;
	private String language;
	private Long customer_type;
	//private Long id;
	//private AcronisStorage storage;
	private Long customer_id;
	private String name;
	private Long status;
	private String parent_has_access;
	//private String capabilities;
	private int strorage;
	
}
