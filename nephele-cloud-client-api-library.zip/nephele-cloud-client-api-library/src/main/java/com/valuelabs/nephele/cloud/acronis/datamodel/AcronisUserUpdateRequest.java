package com.valuelabs.nephele.cloud.acronis.datamodel;



import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class AcronisUserUpdateRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;		
	private String firstname;
	private String lastname;
	private String email;	
	private Long brand;
	private Long access_type;
	private AcronisGroup group;	
	private AcronisLinks links;	
}
