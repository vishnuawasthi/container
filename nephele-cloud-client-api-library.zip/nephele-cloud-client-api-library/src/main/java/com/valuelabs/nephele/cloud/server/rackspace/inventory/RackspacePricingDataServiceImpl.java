package com.valuelabs.nephele.cloud.server.rackspace.inventory;

import java.io.File;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

import com.valuelabs.nephele.admin.data.api.JobName;
import com.valuelabs.nephele.admin.data.api.JobStatus;
import com.valuelabs.nephele.admin.data.entity.CloudRackspacePriceUnitMeasure;
import com.valuelabs.nephele.admin.data.entity.CloudRackspacePricingDetails;
import com.valuelabs.nephele.admin.data.repository.CloudRackspacePriceUnitMeasureRepository;
import com.valuelabs.nephele.admin.data.repository.CloudRackspacePricingDetailsRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.JobDetails;
import com.valuelabs.nephele.admin.rest.lib.event.RackspacePricingDataCreatedEvent;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.Price;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.PriceCharacteristic;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.PriceDetails;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.Prices;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.Product;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.ProductCharacteristic;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.ProductOfferingPrice;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.ProductPriceDetails;
import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.Products;

@Slf4j
@Service
public class RackspacePricingDataServiceImpl implements RackspacePricingDataService {
	
	@Autowired
	CloudRackspacePricingDetailsRepository pricingRepository;
	
	@Autowired
	CloudRackspacePriceUnitMeasureRepository unitMeasureRepository;
	
	@Override
	public RackspacePricingDataCreatedEvent loadProudctPriceJsonData() {
		String status = "";
		File rackspacePricingFile = new File("/opt/nephele/config/rackspace_pricing.json");
		RackspacePricingDataCreatedEvent event = null;
		try{			
			if (!rackspacePricingFile.exists() || rackspacePricingFile.length() == 0) {
				log.error("Catalog file does not exixt in source path folder (i.e " + rackspacePricingFile.getAbsolutePath()
	            + ").Please provide this files to run  superd datalload.  ");
	        	status = "Catalog file does not exixt in source path folder (i.e " + rackspacePricingFile.getAbsolutePath() + ").Please provide this files to run  superd datalload.  ";
	        	event = new RackspacePricingDataCreatedEvent();
	        	event.setStatus(status);
		    }else {
		        	event = loadJSONData(rackspacePricingFile);// loading catalog file
		    }
		}catch(Exception e){
			e.printStackTrace();
		}
	    
		return event;
	       
	}
	
	private RackspacePricingDataCreatedEvent loadJSONData(File pricingDataFile ) {
		String status = "";
		boolean dataStatus = false;
		RackspacePricingDataCreatedEvent response = null;
		try {			
			ObjectMapper mapper = new ObjectMapper();
			ProductPriceDetails productDetails = mapper.readValue(pricingDataFile , ProductPriceDetails.class);
			Products products = productDetails.getProducts();
			int version = 0;			
			if(products != null ){
				CloudRackspacePricingDetails pricingDetails = pricingRepository.getLatestVersion().size() ==0 ? null : pricingRepository.getLatestVersion().get(0);
				version = pricingDetails==null ? version : pricingDetails.getVersion()+1;
			}
			CloudRackspacePricingDetails details = null;			
			for (Product product : products.getProduct()) {
				details = new CloudRackspacePricingDetails();
				details.setProduct_id(product.getId());
				details.setProductDescription(product.getDescription());
				details.setProductName(product.getName());
				details.setProductCode(product.getProductCode());
				details.setStatus(product.getStatus());
				details.setSalesChannel(product.getSalesChannel());
				details.setVersion(version);
				ProductOfferingPrice offerPrice = product.getProductOfferingPrice();

				ProductCharacteristic[] characteristics = product.getProductCharacteristic();
				for (ProductCharacteristic characteristic : characteristics) {
					if (characteristic.getName().equalsIgnoreCase("class")) {
						details.setClassName(characteristic.getValue());
					} else if (characteristic.getName().equalsIgnoreCase("com.rackspace_1_options")) {
						details.setOptions(characteristic.getValue());
					} else if (characteristic.getName().equalsIgnoreCase("flavor_id")) {
						details.setFlavorId(characteristic.getValue());
					} else if (characteristic.getName().equalsIgnoreCase("os_type")) {
						details.setOsType(characteristic.getValue());
					} else if (characteristic.getName().equalsIgnoreCase("product_category")) {
						details.setProductCategory(characteristic.getValue());
					} else if (characteristic.getName().equalsIgnoreCase("ram_in_mb")) {
						details.setRamInMb(characteristic.getValue());
					}

				}

				br: for (PriceDetails priceDet : offerPrice.getPriceDetails()) {
					if (getPriceDetails(priceDet)) {
						for (PriceCharacteristic characteristic : priceDet.getPriceCharacteristic()) {
							if (characteristic.getName().equalsIgnoreCase("chargeType")) {
								details.setChargeType(characteristic.getValue());
							} else if (characteristic.getName().equalsIgnoreCase("serviceLevel")) {
								details.setServiceLevel(characteristic.getValue());
							} else if (characteristic.getName().equalsIgnoreCase("serviceType")) {
								details.setServiceType(characteristic.getValue());
							}
						}
						dataStatus = true;
						pricingRepository.save(details);

						Prices[] pricesArray = priceDet.getPrices();
						for (Prices prices : pricesArray) {
							CloudRackspacePriceUnitMeasure unit = null;
							for (Price price : prices.getPrice()) {
								unit = new CloudRackspacePriceUnitMeasure();
								unit.setAmount(price.getAmount());
								unit.setCurrency(price.getCurrency());
								unit.setGeo(price.getGeo());
								unit.setUnitOfMeasure(prices.getUnitOfMeasure());
								unit.setCloudRackspacePriceDetails(details);
								unitMeasureRepository.save(unit);								
							}
						}
						break;
					}
				}

			}
			status = "Product price details uploaded successfully into DB !!!";
			
			JobDetails jobDetails =null;
			if(dataStatus){
				 jobDetails = JobDetails.builder().jobId(new Long(version))
											      .jobName(JobName.PRICING_DATA)
												  .jobStatus(JobStatus.COMPLETED)
												  .build();
			}
			response = new RackspacePricingDataCreatedEvent();
			response.setJobDetails(jobDetails);
		}

		catch (Exception e) {
			status = "Error in uploading Product price details Data into DB !!!";
			e.printStackTrace();
		}		
		response.setStatus(status);
		
		return response;
	}
	
	public boolean getPriceDetails(PriceDetails priceDet){
		boolean status = false;	
		int count = 0;
		for(PriceCharacteristic characteristic : priceDet.getPriceCharacteristic()){
			
				if(characteristic.getName().equalsIgnoreCase("serviceType")){				    
				    if(characteristic.getValue().equalsIgnoreCase("SYSOPS"))
				    	count++;
			    }
				if(characteristic.getName().equalsIgnoreCase("serviceLevel"))
				{				    
				    if(characteristic.getValue().equalsIgnoreCase("INFRASTRUCTURE"))
				    	count++;
			    }
			
		}
		if(count == 2)
			status = true;
			
		return status;	
	}
}
