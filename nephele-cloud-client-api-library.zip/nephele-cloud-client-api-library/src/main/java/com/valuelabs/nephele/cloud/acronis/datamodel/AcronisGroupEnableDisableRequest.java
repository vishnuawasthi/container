package com.valuelabs.nephele.cloud.acronis.datamodel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class AcronisGroupEnableDisableRequest  {	
	
	private String groupId;
	private  String version;
	private AcronisGroup group;
	
}
