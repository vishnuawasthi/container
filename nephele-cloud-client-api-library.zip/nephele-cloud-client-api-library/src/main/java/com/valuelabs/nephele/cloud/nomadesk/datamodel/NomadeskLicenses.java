package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Licenses")
public class NomadeskLicenses {
	
	
	private List<NomadeskLicense> license;

	@XmlElement(name = "License")
	public List<NomadeskLicense> getLicense() {
		return license;
	}

	public void setLicense(List<NomadeskLicense> license) {
		this.license = license;
	}

}
