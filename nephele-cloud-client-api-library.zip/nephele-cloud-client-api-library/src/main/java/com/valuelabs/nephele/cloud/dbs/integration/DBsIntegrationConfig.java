package com.valuelabs.nephele.cloud.dbs.integration;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class DBsIntegrationConfig {
	
	@Value("${dbsintegrationservice.uri}")
	private String url;

	@Value("${dbsintegrationservice.receiveresellerxml}")
	private String receiveResellerxmlPath;
	
    
	@Bean(name="dbsRestTemplate")
	public RestTemplate getDBsServiceTemplate() {
		log.debug("Creating: RestTemplate dbsRestTemplate");
		HttpClient httpClient = HttpClientBuilder.create().build();
	
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		RestTemplate restTemplate = new RestTemplate(requestFactory);
	
		return restTemplate;		
	}
	
	@Bean(name="dbsResellerXmlTemplate")
	public String getDBsResellerXmlTemplate() {		
		return String.format("%s%s", url, receiveResellerxmlPath);		
	}

}
