package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


//@Data
@XmlRootElement(name = "MobileDeviceControlSettings")
public class MobileDeviceControlSettings {
	
	 
	 private int idleLogoutTimer;
	 private boolean allowLocalCache;	
	 private boolean allowVaultRemoval;	
	 private boolean allowOpenWith;	
	 private boolean allowRememberMe;
	
	@XmlElement(name = "IdleLogoutTimer")
	public int getIdleLogoutTimer() {
		return idleLogoutTimer;
	}
	public void setIdleLogoutTimer(int idleLogoutTimer) {
		this.idleLogoutTimer = idleLogoutTimer;
	}
	@XmlElement(name = "AllowLocalCache")
	public boolean isAllowLocalCache() {
		return allowLocalCache;
	}
	public void setAllowLocalCache(boolean allowLocalCache) {
		this.allowLocalCache = allowLocalCache;
	}
	@XmlElement(name = "AllowVaultRemoval")
	public boolean isAllowVaultRemoval() {
		return allowVaultRemoval;
	}
	public void setAllowVaultRemoval(boolean allowVaultRemoval) {
		this.allowVaultRemoval = allowVaultRemoval;
	}
	@XmlElement(name = "AllowOpenWith")
	public boolean isAllowOpenWith() {
		return allowOpenWith;
	}
	public void setAllowOpenWith(boolean allowOpenWith) {
		this.allowOpenWith = allowOpenWith;
	}
	@XmlElement(name = "AllowRememberMe")
	public boolean isAllowRememberMe() {
		return allowRememberMe;
	}
	public void setAllowRememberMe(boolean allowRememberMe) {
		this.allowRememberMe = allowRememberMe;
	}

}
