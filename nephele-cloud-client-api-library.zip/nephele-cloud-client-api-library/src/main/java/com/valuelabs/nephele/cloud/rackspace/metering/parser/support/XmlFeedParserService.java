package com.valuelabs.nephele.cloud.rackspace.metering.parser.support;

import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.BANDWITH_IN;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.BANDWITH_OUT;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.DATA_CENTER;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.END_TIME;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.ENVIRONMENT;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.EVENT;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.FLAVOR_ID;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.FLAVOR_NAME;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.ID;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.IS_MANAGED;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.NOVA_PRODUCT;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.OS_LICENCE_TYPE;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.REGION;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.RESOURCE_ID;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.RESOURCE_NAME;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.RESOURCE_TYPE;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.SERVICE_CODE;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.START_TIME;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.STATUS;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.TENANT_ID;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.TYPE;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.RackspaceMeteringDataConstants.VERSION;
import static com.valuelabs.nephele.cloud.rackspace.metering.parser.support.ValidationSupport.safe;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sun.syndication.feed.synd.SyndCategoryImpl;
import com.sun.syndication.feed.synd.SyndContentImpl;
import com.sun.syndication.feed.synd.SyndEntryImpl;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.feed.synd.SyndLinkImpl;
import com.sun.syndication.io.FeedException;
import com.sun.syndication.io.SyndFeedInput;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedEntryResources;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedEventResources;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedLinksResources;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudFeedProductResources;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleCloudFeedResources;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleSyndCategoryResources;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleSyndContentResources;
import com.valuelabs.nephele.cloud.server.rackspace.RackspaceMeteringDataConnection;

import lombok.extern.slf4j.Slf4j;

public interface XmlFeedParserService {

	public abstract NepheleCloudFeedResources readFromServer(String s)
			throws IllegalArgumentException, FeedException, IOException;

	@Slf4j
	@Component
	public class Impl implements XmlFeedParserService {

		@Autowired
		RackspaceMeteringDataConnection feedConn;

		public NepheleCloudFeedResources readFromServer(String url) throws IllegalArgumentException, FeedException, IOException {
			NepheleCloudFeedResources nepheleCloudFeed = new NepheleCloudFeedResources();
			try {
				InputSource in = new InputSource(new StringReader(feedConn.getConnection(url)));
				SyndFeedInput input = new SyndFeedInput();
				SyndFeed syndFeed = input.build(in);
				populateNepheleCloudFeed(syndFeed, nepheleCloudFeed);
			} catch (HttpClientErrorException e) {
				log.debug("*********** Too Many Url Hits. Please wait some Time:Limit Exceed :************ " + e.getMessage());
				nepheleCloudFeed.setEntries(Collections.<CloudFeedEntryResources> emptyList());
				return nepheleCloudFeed;
			} catch (ResourceAccessException e) {
				log.debug("Connection Lost with Rackspace server, Check internet connection also ***** :  " + e.getMessage());
				nepheleCloudFeed.setEntries(Collections.<CloudFeedEntryResources> emptyList());
				return nepheleCloudFeed;
			}
			catch (Exception e) {
				log.debug("Exception in readFromServer:  " + e.getMessage());
				nepheleCloudFeed.setEntries(Collections.<CloudFeedEntryResources> emptyList());
				return nepheleCloudFeed;
			}

			return nepheleCloudFeed;
		}

		@SuppressWarnings({ "unchecked" })
		private void populateNepheleCloudFeed(SyndFeed syndFeed, NepheleCloudFeedResources nepheleCloudFeed) {

			List<CloudFeedLinksResources> links = new ArrayList<CloudFeedLinksResources>();

			List<CloudFeedEntryResources> entries = new ArrayList<CloudFeedEntryResources>();

			nepheleCloudFeed.setTitle(syndFeed.getTitle());

			nepheleCloudFeed.setUuid(syndFeed.getUri());
			nepheleCloudFeed.setPublishedDate(syndFeed.getPublishedDate());
			nepheleCloudFeed.setLink(syndFeed.getLink());
			nepheleCloudFeed.setFeedType(syndFeed.getFeedType());

			for (SyndLinkImpl impl : (List<SyndLinkImpl>) safe(syndFeed.getLinks())) {
				CloudFeedLinksResources link = new CloudFeedLinksResources(null, impl.getHref(), impl.getRel(), impl.getType(), impl.getHreflang(),
						impl.getTitle(), impl.getLength());
				links.add(link);
			}

			for (SyndEntryImpl impl : (List<SyndEntryImpl>) safe(syndFeed.getEntries())) {
				CloudFeedEntryResources entry = new CloudFeedEntryResources();
				entry.setDescription(impl.getDescription());
				entry.setForeignMarkup(impl.getForeignMarkup());
				entry.setLink(impl.getLink());
				entry.setPublishedDate(impl.getPublishedDate());
				entry.setUpdatedDate(impl.getUpdatedDate());
				entry.setTitle(impl.getTitle());
				entry.setUuid(impl.getUri());
				entry.setFeedUuid(syndFeed.getUri());

				// Reading links
				List<CloudFeedLinksResources> atomLinks = new ArrayList<CloudFeedLinksResources>();
				for (SyndLinkImpl syndLinkImpl : (List<SyndLinkImpl>) safe(impl.getLinks())) {
					CloudFeedLinksResources atomLink = new CloudFeedLinksResources(null, syndLinkImpl.getHref(), syndLinkImpl.getRel(),
							syndLinkImpl.getType(), syndLinkImpl.getHreflang(), syndLinkImpl.getTitle(),
							syndLinkImpl.getLength());
					atomLinks.add(atomLink);
				}

				// Reading categories
				List<NepheleSyndCategoryResources> categories = new ArrayList<NepheleSyndCategoryResources>();
				for (SyndCategoryImpl syndCategoryImpl : (List<SyndCategoryImpl>) safe(impl.getCategories())) {
					NepheleSyndCategoryResources category = new NepheleSyndCategoryResources(syndCategoryImpl.getName(),
							syndCategoryImpl.getTaxonomyUri());
					categories.add(category);
				}

				// Reading contents
				// entry.setContents(impl.getContents());
				List<NepheleSyndContentResources> nepheleSyndContents = new ArrayList<NepheleSyndContentResources>();
				for (SyndContentImpl contentImpl : (List<SyndContentImpl>) safe(impl.getContents())) {
					NepheleSyndContentResources content = new NepheleSyndContentResources(contentImpl.getType(), contentImpl.getMode(),
							null);
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					javax.xml.parsers.DocumentBuilder builder;
					org.w3c.dom.Document document;
					try {
						builder = factory.newDocumentBuilder();
						try {
							document = (org.w3c.dom.Document) builder
									.parse(new InputSource(new StringReader(contentImpl.getValue())));
							NodeList nl = document.getElementsByTagName(EVENT);
							CloudFeedEventResources event = new CloudFeedEventResources();

							for (int i2 = 0; i2 < nl.getLength(); i2++) {
								event.setDataCenter(
										((nl.item(i2).getAttributes().getNamedItem(DATA_CENTER).getNodeValue())));
								event.setEndTime((nl.item(i2).getAttributes().getNamedItem(END_TIME).getNodeValue()));
								event.setEnvironment(
										(nl.item(i2).getAttributes().getNamedItem(ENVIRONMENT).getNodeValue()));
								event.setId((nl.item(i2).getAttributes().getNamedItem(ID).getNodeValue()));
								event.setRegion((nl.item(i2).getAttributes().getNamedItem(REGION).getNodeValue()));
								event.setResourceId(
										(nl.item(i2).getAttributes().getNamedItem(RESOURCE_ID).getNodeValue()));
								event.setResourceName(
										(nl.item(i2).getAttributes().getNamedItem(RESOURCE_NAME).getNodeValue()));
								event.setStartTime(
										(nl.item(i2).getAttributes().getNamedItem(START_TIME).getNodeValue()));
								event.setTenantId((nl.item(i2).getAttributes().getNamedItem(TENANT_ID).getNodeValue()));
								event.setType((nl.item(i2).getAttributes().getNamedItem(TYPE).getNodeValue()));
								event.setVersion((nl.item(i2).getAttributes().getNamedItem(VERSION).getNodeValue()));
							}

							NodeList nova = document.getElementsByTagName(NOVA_PRODUCT);
							CloudFeedProductResources novaProduct = new CloudFeedProductResources();
							for (int i3 = 0; i3 < nova.getLength(); i3++) {
								novaProduct.setBandwidthIn(
										(nova.item(i3).getAttributes().getNamedItem(BANDWITH_IN).getNodeValue()));
								novaProduct.setBandwidthOut(
										(nova.item(i3).getAttributes().getNamedItem(BANDWITH_OUT).getNodeValue()));
								novaProduct.setFlavorId(
										(nova.item(i3).getAttributes().getNamedItem(FLAVOR_ID).getNodeValue()));
								novaProduct.setFlavorName(
										(nova.item(i3).getAttributes().getNamedItem(FLAVOR_NAME).getNodeValue()));
								novaProduct.setIsManaged(
										(nova.item(i3).getAttributes().getNamedItem(IS_MANAGED).getNodeValue()));
								novaProduct.setOsLicenseType(
										(nova.item(i3).getAttributes().getNamedItem(OS_LICENCE_TYPE).getNodeValue()));
								novaProduct.setResourceType(
										(nova.item(i3).getAttributes().getNamedItem(RESOURCE_TYPE).getNodeValue()));
								novaProduct.setServiceCode(
										(nova.item(i3).getAttributes().getNamedItem(SERVICE_CODE).getNodeValue()));
								novaProduct
										.setStatus((nova.item(i3).getAttributes().getNamedItem(STATUS).getNodeValue()));
								novaProduct.setVersion(
										(nova.item(i3).getAttributes().getNamedItem(VERSION).getNodeValue()));
							}
							event.setProduct(novaProduct);
							content.setEvent(event);
						} catch (SAXException e) {
							log.debug("Exception while parsing data :" + e.getMessage());
						} catch (IOException e) {
							log.debug("Exception while parsing data :" + e.getMessage());
						}
					} catch (ParserConfigurationException e) {
						log.debug("Exception while parsing data :" + e.getMessage());
					}
					nepheleSyndContents.add(content);
				}
				entry.setLinks(atomLinks);
				entry.setContents(nepheleSyndContents);
				entry.setCategories(categories);
				entries.add(entry);
			}
			nepheleCloudFeed.setLinks(links);
			nepheleCloudFeed.setEntries(entries);
		}
	}

}
