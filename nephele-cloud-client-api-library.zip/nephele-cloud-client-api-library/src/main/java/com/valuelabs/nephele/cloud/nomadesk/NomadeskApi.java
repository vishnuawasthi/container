package com.valuelabs.nephele.cloud.nomadesk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.valuelabs.nephele.cloud.nomadesk.datamodel.CancelRequest;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.CheckAccountStatusRequest;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.LicenseRequest;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.LicenseResponse;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.LicenseSubscription;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.NomadeskAccountRequest;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.NomadeskLoginResource;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.NomadeskResponse;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.ReActivateAccountRequest;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.SuspendAccountRequest;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.SuspendAccountResponse;
import com.valuelabs.nephele.cloud.nomadesk.datamodel.UnAssignedLicenseRequest;

@Slf4j
@Component
@Service
public class NomadeskApi {
	
	
	@Autowired
	private RestTemplate nomadeskRestTemplate;

	@Autowired
	private String nomadeskLoginUrlTemplate;
	
	@Autowired
	private String nomadeskLogoutUrlTemplate;
	
	@Autowired
	private String nomadeskAccountsUrlTemplate;
	
	@Autowired
	private String nomadeskGetAcctUrlTemplate;
	
	@Autowired
	private String nomadeskDestroyAcctUrlTemplate;
	
	@Autowired
	private String nomadeskForgotPwdUrlTemplate;
	
	@Autowired
	private String nomadeskAssignedLicensesUrlTemplate;
	
	@Autowired
	private String nomadeskUnassignedLicensesUrlTemplate;
	
	@Autowired
	private String nomadeskCheckAccountStatusUrlTemplate;
	
	@Autowired
	private String nomadeskGetLicensesUrlTemplate;
	
	@Autowired
	private String nomadeskReActivateAccountUrlTemplate;
	
	@Autowired
	private String nomadeskSuspendAccountUrlTemplate;
	
	@Autowired
	private String nomadeskCancelAccountUrlTemplate;
	
	/**
     * nomadesk login Requires you to specify username and password as query params.
     * @param username
     * @param password     
    */	
    public NomadeskResponse login(NomadeskLoginResource login) {
			
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url =  String.format("%s&%s&%s", nomadeskLoginUrlTemplate, "AMSUsername="+login.getEmail(), "AMSPassword="+login.getPassword());
			log.debug("NomadeskApi Calling START : ", url);	
			responseString = nomadeskRestTemplate.getForObject(url, String.class);		
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("NomadeskApi Calling END"); 
		return responseObj;
	}
    
   /**
	* nomadesk Logout
	*
	*/
    public NomadeskResponse logout(String token) {		
		
    	String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s", nomadeskLogoutUrlTemplate, "Token="+token);		
			log.debug("Nomadesk LogoutApi Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk LogoutApi Calling END");
		return responseObj;	
	}
    
    /**
     * nomadesk AccountCreation Requires 
     * @param firstName
	 * @param lastName			
	 * @param email;	
	 * @param password;
	 * @param fileserverlabel;	
	 * @param extendedInfo;
	 * @param skipConfirm;	
     *       
    */
	public NomadeskResponse createAccount(NomadeskAccountRequest acctInfo) {
		
		
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s&%s&%s&%s&%s&%s", nomadeskAccountsUrlTemplate, "FirstName="+acctInfo.getFirstName()
			                                  , "LastName="+acctInfo.getLastName()
			                                  , "Email="+acctInfo.getEmail()
			                                  , "Password="+acctInfo.getPassword()
			                                  , "ExtendedInfo="+acctInfo.getExtendedInfo()
			                                  , "SkipConfirm="+acctInfo.getSkipConfirm()
			                                  , "GoogleAnalyticsSource="+acctInfo.getGoogleAnalyticsSource());	
			
			log.debug("Nomadesk createAccountApi Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk createAccountApi Calling END");
		return responseObj;	
		
	}
	
	
	/**
     * nomadesk getAccount Requires     
	 * @param email;	
	 * @param token;	 
	 * @param extendedInfo;
	 * @param ExtendedAccountInfo;	
     *       
    */
	public NomadeskResponse getAccountInfo(NomadeskAccountRequest acctInfo) {
		
		
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s&%s&%s", nomadeskGetAcctUrlTemplate, "token="+acctInfo.getToken()
			                                 , "Email="+acctInfo.getEmail()			                                  
			                                  , "ExtendedInfo="+acctInfo.getExtendedInfo()
			                                  , "ExtendedAccountInfo="+acctInfo.getExtendedAccountInfo());	
			
			log.debug("Nomadesk GetAccountInfoApi Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk createAccountApi Calling END");
		return responseObj;	
		
	}
	
	/**
     * nomadesk destroyAccount Requires     
	 * @param email;	
	 * @param token;	
     *       
    */
	public NomadeskResponse destroyAccount(NomadeskAccountRequest acctInfo) {
		
		
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s", nomadeskDestroyAcctUrlTemplate, "token="+acctInfo.getToken()
			                                 , "Email="+acctInfo.getEmail());
			
			log.debug("Nomadesk destroyAccount Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk destroyAccount Calling END");
		return responseObj;	
		
	}
	
	/**
     * nomadesk forgotPassword Requires     
	 * @param email;		
     *       
    */
	public NomadeskResponse forgotPassword(String email) {	
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s", nomadeskForgotPwdUrlTemplate, "Email="+email);
			
			log.debug("Nomadesk forgotPassword Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk forgotPassword Calling END");
		return responseObj;			
	}
	
	/**
     * nomadesk assignedLicenses Requires     
	 * @param Token;	
	 * @param SkipConfirm;
	 * @param AccountName;	
	 * @param Subscription;		
     *       
    */
	public NomadeskResponse assignedLicenses(LicenseRequest request) {	
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s&%s", nomadeskAssignedLicensesUrlTemplate, "Token="+request.getToken(), "SkipConfirm="+request.isSkipconfirm(), "AccountName="+request.getAccountName());
			int i = 0;
			for(LicenseSubscription subscription : request.getSubscription()){
				url = String.format("%s&%s&%s&%s", url, "Subscription["+i+"][newcount]="+subscription.getNewcount()
				                                       , "Subscription["+i+"][Type]="+subscription.getType()
				                                       , "Subscription["+i+"][Email]="+subscription.getEmail());
			    i++;
			}
			
			log.debug("Nomadesk assignedLicenses Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk assignedLicenses Calling END");
		return responseObj;			
	}
	
	/**
     * nomadesk getLicenses Requires     
	 * @param token;	
	 * @param accountName;		
     *       
    */
	public LicenseResponse getLicenses(LicenseRequest request) {	
		String responseString = null;	
		JAXBContext jaxbContext;
		LicenseResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s", nomadeskGetLicensesUrlTemplate, "Token="+request.getToken(), "AccountName="+request.getAccountName());			
			log.debug("Nomadesk getLicenses Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(LicenseResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (LicenseResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getTotalCount());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk getLicenses Calling END");
		return responseObj;			
	}
	
	/**
     * nomadesk assignedLicenses Requires     
	 * @param Token;	
	 * @param LicenseID;	
	 * @param FileserverAction;		
	 * @param RemoveUser;		
	 * @param RemoveLicense;		
     *       
    */
	public NomadeskResponse unAssignedLicenses(UnAssignedLicenseRequest request) {	
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s&%s&%s&%s", nomadeskUnassignedLicensesUrlTemplate, "Token="+request.getToken(), "LicenseID="+request.getLicenseID() 
																					 ,  "FileserverAction="+request.getFileserverAction()
																					 , "RemoveUser="+request.isRemoveUser()
																					 , "RemoveLicense="+request.isRemoveLicense());			
			log.debug("Nomadesk unAssignedLicenses Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk unAssignedLicenses Calling END");
		return responseObj;			
	}
	
	/**
     * nomadesk assignedLicenses Requires     
	 * @param Token;	
	 * @param LicenseID;	
	 * @param FileserverAction;		
	 * @param RemoveUser;		
	 * @param RemoveLicense;		
     *       
    */
	public NomadeskResponse checkAccountStatus(CheckAccountStatusRequest request) {	
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s", nomadeskCheckAccountStatusUrlTemplate, "Email="+request.getEmail());			
			log.debug("Nomadesk checkAccountStatus Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....token....."+responseObj.getToken());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk checkAccountStatus Calling END");
		return responseObj;			
	}
	
	/**
     * nomadesk getLicenses Requires     
	 * @param token;	
	 * @param accountName;		
     *       
    */
	public NomadeskResponse suspendAccount(SuspendAccountRequest request) {	
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s", nomadeskSuspendAccountUrlTemplate, "Token="+request.getToken(), "Email="+request.getEmail());			
			log.debug("Nomadesk Suspend Account Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("output......."+responseObj.getMessage()+".....status....."+responseObj.getStatus());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk Suspend Account Calling  END");
		return responseObj;			
	}
	
	/**
     * nomadesk reActivateAccount Requires     
	 * @param token;	
	 * @param accountName;		
     *       
    */
	public NomadeskResponse reActivateAccount(ReActivateAccountRequest request) {	
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s", nomadeskReActivateAccountUrlTemplate, "Token="+request.getToken(), "Email="+request.getEmail());			
			log.debug("Nomadesk reActivateAccount Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			log.debug("Message......."+responseObj.getMessage()+".....status....."+responseObj.getStatus());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk getLicenses Calling END");
		return responseObj;			
	}
	
	public NomadeskResponse cancelAccount(CancelRequest request) throws IOException {	
		String responseString = null;	
		JAXBContext jaxbContext;
		NomadeskResponse responseObj = null;
		try{
			String url = String.format("%s&%s&%s", nomadeskCancelAccountUrlTemplate, "Token="+request.getToken(), "Email="+request.getEmail());			
			log.debug("Nomadesk Cancel Account Calling START : ", url);		
			responseString = nomadeskRestTemplate.getForObject(url, String.class);				
			log.debug(responseString+"....resultString");		
			jaxbContext = JAXBContext.newInstance(NomadeskResponse.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			//responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(responseString));
			StringBuilder builder = new StringBuilder();  
			BufferedReader br = new BufferedReader(new StringReader(responseString));
			br.mark(4);
			if ('\ufeff' != br.read())
				br.reset(); // not the BOM marker

			String line;
			while ((line = br.readLine()) != null)
			{
				builder.append(line);
			}
			responseObj = (NomadeskResponse) jaxbUnmarshaller.unmarshal(new StringReader(builder.toString()));
			log.debug("output......."+responseObj.getMessage()+".....status....."+responseObj.getStatus());
		} catch (JAXBException e) {
			e.printStackTrace();
		}	
		log.debug("Nomadesk Cancel Account Calling  END");
		return responseObj;			
	}

}
