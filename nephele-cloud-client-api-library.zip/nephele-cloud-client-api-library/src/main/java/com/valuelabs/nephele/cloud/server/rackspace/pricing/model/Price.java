package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;

public class Price
{
private String amount;

private String geo;

private String currency;

public String getAmount ()
{
return amount;
}

public void setAmount (String amount)
{
this.amount = amount;
}

public String getGeo ()
{
return geo;
}

public void setGeo (String geo)
{
this.geo = geo;
}

public String getCurrency ()
{
return currency;
}

public void setCurrency (String currency)
{
this.currency = currency;
}

@Override
public String toString()
{
return "ClassPojo [amount = "+amount+", geo = "+geo+", currency = "+currency+"]";
}
}

