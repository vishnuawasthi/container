package com.valuelabs.nephele.cloud.nomadesk.datamodel;

import javax.xml.bind.annotation.XmlElement;

public class NomadeskBillingInfo {
	
	private boolean inTrial;
	private long trialEndDstamp;
	private boolean allowChangeCreditCard;
	
	@XmlElement(name = "InTrial")
	public boolean isInTrial() {
		return inTrial;
	}
	public void setInTrial(boolean inTrial) {
		this.inTrial = inTrial;
	}
	@XmlElement(name = "TrialEndDstamp")
	public long getTrialEndDstamp() {
		return trialEndDstamp;
	}
	public void setTrialEndDstamp(long trialEndDstamp) {
		this.trialEndDstamp = trialEndDstamp;
	}
	@XmlElement(name = "AllowChangeCreditCard")
	public boolean isAllowChangeCreditCard() {
		return allowChangeCreditCard;
	}
	public void setAllowChangeCreditCard(boolean allowChangeCreditCard) {
		this.allowChangeCreditCard = allowChangeCreditCard;
	}
	

}
