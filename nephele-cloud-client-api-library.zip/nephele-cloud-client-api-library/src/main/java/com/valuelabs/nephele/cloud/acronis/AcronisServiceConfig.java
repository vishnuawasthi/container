package com.valuelabs.nephele.cloud.acronis;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.extern.slf4j.Slf4j;



@Slf4j
@Configuration
public class AcronisServiceConfig {
	
	@Value("${acronisservice.uri}")
	private String url;

	@Value("${acronisservice.login}")
	private String accountLoginPath;
	
	@Value("${acronisservice.logout}")
	private String logoutPath;
	
	@Value("${acronisservice.groups}")
	private String groupsPath;	
   
	@Value("${acronisservice.activatemail}") 
	private String activatemailPath;         

	@Value("${acronisservice.accounts}") 
	private String accountsPath;         

	@Value("${acronisservice.actions}") 
	private String actionsPath;         
	
	@Value("${acronisservice.admins}") 
	private String adminsPath;     
	
	                                         
	@Bean(name="acronisRestTemplate")
	public RestTemplate getAcronisServiceTemplate() {
		log.debug("Creating: RestTemplate acronisServiceTemplate");
		HttpClient httpClient = HttpClientBuilder.create().build();

		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		RestTemplate restTemplate = new RestTemplate(requestFactory);

		return restTemplate;
	}

	@Bean(name="loginUrlTemplate")
	public String getAcronisLoginUrlTemplate() {		
		return String.format("%s%s", url,accountLoginPath);		
	}
	@Bean(name="logoutUrlTemplate")
	public String getAcronisLogoutUrlTemplate() {	
		return String.format("%s%s", url,logoutPath);			
	}
	@Bean(name="listOfAdminsFromGroupUrlTemplate")
	public String getAcronislistOfAdminsFromGroupUrlTemplate() {	
		return String.format("%s%s", url,groupsPath);			
	}
	@Bean(name="groupsUrlTemplate")                                         
	public String getAcronislGroupsServiceUrlTemplate() {		
		return String.format("%s%s", url,groupsPath);			 
	}	
	@Bean(name="accountsUrlTemplate")                                                  
	public String getAcronislAccountsUrlTemplate() {	
		return String.format("%s%s", url,accountsPath);				
	}  	
	@Bean(name="actionsUrlTemplate")                                                  
	public String getAcronislActionsUrlTemplate() {	
		return String.format("%s%s", url,actionsPath);			
	}	
	@Bean(name="adminsUrlTemplate")                                                  
	public String getAcronislAdminsServiceUrlTemplate() {	
		return String.format("%s%s", url,adminsPath);			
	}           
	
	@Bean(name="activatemailUrlTemplate")                                                        
	public String getAcronislActivatemailServiceUrlTemplate() {	
		return String.format("%s%s", url,activatemailPath);				 
	}   
}                                                                                                    
