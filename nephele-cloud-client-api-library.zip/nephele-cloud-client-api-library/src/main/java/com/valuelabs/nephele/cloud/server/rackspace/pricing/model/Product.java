package com.valuelabs.nephele.cloud.server.rackspace.pricing.model;

public class Product
{
private String id;

private ProductOfferingPrice productOfferingPrice;

private String productCode;

private String status;

private ProductCharacteristic[] productCharacteristic;

private String description;

private Link link;

private String name;

private String salesChannel;

public String getId ()
{
return id;
}

public void setId (String id)
{
this.id = id;
}

public ProductOfferingPrice getProductOfferingPrice ()
{
return productOfferingPrice;
}

public void setProductOfferingPrice (ProductOfferingPrice productOfferingPrice)
{
this.productOfferingPrice = productOfferingPrice;
}

public String getProductCode ()
{
return productCode;
}

public void setProductCode (String productCode)
{
this.productCode = productCode;
}

public String getStatus ()
{
return status;
}

public void setStatus (String status)
{
this.status = status;
}

public ProductCharacteristic[] getProductCharacteristic ()
{
return productCharacteristic;
}

public void setProductCharacteristic (ProductCharacteristic[] productCharacteristic)
{
this.productCharacteristic = productCharacteristic;
}

public String getDescription ()
{
return description;
}

public void setDescription (String description)
{
this.description = description;
}

public Link getLink ()
{
return link;
}

public void setLink (Link link)
{
this.link = link;
}

public String getName ()
{
return name;
}

public void setName (String name)
{
this.name = name;
}

public String getSalesChannel ()
{
return salesChannel;
}

public void setSalesChannel (String salesChannel)
{
this.salesChannel = salesChannel;
}

@Override
public String toString()
{
return "ClassPojo [id = "+id+", productOfferingPrice = "+productOfferingPrice+", productCode = "+productCode+", status = "+status+", productCharacteristic = "+productCharacteristic+", description = "+description+", link = "+link+", name = "+name+", salesChannel = "+salesChannel+"]";
}
}

