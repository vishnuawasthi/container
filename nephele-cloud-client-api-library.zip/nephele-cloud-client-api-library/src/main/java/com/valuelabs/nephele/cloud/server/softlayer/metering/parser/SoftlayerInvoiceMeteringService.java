package com.valuelabs.nephele.cloud.server.softlayer.metering.parser;

import java.io.IOException;

import com.sun.syndication.io.FeedException;
import com.valuelabs.nephele.admin.rest.lib.event.SoftlayerMeteringDataCreatedEvent;

public interface SoftlayerInvoiceMeteringService {

	SoftlayerMeteringDataCreatedEvent loadInvoiceDataFromSoftlayer() throws IllegalArgumentException, FeedException, IOException, Exception;

}
