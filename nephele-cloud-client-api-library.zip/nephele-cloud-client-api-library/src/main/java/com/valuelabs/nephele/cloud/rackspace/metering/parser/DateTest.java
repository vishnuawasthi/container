package com.valuelabs.nephele.cloud.rackspace.metering.parser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class DateTest {

	public static void main(String[] args) throws ParseException {
		
		NepheleUtils utils = new NepheleUtils();
		log.debug("encrypt..:" + utils.encrypt("984e0b37658a37591b0796b7b813d11c359bd6d0e636405802494924c99c508d") + "End");
		// TODO Auto-generated method stub
		
			/*Date billingUTCStartDate = DateFormatterUtility.getPreviousMonthUTCDateFromDay(20);
			
		
		 	Date billingUTCEndDate = DateFormatterUtility.getUTCDateFromDay(19);
		 	billingUTCEndDate.setHours(23);
		 	billingUTCEndDate.setMinutes(59);
		 	billingUTCEndDate.setSeconds(59);
		    
		    
		    
		    Date billingEndDate = DateFormatterUtility.getDateFromDay(19);
		    
		    
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		    
		    SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    
		    Date currDateInUtcZone = dateFormatLocal.parse(sdf.format(new Date()));
		    
		    
		    /*Date formatStringToDateForAtomFeed =  DateFormatterUtility.formatStringToDateForAtomFeed("20");
		    
		    /*Calendar currentTime = Calendar.getInstance();
		    Date currDateInZone = dateFormatLocal.parse(sdf.format(new Date()));
		    
		
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		Calendar cal_Two = Calendar.getInstance(TimeZone.getTimeZone("UTC"));

		Calendar cal_Three = Calendar.getInstance();
		
		TimeZone.setDefault(TimeZone.getTimeZone("IST"));
		
		Calendar cal_four = Calendar.getInstance();
		*/
	}

}
