package com.valuelabs.nephele.cloud.rackspace.metering.parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import com.sun.syndication.io.FeedException;
import com.valuelabs.nephele.admin.rest.lib.resource.NepheleCloudFeedResources;
import com.valuelabs.nephele.cloud.rackspace.metering.parser.support.XmlFeedParserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class XmlFeedParser implements Parser {

	/** The Queue that is used for managing the objects */
	private BlockingQueue<Object> queue;

	private XmlFeedParserService.Impl service;

	/** Processing flag indicates whether file reading is in progress or not. */
	private boolean inProgress;

	private static final int queueBufferSize = 2000;

	private XmlFeedParserWrapper xmlFeedParserWrapper;;

	private String feedUrl;

	public XmlFeedParser(XmlFeedParserService.Impl xmlFeedParserService, String url) {
		this.queue = new LinkedBlockingQueue<Object>(queueBufferSize);
		this.service = xmlFeedParserService;
		this.feedUrl = url;
	}

	@Override
	public <T> void loadDataObjects() {
		// Enable progress flag
		setInProgress(true);
		try {
			//log.debug("loadDataObjects :  START");
			NepheleCloudFeedResources feed = service.readFromServer(feedUrl);
			xmlFeedParserWrapper = new XmlFeedParserWrapper();
			if (feed.getUuid()!=null) {
			List<Object> object = new ArrayList<Object>();
			object.add(feed);
			xmlFeedParserWrapper = new XmlFeedParserWrapper();
			xmlFeedParserWrapper.setParsedObjects(object);
			putIntoQueue(xmlFeedParserWrapper);
			}
			// list of entries
			List<Object> list = new ArrayList<Object>();
			if (!feed.getEntries().isEmpty()) {
				log.debug("Number of Records in Rackspace Stream :  "+feed.getEntries().size());
				list.addAll(feed.getEntries());

				List<Object> objects = list;
				xmlFeedParserWrapper = new XmlFeedParserWrapper();
				xmlFeedParserWrapper.setParsedObjects(objects);
				putIntoQueue(xmlFeedParserWrapper);
			}else{
				log.debug("Number of Records in Rackspace Stream : 0");
			}
		
		} catch (NullPointerException e) {
			log.debug("No Records found in Stream : " + e.getMessage());
			e.printStackTrace();

		} catch (IllegalArgumentException | FeedException e) {
			log.debug("Exception in FeedParser loadDataObjects()" + e.getMessage());

		} catch (IOException e) {
			log.debug("Exception in FeedParser loadDataObjects()" + e.getMessage());
		} finally {
			// set false for processing flag.
			setInProgress(false);
			//log.debug("loadDataObjects :  END");
		}

	}

	private void putIntoQueue(XmlFeedParserWrapper superdParserWrapper) {
		try {
			if (superdParserWrapper != null) {
				queue.put(superdParserWrapper);
			}

		} catch (InterruptedException e) {
			log.debug("Exception in FeedParser :putIntoQueue" + e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> Object getDataObject() {
		Object object = null;
		object = queue.poll();
		return ((T) object);
	}

	/**
	 * @return the inProgress
	 */
	@Override
	public boolean isReadingInProgress() {
		return inProgress;
	}

	/**
	 * @param inProgress
	 *            the inProgress to set
	 */
	public void setInProgress(boolean inProgress) {
		this.inProgress = inProgress;
	}

	@Override
	public int sizeOfRecordsInMemory() {
		return queue.size();
	}

	@Override
	public <T> List<Object> getFailedRecords() {
		// return failed records.
		return null;
		// return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.overstock.merch.books.Parser#getAllPojoClasses()
	 */
	@Override
	public <T> Collection<T> getAllPojoClasses() {
		// TODO Auto-generated method stub
		return null;
	}
}
