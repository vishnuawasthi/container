package com.valuelabs.nephele.cloud.server.rackspace;

import static com.valuelabs.nephele.cloud.server.rackspace.Constants.PROVIDER;

import java.io.IOException;

import org.jclouds.compute.ComputeService;
import org.jclouds.openstack.nova.v2_0.NovaApi;
import org.jclouds.openstack.nova.v2_0.domain.Flavor;
import org.jclouds.openstack.nova.v2_0.domain.Image;
import org.jclouds.openstack.nova.v2_0.domain.ServerCreated;
import org.jclouds.openstack.nova.v2_0.extensions.FlavorExtraSpecsApi;
import org.jclouds.openstack.nova.v2_0.features.ServerApi;

import com.google.common.collect.FluentIterable;
import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;
import com.valuelabs.nephele.cloud.connection.factory.CloudConnection;

public class RackspaceCloudConnection implements CloudConnection {

	@Override
	public NovaApi getNovaConnection(String username, String apiKey) {
		//String username="synnexadmin";
		//String apiKey="cfb360bd7d9b4dc2a18fee65ec030690";
		NovaApi novaApi =RackspaceNovaApi.getInstance().initNovaApi(PROVIDER, username, apiKey);
		return novaApi;
	}
	
	@Override
	public ServerApi getServerConnection(NovaApi novaApi, String locationId) {
		ServerApi serverApi =RackspaceNovaApi.getInstance().initServerApi(novaApi, locationId);
		return serverApi;
	}

	@Override
	public ServerCreated createServer(ServerApi serverApi, AcquireServerDetails acquireServerDetails) throws Exception {
		return RackspaceNovaApi.getInstance().createServer(serverApi, acquireServerDetails);
		
	}
	
	@Override
	public FluentIterable<Image> listImages(NovaApi novaApi) {
		return RackspaceNovaApi.getInstance().listImages(novaApi);
	}


	@Override
	public FluentIterable<Flavor> listFlavors(NovaApi novaApi) {
		return RackspaceNovaApi.getInstance().listFlavours(novaApi);
	}

	@Override
	public FlavorExtraSpecsApi getFlavorExtraSpecs(NovaApi novaApi) {
		return RackspaceNovaApi.getInstance().getFlavorExtraSpecs(novaApi);
	}
	
	@Override
	public void close(NovaApi novaApi) throws IOException {
		RackspaceNovaApi.getInstance().close(novaApi);
		
	}

}
