package com.valuelabs.nephele.cloud.server.rackspace.inventory;

import com.valuelabs.nephele.admin.rest.lib.event.RackspacePricingDataCreatedEvent;

public interface RackspacePricingDataService {
	RackspacePricingDataCreatedEvent loadProudctPriceJsonData();
}
