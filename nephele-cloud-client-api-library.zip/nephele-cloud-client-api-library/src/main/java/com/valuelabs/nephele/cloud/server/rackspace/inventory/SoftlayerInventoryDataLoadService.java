package com.valuelabs.nephele.cloud.server.rackspace.inventory;

import org.springframework.stereotype.Component;

import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.cloud.connection.factory.CloudTypes;

@Component
public interface SoftlayerInventoryDataLoadService {
	
	public void loadImageData(CloudService service) throws Exception;
	public void loadRamConfiguration(CloudService service) throws Exception;
	public void loadCpuConfiguration(CloudService service) throws Exception;
	public void loadDiskConfiguration(CloudService service) throws Exception;
	public void loadLocations(CloudService service) throws Exception;
	public void loadFlavorData(CloudService service) throws Exception;
	public void loadProducts(CloudService service) throws Exception;
	public void loadProductPlans(CloudService service) throws Exception;
	public void loadAdditionalPrice(CloudService service);
	

}
