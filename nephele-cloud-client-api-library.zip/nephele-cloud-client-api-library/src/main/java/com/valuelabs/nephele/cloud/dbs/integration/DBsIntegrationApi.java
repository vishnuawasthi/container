package com.valuelabs.nephele.cloud.dbs.integration;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.valuelabs.nephele.cloud.server.rackspace.pricing.model.MySimpleClientHttpRequestFactory;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Service
public class DBsIntegrationApi {	
	
	@Autowired	
	private RestTemplate dbsRestTemplate;

	@Autowired
	private String dbsResellerXmlTemplate;
	
	private static final HostnameVerifier PROMISCUOUS_VERIFIER = new HostnameVerifier() {
		@Override
		public boolean verify(String s, SSLSession sslSession) {
			return true;
		}
	};
	
	/**
     * dbsIntegration exchangeProductsData Requires 
     * @param ProductsRequest	      
    */
	public String exchangeProductsData(String productsRequest) {
		final MySimpleClientHttpRequestFactory factory = new MySimpleClientHttpRequestFactory(PROMISCUOUS_VERIFIER);
		dbsRestTemplate.setRequestFactory(factory);
		log.debug("dbsIntegration exchangeProductsData Calling START :", dbsResellerXmlTemplate);
		String result = null;	
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_XML);
		HttpEntity<String> response = null;
		HttpEntity<String> requestEntity = new HttpEntity<String>(productsRequest ,headers);
		
		response = dbsRestTemplate.exchange(dbsResellerXmlTemplate, HttpMethod.POST, requestEntity, String.class);		
		result = response.getBody();		
		//log.debug("response....."+result);
		log.debug("dbsIntegration exchangeProductsData  Calling END");
		return result;
	}

}
