package com.valuelabs.nephele.alerts.notifier.service;

import com.valuelabs.nephele.alerts.notifier.Application;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by srikanth on 6/8/15.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=Application.class)
@Ignore
public class MailServiceTest {

  @Autowired
  private MailService mailService;

  @Test
  public void deliverEmailTest() {
    List<String> toList = new ArrayList<>();
    toList.add("srikanth.nagaboina@valuelabs.net");
    mailService.sendEmail(toList, null, null, "Test Email From Nephele", "Email Functionality is working fine !!!");
  }
}

