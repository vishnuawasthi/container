package com.valuelabs.nephele.alerts.notifier.util;

import lombok.extern.slf4j.Slf4j;

import java.util.Collection;

/**
 * Created by srikanth on 6/8/15.
 */
@Slf4j
public class Utility {

  /**
   * Method to check whether the passed object is Not empty or not.
   *
   * @param obj - to be checked.
   * @return - <code>true</code> if the object is not empty.
   */
  public static boolean isNotEmpty(final Object obj) {
    boolean returnVal = false;
    try {
      if (obj != null) {
        if (obj instanceof String) {
          String str = (String) obj;
          if (str.trim().length() > 0) {
            returnVal = true;
          }
        } else if (obj instanceof Collection) {
          Collection col = (Collection) obj;
          if (!col.isEmpty()) {
            returnVal = true;
          }
        }
      }
    } catch (Exception e) {
      log.error("=== Error from Utility.isNotEmpty() " + e.getMessage());
    }

    return returnVal;
  }
}
