package com.valuelabs.nephele.alerts.notifier;

import com.valuelabs.nephele.alerts.notifier.service.MailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by srikanth on 6/8/15.
 */
@Slf4j
@Configuration
@EnableAspectJAutoProxy
@EnableHystrixDashboard
@ConditionalOnExpression("${hystrix.enabled:true}")
@EnableHystrix
@ComponentScan(basePackages = "com.valuelabs.nephele")
@EnableAutoConfiguration
public class Application {

  public Application() {
  }

  public static void main(String[] args) {
    log.info("Start of nephele-alerts-notifier");
    ApplicationContext ctx = SpringApplication.run(Application.class, args);
    /*MailService mailService = ctx.getBean(MailService.class);
    List<String> toList = new ArrayList<>();
    toList.add("srikanth.nagaboina@valuelabs.com");
    mailService.sendEmail(toList, null, null, "Test Mail from Nephele", "Email Notification is working fine");*/
    log.info("End of nephele-alerts-notifier");
  }

}
