package com.valuelabs.nephele.alerts.notifier.service;

import java.util.Map;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

@Component
public class VelocityService {

	@Autowired
	VelocityEngine engine;
	
	public String buildTemplate(Map<String, Object> model,String templateLocation) throws Exception {

        return VelocityEngineUtils.mergeTemplateIntoString(this.engine,templateLocation, "UTF-8", model);         

  }
}
