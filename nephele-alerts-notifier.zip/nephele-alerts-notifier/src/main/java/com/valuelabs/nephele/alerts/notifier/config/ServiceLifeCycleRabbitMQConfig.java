package com.valuelabs.nephele.alerts.notifier.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.annotation.PostConstruct;


@Slf4j
@Configuration
public class ServiceLifeCycleRabbitMQConfig {

  @Autowired
  AmqpAdmin rabbitAdmin;

  public static final String EXCHANGE_NAME = "nephele.cloud.rackspace.exchange";

  //ServerAction=AlertsNotification
  public static final String ALERT_QUEUE_NAME = "nephele.cloud.alerts.notifier.queue";
  public static final String ALERT_ROUTING_KEY = "nephele.cloud.alerts.notifier.key";


  @Bean(name = "alertsQueue")
  public Queue getAlertsQueue() {
    return new Queue(ALERT_QUEUE_NAME, true);
  }

  @Bean
  public DirectExchange getDirectExchange() {
    return new DirectExchange(EXCHANGE_NAME, true, false);
  }

  @Bean(name = "alertsBinding")
  Binding getAlertsBinding(Queue alertsQueue, DirectExchange directExchange) {
    return BindingBuilder.bind(alertsQueue).to(directExchange).with(ALERT_ROUTING_KEY);
  }


  @PostConstruct
  public void initializeMessageQueue() {
    log.debug("initializeMessageQueue");

    DirectExchange directExchange = getDirectExchange();

    Queue alertsQueue = getAlertsQueue();
    Binding alertsBinding = getAlertsBinding(alertsQueue, directExchange);

    rabbitAdmin.declareExchange(directExchange);

    rabbitAdmin.declareQueue(alertsQueue);
    rabbitAdmin.declareBinding(alertsBinding);

  }

}
