package com.valuelabs.nephele.alerts.notifier.service;

import com.valuelabs.nephele.admin.rest.lib.event.AlertsNotificationEvent;
import com.valuelabs.nephele.alerts.notifier.util.Utility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.valuelabs.nephele.alerts.notifier.config.ServiceLifeCycleRabbitMQConfig.ALERT_ROUTING_KEY;
import static com.valuelabs.nephele.alerts.notifier.config.ServiceLifeCycleRabbitMQConfig.EXCHANGE_NAME;

/**
 * Created by Srikanth Nagaboina, Valuelabs on 6/8/15.
 */
@Component
public interface MailService {

  /**
   * This method is responsible for the triggering an email with the given details.
   *
   * @param toList  - List of the TO Email Id's
   * @param ccList  - List of the CC Email Id's
   * @param bccList - List of the BCC Email Id's
   * @param subject - Email Subject
   * @param body    - Email body
   */
  void sendEmail(List<String> toList, List<String> ccList, List<String> bccList, String subject, String body);

  void deliverEmail(AlertsNotificationEvent event);

  void sendMailWithAttachment(List<String> toList, List<String> ccList, List<String> bccList, String subject, String body, String filepath);

  @Service
  @Slf4j
  static class Impl implements MailService {

    @Autowired
    AmqpTemplate template;
    @Autowired
    JavaMailSender javaMailSender;
    @Value("${mail.from}")
    private String fromAddress;

    public Impl() {
      log.info("Creating " + this.getClass().getName() + " bean");
    }

    @Override
    public synchronized void sendEmail(List<String> toList, List<String> ccList, List<String> bccList, String subject, String body) {
      //SimpleMailMessage mailMessage = new SimpleMailMessage();
      try {
        AlertsNotificationEvent event = AlertsNotificationEvent.builder().toList(toList)
            .ccList(ccList).bccList(bccList).body(body).subject(subject).build();
        template.convertAndSend(EXCHANGE_NAME, ALERT_ROUTING_KEY, event);
      } catch (Exception exception) {
        log.error("Exception occurs while sending an email", exception);
      }

    }

    /*@Override
    public void deliverEmail(AlertsNotificationEvent event) {
      SimpleMailMessage mailMessage = new SimpleMailMessage();
      try {
        if (null != event) {
          //To list
          if (Utility.isNotEmpty(event.getToList())) {
            Set<String> uniqueIds = new HashSet<>(event.getToList());
            for (String to : uniqueIds) {
              mailMessage.setTo(to);
            }
          }
          // CC list
          if (Utility.isNotEmpty(event.getCcList())) {
            Set<String> uniqueIds = new HashSet<>(event.getCcList());
            for (String cc : uniqueIds) {
              mailMessage.setCc(cc);
            }
          }
          //Bcc list
          if (Utility.isNotEmpty(event.getBccList())) {
            Set<String> uniqueIds = new HashSet<>(event.getBccList());
            for (String bcc : uniqueIds) {
              mailMessage.setBcc(bcc);
            }
          }
          //Subject
          if (Utility.isNotEmpty(event.getSubject()))
            mailMessage.setSubject(event.getSubject());

          //From Address get this from the application.yml files
          if (Utility.isNotEmpty(fromAddress))
            mailMessage.setFrom(fromAddress);

          //Body
          if (Utility.isNotEmpty(event.getBody()))
            mailMessage.setText(event.getBody());

          //sending mail
          javaMailSender.send(mailMessage);
        }
      } catch (Exception exception) {
        log.error("Exception occurs while sending an email", exception);
      }
    }*/

    @Override
    public void deliverEmail(AlertsNotificationEvent event) {
      MimeMessage message = javaMailSender.createMimeMessage();

      try {
        MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);

        if (Utility.isNotEmpty(event.getToList())) {
          Set<String> uniqueIds = new HashSet<>(event.getToList());
          for (String to : uniqueIds) {
            messageHelper.setTo(to);
          }
        }
        // CC list
        if (Utility.isNotEmpty(event.getCcList())) {
          Set<String> uniqueIds = new HashSet<>(event.getCcList());
          for (String cc : uniqueIds) {
            messageHelper.setCc(cc);
          }
        }
        //Bcc list
        if (Utility.isNotEmpty(event.getBccList())) {
          Set<String> uniqueIds = new HashSet<>(event.getBccList());
          for (String bcc : uniqueIds) {
            messageHelper.setBcc(bcc);
          }
        }
        //Subject
        if (Utility.isNotEmpty(event.getSubject()))
          messageHelper.setSubject(event.getSubject());

        //From Address get this from the application.yml files
        if (Utility.isNotEmpty(fromAddress))
          messageHelper.setFrom(fromAddress);

        //Body
        if (Utility.isNotEmpty(event.getBody()))
          messageHelper.setText(event.getBody(), true);

        //Adding attachment via filepath
        if (Utility.isNotEmpty(event.getFilePath())) {
          FileSystemResource file = new FileSystemResource(event.getFilePath());
          messageHelper.addAttachment(file.getFilename(), file);
        }

        //sending mail
        javaMailSender.send(message);

      } catch (MessagingException e) {
        log.error("Exception occurs while sending an email", e);

      }
    }

    public void sendMailWithAttachment(List<String> toList, List<String> ccList, List<String> bccList, String subject, String body, String filepath) {
      //SimpleMailMessage mailMessage = new SimpleMailMessage();
      try {
        AlertsNotificationEvent event = AlertsNotificationEvent.builder().toList(toList)
            .ccList(ccList).bccList(bccList).body(body).subject(subject).filePath(filepath).build();
        template.convertAndSend(EXCHANGE_NAME, ALERT_ROUTING_KEY, event);
      } catch (Exception exception) {
        log.error("Exception occurs while sending an email", exception);
      }

    }

  }
}
