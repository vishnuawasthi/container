package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.BillingLifeCycleMQConfig.EXCHANGE_NAME;
import static com.valuelabs.nephele.manager.configuration.BillingLifeCycleMQConfig.METERING_DATA_ROUTING_KEY;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.valuelabs.nephele.admin.rest.lib.event.RackspaceMeteringDataCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.service.RackspaceMeteringDataService;



@Slf4j
@RestController
@RequestMapping(value = "/manager/meteringData")
@Transactional
public class RackspaceMeteringDataCommandController {

	@Autowired
	private RackspaceMeteringDataService service;
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	

	/**
	 * This is used to import Rackspace metering data into Database
	 * @param file
	 * @return
	 */
	@RequestMapping(value="/importCSV", method=RequestMethod.POST)
    public @ResponseBody HttpEntity<String> importRackspaceMeteringDataFromFile(@RequestParam(value="file") MultipartFile file ){
        log.info(" importRackspaceMeteringDataFromFile() - Start");
        String status = "";
        RackspaceMeteringDataCreatedEvent response = null;
      try {
        if (!file.isEmpty()) {
        	response = service.readRackspaceMeteringDataFromCSV(file);
            status = response.getStatus();
            Thread.sleep(2000);
            rabbitTemplate.convertAndSend(EXCHANGE_NAME, METERING_DATA_ROUTING_KEY, response.getJobDetails());
            log.info(" importRackspaceMeteringDataFromFile() - Start");
        } else {
        	status = "You failed to upload " + file.getName() + " because the file is empty.";
        	return new ResponseEntity<String>(status,HttpStatus.BAD_REQUEST);
        }

      } catch (Exception e) {
          log.error("Exception occurs while processing metering data: ", e.getMessage());
          e.printStackTrace();
      }
        return new ResponseEntity<String>(status,HttpStatus.OK);
    }
}
