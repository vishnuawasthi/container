package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountConfigDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadPremiumGroupDiscountConfigEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadPremiumGroupDiscountConfigsEvent;
import com.valuelabs.nephele.admin.rest.lib.service.PremiumGroupDiscountConfigQueryService;
import com.valuelabs.nephele.manager.assembler.PremiumGroupDiscountAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.PremiumGroupDiscountConfigResource;

@Slf4j
@RestController	
@RequestMapping("/manager/PremiumGroupDiscountConfig")
@Transactional
public class PremiumGroupDiscountConfigQueryController {

	@Autowired
	private PremiumGroupDiscountAssembler assembler;

	@Autowired
	private PremiumGroupDiscountConfigQueryService service;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PremiumGroupDiscountConfigResource> readPremiumGroupDiscountConfig(@PathVariable Long id) {
		log.info("readPremiumGroupDiscountConfig() START");
		ReadPremiumGroupDiscountConfigEvent request=new ReadPremiumGroupDiscountConfigEvent().setId(id);	
		EntityReadEvent<PremiumGroupDiscountConfigDetails> event = service.readPremiumGroupDiscountConfigService(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		PremiumGroupDiscountConfigDetails entity = event.getEntity();
		log.info("readPremiumGroupDiscountConfig() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	/*@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<PremiumGroupDiscountConfigResource>> readPremiumGroupDiscountConfigs(
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<PremiumGroupDiscountConfigDetails> pagedAssembler) {
		log.info("readPremiumGroupDiscountConfigs() START");
		ReadPremiumGroupDiscountConfigsEvent request=new ReadPremiumGroupDiscountConfigsEvent().setPageable(pageable);
		PageReadEvent<PremiumGroupDiscountConfigDetails> event=service.readPremiumGroupDiscountConfigServices(request);
		Page<PremiumGroupDiscountConfigDetails> page= event.getPage();
		PagedResources<PremiumGroupDiscountConfigResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readPremiumGroupDiscountConfigs() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}*/
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<PremiumGroupDiscountConfigResource>>readPremiumGroupDiscountConfigByNameandStatusandActiveDates(
			@RequestParam(value = "sheetName", required=false) String sheetName,@RequestParam(value = "serviceId", required=false) Long serviceId, @RequestParam(value = "status", required=false) String status,@RequestParam(value = "activeFrom", required=false) String activeFrom,@RequestParam(value = "activeTo", required=false) String activeTo,
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<PremiumGroupDiscountConfigDetails> pagedAssembler) {
		log.info("readPremiumGroupDiscountConfigByNameandStatusandActiveDates() - start");

		ReadPremiumGroupDiscountConfigsEvent request=new ReadPremiumGroupDiscountConfigsEvent().setPageable(pageable)
				.setActiveFrom(activeFrom).setActiveTo(activeTo).setSheetName(sheetName).setStatus(status).setServiceId(serviceId);

		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);

		PageReadEvent<PremiumGroupDiscountConfigDetails> event = service
				.readPremiumGroupDiscountConfigByNameandStatusandActiveDates(request);
		
		Page<PremiumGroupDiscountConfigDetails> page = event.getPage();
		PagedResources<PremiumGroupDiscountConfigResource> pagedResources = pagedAssembler.toResource(page,
				assembler);
		
		log.info("readPremiumGroupDiscountConfigByNameandStatusandActiveDates() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
