package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.common.base.Strings;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
import com.valuelabs.nephele.manager.controller.CloudProductPlanQueryController;
import com.valuelabs.nephele.manager.resource.ProductPlanResource;

@Slf4j
@Service
public class CloudProductPlanAssembler extends ResourceAssemblerSupport<CloudProductPlanDetails, ProductPlanResource>{
	
	public CloudProductPlanAssembler() {
		super(CloudProductPlanQueryController.class, ProductPlanResource.class);
	}
	
	@Override
	public ProductPlanResource toResource(CloudProductPlanDetails details) {
		log.debug("toResource() : START");
		ProductPlanResource resource = instantiateResource(details);
		resource = ProductPlanResource.builder().planId(details.getProductPlanId())
												.price(null ==details.getPrice() ? "" : details.getPrice().toString() )
												.vendorPrice(null == details.getVendorPrice() ? "" : details.getVendorPrice().toString())
												.planName(details.getPlanName())
												.status(details.getStatus())
												.configurationId(details.getFlavorId())
												.configurationName(details.getConfigurationName())
												.flavorCategory(details.getFlavorCategory())
												.locationId(details.getLocationId())
												.productId(details.getProductId())
												.serviceId(details.getServiceId())
												.locationName(details.getLocationName())
												.productId(details.getProductId())
												.productName(details.getProductName())
												.operatingSystemId(details.getOperatingSystemId())
												.operatingSystemName(details.getOperatingSystemName())
												.serviceId(details.getServiceId())
												.serviceName(details.getServiceName())
												.planCode(details.getPlanCode())
												.vendorPlanCode(details.getVendorPlanCode())
												.isTrialPlan(details.getIsTrialPlan())
												.pricingModel(details.getPricingModel())
												.description(details.getDescription())
												.productDescription(details.getProductDescription())
												.build();
		resource.add(linkTo(
				methodOn(CloudProductPlanQueryController.class).readProductPlan(details.getProductPlanId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}
	
	public CloudProductPlanDetails fromResource(ProductPlanResource resource) {
		log.debug("fromResource() START:{}",resource);
		CloudProductPlanDetails details = CloudProductPlanDetails.builder().productPlanId(resource.getPlanId())
																		   .price(Double.parseDouble(resource.getPrice()))
																		   .vendorPrice(Double.parseDouble(resource.getVendorPrice()==null ? "0.0" : resource.getVendorPrice()))
																		   .planName(resource.getPlanName())
																		   .details(resource.getDetails())
																		   .status(resource.getStatus())
																		   .flavorCategory(resource.getFlavorCategory())
																		   .locationId(resource.getLocationId())
																		   .productId(resource.getProductId())
																		   .serviceId(resource.getServiceId())
																		   .vendorPlanCode(resource.getVendorPlanCode())
												                           .isTrialPlan(resource.getIsTrialPlan())
												                           .pricingModel(resource.getPricingModel())
												                           .description(resource.getDescription())
																		   //.planCode(resource.getPlanCode())
																		   .build();
				log.debug("fromResource() - END");
		return details;
	}
	
	public List<CloudProductPlanDetails> fromResouces(List<ProductPlanResource> resources) {
		log.debug("fromResouces()  - START");
		List<CloudProductPlanDetails> detailsList = new ArrayList<CloudProductPlanDetails>();
		for (ProductPlanResource resource : resources) {
			CloudProductPlanDetails details = CloudProductPlanDetails.builder().productPlanId(resource.getPlanId())
																			   .price(Double.parseDouble(resource.getPrice()))																			  
																			   .planName(resource.getPlanName())
																			   .details(resource.getDetails())
																			   .status(resource.getStatus())
																			   .flavorCategory(resource.getFlavorCategory())
																			   .locationId(resource.getLocationId())
																			   .productId(resource.getProductId())
																			   .serviceId(resource.getServiceId())
																			   .vendorPlanCode(resource.getVendorPlanCode())
												                               .isTrialPlan(resource.getIsTrialPlan())
												                               .pricingModel(resource.getPricingModel())
												                               .description(resource.getDescription())
																			   // .planCode(resource.getPlanCode())
																			   .build();
			detailsList.add(details);
		}
		log.debug("fromResouce()  - END");
		return detailsList;
	}
	
	public CloudProductPlanDetails fromResource_update(ProductPlanResource resource) {
		log.debug("fromResource() START:{}",resource);
		CloudProductPlanDetails details = CloudProductPlanDetails.builder().productPlanId(resource.getPlanId())
														.planName(resource.getPlanName())
														.status(resource.getStatus())
														.build();
		if(! Strings.isNullOrEmpty(resource.getPrice())){
			details.setPrice(Double.parseDouble(resource.getPrice()));
		}
		
		log.debug("fromResource() - END");
		return details;
	}





    public List<CloudProductPlanDetails> fromResouces_update(List<ProductPlanResource> resources) {
		log.debug("fromResouces()  - START");
		List<CloudProductPlanDetails> detailsList = new ArrayList<CloudProductPlanDetails>();
		for (ProductPlanResource resource : resources) {
			CloudProductPlanDetails details = CloudProductPlanDetails.builder().productPlanId(resource.getPlanId())
																			   .status(resource.getStatus())
																			   //.vendorPlanCode(resource.getVendorPlanCode())
																			   //.isTrialPlan(resource.getIsTrialPlan())
																			   //.planName(resource.getPlanName())
																			   //.planCode(resource.getPlanCode())
																			   //.description(resource.getDescription())
																			   .build();
			if( ! Strings.isNullOrEmpty(resource.getPrice())){
				details.setPrice(Double.parseDouble(resource.getPrice()));
			}
			/*if( ! Strings.isNullOrEmpty(resource.getVendorPrice())){
				details.setVendorPrice(Double.parseDouble(resource.getVendorPrice()));
			}*/
			detailsList.add(details);
		}
		log.debug("fromResouce()  - END");
		return detailsList;
	}
	
  public List<ProductPlanResource> fromDetailsListToResourcesList(List<CloudProductPlanDetails> detailsList) {
	log.debug("fromDetailsListToResourcesList() - start");
	List<ProductPlanResource> resourceList = null;

	if (!CollectionUtils.isEmpty(detailsList)) {
	  resourceList = new ArrayList<ProductPlanResource>();
	  for (CloudProductPlanDetails details : detailsList) {
		ProductPlanResource resource = ProductPlanResource.builder()
                                                			.planId(details.getProductPlanId())
                                                			.status(details.getStatus())
                                                			.build();
		resourceList.add(resource);
	  }
	  
	}
	log.debug("fromDetailsListToResourcesList() - end");
	return resourceList;

  }
	
}
