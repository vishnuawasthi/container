package com.valuelabs.nephele.marketplace.controller;

import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_CUSTOMER_KEY;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_RESELLER_KEY;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.BusinessRuleNames;
import com.valuelabs.nephele.admin.data.api.NomadeskVendorPlanCode;
import com.valuelabs.nephele.admin.data.api.OrderStatus;
import com.valuelabs.nephele.admin.data.entity.CloudAccount;
import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;
import com.valuelabs.nephele.admin.data.repository.CloudAccountRepository;
import com.valuelabs.nephele.admin.data.repository.CloudAccountSpecifications;
import com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanyRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServerActionRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudBusinessRuleDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.RackspaceTerminateServerDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudOrderCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudOrderEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServerEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.RackspaceTerminateServerEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudBusinessRulesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServerEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServersEvent;
import com.valuelabs.nephele.admin.rest.lib.event.RebootServerEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ResizeServerEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ServerPasswordResetEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudBusinessRuleQueryService;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudOrderQueryService;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudOrderServiceLifeCycleService;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudProductPlanQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAccountQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCustomerCompanyQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudOrderCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServerActionCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServerCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServerQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServiceQueryService;
import com.valuelabs.nephele.admin.rest.lib.validation.CloudOrderValidationService;
import com.valuelabs.nephele.alerts.notifier.service.MailService;
import com.valuelabs.nephele.alerts.notifier.service.VelocityService;
import com.valuelabs.nephele.cloud.connection.factory.CloudTypes;
import com.valuelabs.nephele.cloud.service.dispatcher.ServiceDispatcher;
import com.valuelabs.nephele.manager.resource.CloudAccountResource;
import com.valuelabs.nephele.marketplace.assembler.AcquireServerAssembler;
import com.valuelabs.nephele.marketplace.assembler.CloudServerAssembler;
import com.valuelabs.nephele.marketplace.dispatcher.factory.CloudConnectionFactory;
import com.valuelabs.nephele.marketplace.resource.AcquireServerResource;
import com.valuelabs.nephele.marketplace.resource.CloudOrderResponseResource;
import com.valuelabs.nephele.marketplace.resource.PlaceOrderResource;
import com.valuelabs.nephele.marketplace.resource.PlaceOrderResources;
import com.valuelabs.nephele.marketplace.resource.ResetServerPasswordResource;
import com.valuelabs.nephele.marketplace.resource.ResizeServerResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/marketplace")
@Transactional
public class CloudOrderServiceLifeCycleController {

	@Autowired
  RabbitTemplate rabbitTemplate;
  @Autowired
  CloudServerCommandService serverCommandService;
  @Autowired
  CloudServerQueryService serverQueryService;
  @Autowired
  CloudOrderCommandService orderCommandService;
  @Autowired
  CloudOrderQueryService orderQueryService;
  @Autowired
  CloudOrderServiceLifeCycleService cloudOrderServiceLifeCycleService;
  @Autowired
  CloudServerActionCommandService cloudServerActionCommandService;
  @Autowired
  @Qualifier("cloudConnectionFactory")
  CloudConnectionFactory cloudConnectionFactory;
  @Autowired
  CloudServiceQueryService cloudServiceQueryService;
  @Autowired
  CloudProductPlanQueryService cloudProductPlanQueryService;
  @Autowired
  CloudAccountQueryService cloudAccountQueryService;
  @Autowired
  CloudCustomerCompanyQueryService cloudCustomerCompanyQueryService;
  @Autowired
  CloudBusinessRuleQueryService cloudBusinessRuleQueryService;
  @Autowired
  CloudCustomerCompanyRepository companyRepository;
  @Autowired
  CloudServerActionRepository serverActionRepository;

  /*@Autowired
  CloudCustomerCompanyDAO cloudCustomerCompanyDAO;*/
	@Autowired
  CloudAccountRepository accountRepository;
  @Autowired
  CloudAccountQueryService accountQueryService;
  @Autowired
  VelocityService velocityService;
  @Autowired
  MailService mailService;
  @Autowired
  private AcquireServerAssembler assember;
  @Autowired
  private CloudServerAssembler cloudServerAssembler;
  @Autowired
  private CloudOrderValidationService cloudOrderValidationService;
  @Value("${customerCompany.NO_CUST_FOR_CODE}")
	private String customerErrorMessage;
	
	@Value("${plan.NO_PLAN_FOR_CODE}")
	private String planErrorMessage;
	
	@Value("${businessRule.NO_RULE_FOR_NAME}")
	private String businessRuleErrorMessage;
	
	@Value("${nepheleServer.resizeMessage}")
	private String resizeMessage;
	
	@Value("${nepheleServer.confirmResizeMessage}")
	private String confirmResizeMessage;
	
	@Value("${nepheleServer.revertResizeMessage}")
	private String revertResizeMessage;
	
	@Value("${nepheleServer.serverSync}")
	private String syncServersMessage;
	
	/*@RequestMapping(value = "/checkServerConnection", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RackspaceConnectionCheckResponseResource> checkRackspaceConnection(@RequestBody RackspaceConnectionCheckResource resource) {
		Boolean isConnected = false;
		String errorMessage = null;
		HttpStatus statusCode = HttpStatus.OK;
		ReadServiceEvent readServiceEvent = new ReadServiceEvent().setId(resource.getServiceId());
		EntityReadEvent<CloudServiceDetails> cloudServiceDetailsEvent = cloudServiceQueryService.readService(readServiceEvent);
		CloudServiceDetails cloudServiceDetails = cloudServiceDetailsEvent.getEntity();
		String serviceCode = cloudServiceDetails.getServiceCode();
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(serviceCode));
		try {
			isConnected = dispatchService.checkServerConnection(resource);
		} catch(AuthorizationException e){
			isConnected = false;
			errorMessage = e.getMessage();
			statusCode = HttpStatus.valueOf(401);
		}catch (Exception e) {
			isConnected = false;
			errorMessage = e.getMessage();
			statusCode = HttpStatus.valueOf(500);
		}
		
		RackspaceConnectionCheckResponseResource responseResource = RackspaceConnectionCheckResponseResource.builder().isConnected(isConnected)
																													  .errorMessage(errorMessage)
																													  .build();
		
		return new ResponseEntity<RackspaceConnectionCheckResponseResource>(responseResource, statusCode);
	}*/

	@RequestMapping(value = "/orders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudOrderResponseResource> createServer(@RequestBody PlaceOrderResource resource, 
			@RequestHeader(value = X_CUSTOMER_KEY, required=true) String externalCustomerCompanyCode) {
		log.info("createServer()  - START");
		CloudOrderResponseResource orderResponse = null;
		CloudCustomerCompany customerCompany = null;
		CloudProductPlan productPlan = null;
		CloudBusinessRuleDetails ruleDetails = null;
		//CloudResellerCompany resellerCompany  = null;
		
		/*ObjectMapper mapper = new ObjectMapper();
		CloudProduct selectedProduct = cloudOrderServiceLifeCycleService.getProductDetailsById(resource.getProductId());
		if(selectedProduct == null) 
			throw new ResourceNotFoundException("CloudProduct", resource.getProductId());
		
		String json = "";
		try {
			json = mapper.writeValueAsString(resource.getPlan());
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		if(externalCustomerCompanyCode == null){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
		try{
			customerCompany = cloudCustomerCompanyQueryService.findByCloudCustomerCompanyCode(externalCustomerCompanyCode);
			
			if(null == customerCompany) {
				orderResponse = CloudOrderResponseResource.builder().errorMessage(customerErrorMessage + externalCustomerCompanyCode).build();
				return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
			}
			
			//resellerCompany = customerCompany.getCloudResellerCompany();
			
			/*if(!StringUtils.isEmpty(resellerCompany) && !StringUtils.isEmpty(resellerCompany.getCreditCardExpiryDate()) ) {
			  boolean  result = cloudOrderValidationService.validateResellerCreditCard(resellerCompany.getCreditCardExpiryDate());
			  if(result!=true) {
				throw new NepheleException("Your credit card has been expired.Please enter valid credit card details.");
			  }
			}*/
			
			productPlan = cloudOrderServiceLifeCycleService.getProductPlanDetailsById(resource.getPlanId());
			if(null == productPlan) {
				orderResponse = CloudOrderResponseResource.builder().errorMessage(planErrorMessage + resource.getPlanId()).build();
				return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
			}
			
			ReadCloudBusinessRulesEvent request = new ReadCloudBusinessRulesEvent().setRuleName(BusinessRuleNames.ORDER_PREFIX.name());
			EntityReadEvent<CloudBusinessRuleDetails> ruleDetailsEvent = cloudBusinessRuleQueryService.readCloudBusinessRulesByName(request);
			ruleDetails = ruleDetailsEvent.getEntity();
			if(null == ruleDetails) {
				orderResponse = CloudOrderResponseResource.builder().errorMessage(businessRuleErrorMessage + resource.getPlanId()).build();
				return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
			}
		}
		catch(NepheleException e){
			orderResponse = CloudOrderResponseResource.builder().errorMessage(e.getMessage()).build();
			return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
		}
		catch(Exception e){
			orderResponse = CloudOrderResponseResource.builder().errorMessage(customerErrorMessage + externalCustomerCompanyCode).build();
			return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
		}
		
		resource.setCustomerId(customerCompany.getId());
		
		CloudResellerCompany cloudResellerCompany = customerCompany.getCloudResellerCompany();
		resource.setResellerCompanyId(cloudResellerCompany.getId());
		resource.setExternalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode());
		resource.setResellerEmail(cloudResellerCompany.getEmail());
		resource.setRuleValue(ruleDetails.getRuleValue());
		
		if(productPlan.getPlanCode().equalsIgnoreCase("softlayer_cloud") || NomadeskVendorPlanCode.trial.name().equalsIgnoreCase(productPlan.getVendorPlanCode())){
			
			CloudAccount account = accountRepository.getAccountByCustomerIdAndServiceId(customerCompany.getId(), productPlan.getCloudService().getId());
			if(null != account){
				orderResponse = CloudOrderResponseResource.builder().errorMessage("Account Already exisists for the customer company")
						.build();
				return new ResponseEntity<CloudOrderResponseResource>(orderResponse,HttpStatus.OK);
			}
		}
		// Creating Order
		CloudOrderCreatedEvent  cloudOrderCreatedEvent =null;
		try {
			CloudOrderDetails orderDetails = CloudOrderDetails.builder().orderCode(String.format("%S%S", ruleDetails.getRuleValue(), 
																				   orderCommandService.getOrderCodePatternSequenceValue()))
																		.planId(resource.getPlanId())
																		.quantity(resource.getQuantity())
																		.customerId(resource.getCustomerId())
																		.purchaseOrderNumber(resource.getPurchaseOrderNumber())
																		.status(OrderStatus.RECEIVED.name())
																		.build();
			
			CreateCloudOrderEvent orderRequest=new CreateCloudOrderEvent().setCloudOrderDetails(orderDetails);
			cloudOrderCreatedEvent  = orderCommandService.createServiceCloudOrder(orderRequest);
			
			// Setting OrderId while Creating Server record
			resource.setOrderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId());
			
			String integrationCode = productPlan.getCloudService().getIntegrationCode();
			resource.setServiceId(productPlan.getCloudService().getId());
			resource.setIntegrationCode(integrationCode);
			ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
			dispatchService.provisionServer(assember.fromResource(resource));
			
			orderResponse = CloudOrderResponseResource.builder().orderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId())
																.orderCode(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderCode())
																.build();
			log.info("createServer()  -  END");
			return new ResponseEntity<CloudOrderResponseResource>(orderResponse,HttpStatus.OK);
		} catch (Exception e) {
			if(!StringUtils.isEmpty(cloudOrderCreatedEvent)){
				CloudOrderDetails orderDetails = CloudOrderDetails.builder().orderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId())
																			.status(OrderStatus.FAILED.name())
																			.remarks(e.getMessage())
																			.build();
				CreateCloudOrderEvent orderRequest=new CreateCloudOrderEvent().setCloudOrderDetails(orderDetails);
				orderCommandService.updateServiceCloudOrder(orderRequest);
			}
			orderResponse = CloudOrderResponseResource.builder().errorMessage(e.getMessage())
					.build();
			log.error("Exception in createOrder() "+e.getMessage());
			return new ResponseEntity<CloudOrderResponseResource>(orderResponse,HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		// Update remarks column with exception message
	}
	
	
	
	@RequestMapping(value = "/bulkOrder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<List<CloudOrderResponseResource>> createServers(@RequestBody PlaceOrderResources resources) {
		log.info("createServers()  - START");
		CloudOrderResponseResource orderResponse = null;
		CloudCustomerCompany customerCompany = null;
		CloudProductPlan productPlan = null;
		CloudBusinessRuleDetails ruleDetails = null;
		List<CloudOrderResponseResource> bulkOrderResponse = new ArrayList<CloudOrderResponseResource>();
		
		List<PlaceOrderResource> orderResources = resources.getCart();
		
		if(CollectionUtils.isEmpty(orderResources)){
			orderResponse = CloudOrderResponseResource.builder().errorMessage("Input is empty for post request").build();
			bulkOrderResponse.add(orderResponse);
			return new ResponseEntity<>(bulkOrderResponse, HttpStatus.BAD_REQUEST);
		}
		String orderPatternSeqVal = orderCommandService.getOrderCodePatternSequenceValue();
    ReadCloudBusinessRulesEvent request = new ReadCloudBusinessRulesEvent().setRuleName(BusinessRuleNames.ORDER_PREFIX.name());
    EntityReadEvent<CloudBusinessRuleDetails> ruleDetailsEvent = cloudBusinessRuleQueryService.readCloudBusinessRulesByName(request);
    ruleDetails = ruleDetailsEvent.getEntity();
    if (null == ruleDetails) {
      orderResponse = CloudOrderResponseResource.builder().errorMessage(businessRuleErrorMessage).build();
      bulkOrderResponse.add(orderResponse);
      return new ResponseEntity<>(bulkOrderResponse, HttpStatus.BAD_REQUEST);
    }
    for (int i = 0; i < orderResources.size(); i++) {
			PlaceOrderResource resource = null;
			CreateCloudOrderEvent orderRequest= null;
			CloudOrderCreatedEvent  cloudOrderCreatedEvent = null;
			try{
				resource = orderResources.get(i);
				customerCompany = cloudCustomerCompanyQueryService.findByCloudCustomerCompanyCode(resource.getExternalCustomerCompanyCode());
				
				if(null == customerCompany) {
					orderResponse = CloudOrderResponseResource.builder().errorMessage(customerErrorMessage + resource.getExternalCustomerCompanyCode()).build();
					bulkOrderResponse.add(orderResponse);
					return new ResponseEntity<>(bulkOrderResponse, HttpStatus.BAD_REQUEST);
				}
				
				productPlan = cloudOrderServiceLifeCycleService.getProductPlanDetailsById(resource.getPlanId());
				if(null == productPlan) {
					orderResponse = CloudOrderResponseResource.builder().errorMessage(planErrorMessage + resource.getPlanId()).build();
					bulkOrderResponse.add(orderResponse);
					return new ResponseEntity<>(bulkOrderResponse, HttpStatus.BAD_REQUEST);
				}

			}catch(Exception e){
				orderResponse = CloudOrderResponseResource.builder().errorMessage(customerErrorMessage + resource.getExternalCustomerCompanyCode()).build();
				bulkOrderResponse.add(orderResponse);
				return new ResponseEntity<>(bulkOrderResponse, HttpStatus.BAD_REQUEST);
			}
			
			resource.setCustomerId(customerCompany.getId());
			
			CloudResellerCompany cloudResellerCompany = customerCompany.getCloudResellerCompany();
			resource.setResellerCompanyId(cloudResellerCompany.getId());
			resource.setExternalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode());
			resource.setResellerEmail(cloudResellerCompany.getEmail());
			resource.setRuleValue(ruleDetails.getRuleValue());
			
			try {
				// Creating Order
				String orderCode = null;
				if(orderResources.size() > 1){
					orderCode = String.format("%S-%S", String.format("%S%S", ruleDetails.getRuleValue(), orderPatternSeqVal), i+1);
				}
				else if(orderResources.size() == 1){
					orderCode = String.format("%S%S", ruleDetails.getRuleValue(), orderPatternSeqVal);
				}
				
				CloudOrderDetails orderDetails = CloudOrderDetails.builder().orderCode(orderCode)
																			.planId(resource.getPlanId())
																			.quantity(resource.getQuantity())
																			.customerId(resource.getCustomerId())
																			.purchaseOrderNumber(resource.getPurchaseOrderNumber())
																			.status(OrderStatus.RECEIVED.name())
																			.build();
				
				 orderRequest=new CreateCloudOrderEvent().setCloudOrderDetails(orderDetails);
				 cloudOrderCreatedEvent  = orderCommandService.createServiceCloudOrder(orderRequest);
				
				// Setting OrderId while Creating Server record
				resource.setOrderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId());
				
				String integrationCode = productPlan.getCloudService().getIntegrationCode();
				resource.setServiceId(productPlan.getCloudService().getId());
				ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
				dispatchService.provisionServer(assember.fromResource(resource));
				
				orderResponse = CloudOrderResponseResource.builder().orderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId())
            //.orderCode(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderCode())
            .orderCode(String.format("%S%S", ruleDetails.getRuleValue(), orderPatternSeqVal))
            .build();
			} catch (Exception e) {
				if(!StringUtils.isEmpty(cloudOrderCreatedEvent)){
					CloudOrderDetails orderDetails = CloudOrderDetails.builder().orderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId())
																				.status(OrderStatus.FAILED.name())
																				.remarks(e.getMessage())
																				.build();
					orderRequest=new CreateCloudOrderEvent().setCloudOrderDetails(orderDetails);
					orderCommandService.updateServiceCloudOrder(orderRequest);
				}
				orderResponse = CloudOrderResponseResource.builder().errorMessage(e.getMessage())
						.build();
				log.error("Exception in createOrder() "+e.getMessage());
			}
      //Commented as per the B2B request, required only one order code for bulk ordering
      //bulkOrderResponse.add(orderResponse);
    }
    bulkOrderResponse.add(orderResponse);

    log.info("createServers()  -  END");
		return new ResponseEntity<List<CloudOrderResponseResource>>(bulkOrderResponse,HttpStatus.OK);
	}

	@RequestMapping(value = "/servers/{serverId}/terminate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<AcquireServerResource> deleteServer(@PathVariable Long serverId) {
		log.info("deleteServer()  - START");
		
		ReadServerEvent request = new ReadServerEvent().setServerId(serverId);
		
		EntityReadEvent<CloudServerDetails> readEvent = serverQueryService.readServer(request);
		
		CloudServerDetails cloudServerDetails = readEvent.getEntity();
		
		CloudCustomerCompany cloudCustomerCompany = companyRepository.findOne(cloudServerDetails.getCustomerId());
		CloudResellerCompany  cloudResellerCompany = cloudCustomerCompany.getCloudResellerCompany();
		
		String integrationCode = cloudServerDetails.getIntegrationCode();
		
		/*CloudServerActionDetails cloudServerActionDetails = CloudServerActionDetails.builder().action(RackspaceServerAction.DELETE.name())
				.status(RackspaceServerAction.DELETE.name()).cloudServerId(cloudServerDetails.getServerId()).build();
		
		CreateCloudServerActionEvent createCloudServerActionEvent = new CreateCloudServerActionEvent().setCloudServerActionDetails(cloudServerActionDetails);
		
		cloudServerActionCommandService.createCloudServerAction(createCloudServerActionEvent);*/
		
		RackspaceTerminateServerDetails terminateDetails = RackspaceTerminateServerDetails.builder().cloudServiceId(cloudServerDetails.getCloudServiceId())
																									.serverId(cloudServerDetails.getServerId())
																									.cspServerId(cloudServerDetails.getCspServerId())
																									.locationId(cloudServerDetails.getLocationId())
																									.resellerCompanyId(cloudResellerCompany.getId())
																									.externalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode())
																									.resellerEmail(cloudResellerCompany.getEmail())
		   																				            .build();
		RackspaceTerminateServerEvent termincateEvent = RackspaceTerminateServerEvent.builder().rackspaceTerminateServerDetails(terminateDetails).build();
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
		dispatchService.destroyServer(termincateEvent);
		
		log.info("deleteServer()  -  END");
		return new ResponseEntity<AcquireServerResource>(HttpStatus.OK);
	}

	@RequestMapping(value = "/servers/{serverId}/reboot/{rebootType}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<AcquireServerResource> rebootServer(@PathVariable Long serverId, @PathVariable String rebootType) {
		log.info("rebootServer()  - START");
		ReadServerEvent request = new ReadServerEvent().setServerId(serverId);
		EntityReadEvent<CloudServerDetails> readEvent = serverQueryService.readServer(request);
		CloudServerDetails cloudServerDetails = readEvent.getEntity();
		
		CloudCustomerCompany cloudCustomerCompany = companyRepository.findOne(cloudServerDetails.getCustomerId());
		CloudResellerCompany  cloudResellerCompany = cloudCustomerCompany.getCloudResellerCompany();
		
		String integrationCode = cloudServerDetails.getIntegrationCode();
		
		
		RebootServerEvent rebootRequest = RebootServerEvent.builder().serverId(cloudServerDetails.getServerId())
																	 .cspServerId(cloudServerDetails.getCspServerId())
																	 .cloudServiceId(cloudServerDetails.getCloudServiceId())
																     .locationId(cloudServerDetails.getLocationId())
																     .rebootType(rebootType)
																     .resellerCompanyId(cloudResellerCompany.getId())
																	 .externalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode())
																	 .resellerEmail(cloudResellerCompany.getEmail())
																     .build();
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
		dispatchService.rebootServer(rebootRequest);
		
		log.info("rebootServer()  -  END");
		return new ResponseEntity<AcquireServerResource>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "/servers/{serverId}/resetPassword", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<ResetServerPasswordResource> resetServerPassword(@PathVariable Long serverId){
		log.info("resetServerPassword()  - START");
		if(null == serverId){
			return new ResponseEntity<ResetServerPasswordResource>(HttpStatus.BAD_REQUEST);
		}
		ReadServerEvent request = new ReadServerEvent().setServerId(serverId);
		
		EntityReadEvent<CloudServerDetails> readEvent = serverQueryService.readServer(request);
		
		CloudServerDetails cloudServerDetails = readEvent.getEntity();
		
		String integrationCode = cloudServerDetails.getIntegrationCode();
		CloudCustomerCompany cloudCustomerCompany = companyRepository.findOne(cloudServerDetails.getCustomerId());
		CloudResellerCompany  cloudResellerCompany = cloudCustomerCompany.getCloudResellerCompany();
		ServerPasswordResetEvent passwordResetRequest = ServerPasswordResetEvent.builder().cloudServiceId(cloudServerDetails.getCloudServiceId())
																		   .cspServerId(cloudServerDetails.getCspServerId())
																		   .externalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode())
																		   .locationId(cloudServerDetails.getLocationId())
																		   .newPassword(cloudServerDetails.getPassword())
																		   .resellerCompanyId(cloudResellerCompany.getId())
																		   .resellerEmail(cloudResellerCompany.getEmail())
																		   .serverId(serverId)
																		   .build();
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
		dispatchService.resetPassword(passwordResetRequest);
		
		log.info("resetServerPassword()  - END");
		ResetServerPasswordResource responseResource = ResetServerPasswordResource.builder().message("Server password changed successfully....!!").build();
		return new ResponseEntity<ResetServerPasswordResource>(responseResource,HttpStatus.OK);
		
	}

	@RequestMapping(value = "/servers/{serverId}/resize", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<AcquireServerResource> resizeServer(@PathVariable Long serverId, @RequestBody ResizeServerResource resource) {
		log.info("resizeServer()  - START");
		ReadServerEvent readServerRequest = new ReadServerEvent().setServerId(serverId);
		
		EntityReadEvent<CloudServerDetails> readEvent = serverQueryService.readServer(readServerRequest);
		
		CloudServerDetails cloudServerDetails = readEvent.getEntity();
		String integrationCode = cloudServerDetails.getIntegrationCode();
		CloudCustomerCompany cloudCustomerCompany = companyRepository.findOne(cloudServerDetails.getCustomerId());
		CloudResellerCompany  cloudResellerCompany = cloudCustomerCompany.getCloudResellerCompany();
		ResizeServerEvent request = ResizeServerEvent.builder()
				.serverId(serverId)
				.planId(resource.getPlanId())
				.cloudServiceId(cloudServerDetails.getCloudServiceId())
				.cspServerId(cloudServerDetails.getCspServerId())
				.resellerCompanyId(cloudResellerCompany.getId())
				.resellerEmail(cloudResellerCompany.getEmail())
				.externalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode())
				.locationId(cloudServerDetails.getLocationId()).build();
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
		dispatchService.resizeServer(request);
		log.info("resizeServer()  -  END");
		AcquireServerResource responseResource = AcquireServerResource.builder().resizeMessage(resizeMessage).build();
		return new ResponseEntity<AcquireServerResource>(responseResource,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/servers/{serverId}/confirmResize", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<AcquireServerResource> confirmResizeServer(@PathVariable Long serverId, @RequestBody ResizeServerResource resource) {
		log.info("resizeServer()  - START");
		AcquireServerResource responseResource = null;
		ReadServerEvent readServerRequest = new ReadServerEvent().setServerId(serverId);
		
		EntityReadEvent<CloudServerDetails> readEvent = serverQueryService.readServer(readServerRequest);
		
		CloudServerDetails cloudServerDetails = readEvent.getEntity();
		String integrationCode = cloudServerDetails.getIntegrationCode();
		CloudCustomerCompany cloudCustomerCompany = companyRepository.findOne(cloudServerDetails.getCustomerId());
		CloudResellerCompany  cloudResellerCompany = cloudCustomerCompany.getCloudResellerCompany();
		ResizeServerEvent request = ResizeServerEvent.builder()
				.serverId(serverId)
				.planId(cloudServerDetails.getPlanId())
				.cloudServiceId(cloudServerDetails.getCloudServiceId())
				.cspServerId(cloudServerDetails.getCspServerId())
				.resellerCompanyId(cloudResellerCompany.getId())
				.resellerEmail(cloudResellerCompany.getEmail())
				.externalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode())
				.locationId(cloudServerDetails.getLocationId())
				.confirmResize(resource.getConfirmResize()).build();
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
		dispatchService.confirmResizeServer(request);
		log.info("resizeServer()  -  END");
		if(resource.getConfirmResize())
			responseResource = AcquireServerResource.builder().resizeMessage(confirmResizeMessage).build();
		else
			responseResource = AcquireServerResource.builder().resizeMessage(revertResizeMessage).build();
		
		return new ResponseEntity<AcquireServerResource>(responseResource,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/servers/sync", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<AcquireServerResource> syncServers(@RequestHeader(value = X_RESELLER_KEY, required=true) String externalResellerCode) {
		log.info("syncServers()  - START");
		ReadServersEvent request = new ReadServersEvent().setResellerCode(externalResellerCode);
		List<CloudServerDetails> servers = serverQueryService.readAllServers(request);
		try {
			for(CloudServerDetails server:servers){
				String integrationCode = server.getIntegrationCode();
				CreateServerEvent syncRequest = new CreateServerEvent().setServerDetails(server);
				ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
				dispatchService.syncServer(syncRequest);
			}
		} catch (Exception e) {
			log.error("Error occured while syncing servers");
			e.printStackTrace();
		}
		log.info("syncServers()  -  END");
		AcquireServerResource responseResource = AcquireServerResource.builder().syncMessage(syncServersMessage).build();
		return new ResponseEntity<AcquireServerResource>(responseResource,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/accounts/sync", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<AcquireServerResource> syncAccount(@RequestHeader(value = X_RESELLER_KEY, required=true) String externalResellerCode){
		log.info("syncAccount() - Start");
		List<CloudAccount> accounts = accountRepository.findAll(CloudAccountSpecifications.findByFilter(null, externalResellerCode));
		try{
			for (CloudAccount record : accounts) {
				String integrationCode = record.getCloudService().getIntegrationCode();
				ReadCloudAccountEvent syncRequest = new ReadCloudAccountEvent().setId(record.getId());
				ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
				dispatchService.syncAccounts(syncRequest);
			}
		}catch(Exception e){
			log.error("Error occured while syncing Account details. Error message: " + e.getMessage());
			e.printStackTrace();
		}
		
		log.info("syncAccount() - End");
		AcquireServerResource responseResource = AcquireServerResource.builder().syncMessage(syncServersMessage).build();
		return new ResponseEntity<AcquireServerResource>(responseResource,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/nomadesk/reactivate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudAccountResource> reactivateAccount(@RequestBody  CloudAccountResource resource, @RequestHeader(value = X_CUSTOMER_KEY, required=true) String externalCompanyCode) {
		log.info("reactivateAccount()  - START");
		ReadCloudAccountEvent request = new ReadCloudAccountEvent().setId(resource.getAccountId());
		EntityReadEvent<CloudAccountDetails> event = cloudAccountQueryService.readCloudAccount(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudAccountDetails cloudAccountDetails = event.getEntity();
		CreateCloudAccountEvent eventRequest = new CreateCloudAccountEvent().setAccountDetails(cloudAccountDetails);
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.nomadesk);
		dispatchService.reactivateAccount(eventRequest);
		log.info("reactivateAccount()  -  END");
		//AcquireServerResource responseResource = AcquireServerResource.builder().syncMessage(syncServersMessage).build();
		return new ResponseEntity<CloudAccountResource>(resource,HttpStatus.OK);
	}

	@RequestMapping(value = "/sendMail", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void sendMail() throws Exception{
		
		Map<String, Object> model = new HashMap<>();
		model.put("orderNumber", "12345");
		model.put("serviceProvider", "Rackspace");
		String mailSubject = velocityService.buildTemplate(model, "orderReceivedSubject.vm");
		String mailBody = velocityService.buildTemplate(model, "orderReceived.vm");
		List<String> mailList = new ArrayList<>();
		mailList.add("rajamohan.sanepalle@valuelabs.net");
		mailService.sendEmail(mailList, null, null, mailSubject , mailBody);
		
	}
	
	@RequestMapping(value = "/nomadesk/cancelAccount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudAccountResource> cancelAccount(@RequestBody  CloudAccountResource resource, @RequestHeader(value = X_CUSTOMER_KEY, required=true) String externalCompanyCode) {
		log.info("cancelAccount()  - START");
		ReadCloudAccountEvent request = new ReadCloudAccountEvent().setId(resource.getAccountId());
		EntityReadEvent<CloudAccountDetails> event = cloudAccountQueryService.readCloudAccount(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudAccountDetails cloudAccountDetails = event.getEntity();
		CreateCloudAccountEvent eventRequest = new CreateCloudAccountEvent().setAccountDetails(cloudAccountDetails);
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.nomadesk);
		dispatchService.cancelAccount(eventRequest);
		log.info("cancelAccount()  -  END");
		//AcquireServerResource responseResource = AcquireServerResource.builder().syncMessage(syncServersMessage).build();
		return new ResponseEntity<CloudAccountResource>(resource,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/nomadesk/suspendAccount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, 
			consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudAccountResource> suspendAccount(@RequestBody  CloudAccountResource resource, @RequestHeader(value = X_CUSTOMER_KEY, required=true) String externalCompanyCode) {
		log.info("reactivateAccount()  - START");
		ReadCloudAccountEvent request = new ReadCloudAccountEvent().setId(resource.getAccountId());
		EntityReadEvent<CloudAccountDetails> event = cloudAccountQueryService.readCloudAccount(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudAccountDetails cloudAccountDetails = event.getEntity();
		CreateCloudAccountEvent eventRequest = new CreateCloudAccountEvent().setAccountDetails(cloudAccountDetails);
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.nomadesk);
		dispatchService.suspendAccount(eventRequest);
		log.info("reactivateAccount()  -  END");
		//AcquireServerResource responseResource = AcquireServerResource.builder().syncMessage(syncServersMessage).build();
		return new ResponseEntity<CloudAccountResource>(resource,HttpStatus.OK);
	}
	
	

	/*@RequestMapping(value = "/softlayerorders", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudOrderResponseResource> createAccount(@RequestBody PlaceOrderResource resource, 
			@RequestHeader(value = X_CUSTOMER_KEY, required=true) String externalCompanyCode) {
		log.info("createServer()  - START");
		CloudOrderResponseResource orderResponse = null;
		CloudCustomerCompany customerCompany = null;
		CloudProductPlan productPlan = null;
		CloudBusinessRuleDetails ruleDetails = null;
		CloudResellerCompany resellerCompany  = null;
		
		ObjectMapper mapper = new ObjectMapper();
		CloudProduct selectedProduct = cloudOrderServiceLifeCycleService.getProductDetailsById(resource.getProductId());
		if(selectedProduct == null) 
			throw new ResourceNotFoundException("CloudProduct", resource.getProductId());
		
		String json = "";
		try {
			json = mapper.writeValueAsString(resource.getPlan());
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(externalCompanyCode == null){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
		try{
			customerCompany = cloudCustomerCompanyQueryService.findByCloudCustomerCompanyCode(externalCompanyCode);
			
			if(null == customerCompany) {
				orderResponse = CloudOrderResponseResource.builder().errorMessage(customerErrorMessage + externalCompanyCode).build();
				return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
			}
			
			resellerCompany = customerCompany.getCloudResellerCompany();
			
			if(!StringUtils.isEmpty(resellerCompany) && !StringUtils.isEmpty(resellerCompany.getCreditCardExpiryDate()) ) {
			  boolean  result = cloudOrderValidationService.validateResellerCreditCard(resellerCompany.getCreditCardExpiryDate());
			  if(result!=true) {
				throw new NepheleException("Your credit card has been expired.Please enter valid credit card details.");
			  }
			}
			
			productPlan = cloudOrderServiceLifeCycleService.getProductPlanDetailsById(resource.getPlanId());
			if(null == productPlan) {
				orderResponse = CloudOrderResponseResource.builder().errorMessage(planErrorMessage + resource.getPlanId()).build();
				return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
			}
			
			ReadCloudBusinessRulesEvent request = new ReadCloudBusinessRulesEvent().setRuleName(BusinessRuleNames.ORDER_PREFIX.name());
			EntityReadEvent<CloudBusinessRuleDetails> ruleDetailsEvent = cloudBusinessRuleQueryService.readCloudBusinessRulesByName(request);
			ruleDetails = ruleDetailsEvent.getEntity();
			if(null == ruleDetails) {
				orderResponse = CloudOrderResponseResource.builder().errorMessage(businessRuleErrorMessage + resource.getPlanId()).build();
				return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
			}
		}
		catch(NepheleException e){
			orderResponse = CloudOrderResponseResource.builder().errorMessage(e.getMessage()).build();
			return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
		}
		catch(Exception e){
			orderResponse = CloudOrderResponseResource.builder().errorMessage(customerErrorMessage + externalCompanyCode).build();
			return new ResponseEntity<>(orderResponse, HttpStatus.BAD_REQUEST);
		}
		
		resource.setCustomerId(customerCompany.getId());
		
		CloudResellerCompany cloudResellerCompany = customerCompany.getCloudResellerCompany();
		resource.setResellerCompanyId(cloudResellerCompany.getId());
		resource.setExternalResellerCompanyCode(cloudResellerCompany.getResellerCompanyCode());
		resource.setResellerEmail(cloudResellerCompany.getEmail());
		
		// Creating Order
		CloudOrderDetails orderDetails = CloudOrderDetails.builder().orderCode(String.format("%S%S", ruleDetails.getRuleValue(), 
																			   orderCommandService.getOrderCodePatternSequenceValue()))
																	.planId(resource.getPlanId())
																	.quantity(resource.getQuantity())
																	.customerId(resource.getCustomerId())
																	.purchaseOrderNumber(resource.getPurchaseOrderNumber())
																	.status(OrderStatus.RECEIVED.name())
																	.build();
		
		CreateCloudOrderEvent orderRequest=new CreateCloudOrderEvent().setCloudOrderDetails(orderDetails);
		CloudOrderCreatedEvent  cloudOrderCreatedEvent  = orderCommandService.createServiceCloudOrder(orderRequest);
		
		// Setting OrderId while Creating Server record
		resource.setOrderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId());
		
		String integrationCode = productPlan.getCloudService().getIntegrationCode();
		resource.setServiceId(productPlan.getCloudService().getId());
		resource.setIntegrationCode(integrationCode);
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.softlayer);
		dispatchService.provisionServer(resource);
		
		orderResponse = CloudOrderResponseResource.builder().orderId(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderId())
															.orderCode(cloudOrderCreatedEvent.getCloudOrderDetails().getOrderCode())
															.build();
		log.info("createServer()  -  END");
		return new ResponseEntity<CloudOrderResponseResource>(orderResponse,HttpStatus.OK);
	}*/
}
