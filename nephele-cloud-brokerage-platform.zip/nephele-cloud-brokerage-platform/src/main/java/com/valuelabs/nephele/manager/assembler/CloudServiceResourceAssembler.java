package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;
import com.valuelabs.nephele.manager.controller.CloudServiceQueryController;
import com.valuelabs.nephele.manager.resource.CloudServiceResource;

@Slf4j
@Service
public class CloudServiceResourceAssembler extends
		ResourceAssemblerSupport<CloudServiceDetails, CloudServiceResource> {

	public CloudServiceResourceAssembler() {
		super(CloudServiceQueryController.class, CloudServiceResource.class);
	}

	@Override
	public CloudServiceResource toResource(CloudServiceDetails entity) {

		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + entity);
		CloudServiceResource resource = instantiateResource(entity);

		resource = CloudServiceResource.builder()
				.serviceId(entity.getServiceId())
				.name(entity.getName())
				.isPublished(entity.getIsPublished())				
				.serviceProviderId(entity.getServiceProviderId())				
				.serviceCode(entity.getServiceCode())
				.billingCycle(entity.getBillingCycle())
				.billingDay(entity.getBillingDay())
				.updatedAt(entity.getUpdatedDate())
				.brandName(entity.getServiceProviderName())
				.description(entity.getDescription())
				.planPrefix(entity.getPlanPrefix())
				.subscriptionNamePrefix(entity.getSubscriptionNamePrefix())
				.isLive(entity.getIsLive())
				.integrationCode(entity.getIntegrationCode())
				.vendorCode(entity.getVendorCode())
				.vendorCurrency(entity.getVendorCurrency())
				.timeZone(entity.getTimeZone())
				.serviceCategoryId(entity.getServiceCategoryId())
				.serviceIndustryVerticalId(entity.getServiceIndustryVerticalId())
				.serviceCategoryName(entity.getServiceCategoryName())
				.serviceIndustryVerticalName(entity.getServiceIndustryVerticalName())
				.serviceType(entity.getServiceType())
				.build();
		
		resource.add(linkTo(
				methodOn(CloudServiceQueryController.class).readService(
						entity.getServiceId())).withSelfRel());		
		log.debug("toResource() : END");
		return resource;
	}

	public CloudServiceDetails fromResource(CloudServiceResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudServiceDetails serviceDetails = CloudServiceDetails.builder()
				.serviceId(resource.getServiceId())
				.name(resource.getName())
				.isPublished(resource.getIsPublished())				
				.serviceProviderId(resource.getServiceProviderId())				
				.serviceCode(resource.getServiceCode())
				.billingCycle(resource.getBillingCycle())
				.billingDay(resource.getBillingDay())
				.serviceProviderName(resource.getBrandName())
				.description(resource.getDescription())
				.planPrefix(resource.getPlanPrefix())
				.subscriptionNamePrefix(resource.getSubscriptionNamePrefix()).isLive(resource.getIsLive())
				.integrationCode(resource.getIntegrationCode())
				.vendorCode(resource.getVendorCode())
				.vendorCurrency(resource.getVendorCurrency())
				.timeZone(resource.getTimeZone())
				.serviceCategoryId(resource.getServiceCategoryId())
				.serviceIndustryVerticalId(resource.getServiceIndustryVerticalId())
				.serviceCategoryName(resource.getServiceCategoryName())
				.serviceIndustryVerticalName(resource.getServiceIndustryVerticalName())
				.build();			
		log.debug("fromResource: END");
		return serviceDetails;
	}

}
