package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.valuelabs.nephele.admin.rest.lib.resource.CloudDistributorResource;


@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class CloudBusinessRuleResource extends ResourceSupport {

	private Long ruleId;
	private String ruleName;
	private String ruleDescription;
	private String ruleValue;
	private CloudDistributorResource resource;
}
