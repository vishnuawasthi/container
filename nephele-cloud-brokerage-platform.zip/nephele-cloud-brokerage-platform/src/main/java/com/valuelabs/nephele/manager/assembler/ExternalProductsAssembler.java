package com.valuelabs.nephele.manager.assembler;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;
import com.valuelabs.nephele.manager.controller.ExternalCloudProductQueryController;
import com.valuelabs.nephele.manager.resource.ExternalProductResource;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExternalProductsAssembler extends ResourceAssemblerSupport<ExternalProductDetails, ExternalProductResource> {

  public ExternalProductsAssembler() {
	super(ExternalCloudProductQueryController.class, ExternalProductResource.class);
  }

  @Override
  public ExternalProductResource toResource(ExternalProductDetails entity) {
	log.debug("toResource() - start");
	ExternalProductResource resource = instantiateResource(entity);
	resource = ExternalProductResource.builder()
                            		.externalProductId(entity.getExternalProductId())
                            		.description(entity.getDescription())                            		
                            		.status(entity.getStatus())
                            		.brandName(entity.getBrandName())
                            		.type(entity.getType()) 
                            		.serviceName(entity.getBrandName())
                            		.productName(entity.getProductName())
                            		.name(entity.getProductName())
                            		.label(entity.getLabel())
                            		.build();
	// TO DO - Need to add the link
	log.debug("toResource() - end");
	return resource;
  }
  
  public ExternalProductDetails fromResource(ExternalProductResource resource) {
	log.debug("fromResource() - start");
	ExternalProductDetails details = ExternalProductDetails.builder()
									.externalProductId(resource.getExternalProductId())
									.description(resource.getDescription())                            		
									.status(resource.getStatus())
									.brandName(resource.getBrandName())
									.type(resource.getType())   
									.label(resource.getLabel())
                              		.build();
	log.debug("fromResource() - end");
	return details;
  }
  

}
