package com.valuelabs.nephele.manager.security.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserService;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.manager.security.service.CloudUserDetailsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("customAuthenticationProvider")
public class CustomAuthenticationProvider implements AuthenticationProvider {

  @Autowired
  CloudUserDetailsService userDetailsService;

  @Autowired
  CloudUserService service;
  
  @Autowired
  private NepheleUtils nepheleUtils;

  // API
  @Override
  public Authentication authenticate(final Authentication authentication) throws AuthenticationException {
	  //synchronized (authentication) {
		  log.debug("In authenticate()");
		  final String name = authentication.getName();
		    final String password = authentication.getCredentials().toString();
		    UserDetails user = userDetailsService.loadUserByUsername(authentication.getName());
		    if (null != user && nepheleUtils.decrypt((String) authentication.getCredentials()).equals(user.getPassword())) {
		      final UserDetails principal = new User(name, password, user.getAuthorities());
		      final Authentication auth = new UsernamePasswordAuthenticationToken(principal, password, user.getAuthorities());
		      return auth;
		    } else {
		      return null;
		    }
	//}
  }

  @Override
  public boolean supports(final Class<?> authentication) {
    return authentication.equals(UsernamePasswordAuthenticationToken.class);
  }

}