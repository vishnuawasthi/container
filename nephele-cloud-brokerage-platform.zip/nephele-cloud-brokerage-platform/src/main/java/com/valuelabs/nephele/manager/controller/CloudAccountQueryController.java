package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;	

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAccountsEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAccountQueryService;
import com.valuelabs.nephele.manager.assembler.CloudAccountAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudAccountResource;
import static  com.valuelabs.nephele.manager.constants.QueryParameterConstants.*;

@Slf4j
@RestController
@RequestMapping(value="/marketplace/cloudAccount")
public class CloudAccountQueryController {

  @Autowired
  private CloudAccountAssembler assembler;
  
  @Autowired
  private CloudAccountQueryService service;
  
  @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudAccountResource> readCloudAccount(@PathVariable Long id) {
		log.info("readCloudAccount() - start");
		ReadCloudAccountEvent request = new ReadCloudAccountEvent().setId(id);
		EntityReadEvent<CloudAccountDetails> event = service.readCloudAccount(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudAccountDetails entity = event.getEntity();
		log.info("readCloudAccount() - end");
		return new ResponseEntity<CloudAccountResource>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudAccountResource>> readCloudAccounts(
		@RequestParam(value=QueryParameterConstants.SERVICE_ID,required=false) Long serviceId,	
        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, 
			PagedResourcesAssembler<CloudAccountDetails> pagedAssembler) {
		log.info("readCloudAccounts()  - start");
		ReadCloudAccountsEvent request = new ReadCloudAccountsEvent().setPageable(pageable);
		request.setServiceId(serviceId);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudAccountDetails> event = service.readCloudAccounts(request);
		Page<CloudAccountDetails> page = event.getPage();
		PagedResources<CloudAccountResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudAccounts()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
