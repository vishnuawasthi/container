package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServicePricingModelDetails;
import com.valuelabs.nephele.manager.controller.CloudServicePricingModelQueryController;
import com.valuelabs.nephele.manager.resource.CloudServicePricingModelResource;

@Slf4j
@Service
public class CloudServicePricingModelAssembler
		extends
		ResourceAssemblerSupport<CloudServicePricingModelDetails, CloudServicePricingModelResource> {

	public CloudServicePricingModelAssembler() {
		super(CloudServicePricingModelQueryController.class,
				CloudServicePricingModelResource.class);
	}

	@Override
	public CloudServicePricingModelResource toResource(
			CloudServicePricingModelDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + entity);
		CloudServicePricingModelResource resource = instantiateResource(entity);
		resource = CloudServicePricingModelResource.builder()
				.name(entity.getName())
				.servicePricingModelId(entity.getServicePricingModelId())
				.build();
		resource.add(linkTo(
				methodOn(CloudServicePricingModelQueryController.class)
						.readServicePricingModel(
								entity.getServicePricingModelId()))
				.withSelfRel());
		log.debug("toResource() : resource : " + resource);
		log.debug("toResource() : resource Links: " + resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudServicePricingModelDetails fromResource(
			CloudServicePricingModelResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudServicePricingModelDetails details = CloudServicePricingModelDetails
				.builder()
				.servicePricingModelId(resource.getServicePricingModelId())
				.name(resource.getName()).build();
		log.debug("fromResouce: END");
		return details;

	}
}
