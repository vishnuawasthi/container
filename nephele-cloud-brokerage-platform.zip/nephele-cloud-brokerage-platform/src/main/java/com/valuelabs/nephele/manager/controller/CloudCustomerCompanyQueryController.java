package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomersCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCustomerCompanyQueryService;
import com.valuelabs.nephele.manager.assembler.CloudCustomerCompanyAssembler;
import com.valuelabs.nephele.manager.resource.CloudCustomerCompanyResource;
import static  com.valuelabs.nephele.manager.constants.QueryParameterConstants.*;
@Slf4j
@RestController
@RequestMapping("/manager/customerCompany")
@Transactional
public class CloudCustomerCompanyQueryController {

	@Autowired
	CloudCustomerCompanyAssembler assembler;

	@Autowired
	CloudCustomerCompanyQueryService service;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudCustomerCompanyResource> readCloudCustomerCompany(@PathVariable Long id) {
		log.info("readCloudCustomerCompany() START");

		ReadCloudCustomerCompanyEvent request=new ReadCloudCustomerCompanyEvent().setCustomerCompanyId(id);

		EntityReadEvent<CloudCustomerCompanyDetails> event = service.readCustomerCompany(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudCustomerCompanyDetails entity = event.getEntity();
		log.info("readCloudCustomerCompany() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudCustomerCompanyResource>> readCloudCustomerCompanys(
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
			@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudCustomerCompanyDetails> pagedAssembler) {
		log.info("readCloudCustomerCompanys() START");
		ReadCloudCustomersCompanyEvent request=new ReadCloudCustomersCompanyEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);

		PageReadEvent<CloudCustomerCompanyDetails> event=service.readCustomersCompany(request);

		Page<CloudCustomerCompanyDetails> page=event.getPage();
		PagedResources<CloudCustomerCompanyResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudCustomerCompanys() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}


}
