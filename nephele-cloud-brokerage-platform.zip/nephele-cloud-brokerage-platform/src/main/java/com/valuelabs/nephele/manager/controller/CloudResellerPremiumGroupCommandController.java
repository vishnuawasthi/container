package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudResellerPremiumGroupEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ValidationException;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerPremiumGroupCommandService;
import com.valuelabs.nephele.manager.assembler.CloudResellerPremiumGroupAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudResellerPremiumGroupResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/cloudResellerPremiumGroup")
@Transactional
public class CloudResellerPremiumGroupCommandController {

  @Autowired
  CloudResellerPremiumGroupAssembler assembler;

  @Autowired
  CloudResellerPremiumGroupCommandService service;

  @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerPremiumGroupResource> createResellerPremiumGroup(
			@Valid @RequestBody CloudResellerPremiumGroupResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createResellerPremiumGroup() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudResellerPremiumGroupResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudResellerPremiumGroupDetails premiumGroupDetails = assembler.fromResource(resource);
		CreateCloudResellerPremiumGroupEvent request = new CreateCloudResellerPremiumGroupEvent()
				.setCloudResellerPremiumGroupDetails(premiumGroupDetails);
		if (request != null) {
			service.createResellerPremiumGroup(request);
		}
		log.info("createResellerPremiumGroup() : END");
		return new ResponseEntity<CloudResellerPremiumGroupResource>(HttpStatus.CREATED);
	}
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerPremiumGroupResource> updateResellerPremiumGroup(
			@Valid @RequestBody CloudResellerPremiumGroupResource resource,
			BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {		
		log.info("updateResellerPremiumGroup() : START");
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;	
		try{
			if (resource.getPremiumGroupid() == null) {
				result.addError(new FieldError("resource", "id", resource.getPremiumGroupid(), false, null, null, null));
			}
			if (result.hasErrors()) {
				return new ResponseEntity<CloudResellerPremiumGroupResource>(resource,HttpStatus.BAD_REQUEST);
			}
			CloudResellerPremiumGroupDetails premiumGroupDetails = assembler.fromResource(resource);
			CreateCloudResellerPremiumGroupEvent request = new CreateCloudResellerPremiumGroupEvent()
					.setCloudResellerPremiumGroupDetails(premiumGroupDetails);
			if (request != null) {
				service.updateResellerPremiumGroup(request);
				message = "ResellerPremiumGroup updated successfully";
			}
		}catch(NepheleException | ValidationException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);
		}
		log.info("updateResellerPremiumGroup() : END");
		resource = CloudResellerPremiumGroupResource.builder().message(message).build();		
		return new ResponseEntity<CloudResellerPremiumGroupResource>(resource, statusCode) ;
	}
	
	@RequestMapping(value = "/activate",method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerPremiumGroupResource> activateResellerPremiumGroup(@Valid @RequestBody CloudResellerPremiumGroupResource resource,BindingResult result)
			throws ResourceNotFoundException, IllegalArgumentException {
		log.info(" activateResellerPremiumGroup() : START" );

		if (resource.getPremiumGroupid() == null) {
			result.addError(new FieldError("resource", "id", resource.getPremiumGroupid(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudResellerPremiumGroupResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudResellerPremiumGroupDetails premiumGroupDetails = assembler.fromResource(resource);	
		CreateCloudResellerPremiumGroupEvent request = new CreateCloudResellerPremiumGroupEvent()
															.setCloudResellerPremiumGroupDetails(premiumGroupDetails);
		log.debug("reqeust details " +request);

		if (request != null) {
			service.activateResellerPremiumGroup(request);
		}
		log.info("activateResellerPremiumGroup(): END");
		return new ResponseEntity<CloudResellerPremiumGroupResource>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
	public HttpEntity<CloudResellerPremiumGroupResource> deleteResellerPremiumGroup( @PathVariable Long id) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("deleteResellerPremiumGroup() - START");
		if(id == null) {
			return new ResponseEntity<CloudResellerPremiumGroupResource>(HttpStatus.BAD_REQUEST);
		}
		CloudResellerPremiumGroupDetails premiumGroupDetails = CloudResellerPremiumGroupDetails.builder().premiumGroupId(id).build();
		CreateCloudResellerPremiumGroupEvent request = new CreateCloudResellerPremiumGroupEvent()
				.setCloudResellerPremiumGroupDetails(premiumGroupDetails);		
		service.deleteResellerPremiumGroup(request);
		log.info("deleteResellerPremiumGroup() - END");
		return new ResponseEntity<CloudResellerPremiumGroupResource>(HttpStatus.OK);
	}

}
