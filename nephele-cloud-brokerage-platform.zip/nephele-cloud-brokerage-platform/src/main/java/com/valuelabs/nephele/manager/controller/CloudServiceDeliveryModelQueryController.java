package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDeliveryModelDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceDeliveryModelEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceDeliveryModelsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceDeliveryModelQueryService;
import com.valuelabs.nephele.manager.assembler.CloudServiceDeliveryModelAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudServiceDeliveryModelResource;

@Slf4j
@RestController
@RequestMapping("/manager/serviceDeliveryModel")
public class CloudServiceDeliveryModelQueryController {
	
	@Autowired
	private CloudServiceDeliveryModelAssembler assembler;
	
	@Autowired
	private CloudServiceDeliveryModelQueryService service;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceDeliveryModelResource> readServiceDeliveryModel(@PathVariable Long id) {
		log.info("readDeliveryModelService() START");

		ReadServiceDeliveryModelEvent request=new ReadServiceDeliveryModelEvent().setServiceDeliveryModelId(id);
		
		EntityReadEvent<CloudServiceDeliveryModelDetails> event = service.readServiceDeliveryModel(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudServiceDeliveryModelDetails entity = event.getEntity();
		log.info("readDeliveryModelService() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServiceDeliveryModelResource>> readServiceDeliveryModels(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServiceDeliveryModelDetails> pagedAssembler) {
		log.info("readServiceDeliveryModels() START");
		ReadServiceDeliveryModelsEvent request=new ReadServiceDeliveryModelsEvent().setPageable(pageable);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudServiceDeliveryModelDetails> event=service.readServiceDeliveryModels(request);
		Page<CloudServiceDeliveryModelDetails> page=event.getPage();
		PagedResources<CloudServiceDeliveryModelResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServiceDeliveryModels() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

}
