package com.valuelabs.nephele.marketplace.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductAdditionalChargeDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudProductResource;
import com.valuelabs.nephele.manager.resource.CloudProductPlanResource;
import com.valuelabs.nephele.manager.resource.PlansResource;
import com.valuelabs.nephele.marketplace.controller.CloudProductQueryController;

@Slf4j
@Service
public class CloudProductAssembler extends ResourceAssemblerSupport<CloudProductDetails, CloudProductResource>{
	
	public CloudProductAssembler() {
		super(CloudProductQueryController.class, CloudProductResource.class);
	}
	
	@Override
	public CloudProductResource toResource(CloudProductDetails details) {
		log.debug("toResource() : START");
		CloudProductResource resource=instantiateResource(details);
	
		resource= CloudProductResource.builder().productId(details.getProductId())
											    .name(details.getName())
											    .description(details.getDescription())
											    .startingPlan(details.getStartingPlan())
											    .type(details.getType())
											    .operatingSystemId(details.getOperatingSystemId())
											    .operatingSystemName(details.getOperatingSystemName())
											    .serviceId(details.getServiceId())
											    .serviceName(details.getServiceName())
											    //.serviceCode(details.getServiceCode())
											    .integrationCode(details.getIntegrationCode())
											    .brandCode(details.getBrandCode())
											    .brandName(details.getBrandName())
											    .categoryId(details.getCategoryId())
											    .categoryName(details.getCategoryName())
											    .status(details.getStatus())
											    .isFeatured(details.getIsFeatured())
											    .hasFreeTrial(details.getHasFreeTrial())
											    .hasRelatedProducts(details.getHasRelatedProducts())
											    .label(details.getLabel())
											    .build();
		
		resource.add(linkTo(methodOn(CloudProductQueryController.class).readCloudProduct(details.getProductId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}
	
	public CloudProductDetails fromResource(CloudProductResource resource){
		log.debug("fromResource() - START");
		CloudProductDetails cloudProductDetails=CloudProductDetails.builder()
																	.productId(resource.getProductId())
																	.name(resource.getName())
																	.description(resource.getDescription())
																	.type(resource.getType())
																	.startingPlan(resource.getStartingPlan())
																	.operatingSystemId(resource.getOperatingSystemId())
																	.serviceId(resource.getServiceId())
																	.isFeatured(resource.getIsFeatured())
																	.hasFreeTrial(resource.getHasFreeTrial())
																	.hasRelatedProducts(resource.getHasRelatedProducts())
																	.label(resource.getLabel())
																	.build();
		log.debug("fromResource() - END");
		return cloudProductDetails;
		
	}
	
	public CloudProductPlanResource toResources_forProductPlans(CloudProductResource productDetailsResource, List<PlansResource> planResourceList, List<CloudProductAdditionalChargeDetails> additionalChargeList) {
		log.debug("toResource() : START");
		return CloudProductPlanResource.builder().details(productDetailsResource)
											     .plans(planResourceList)
											     .additionalCharges(additionalChargeList)
											     .build();
		
	}
}

