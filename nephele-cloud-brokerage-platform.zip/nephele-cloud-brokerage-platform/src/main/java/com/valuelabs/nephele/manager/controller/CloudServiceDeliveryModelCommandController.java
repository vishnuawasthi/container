package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDeliveryModelDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServiceDeliveryModelEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceDeliverModelCommandService;
import com.valuelabs.nephele.manager.assembler.CloudServiceDeliveryModelAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudServiceDeliveryModelResource;

@Slf4j
@RestController
@RequestMapping("/manager/serviceDeliveryModel")
@Transactional
public class CloudServiceDeliveryModelCommandController {

	@Autowired
	CloudServiceDeliveryModelAssembler assembler;
	
	@Autowired
	CloudServiceDeliverModelCommandService commandService;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceDeliveryModelResource> createDeliveryModel(@Valid @RequestBody CloudServiceDeliveryModelResource resource,BindingResult result) throws IllegalArgumentException{
		log.info("createDeliveryModel() : START");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudServiceDeliveryModelResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudServiceDeliveryModelDetails deliveryModelDetails=assembler.fromResouce(resource);
		CreateServiceDeliveryModelEvent request=new CreateServiceDeliveryModelEvent().setCloudServiceDeliveryModelDetails(deliveryModelDetails);
		
		if(request != null){
			commandService.createServiceDeliveryModel(request);
		}
		
		log.info("createDeliveryModel() : END");
		return new ResponseEntity<CloudServiceDeliveryModelResource>(HttpStatus.CREATED);
	}
	
	
	/*@RequestMapping(value="{id}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceDeliveryModelResource> deleteDeliveryModel(@PathVariable Integer id){
		log.info("deleteDeliveryModel() : START");
		
		if(id != null){
		boolean recordDeleted =	commandService.deleteServiceDeliveryModel(id);
			if(recordDeleted){
				return new ResponseEntity<CloudServiceDeliveryModelResource>(HttpStatus.ACCEPTED);
			}else{
				return new ResponseEntity<CloudServiceDeliveryModelResource>(HttpStatus.NOT_FOUND);
			}
			
		}else{
			return new ResponseEntity<CloudServiceDeliveryModelResource>(HttpStatus.BAD_REQUEST);
		}
		
	}*/
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceDeliveryModelResource> updateDeliveryModel(@Valid @RequestBody CloudServiceDeliveryModelResource resource,BindingResult result) throws ResourceNotFoundException,IllegalArgumentException{
		log.info("updateDeliveryModel() : START");
		if(resource.getServiceDeliveryModelId() == null){
			result.addError(new FieldError("resource", "serviceDeliveryModelId", resource.getServiceDeliveryModelId(), true, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudServiceDeliveryModelResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudServiceDeliveryModelDetails deliveryModelDetails=assembler.fromResouce(resource);
		CreateServiceDeliveryModelEvent request=new CreateServiceDeliveryModelEvent().setCloudServiceDeliveryModelDetails(deliveryModelDetails);
		
		if(request != null){
			commandService.updateServiceDeliveryModel(request);
		}
		
		log.info("updateDeliveryModel() : END");
		return new ResponseEntity<CloudServiceDeliveryModelResource>(HttpStatus.OK);
	}

}
