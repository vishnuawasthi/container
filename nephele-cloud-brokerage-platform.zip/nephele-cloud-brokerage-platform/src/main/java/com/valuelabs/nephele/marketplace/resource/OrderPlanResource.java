package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode(callSuper=false)
@Setter
@Getter
@Builder
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL)
public class OrderPlanResource  extends ResourceSupport {
	
	private Integer operatingSystemId;
	
	private Integer locationId;
	
	private Integer flavorId;

}
