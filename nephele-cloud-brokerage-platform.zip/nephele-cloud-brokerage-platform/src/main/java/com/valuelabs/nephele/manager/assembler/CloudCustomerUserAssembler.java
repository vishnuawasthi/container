package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerUserDetails;
import com.valuelabs.nephele.manager.controller.CloudCustomerUserQueryController;
import com.valuelabs.nephele.manager.resource.CloudCustomerUserResource;

@Slf4j
@Service
public class CloudCustomerUserAssembler extends ResourceAssemblerSupport<CloudCustomerUserDetails, CloudCustomerUserResource>{
	
	public CloudCustomerUserAssembler() {
		super(CloudCustomerUserQueryController.class, CloudCustomerUserResource.class);
		
	}
	@Override
	public CloudCustomerUserResource toResource(CloudCustomerUserDetails entity) {
		log.debug("toResource() : START");
		CloudCustomerUserResource resource=instantiateResource(entity);
		resource=CloudCustomerUserResource.builder().customerId(entity.getCustomerId()).customerName(entity.getCustomerName())
				.customerCompanyId(entity.getCustomerCompanyId()).build();
		resource.add(linkTo(methodOn(CloudCustomerUserQueryController.class).readCustomerUser(entity.getCustomerId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}
	
	public CloudCustomerUserDetails fromResource(CloudCustomerUserResource resource){
		log.debug("fromResource: START:{} ",resource);
		CloudCustomerUserDetails details=CloudCustomerUserDetails.builder().customerId(resource.getCustomerId()).customerName(resource.getCustomerName())
										.customerCompanyId(resource.getCustomerCompanyId()).build();
		log.debug("fromResouce: END");
		return details;
	}
}
