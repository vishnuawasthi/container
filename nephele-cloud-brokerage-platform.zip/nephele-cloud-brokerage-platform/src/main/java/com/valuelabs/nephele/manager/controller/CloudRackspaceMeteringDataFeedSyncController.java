package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.MeteringDataFeedMQConfig.EXCHANGE_NAME;
import static com.valuelabs.nephele.manager.configuration.MeteringDataFeedMQConfig.RACKSPACE_METERING_DATA_FEED_ROUTING_KEY;
import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/manager")
public class CloudRackspaceMeteringDataFeedSyncController {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@RequestMapping(value = "/rackspaceMeteringDataFeedSync", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> runRsMeteringDataFeedSync() {
		log.info("runRackspaceMeteringDataFeedSync() -START");

		try {

			rabbitTemplate.convertAndSend(EXCHANGE_NAME, RACKSPACE_METERING_DATA_FEED_ROUTING_KEY,
					"RackspaceMeteringDataFeedSync");

		} catch (Exception e) {
			log.error("Exception while Synchronisation:" + e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("runRackspaceMeteringDataFeedSync()  - END");
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
