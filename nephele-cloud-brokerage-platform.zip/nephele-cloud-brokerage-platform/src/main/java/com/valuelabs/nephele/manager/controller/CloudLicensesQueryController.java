package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLicenseDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudLicensesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadLicenseEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudLicenseQueryService;
import com.valuelabs.nephele.manager.assembler.CloudLicenseAssembler;
import com.valuelabs.nephele.manager.resource.CloudLicenseResource;
@Slf4j
@RestController
@RequestMapping("/marketplace/license")
@Transactional
public class CloudLicensesQueryController {

	@Autowired
	private CloudLicenseAssembler assembler;

	@Autowired
	private CloudLicenseQueryService service;

	/**
	 * Get a record by passing id from DB
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudLicenseResource> readLicense(
			@PathVariable Long id) {
		log.info("readLicense() START");
		EntityReadEvent<CloudLicenseDetails> event = null;
		if (id != null) {
			ReadLicenseEvent request = new ReadLicenseEvent().setLicenseId(id);
					
			event = service.readLicenseService(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudLicenseDetails entity = event.getEntity();
		log.info("readLicense() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	/**
	 * Get all records from DB
	 * 
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudLicenseResource>> readLicenses(
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
			@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudLicenseDetails> pagedAssembler) {
		log.info("readLicenses() START");
		ReadCloudLicensesEvent request = new ReadCloudLicensesEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudLicenseDetails> event = service.readServiceLicenses(request);				
		Page<CloudLicenseDetails> page = event.getPage();
		PagedResources<CloudLicenseResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readLicenses() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
