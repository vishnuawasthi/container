package com.valuelabs.nephele.manager.configuration;

public enum CloudServiceStatus {

	STAGED,
	INTEGRATED,
	PUBLISHED,
	SUSPENDED
}
