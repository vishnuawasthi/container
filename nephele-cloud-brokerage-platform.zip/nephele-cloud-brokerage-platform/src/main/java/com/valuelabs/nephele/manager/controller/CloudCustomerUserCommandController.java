package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerUserDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudCustomerUserEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudCustomerUserCommandService;
import com.valuelabs.nephele.manager.assembler.CloudCustomerUserAssembler;
import com.valuelabs.nephele.manager.resource.CloudCustomerUserResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/cloudCustomerUser")
@Transactional
public class CloudCustomerUserCommandController {

	@Autowired
	private CloudCustomerUserAssembler assembler;

	@Autowired
	private CloudCustomerUserCommandService service;

	/**
	 * Create new record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudCustomerUserResource> createCloudCustomerUser(
			@Valid @RequestBody CloudCustomerUserResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createCloudCustomerUser() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudCustomerUserResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudCustomerUserDetails userDetails = assembler.fromResource(resource);
		CreateCloudCustomerUserEvent request = new CreateCloudCustomerUserEvent()
				.setCloudCustomerUserDetails(userDetails);
		if (request != null) {
			service.createCustomerUser(request);
		}
		log.info("createCloudCustomerUser() : END");
		return new ResponseEntity<CloudCustomerUserResource>(HttpStatus.CREATED);
	}

	/**
	 * Update existing record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudCustomerUserResource> updateCloudCustomerUser(
			@Valid @RequestBody CloudCustomerUserResource resource,
			BindingResult result) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("updateCloudCustomerUser() : START");
		if (resource.getCustomerId() == null) {
			result.addError(new FieldError("resource", "customerId", resource
					.getCustomerId(), true, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudCustomerUserResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudCustomerUserDetails userDetails = assembler.fromResource(resource);
		CreateCloudCustomerUserEvent request = new CreateCloudCustomerUserEvent()
				.setCloudCustomerUserDetails(userDetails);
		if (request != null) {
			service.updateCustomerUser(request);
		}
		log.info("updateCloudCustomerUser() : END");
		return new ResponseEntity<CloudCustomerUserResource>(HttpStatus.OK);
	}

}
