package com.valuelabs.nephele.manager.configuration;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
public class B2BServiceIntegrationMQConfig {
	
	@Autowired
	AmqpAdmin rabbitAdmin;
	
	public static final String EXCHANGE_NAME = "nephele.cloud.b2b.sync.exchange";

	//Reseller Data Sync
		//public static final String RESELLER_DATA_QUEUE_NAME = "nephele.cloud.b2b.reseller.data.sync.queue";
//		public static final String RESELLER_DATA_ROUTING_KEY = "nephele.cloud.b2b.reseller.data.syncKey";
		
	//Reseller Data Sync
	public static final String CREATE_RESELLER_DATA_QUEUE_NAME = "nephele.cloud.b2b.create.reseller.data.sync.queue";
	public static final String CREATE_RESELLER_DATA_ROUTING_KEY = "nephele.cloud.b2b.create.reseller.data.syncKey";
	
	public static final String UPDATE_RESELLER_DATA_QUEUE_NAME = "nephele.cloud.b2b.update.reseller.data.sync.queue";
	public static final String UPDATE_RESELLER_DATA_ROUTING_KEY = "nephele.cloud.b2b.update.reseller.data.syncKey";
	
	public static final String DELETE_RESELLER_DATA_QUEUE_NAME = "nephele.cloud.b2b.delete.reseller.data.sync.queue";
	public static final String DELETE_RESELLER_DATA_ROUTING_KEY = "nephele.cloud.b2b.delete.reseller.data.syncKey";
	
	//Customer Data Sync
	public static final String CREATE_CUSTOMER_DATA_QUEUE_NAME = "nephele.cloud.b2b.create.customer.data.sync.queue";
	public static final String CREATE_CUSTOMER_DATA_ROUTING_KEY = "nephele.cloud.b2b.create.customer.data.syncKey";
	
	public static final String UPDATE_CUSTOMER_DATA_QUEUE_NAME = "nephele.cloud.b2b.update.customer.data.sync.queue";
	public static final String UPDATE_CUSTOMER_DATA_ROUTING_KEY = "nephele.cloud.b2b.update.customer.data.syncKey";
	
	public static final String DELETE_CUSTOMER_DATA_QUEUE_NAME="nephele.cloud.b2b.delete.customer.data.sync.queue";
	public static final String DELETE_CUSTOMER_DATA_ROUTING_KEY = "nephele.cloud.b2b.delete.customer.data.syncKey";
	
	public static final String CREATE_EXTERNAL_PRODUCT_DATA_QUEUE_NAME = "nephele.cloud.b2b.create.external.product.data.sync.queue";
	public static final String CREATE_EXTERNAL_PRODUCT_DATA_ROUTING_KEY = "nephele.cloud.b2b.create.external.product.data.syncKey";
	
	public static final String UPDATE_EXTERNAL_PRODUCT_QUEUE_NAME = "nephele.cloud.b2b.update.external.product.data.sync.queue";
	public static final String UPDATE_EXTERNAL_PRODUCT_ROUTING_KEY = "nephele.cloud.b2b.update.external.product.data.syncKey";
	
	public static final String SOLAR_SEARCH_PRODUCT_SYNC_QUEUE_NAME="nephele.cloud.b2b.solar.search.product.sync.queue";
	public static final String SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY = "nephele.cloud.b2b.solar.search.product.syncKey";
	
	public static final String SOLR_ELASTIC_PRODUCTPLAN_SYNC_QUEUE_NAME="nephele.cloud.b2b.solr.elastic.productplan.sync.queue";
	public static final String SOLR_ELASTIC_PRODUCTPLAN_SYNC_ROUTING_KEY = "nephele.cloud.b2b.solr.elastic.productplan.syncKey";
	
	
	
	
	/*@Bean(name = "resellerDataQueue")
	public Queue getResellerDataQueue() {
		return new Queue(RESELLER_DATA_QUEUE_NAME, true);
	}*/
	

	@Bean(name = "createResellerDataQueue")
	public Queue getCreateResellerDataQueue() {
		return new Queue(CREATE_RESELLER_DATA_QUEUE_NAME, true);
	}
	
	@Bean(name = "updateResellerDataQueue")
	public Queue getUpdateResellerDataQueue() {
		return new Queue(UPDATE_RESELLER_DATA_QUEUE_NAME, true);
	}
	
	@Bean(name="deleteResellerDataQueue")
	public Queue getDeleteResellerDataQueue(){
		return new Queue(DELETE_RESELLER_DATA_QUEUE_NAME, true);
	}
	
	@Bean(name = "createCustomerDataQueue")
	public Queue getCreateCustomerDataQueue() {
		return new Queue(CREATE_CUSTOMER_DATA_QUEUE_NAME, true);
	}
	
	@Bean(name = "updateCustomerDataQueue")
	public Queue getUpdateCustomerDataQueue() {
		return new Queue(UPDATE_CUSTOMER_DATA_QUEUE_NAME, true);
	}
	
	@Bean(name="deleteCustomerDataQueue")
	public Queue getDeleteCustomerDataQueue(){
		return new Queue(DELETE_CUSTOMER_DATA_QUEUE_NAME, true);
	}
	
	@Bean(name="solarSearchProductSyncQueue")
	public Queue getSolarSearchProductSyncQueue(){
		return new Queue(SOLAR_SEARCH_PRODUCT_SYNC_QUEUE_NAME, true);
	}
	
	@Bean(name = "createExternalProductDataQueue")
	public Queue getExternalProductDataQueue() {
		return new Queue(CREATE_EXTERNAL_PRODUCT_DATA_QUEUE_NAME, true);
	}
	
	@Bean(name = "updateExternalProductDataQueue")
	public Queue getUpdateExternalProductDataQueue() {
		return new Queue(UPDATE_EXTERNAL_PRODUCT_QUEUE_NAME, true);
	}
	
	@Bean(name="solrElasticProductPlanSyncQueue")
	public Queue getSolrElasticProductPlanSyncQueue(){
		return new Queue(SOLR_ELASTIC_PRODUCTPLAN_SYNC_QUEUE_NAME, true);
	}
	
	
	@Bean(name = "b2bDirectExchange")
	public DirectExchange getB2BDirectExchange() {
		return new DirectExchange(EXCHANGE_NAME, true, false);
	}
	
	/*	@Bean(name = "resellerDataBinding")
	Binding getResellerDataBinding(Queue resellerDataQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(resellerDataQueue).to(b2bDirectExchange).with(RESELLER_DATA_ROUTING_KEY);
	}*/
	
	@Bean(name = "createResellerDataBinding")
	Binding getCreateResellerDataBinding(Queue createResellerDataQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(createResellerDataQueue).to(b2bDirectExchange).with(CREATE_RESELLER_DATA_ROUTING_KEY);
	}
	
	@Bean(name = "updateResellerDataBinding")
	Binding getUpdateResellerDataBinding(Queue updateResellerDataQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(updateResellerDataQueue).to(b2bDirectExchange).with(UPDATE_RESELLER_DATA_ROUTING_KEY);
	}
	
	@Bean(name="deleteResellerDataBinding")
	Binding getDeleteResellerDataBinding(Queue deleteResellerDataQueue,DirectExchange b2bDirectExchange){
		return BindingBuilder.bind(deleteResellerDataQueue).to(b2bDirectExchange).with(DELETE_RESELLER_DATA_ROUTING_KEY);
	}
	
	@Bean(name = "createCustomerDataBinding")
	Binding getCreateCustomerDataBinding(Queue createCustomerDataQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(createCustomerDataQueue).to(b2bDirectExchange).with(CREATE_CUSTOMER_DATA_ROUTING_KEY);
	}
	
	@Bean(name = "updateCustomerDataBinding")
	Binding getUpdateCustomerDataBinding(Queue updateCustomerDataQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(updateCustomerDataQueue).to(b2bDirectExchange).with(UPDATE_CUSTOMER_DATA_ROUTING_KEY);
	}
	
	@Bean(name="deleteCustomerDataBinding")
	Binding getDeleteCustomerDataBinding(Queue deleteCustomerDataQueue,DirectExchange b2bDirectExchange){
		return BindingBuilder.bind(deleteCustomerDataQueue).to(b2bDirectExchange).with(DELETE_CUSTOMER_DATA_ROUTING_KEY);
	}
	
	@Bean(name="solarSearchProductSyncBinding")
	Binding getSolarSearchProductSyncBinding(Queue solarSearchProductSyncQueue, DirectExchange b2bDirectExchange){
		return BindingBuilder.bind(solarSearchProductSyncQueue).to(b2bDirectExchange).with(SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY);
	}
	

	@Bean(name = "createExternalProductDataBinding")
	Binding getCreateExternalProductDataBinding(Queue createExternalProductDataQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(createExternalProductDataQueue).to(b2bDirectExchange).with(CREATE_EXTERNAL_PRODUCT_DATA_ROUTING_KEY);
	}
	
	@Bean(name = "updateExternalProductDataBinding")
	Binding getUpdateExternalProductDataBinding(Queue updateExternalProductDataQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(updateExternalProductDataQueue).to(b2bDirectExchange).with(UPDATE_EXTERNAL_PRODUCT_ROUTING_KEY);
	}
	
	@Bean(name = "solrElasticProductPlanSyncBinding")
	Binding getSolrElasticProductPlanSyncBinding(Queue solrElasticProductPlanSyncQueue, DirectExchange b2bDirectExchange) {
		return BindingBuilder.bind(solrElasticProductPlanSyncQueue).to(b2bDirectExchange).with(SOLR_ELASTIC_PRODUCTPLAN_SYNC_ROUTING_KEY);
	}
	
	
	

	@PostConstruct
	public void initializeB2BServiceMessageQueue() {
		log.debug("initializeB2BServiceMessageQueue");

		DirectExchange b2bDirectExchange = getB2BDirectExchange();
		
		Queue createResellerDataQueue = getCreateResellerDataQueue();
		Binding createResellerDataBinding = getCreateResellerDataBinding(createResellerDataQueue, b2bDirectExchange);
		
		Queue updateResellerDataQueue = getUpdateResellerDataQueue();
		Binding updateResellerDataBinding = getUpdateResellerDataBinding(updateResellerDataQueue, b2bDirectExchange);
		
		Queue deleteResellerDataQueue=getDeleteResellerDataQueue();
		Binding deleteResellerDataBinding=getDeleteResellerDataBinding(deleteResellerDataQueue, b2bDirectExchange);
		
		Queue createCustomerDataQueue = getCreateCustomerDataQueue();
		Binding createCustomerDataBinding = getCreateCustomerDataBinding(createCustomerDataQueue, b2bDirectExchange);
		
		Queue updateCustomerDataQueue = getUpdateCustomerDataQueue();
		Binding updateCustomerDataBinding = getUpdateCustomerDataBinding(updateCustomerDataQueue, b2bDirectExchange);
		
		Queue deleteCustomerDataQueue=getDeleteCustomerDataQueue();
		Binding deleteCustomerDataBinding = getDeleteCustomerDataBinding(deleteCustomerDataQueue, b2bDirectExchange);
		
		Queue solarSearchProductSyncQueue = getSolarSearchProductSyncQueue();
		Binding solarSearchProductSyncBinding = getSolarSearchProductSyncBinding(solarSearchProductSyncQueue, b2bDirectExchange);
		
		Queue createExternalProductDataQueue = getExternalProductDataQueue();
		Binding createExternalProductDataBinding = getCreateExternalProductDataBinding(createExternalProductDataQueue, b2bDirectExchange);
		
		Queue updateExternalProductDataQueue = getUpdateExternalProductDataQueue();
		Binding updateExternalProductDataBinding = getUpdateExternalProductDataBinding(updateExternalProductDataQueue, b2bDirectExchange);

		Queue solrElasticProductPlanSyncQueue = getSolrElasticProductPlanSyncQueue();
		Binding solrElasticProductPlanSyncBinding = getSolrElasticProductPlanSyncBinding(solrElasticProductPlanSyncQueue, b2bDirectExchange);
		
		
		rabbitAdmin.declareExchange(b2bDirectExchange);
		
		/*rabbitAdmin.declareQueue(resellerDataQueue);
		rabbitAdmin.declareBinding(resellerDataBinding);*/
		
		rabbitAdmin.declareQueue(createResellerDataQueue);
		rabbitAdmin.declareBinding(createResellerDataBinding);
		
		rabbitAdmin.declareQueue(updateResellerDataQueue);
		rabbitAdmin.declareBinding(updateResellerDataBinding);
		
		rabbitAdmin.declareQueue(deleteResellerDataQueue);
		rabbitAdmin.declareBinding(deleteResellerDataBinding);
		
		rabbitAdmin.declareQueue(createCustomerDataQueue);
		rabbitAdmin.declareBinding(createCustomerDataBinding);
		
		rabbitAdmin.declareQueue(updateCustomerDataQueue);
		rabbitAdmin.declareBinding(updateCustomerDataBinding);
		
		rabbitAdmin.declareQueue(deleteCustomerDataQueue);
		rabbitAdmin.declareBinding(deleteCustomerDataBinding);
		
		rabbitAdmin.declareQueue(solarSearchProductSyncQueue);
		rabbitAdmin.declareBinding(solarSearchProductSyncBinding);
		
		rabbitAdmin.declareQueue(createExternalProductDataQueue);
		rabbitAdmin.declareBinding(createExternalProductDataBinding);
		
		rabbitAdmin.declareQueue(updateExternalProductDataQueue);
		rabbitAdmin.declareBinding(updateExternalProductDataBinding);
		
		rabbitAdmin.declareQueue(solrElasticProductPlanSyncQueue);
		rabbitAdmin.declareBinding(solrElasticProductPlanSyncBinding);

	}
	
}
