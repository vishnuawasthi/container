package com.valuelabs.nephele.manager.controller;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.*;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.BundleCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.BundleQueryService;
import com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.BundleAssembler;
import com.valuelabs.nephele.marketplace.resource.BundleResource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY;

@Slf4j
@RestController
@RequestMapping(value = "/manager/bundles")
public class BundleCommandController {

	@Autowired
	RabbitTemplate rabbitTemplate;
	@Autowired
	private BundleAssembler assembler;
	@Autowired
	private BundleCommandService service;
	@Autowired
	private BundleQueryService bundleQueryService;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<BundleResource> createBundle(@Valid @RequestBody BundleResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createBundle() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<BundleResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		BundleDetails details = assembler.fromResource(resource);
		CreateBundleEvent request = new CreateBundleEvent().setBundleDetails(details);
		if (request != null) {
			BundleCreatedEvent event=service.createBundle(request);
            	details = event.getBundleDetails();
			
		}
		log.info("createBundle() : END");
		return new ResponseEntity<BundleResource>( assembler.toResource(details),HttpStatus.CREATED);
	}
	
	@RequestMapping(value="{id}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<BundleResource> deleteBundle(@PathVariable Long id){
		log.info("deleteBundle() : START");

		if(id != null){
			service.deleteBundle(id);
		}		
		
		log.info("deleteBundle() : START");
		return new ResponseEntity<BundleResource>(HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<BundleResource> updateBundleStatus(
			@Valid @RequestBody BundleResource resource,
			BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateBundleStatus() : START");
		if (resource.getBundleId() == null) {
			result.addError(new FieldError("resource", "bundleId", resource
					.getBundleId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		BundleDetails bundleDetails = assembler.fromResource(resource);
		log.info("details {} ", bundleDetails);
		CreateBundleEvent request = new CreateBundleEvent()
				.setBundleDetails(bundleDetails);
		if (request != null) {
			BundleCreatedEvent response = service.updateBundle(request);
			if(null != response){
				ReadBundleEvent event = new ReadBundleEvent().setId(bundleDetails.getId());
				EntityReadEvent<BundleDetails> entityReadEvent = bundleQueryService.readBundle(event);
				B2BSolarProductSyncEvent productListSyncEvent = new B2BSolarProductSyncEvent().setBundleDetails(entityReadEvent.getEntity());
			log.info("Solr bundle request:{}"+productListSyncEvent.getBundleDetails());
			rabbitTemplate.convertAndSend(B2BServiceIntegrationMQConfig.EXCHANGE_NAME, SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY,	productListSyncEvent);
			}
		}
		log.info("updateBundleStatus() : END");
		return new ResponseEntity<BundleResource>(HttpStatus.OK);
	}
	

}
