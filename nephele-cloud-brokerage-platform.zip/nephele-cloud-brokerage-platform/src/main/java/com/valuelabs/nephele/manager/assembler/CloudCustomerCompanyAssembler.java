package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;
import com.valuelabs.nephele.manager.controller.CloudCustomerCompanyQueryController;
import com.valuelabs.nephele.manager.resource.CloudCustomerCompanyResource;

@Slf4j
@Service
public class CloudCustomerCompanyAssembler
		extends
		ResourceAssemblerSupport<CloudCustomerCompanyDetails, CloudCustomerCompanyResource> {

	public CloudCustomerCompanyAssembler() {
		super(CloudCustomerCompanyDetails.class,
				CloudCustomerCompanyResource.class);
	}

	@Override
	public CloudCustomerCompanyResource toResource(
			CloudCustomerCompanyDetails details) {
		log.debug("toResource() : START");
		CloudCustomerCompanyResource resource = instantiateResource(details);

		resource = CloudCustomerCompanyResource.builder()
												.customerCompanyId(details.getCustomerCompanyId())
												.customerCompanyName(details.getCustomerCompanyName())
												.cloudResellerCompanyId(details.getCloudResellerCompanyId())
												.firstName(details.getFirstName())
												.lastName(details.getLastName())
												.email(details.getEmail())
												.addressLine1(details.getAddressLine1())
												.addressLine2(details.getAddressLine2())
												.city(details.getCity())
												.state(details.getState())
												.zipcode(details.getZipcode())
												.country(details.getCountry())
												.externalCustomerCompanyCode(
														details.getExternalCustomerCompanyCode())
												.externalResellerCompanyCode(details.getExternalResellerCompanyCode())
												.isActive(details.getIsActive())
												.businessContactname(details.getBusinessContactname())
												.businessContactEmail(details.getBusinessContactEmail())
												.abnNumber(details.getAbnNumber())
												.acnNumber(details.getAcnNumber())
												.phoneNumber(details.getPhoneNumber())
												.countryCodeISO(details.getCountryCodeISO())
												.countryCodeUN(details.getCountryCodeUN())
												.websiteUrl(details.getWebsiteUrl())
												.build();
		resource.add(linkTo(
				methodOn(CloudCustomerCompanyQueryController.class)
						.readCloudCustomerCompany(
								details.getCustomerCompanyId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;

	}

	public CloudCustomerCompanyDetails fromResouce(
			CloudCustomerCompanyResource resource) {
		log.debug("fromResource: START:{} ", resource);
		CloudCustomerCompanyDetails details = CloudCustomerCompanyDetails.builder()
																			.customerCompanyId(resource.getCustomerCompanyId())
																			.customerCompanyName(resource.getCustomerCompanyName())
																			.firstName(resource.getFirstName())
																			.lastName(resource.getLastName())
																			.cloudResellerCompanyId(resource.getCloudResellerCompanyId())
																			.email(resource.getEmail())
																			.addressLine1(resource.getAddressLine1())
																			.addressLine2(resource.getAddressLine2())
																			.city(resource.getCity())
																			.zipcode(resource.getZipcode())
																			.state(resource.getState())
																			.country(resource.getCountry())
																			.externalCustomerCompanyCode(
																					resource.getExternalCustomerCompanyCode())
																			.externalResellerCompanyCode(
																					resource.getExternalResellerCompanyCode())
																			.isActive(resource.getIsActive())
																			.businessContactname(resource.getBusinessContactname())
																			.businessContactEmail(resource.getBusinessContactEmail())
																			.abnNumber(resource.getAbnNumber())
																			.acnNumber(resource.getAcnNumber())
																			.phoneNumber(resource.getPhoneNumber())
																			.countryCodeISO(resource.getCountryCodeISO())
																			.countryCodeUN(resource.getCountryCodeUN())
																			.websiteUrl(resource.getWebsiteUrl())
																			.build();
		log.debug("fromResouce() : END");
		return details;
	}

	public List<CloudCustomerCompanyDetails> fromResouce(
			List<CloudCustomerCompanyResource> resources) {
		log.debug("fromResouce()  - start");
		List<CloudCustomerCompanyDetails> detailsList = new ArrayList<CloudCustomerCompanyDetails>();
		for (CloudCustomerCompanyResource resource : resources) {
			CloudCustomerCompanyDetails details = CloudCustomerCompanyDetails.builder()
																				.customerCompanyId(resource.getCustomerCompanyId())
																				.customerCompanyName(resource.getCustomerCompanyName())
																				.firstName(resource.getFirstName())
																				.lastName(resource.getLastName())
																				.email(resource.getEmail())
																				.addressLine1(resource.getAddressLine1())
																				.addressLine2(resource.getAddressLine2())
																				.city(resource.getCity())
																				.zipcode(resource.getZipcode())
																				.state(resource.getState())
																				.country(resource.getCountry())
																				.externalCustomerCompanyCode(
																						resource.getExternalCustomerCompanyCode())
																				.externalResellerCompanyCode(
																						resource.getExternalResellerCompanyCode())
																				.isActive(resource.getIsActive())
																				.businessContactname(resource.getBusinessContactname())
																				.businessContactEmail(resource.getBusinessContactEmail())
																				.abnNumber(resource.getAbnNumber())
																				.acnNumber(resource.getAcnNumber())
																				.phoneNumber(resource.getPhoneNumber())
																				.countryCodeISO(resource.getCountryCodeISO())
																				.countryCodeUN(resource.getCountryCodeUN())
																				.websiteUrl(resource.getWebsiteUrl())
																				.build();
			detailsList.add(details);
		}
		log.debug("fromResouce()  - end");
		return detailsList;
	}

}
