package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudGeographyDetails;
import com.valuelabs.nephele.manager.controller.CloudGeographyQueryController;
import com.valuelabs.nephele.manager.resource.CloudGeographyResource;

@Service
@Slf4j
public class CloudGeographyAssembler extends ResourceAssemblerSupport<CloudGeographyDetails, CloudGeographyResource>  {

	public CloudGeographyAssembler() {
		super(CloudGeographyQueryController.class, CloudGeographyResource.class);
	}

	@Override
	public CloudGeographyResource toResource(CloudGeographyDetails entity) {
		log.debug("toResource()- start") ;
		CloudGeographyResource resource = CloudGeographyResource.builder()
																.geographyId(entity.getId())
																.geographyCode(entity.getGeographyCode())
																.geographyName(entity.getGeographyName())
																.build();
		resource.add(linkTo(methodOn(CloudGeographyQueryController.class).readCloudGeography(entity.getId())).withSelfRel());		
		log.debug("toResource()- end") ;
		return resource;
	}
	
	public CloudGeographyDetails fromResource(CloudGeographyResource  resource) {
		log.debug("fromResource()- start") ;
		CloudGeographyDetails details = CloudGeographyDetails.builder()
																.id(resource.getGeographyId())
																.geographyCode(resource.getGeographyCode())
																.geographyName(resource.getGeographyName())
																.build();
		log.debug("fromResource()- end") ;
		return details;
	}
	
	

	
}
