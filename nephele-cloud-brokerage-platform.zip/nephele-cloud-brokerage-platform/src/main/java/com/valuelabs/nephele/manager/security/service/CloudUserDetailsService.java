/**
 * 
 */
package com.valuelabs.nephele.manager.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudDistributorUser;
import com.valuelabs.nephele.admin.data.repository.CloudDistributorUserRepository;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserService;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Vishnu Awasthi on 24/08/2015
 *
 */
@Slf4j
@Service("userDetailsService")
public class CloudUserDetailsService implements UserDetailsService {

	/*@Autowired
	private CloudDistributorUserDAO userDAO;*/
	
	@Autowired 
	private CloudDistributorUserRepository userRepository;

	@Autowired
	private CloudUserService service;
	
	@Autowired
	private NepheleUtils nepheleUtils;
	
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		log.debug("loadUserByUsername() -start");
		UserDetails userDetails = null;
		CloudDistributorUser user = userRepository.findUserByEmail(userName);
		if (null != user && !StringUtils.isEmpty(user.getPassword())){
			log.debug("username  : " + user.getEmail() + "password  : " + user.getPassword());
			user.setPassword(nepheleUtils.decrypt(user.getPassword()));
			userDetails = new CloudUserDetails(user);
		}
		log.debug("loadUserByUsername() -end");
		return userDetails;
	}

}
