package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudLocationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudLocationsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudLocationQueryService;
import com.valuelabs.nephele.manager.assembler.CloudLocationAssembler;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;
import com.valuelabs.nephele.marketplace.resource.Summary;

import lombok.extern.slf4j.Slf4j;



@Slf4j
@RestController
@RequestMapping("/manager/cloudLocation")
public class CloudLocationQueryController {

	
	
		@Autowired
		private CloudLocationAssembler assembler;

		@Autowired
		private CloudLocationQueryService service;

		@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<CloudLocationResource> readCloudLocation(@PathVariable Long id){
			log.info("readCloudLocation() START");
			ReadCloudLocationEvent request=new ReadCloudLocationEvent().setCloudLocationId(id);

			EntityReadEvent<CloudLocationDetails> event = service.readCloudLocation(request);
			if(!event.isFound()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			CloudLocationDetails entity=event.getEntity();
			log.info("readCloudLocation() END");
			return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
		}
		
		
		@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<PagedResources<CloudLocationResource>> readCloudLocations(
				@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
				@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
				@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
				PagedResourcesAssembler<CloudLocationDetails> pagedAssembler) {
			log.info("readCloudLocation() START");
			ReadCloudLocationsEvent request=new ReadCloudLocationsEvent().setPageable(pageable);
			request.setSortColumnName(sortColumnName);
			request.setSortDirection(sortDirection);

			PageReadEvent<CloudLocationDetails> event=service.readCloudLocations(request);

			Page<CloudLocationDetails> page=event.getPage();
			PagedResources<CloudLocationResource> pagedResources = pagedAssembler.toResource(page, assembler);
			log.info("readCloudLocation() END");
			return new ResponseEntity<>(pagedResources, HttpStatus.OK);
		}
		
		/**
		 * This method read all the operating system details matched by status.
		 * @param status
		 * @param pageable
		 * @param pagedAssembler
		 * @return
		 */
	@RequestMapping(value = "/readByStatus/{status}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudLocationResource>> readreadCloudLocationByStatus(
		@PathVariable String status,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
		@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
		PagedResourcesAssembler<CloudLocationDetails> pagedAssembler) {
		log.info("readreadCloudLocationByStatus()  - start");
		ReadCloudLocationsEvent request = new ReadCloudLocationsEvent().setPageable(pageable);
		request.setStatus(status);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudLocationDetails> event = service.findByStatus(request);
		Page<CloudLocationDetails> page = event.getPage();
		PagedResources<CloudLocationResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readreadCloudLocationByStatus() -end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * This method read all the Cloud_location details matched by Name and Status.
	 * @param status
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	/*@RequestMapping(value = "/readByStatus/{name}/{status}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudLocationResource>> readreadCloudLocationByNameNStatus(@PathVariable String name, @PathVariable String status,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudLocationDetails> pagedAssembler) {
		log.info("readreadCloudLocationByStatus()  - start");
		ReadCloudLocationsEvent request = new ReadCloudLocationsEvent().setPageable(pageable);
		request.setName(name);
		request.setStatus(status);
		EntityReadEvent<CloudLocationDetails> event = service.findByNameNStatus(request);
		Page<CloudLocationDetails> page = event.getPage();
		PagedResources<CloudLocationResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readreadCloudLocationByStatus() -end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}*/
	

	/**
	 * 
	 * @param serviceId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/summaryByServiceId/{serviceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Summary> readSummaryByServiceId(@PathVariable Long serviceId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudLocationDetails> pagedAssembler) {
		log.info("readLocationSummaryByService() - start");
		ReadCloudLocationsEvent request = new ReadCloudLocationsEvent().setServiceId(serviceId);
		Map<String, Long> event = service.readLocationSummaryByServiceId(request);
		Summary summary = Summary.builder().summary(event).build();
		log.info("readLocationSummaryByService()   -end");
		return new ResponseEntity<>(summary, HttpStatus.OK);
	}
}
