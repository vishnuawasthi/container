package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorCompanyDetails;
import com.valuelabs.nephele.manager.controller.CloudDistributorCompanyQueryController;
import com.valuelabs.nephele.manager.resource.CloudDistributorCompanyResource;
;

@Slf4j
@Service
public class CloudDistributorCompanyAssembler extends ResourceAssemblerSupport<CloudDistributorCompanyDetails, CloudDistributorCompanyResource> {

	public CloudDistributorCompanyAssembler() {
		super(CloudDistributorCompanyQueryController.class, CloudDistributorCompanyResource.class);
	}

	@Override
	public CloudDistributorCompanyResource toResource(CloudDistributorCompanyDetails entity) {
		log.debug("toResource() - start");
		CloudDistributorCompanyResource resource = instantiateResource(entity);
		resource = CloudDistributorCompanyResource.builder().distributorCompanyId(entity.getDistributorCompanyId())
				.distributorCompanyName(entity.getDistributorCompanyName()).build();
		resource.add(linkTo(methodOn(CloudDistributorCompanyQueryController.class).readCloudDistributorCompany(entity.getDistributorCompanyId()))
				.withSelfRel());
		log.debug("toResource() - end");
		return resource;
	}

	public CloudDistributorCompanyDetails fromResource(CloudDistributorCompanyResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudDistributorCompanyDetails details = CloudDistributorCompanyDetails.builder().distributorCompanyId(resource.getDistributorCompanyId())
				.distributorCompanyName(resource.getDistributorCompanyName()).build();
		log.debug("fromResource() - end");
		return details;
	}
}
