package com.valuelabs.nephele.manager.configuration;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class PriceMgmtMQConfig {

	@Autowired
	AmqpAdmin rabbitAdmin;

	public static final String EXCHANGE_NAME = "nephele.cloud.price.mgmt.exchange";

	public static final String PRICE_MGMT_CONFIG_QUEUE_NAME = "nephele.cloud.price.mgmt.queue";
	public static final String PRICE_MGMT_CONFIG_ROUTING_KEY = "nephele.cloud.price.mgmt.syncKey";

	@Bean(name = "createPriceMgmtConfigQueue")
	public Queue getPriceMgmtConfigQueue() {
		return new Queue(PRICE_MGMT_CONFIG_QUEUE_NAME, true);
	}

	@Bean(name = "priceMgmtConfigDirectExchange")
	public DirectExchange getPriceMgmtConfigDirectExchange() {
		return new DirectExchange(EXCHANGE_NAME, true, false);
	}

	@Bean(name = "priceMgmtConfigBinding")
	Binding getPriceMgmtConfigDataFeedBinding(Queue createPriceMgmtConfigQueue,
			DirectExchange priceMgmtConfigDirectExchange) {
		return BindingBuilder.bind(createPriceMgmtConfigQueue).to(priceMgmtConfigDirectExchange)
				.with(PRICE_MGMT_CONFIG_ROUTING_KEY);
	}

	@PostConstruct
	public void initializePriceMgmtConfigQueue() {
		log.debug("initializePriceMgmtConfigDataFeedQueue");

		DirectExchange priceMgmtConfigDirectExchange = getPriceMgmtConfigDirectExchange();

		Queue createPriceMgmtConfigQueue = getPriceMgmtConfigQueue();
		Binding priceMgmtConfigBinding = getPriceMgmtConfigDataFeedBinding(createPriceMgmtConfigQueue,
				priceMgmtConfigDirectExchange);

		rabbitAdmin.declareExchange(priceMgmtConfigDirectExchange);

		rabbitAdmin.declareQueue(createPriceMgmtConfigQueue);
		rabbitAdmin.declareBinding(priceMgmtConfigBinding);

	}

}
