package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionEditionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateSubscriptionEditionEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudSubscriptionEditionCommandService;
import com.valuelabs.nephele.manager.assembler.CloudSubscriptionEditionAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudSubscriptionEditionResource;

@Slf4j
@RestController
@RequestMapping("/manager/subscriptionEdition")
@Transactional
public class CloudSubscriptionEditionCommandController {

	@Autowired
	private CloudSubscriptionEditionAssembler assembler;

	@Autowired
	private CloudSubscriptionEditionCommandService service;

	/**
	 * Create new record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudSubscriptionEditionResource> createSubscriptionEdition(
			@Valid @RequestBody CloudSubscriptionEditionResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createSubscriptionEdition() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudSubscriptionEditionResource>(
					resource, HttpStatus.BAD_REQUEST);
		}
		CloudSubscriptionEditionDetails cloudSubscriptionEditionDetails = assembler
				.fromResource(resource);
		CreateSubscriptionEditionEvent request = new CreateSubscriptionEditionEvent()
				.setCloudSubscriptionEditionDetails(cloudSubscriptionEditionDetails);
		if (request != null) {
			service.createServiceSubscriptionEdition(request);
		}
		log.info("createSubscriptionEdition() : END");
		return new ResponseEntity<CloudSubscriptionEditionResource>(
				HttpStatus.CREATED);
	}

	/**
	 * Update existing record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudSubscriptionEditionResource> updateSubscriptionEdition(
			@Valid @RequestBody CloudSubscriptionEditionResource resource,
			BindingResult result) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("updateSubscriptionEdition() : START");
		if (resource.getSubscriptionEditionId() == null) {
			result.addError(new FieldError("resource",
					"cloudSubscriptionEditionId", resource
							.getSubscriptionEditionId(), false, null,
					null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudSubscriptionEditionResource>(
					resource, HttpStatus.BAD_REQUEST);
		}
		CloudSubscriptionEditionDetails cloudSubscriptionEditionDetails = assembler
				.fromResource(resource);
		CreateSubscriptionEditionEvent eventRequest = new CreateSubscriptionEditionEvent()
				.setCloudSubscriptionEditionDetails(cloudSubscriptionEditionDetails);
		if (eventRequest != null) {
			service.updateServiceSubscriptionEdition(eventRequest);
		}
		log.info("updateSubscriptionEdition() : END");
		return new ResponseEntity<CloudSubscriptionEditionResource>(
				HttpStatus.OK);
	}

}
