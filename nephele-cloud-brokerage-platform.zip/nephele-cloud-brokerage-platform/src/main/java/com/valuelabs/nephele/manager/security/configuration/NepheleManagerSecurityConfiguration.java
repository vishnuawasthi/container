package com.valuelabs.nephele.manager.security.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.valuelabs.nephele.admin.data.repository.CloudDistributorUserRepository;
import com.valuelabs.nephele.admin.data.repository.CloudManagerAppPermissionRepository;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerCompanyQueryService;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCustomerCompanyQueryService;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.filter.NepheleManagerFilter;
import com.valuelabs.nephele.manager.security.service.CloudUserDetailsService;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)
public class NepheleManagerSecurityConfiguration extends WebSecurityConfigurerAdapter {

  NepheleManagerFilter filter;
  @Autowired
  @Qualifier("customAuthenticationProvider")
  CustomAuthenticationProvider provider;
  @Autowired
  CloudUserService userService;
  @Autowired
  CloudManagerAppPermissionRepository permissionRepository;
  @Autowired
  Environment environment;
  @Autowired
  private CloudUserDetailsService userDetailsService;
  @Autowired
  private CloudDistributorUserRepository userRepository;
  @Autowired
  private CloudResellerCompanyQueryService cloudResellerCompanyQueryService;
  @Autowired
  private CloudCustomerCompanyQueryService cloudCustomerCompanyQueryService;
  
  @Autowired
  private NepheleUtils nepheleUtils;
  
  @Value("${marketplace.secret}")
  private String marketplaceSecretKey;

  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    auth.userDetailsService(userDetailsService);
    filter = new NepheleManagerFilter(provider, userRepository, cloudResellerCompanyQueryService, cloudCustomerCompanyQueryService, userService, permissionRepository, environment,nepheleUtils,marketplaceSecretKey);
  }

  @Override
  protected void configure(HttpSecurity http) throws Exception {
   /* http
        .httpBasic()
        .and()
        .authorizeRequests()
        .antMatchers("/login", "/login*").permitAll()
        .antMatchers("*//*password**").permitAll()
        .antMatchers("/globalLogout", "/globalLogout*").permitAll()
        .antMatchers(HttpMethod.POST, "/manager*//*").access("hasRole('ADMIN')")
        .antMatchers(HttpMethod.PUT, "/manager*//*").access("hasRole('ADMIN')")
        .antMatchers(HttpMethod.PATCH, "/manager*//*").access("hasRole('ADMIN')")
        .antMatchers(HttpMethod.DELETE, "/manager*//*").access("hasRole('ADMIN')")
        .antMatchers(HttpMethod.GET, "/manager*//*").permitAll()
        .and()
        .csrf().disable()
        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

    http.userDetailsService(userDetailsService());*/

    http.csrf().disable()
        .authorizeRequests()
        .antMatchers("/login", "/login*").permitAll()
        .antMatchers("*//*password**").permitAll()
        .antMatchers("/globalLogout", "/globalLogout*").permitAll()
        /*.antMatchers(HttpMethod.POST, "/manager*//*").access("hasRole('ADMIN')")
        .antMatchers(HttpMethod.PUT, "/manager*//*").access("hasRole('ADMIN')")
        .antMatchers(HttpMethod.PATCH, "/manager*//*").access("hasRole('ADMIN')")
        .antMatchers(HttpMethod.DELETE, "/manager*//*").access("hasRole('ADMIN')")*/
        .antMatchers(HttpMethod.GET, "/manager*//*").permitAll()
        .and()
            //.antMatcher("/manager*//**")
            //.antMatcher("/marketplace*//**")
        .addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class)
        .authenticationProvider(provider);
  }

  @Override
  protected UserDetailsService userDetailsService() {
    return userDetailsService;
  }

}
