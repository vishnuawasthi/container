package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDeliveryModelDetails;
import com.valuelabs.nephele.manager.controller.CloudServiceDeliveryModelQueryController;
import com.valuelabs.nephele.manager.resource.CloudServiceDeliveryModelResource;

@Slf4j
@Service
public class CloudServiceDeliveryModelAssembler
		extends
		ResourceAssemblerSupport<CloudServiceDeliveryModelDetails, CloudServiceDeliveryModelResource> {

	public CloudServiceDeliveryModelAssembler() {
		super(CloudServiceDeliveryModelQueryController.class,
				CloudServiceDeliveryModelResource.class);
	}

	@Override
	public CloudServiceDeliveryModelResource toResource(
			CloudServiceDeliveryModelDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + entity);
		CloudServiceDeliveryModelResource resource = instantiateResource(entity);

		resource = CloudServiceDeliveryModelResource.builder()
				.serviceDeliveryModelId(entity.getServiceDeliveryModelId())
				.name(entity.getName()).description(entity.getDescription())
				.build();
		resource.add(linkTo(
				methodOn(CloudServiceDeliveryModelQueryController.class)
						.readServiceDeliveryModel(
								entity.getServiceDeliveryModelId()))
				.withSelfRel());
		log.debug("toResource() : resource : " + resource);
		log.debug("toResource() : resource Links: " + resource.getLinks());
		log.debug("toResource() : END");
		return resource;

	}

	public CloudServiceDeliveryModelDetails fromResouce(
			CloudServiceDeliveryModelResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudServiceDeliveryModelDetails details = CloudServiceDeliveryModelDetails
				.builder().name(resource.getName())
				.description(resource.getDescription())
				.serviceDeliveryModelId(resource.getServiceDeliveryModelId())
				.build();
		log.debug("fromResouce: END");
		return details;
	}

}
