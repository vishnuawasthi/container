package com.valuelabs.nephele.manager.resource;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
public class CloudDistributorPriceGroupResource extends ResourceSupport {

	private Integer distributorPriceGroupId;
	private String description;
	private String name;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date created;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date updated;
	private Integer resellersCount;

}
