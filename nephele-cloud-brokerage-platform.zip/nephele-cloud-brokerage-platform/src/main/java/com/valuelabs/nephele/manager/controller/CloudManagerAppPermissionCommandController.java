package com.valuelabs.nephele.manager.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppPermissionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudManagerAppPermissionEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudManagerAppPermissionCommandService;
import com.valuelabs.nephele.manager.assembler.CloudManagerAppPermissionAssembler;
import com.valuelabs.nephele.manager.resource.CloudManagerAppPermissionResource;
import com.valuelabs.nephele.manager.resource.CloudPermissionsResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j 
@RestController
@RequestMapping(value="/manager/cloudManagerAppPermission")
public class CloudManagerAppPermissionCommandController {
	
	@Autowired
	private CloudManagerAppPermissionCommandService service;
	
	@Autowired
	private CloudManagerAppPermissionAssembler assembler;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudManagerAppPermissionResource> createCloudManagerAppPermission(
			@Valid @RequestBody CloudManagerAppPermissionResource resource,
			BindingResult result) throws IllegalArgumentException   {
		log.info("createCloudManagerAppPermission() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudManagerAppPermissionResource>(resource,HttpStatus.BAD_REQUEST);
					
		}
		CloudManagerAppPermissionDetails userDetails = assembler.fromResource(resource);
		CreateCloudManagerAppPermissionEvent request = new CreateCloudManagerAppPermissionEvent().setCloudManagerAppPermissionDetails(userDetails);
				
		if (request != null) {
			service.createCloudManagerAppPermission(request);
		}
		log.info("createCloudManagerAppPermission() : END");
		return new ResponseEntity<CloudManagerAppPermissionResource>(HttpStatus.CREATED);
	}
	
	/*@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudManagerAppPermissionResource> updateCloudManagerAppPermission(
		@Valid	@RequestBody CloudManagerAppPermissionResource resource,BindingResult result) throws IllegalArgumentException {
		log.info("updateCloudManagerAppPermission() : START");
		
		if(StringUtils.isEmpty(resource.getCloudManagerAppPermissionId())) {
			result.addError(new FieldError("resource", "cloudManagerAppPermissionId", resource.getCloudManagerAppPermissionId(), false, null, null, ""));
		}
		
		if (result.hasErrors()) {
			return new ResponseEntity<CloudManagerAppPermissionResource>(resource,HttpStatus.BAD_REQUEST);
					
		}
		CloudManagerAppPermissionDetails userDetails = assembler.fromResource(resource);
		CreateCloudManagerAppPermissionEvent request = new CreateCloudManagerAppPermissionEvent().setCloudManagerAppPermissionDetails(userDetails);
				
		if (request != null) {
			service.updateCloudManagerAppPermission(request);
		}
		log.info("updateCloudManagerAppPermission() : END");
		return new ResponseEntity<CloudManagerAppPermissionResource>(HttpStatus.OK);
	}*/
	
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudPermissionsResource> updateUserPermissions(@RequestBody CloudPermissionsResource resource){
		log.info("updateUserPermissions() : START");
		
		List<CloudManagerAppPermissionDetails> permissionsDetails = assembler.fromResource(resource);
		CreateCloudManagerAppPermissionEvent request = new CreateCloudManagerAppPermissionEvent().setPermissionsDetails(permissionsDetails);
		
		if(request != null){
			service.updatePermissions(request);
		}
		log.info("updateUserPermissions() : START");
		return new ResponseEntity<CloudPermissionsResource>(HttpStatus.OK);
		
	}
	
	
	
}
