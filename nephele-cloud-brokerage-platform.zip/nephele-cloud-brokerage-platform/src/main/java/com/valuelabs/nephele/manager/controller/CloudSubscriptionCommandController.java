package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateSubscriptionEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudSubscriptionCommandService;
import com.valuelabs.nephele.manager.assembler.CloudSubscriptionAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudSubscriptionResource;

@Slf4j
@RestController
@RequestMapping("/manager/subscription")
@Transactional
public class CloudSubscriptionCommandController {

	@Autowired
	private CloudSubscriptionAssembler assembler;

	@Autowired
	private CloudSubscriptionCommandService service;

	/**
	 * Create new record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudSubscriptionResource> createCloudSubscription(
			@Valid @RequestBody CloudSubscriptionResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createCloudSubscription() : START");
		
		if(StringUtils.isEmpty(resource.getAccountId())) {
			  result.addError(new FieldError("resource", "accountId", resource.getAccountId(), false, null, null, null));
		}
		
		if(StringUtils.isEmpty(resource.getOrderId())) {
			  result.addError(new FieldError("resource", "orderId", resource.getOrderId(), false, null, null, null));
		}
		/*	if(StringUtils.isEmpty(resource.getProductId())) {
			  result.addError(new FieldError("resource", "productId", resource.getProductId(), false, null, null, null));
		}*/
		if(StringUtils.isEmpty(resource.getCloudProductPlanId())) {
			  result.addError(new FieldError("resource", "cloudProductPlan", resource.getCloudProductPlanId(), false, null, null, null));
		}
		
		if (result.hasErrors()) {
			  List<String> errorMessageList = new ArrayList<String>();
			  List<FieldError> errors = result.getFieldErrors();
			  if (result.hasErrors()) {
				for (FieldError fieldError : errors) {
				  errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
				}
				CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
				    .errorMessages(errorMessageList).build();
				return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			  }
			}
		
		
		CloudSubscriptionDetails cloudSubscriptionDetails = assembler
				.fromResource(resource);
		CreateSubscriptionEvent request = new CreateSubscriptionEvent()
				.setCloudSubscriptionDetails(cloudSubscriptionDetails);
		if (request != null) {
			service.createSubscription(request);
		}
		log.info("createCloudSubscription() : END");
		return new ResponseEntity<CloudSubscriptionResource>(HttpStatus.CREATED);
	}

	/**
	 * Update existing record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudSubscriptionResource> updateCloudSubscription(
			@Valid @RequestBody CloudSubscriptionResource resource,
			BindingResult result) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("updateCloudSubscription() : START");
		if (resource.getSubscriptionId() == null) {
			result.addError(new FieldError("resource", "cloudSubscriptionId",
					resource.getSubscriptionId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudSubscriptionResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudSubscriptionDetails subscriptionDetails = assembler
				.fromResource(resource);
		CreateSubscriptionEvent request = new CreateSubscriptionEvent()
				.setCloudSubscriptionDetails(subscriptionDetails);
		if (request != null) {
			service.updateSubscription(request);
		}
		log.info("updateCloudSubscription() : END");
		return new ResponseEntity<CloudSubscriptionResource>(HttpStatus.OK);
	}

}
