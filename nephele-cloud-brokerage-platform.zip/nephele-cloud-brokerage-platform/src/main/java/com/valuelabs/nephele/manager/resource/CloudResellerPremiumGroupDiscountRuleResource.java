package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudResellerPremiumGroupDiscountRuleResource extends ResourceSupport {

  private Long premiumGroupDiscountRuleId;
  private Long premiumGroupDiscountId;
  private Double startRange;
  private Double endRange;
  private Double discount;
}