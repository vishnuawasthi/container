package com.valuelabs.nephele.manager.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import lombok.experimental.Accessors;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.springframework.hateoas.ResourceSupport;

import javax.validation.constraints.NotNull;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CloudManagerAppPermissionResource extends ResourceSupport {
	private Long permissionId;
	private Boolean isRead;
	private Boolean isWrite;
	@NotNull
	private Long roleId;
	private String roleName;
	private CloudManagerAppAccountResource accounts;
	// For Feature 
	private String accountName;
	private Long cloudManagerAppAccountId;
	private String name;
	private String description;
	
	
	
	
}
