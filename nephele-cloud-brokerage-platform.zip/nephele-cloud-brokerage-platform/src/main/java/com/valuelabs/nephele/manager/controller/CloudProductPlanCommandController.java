package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.BillingLifeCycleMQConfig.EXCHANGE_NAME;
import static com.valuelabs.nephele.manager.configuration.BillingLifeCycleMQConfig.PRODUCT_PRICE_ROUTING_KEY;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudProductPlanEvent;
import com.valuelabs.nephele.admin.rest.lib.event.RackspacePricingDataCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ValidationException;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudProductPlanCommandService;
import com.valuelabs.nephele.cloud.dbs.integration.datamodel.XcpsrRequest;
import com.valuelabs.nephele.cloud.server.rackspace.inventory.RackspacePricingDataService;
import com.valuelabs.nephele.manager.assembler.CloudProductPlanAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudProductPlanResources;
import com.valuelabs.nephele.manager.resource.ProductPlanResource;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping("/manager/productPlan")
@Transactional
public class CloudProductPlanCommandController {
	
	@Autowired
	private CloudProductPlanAssembler assembler;

	@Autowired
	private CloudProductPlanCommandService commandService;
	
	@Autowired
	private RackspacePricingDataService rackspacePricingDataService;
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	
	/**
	 * This method create's new record in the DB by accepting http request object.
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<ProductPlanResource> createProductPlan(
			@Valid @RequestBody ProductPlanResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createProductPlan() : START");
		
		if (result.hasErrors()) {
			return new ResponseEntity<ProductPlanResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudProductPlanDetails cloudProductPlanDetails = assembler.fromResource(resource);
		CreateCloudProductPlanEvent request = new CreateCloudProductPlanEvent()
				.setCloudProductPlanDetails(cloudProductPlanDetails);
		if (request != null) {
			commandService.createProductPlanService(request);
		}
		log.info("createProductPlan() : END");
		return new ResponseEntity<ProductPlanResource>(HttpStatus.CREATED);
	}
	
	/**
	 * This method modifies the existing record in the DB by accepting http request object.
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 * @throws ResourceNotFoundException
	 */
	/*@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<ProductPlanResource> updateProductPlan(@Valid @RequestBody ProductPlanResource resource, 
			BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateProductPlan() : START");
		if (resource.getProductPlanId() == null) {
			result.addError(new FieldError("resource", "getCloudProductPlanId", resource.getProductPlanId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<ProductPlanResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudProductPlanDetails cloudProductPlanDetails = assembler.fromResource(resource);
		CreateCloudProductPlanEvent request = new CreateCloudProductPlanEvent().setCloudProductPlanDetails(cloudProductPlanDetails);
		if (request != null) {
			commandService.updateProductPlanService(request);
		}
		log.info("updateProductPlan() : END");
		return new ResponseEntity<ProductPlanResource>(HttpStatus.OK);
	}*/
	
	@RequestMapping(value="/vendorprice", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<ProductPlanResource> updateProductPlanVendorPrice(@Valid @RequestBody ProductPlanResource resource, 
			BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateProductPlanVendorPrice() : START");
		if (resource.getPlanId()==null) {
			result.addError(new FieldError("resource", "getCloudProductPlanId", resource.getPlanId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<ProductPlanResource>(resource,HttpStatus.BAD_REQUEST);
		}
		if(resource.getPrice() == null )
			resource.setPrice("0.0");
		if(resource.getVendorPrice() == null){
			resource.setVendorPrice("0.0");
		}		
		
		CloudProductPlanDetails cloudProductPlanDetails = assembler.fromResource(resource);
		CreateCloudProductPlanEvent request = new CreateCloudProductPlanEvent().setCloudProductPlanDetails(cloudProductPlanDetails);
		if (request != null) {
			commandService.updateProductPlanVendorPrice(request);
		}
		log.info("updateProductPlanVendorPrice() : END");
		return new ResponseEntity<ProductPlanResource>(HttpStatus.OK);
	}
	
	/**This method updates list of the price's of the CloudProductPlan entity by accepting http requests.
	 * @param resources
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductPlanResources> updateProductPlans(@RequestBody CloudProductPlanResources resources)
			throws Exception {
		log.info("updateProductPlans() - START");
		CloudProductPlanResources responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		try{

			if (!CollectionUtils.isEmpty(resources.getProductPlans())) {
				List<CloudProductPlanDetails> detailsList = assembler.fromResouces_update(resources.getProductPlans());
				CreateCloudProductPlanEvent request = new CreateCloudProductPlanEvent().setCloudProductPlanDetailsList(detailsList);
				commandService.updateProductPlansService(request);
				message = "Plans updated successfully";
			}else {
				message = "There are no plans specified in request to update";
				responseResource = CloudProductPlanResources.builder().message(message).build();
				return new ResponseEntity<CloudProductPlanResources>(responseResource, HttpStatus.BAD_REQUEST);
			}
		}catch(NepheleException | ValidationException e ){
			e.printStackTrace();
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);
		}catch (Exception e) {
			e.printStackTrace();
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);
		}
		
		responseResource = CloudProductPlanResources.builder().message(message).build();
		
		log.info("updateProductPlans() - END");
		return new ResponseEntity<CloudProductPlanResources>(responseResource, statusCode) ; 
	}
	
	@RequestMapping(value = "/exportCSV", produces = "text/csv")
	public void exportComputePriceDataInCsvFormat(@RequestParam(value="serviceId" ,  required=false) Long serviceId,HttpServletResponse response) {
		log.info(" exportComputePriceDataInCsvFormatGet()  - start");

        String status = commandService.exportProductPlansInitialDataInCsvFormat(serviceId, response);
        
        log.info("exportComputePriceDataInCsvFormat() : END");
		//return new ResponseEntity<CloudRackspaceComputePriceResource>(CloudRackspaceComputePriceResource.builder().status(status).build(), HttpStatus.OK);
	}
	
	@RequestMapping(value="/importCSV", method=RequestMethod.POST)
    public @ResponseBody HttpEntity<CloudProductPlanResources> importComputePriceDataFromFile(@RequestParam(value="file") MultipartFile file ){
        log.info(" importComputePriceDataFromFile() - Start");
        String status = "";
        CloudProductPlanResources response = CloudProductPlanResources.builder().build();
        if (!file.isEmpty()) {
        	status = commandService.loadProductPlanCsvData(file);
        	response.setMessage(status);
        } else {
        	status = "You failed to upload " + file.getName() + " because the file is empty.";
        	response.setMessage(status);
        	return new ResponseEntity<CloudProductPlanResources>(response,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<CloudProductPlanResources>(response,HttpStatus.OK);
    }
	
	@RequestMapping(value="/productService", method=RequestMethod.GET)
    public @ResponseBody HttpEntity<String> importProductPriceDataFromFile(@RequestParam(value="serviceId" ,  required=true) Long serviceId){
        log.info(" importProductPriceDataFromFile() - Start");
        RackspacePricingDataCreatedEvent event = null;
        String status = "";
        try{       
	        	event = rackspacePricingDataService.loadProudctPriceJsonData(serviceId);
	        	status = event.getStatus();
	            Thread.sleep(2000);
	            log.info(EXCHANGE_NAME+""+PRODUCT_PRICE_ROUTING_KEY+"-START()");
	            rabbitTemplate.convertAndSend(EXCHANGE_NAME, PRODUCT_PRICE_ROUTING_KEY, event.getJobDetails());
	            log.info(EXCHANGE_NAME+""+PRODUCT_PRICE_ROUTING_KEY+"-END()");
	        
        } catch (Exception e) {
            log.error("Exception occurs while processing ProductPrice data: ", e.getMessage());
            e.printStackTrace();
        }
        log.info(" importProductPriceDataFromFile() - END");
        return new ResponseEntity<String>(status,HttpStatus.OK);
    }
	
	@RequestMapping(value = "/plansDbsReportexportXML", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public void exportPublishedProductPlansForDbs(@RequestParam(value="serviceId" ,  required=false) Long serviceId,HttpServletResponse response) {
		log.info(" exportPublishedProductPlansForDbs()  - start");

		XcpsrRequest xcpsrRequest = commandService.getPublishedPlansDbsRequest(serviceId);
		if (null != xcpsrRequest)
			commandService.createDownloadableXMLFile(xcpsrRequest, response);
		else
			response.setStatus(HttpStatus.NO_CONTENT.value());

		log.info("exportPublishedProductPlansForDbs() : END");
		//return new ResponseEntity<CloudRackspaceComputePriceResource>(CloudRackspaceComputePriceResource.builder().status(status).build(), HttpStatus.OK);
	}

}
