package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceProviderDetails;
import com.valuelabs.nephele.manager.controller.CloudServiceProviderQueryController;
import com.valuelabs.nephele.manager.resource.CloudServiceProviderResource;

@Slf4j
@Service
public class CloudServiceProviderAssembler extends ResourceAssemblerSupport<CloudServiceProviderDetails, CloudServiceProviderResource> {
	
	public CloudServiceProviderAssembler() {
		super(CloudServiceProviderQueryController.class, CloudServiceProviderResource.class);
		// TODO Auto-generated constructor stub
	}


	@Override
	public CloudServiceProviderResource toResource(
			CloudServiceProviderDetails details) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service:{} ",details);
		CloudServiceProviderResource resource=instantiateResource(details);
		resource=CloudServiceProviderResource.builder().brandName(details.getBrandName()).brandCode(details.getBrandCode()).description(details.getDescription()).serviceProviderId(details.getServiceProviderId()).build();
		resource.add(linkTo(methodOn(CloudServiceProviderQueryController.class)
				.readServiceProvider(details.getServiceProviderId())).withSelfRel());
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudServiceProviderDetails fromResource(CloudServiceProviderResource resource){
		log.debug("fromResource: START:{} ",resource);
		CloudServiceProviderDetails details=CloudServiceProviderDetails.builder().brandName(resource.getBrandName()).brandCode(resource.getBrandCode()).description(resource.getDescription()).serviceProviderId(resource.getServiceProviderId()).build();
		log.debug("fromResource() : END");
		return details;
	}
	
}
