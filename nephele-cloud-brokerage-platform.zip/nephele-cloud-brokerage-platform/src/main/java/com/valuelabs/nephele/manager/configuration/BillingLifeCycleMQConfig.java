package com.valuelabs.nephele.manager.configuration;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
public class BillingLifeCycleMQConfig {
	
	@Autowired
	AmqpAdmin rabbitAdmin;
	
	public static final String EXCHANGE_NAME = "nephele.cloud.billing.metering";

	public static final String METERING_DATA_QUEUE_NAME = "nephele.cloud.metering.data.queue";
	public static final String METERING_DATA_ROUTING_KEY = "nephele.cloud.metering.data.key";
	
	public static final String INVOICE_GENERATION_QUEUE_NAME = "nephele.cloud.invoice.generation.queue";
	public static final String INVOICE_GENERATION_ROUTING_KEY = "nephele.cloud.invoice.generation.key";
	
	public static final String PRODUCT_PRICE_QUEUE_NAME  = "nephele.cloud.product.price.queue";
	public static final String PRODUCT_PRICE_ROUTING_KEY = "nephele.cloud.product.price.key";
	
	@Bean(name = "createMeteringDataQueue")
	public Queue getCreateMeteringDataQueue() {
		return new Queue(METERING_DATA_QUEUE_NAME, true);
	}	
	
	@Bean(name = "createInvoiceGenerationQueue")
	public Queue getInvoiceGenerationQueue() {
		return new Queue(INVOICE_GENERATION_QUEUE_NAME, true);
	}
	
	@Bean(name = "createProductPriceQueue")
	public Queue getProductPriceQueue() {
		return new Queue(PRODUCT_PRICE_QUEUE_NAME, true);
	}
	
	@Bean(name = "meteringDirectExchange")
	public DirectExchange getMeteringDirectExchange() {
		return new DirectExchange(EXCHANGE_NAME, true, false);
	}
	
	@Bean(name = "createMeteringDataBinding")
	Binding getCreateMeteringDataBinding(Queue createMeteringDataQueue, DirectExchange meteringDirectExchange) {
		return BindingBuilder.bind(createMeteringDataQueue).to(meteringDirectExchange).with(METERING_DATA_ROUTING_KEY);
	}	

	@Bean(name = "createInvoiceGenerationBinding")
	Binding getCreateInvoiceGenerationBinding(Queue createInvoiceGenerationQueue, DirectExchange meteringDirectExchange) {
		return BindingBuilder.bind(createInvoiceGenerationQueue).to(meteringDirectExchange).with(INVOICE_GENERATION_ROUTING_KEY);
	}	
	
	@Bean(name = "createProductPriceBinding")
	Binding getCreateProductPriceBinding(Queue createProductPriceQueue, DirectExchange meteringDirectExchange) {
		return BindingBuilder.bind(createProductPriceQueue).to(meteringDirectExchange).with(PRODUCT_PRICE_ROUTING_KEY);
	}	
	/**
	 * For jobs related to metering data
	 */
	@PostConstruct
	public void initializeMeteringServiceMessageQueue() {
		log.debug("initializeMeteringServiceMessageQueue");
		DirectExchange meteringDirectExchange = getMeteringDirectExchange();
		
		Queue createMeteringQueue = getCreateMeteringDataQueue();
		Binding createMeteringDataBinding = getCreateMeteringDataBinding(createMeteringQueue, meteringDirectExchange);
		
		Queue createInvoiceGenerationQueue = getInvoiceGenerationQueue();
		Binding createInvoiceGenerationBinding = getCreateInvoiceGenerationBinding(createInvoiceGenerationQueue, meteringDirectExchange);
		
		Queue createProductPriceQueue = getProductPriceQueue();
		Binding createProductPriceBinding = getCreateProductPriceBinding(createProductPriceQueue, meteringDirectExchange);
		
		rabbitAdmin.declareExchange(meteringDirectExchange);
		
		rabbitAdmin.declareQueue(createMeteringQueue);
		rabbitAdmin.declareBinding(createMeteringDataBinding);	
		
		rabbitAdmin.declareQueue(createInvoiceGenerationQueue);
		rabbitAdmin.declareBinding(createInvoiceGenerationBinding);	
		
		rabbitAdmin.declareQueue(createProductPriceQueue);
		rabbitAdmin.declareBinding(createProductPriceBinding);	
	}
	
}
