package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode(callSuper=false)
@Setter
@Getter
@Builder
@Accessors(chain=true)
@JsonInclude(Include.NON_DEFAULT)
public class AcquireServerResource extends ResourceSupport {
	
	
	private String locationId;

	private String groupName;

	private String operatingSystem;

	private String opeatingSystemVersion;

	private Integer ram;

	private Integer disk;

	private Integer serverCount;

	private String publicAddresses;

	private String loginUser;

	private String password;

	private String serverName;

	private String serverId;
	
	private String imageId;
	
	private String flavorId;
	
	private Integer cloudCustomerCompanyId;
	
	private String status;
	
	private Integer productId;
	
	private String customization;
	
	private Integer quantity;
	
	private Integer orderId;
	
	private String resizeMessage;
	
	private String syncMessage;
	
}
