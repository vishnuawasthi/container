package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudSubscriptionsEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadSubscriptionEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudSubscriptionQueryService;
import com.valuelabs.nephele.manager.assembler.CloudSubscriptionAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudSubscriptionResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/marketplace/subscription")
@Transactional
public class CloudSubscriptionQueryController {

	@Autowired
	private CloudSubscriptionAssembler assembler;

	@Autowired
	private CloudSubscriptionQueryService service;

	/**
	 * Get a record by passing id from DB
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudSubscriptionResource> readSubscription(
			@PathVariable Long id) {
		log.info("readSubscription() START");
		EntityReadEvent<CloudSubscriptionDetails> event = null;
		if (id != null) {
			ReadSubscriptionEvent request = new ReadSubscriptionEvent()
					.setSubscriptionId(id);
			event = service.readSubscriptionService(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudSubscriptionDetails entity = event.getEntity();
		log.info("readSubscription() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	/**
	 * Get all records from DB
	 * 
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudSubscriptionResource>> readServiceSubscriptions(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
		    @RequestParam(value=QueryParameterConstants.CLOUD_ACCOUNT_ID,required=false)Long accountId,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudSubscriptionDetails> pagedAssembler) {
		log.info("readServiceSubscriptions() START");
		ReadCloudSubscriptionsEvent request = new ReadCloudSubscriptionsEvent()
				.setPageable(pageable);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		
		// Search Criteria
		request.setAccountId(accountId);
		PageReadEvent<CloudSubscriptionDetails> event = service.readServiceSubscriptions(request);
				
		Page<CloudSubscriptionDetails> page = event.getPage();
		PagedResources<CloudSubscriptionResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readServiceSubscriptions() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/read", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudSubscriptionResource> readSubscriptionByAccountAndOrder( 
			@RequestParam(value="accountId",required=false) Long accountId,
			@RequestParam(value="orderId",required=false) Long orderId			
			) {
		log.info("readSubscriptionByAccountAndOrder() START");
		
		EntityReadEvent<CloudSubscriptionDetails> event = null;
		ReadSubscriptionEvent request = new ReadSubscriptionEvent();
		request.setAccountId(accountId);
		request.setOrderId(orderId);

		event = service.readSubscriptionByOrderIdAndAccountId(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudSubscriptionDetails entity = event.getEntity();
		log.info("readSubscriptionByAccountAndOrder() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
}
