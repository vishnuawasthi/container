package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerDiscountPlanTypeDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudResellerDiscountPlanTypeEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerDiscountPlanTypeCommandService;
import com.valuelabs.nephele.manager.assembler.CloudResellerDiscountPlanTypeAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudResellerDiscountPlanTypeResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/cloudResellerDiscountPlanType")
@Transactional
public class CloudResellerDiscountPlanTypeCommandController {

  @Autowired
  CloudResellerDiscountPlanTypeAssembler assembler;

  @Autowired
  CloudResellerDiscountPlanTypeCommandService service;

  @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerDiscountPlanTypeResource> createResellerDiscountPlanType(
			@Valid @RequestBody CloudResellerDiscountPlanTypeResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createResellerDiscountPlanType() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudResellerDiscountPlanTypeResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudResellerDiscountPlanTypeDetails planTypeDetails = assembler.fromResource(resource);
		CreateCloudResellerDiscountPlanTypeEvent request = new CreateCloudResellerDiscountPlanTypeEvent()
				.setCloudResellerDiscountPlanTypeDetails(planTypeDetails);
		if (request != null) {
			service.createResellerDiscountPlanType(request);
		}
		log.info("createResellerDiscountPlanType() : END");
		return new ResponseEntity<CloudResellerDiscountPlanTypeResource>(HttpStatus.CREATED);
	}
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerDiscountPlanTypeResource> updateResellerDiscountPlanType(
			@Valid @RequestBody CloudResellerDiscountPlanTypeResource resource,
			BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		
		log.info("updateResellerDiscountPlanType() : START");
		if (resource.getDiscountPlanTypeId() == null) {
			result.addError(new FieldError("resource", "id", resource.getDiscountPlanTypeId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudResellerDiscountPlanTypeResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudResellerDiscountPlanTypeDetails planTypeDetails = assembler.fromResource(resource);
		CreateCloudResellerDiscountPlanTypeEvent request = new CreateCloudResellerDiscountPlanTypeEvent()
				.setCloudResellerDiscountPlanTypeDetails(planTypeDetails);
		if (request != null) {
			service.updateResellerDiscountPlanType(request);
		}
		log.info("updateResellerDiscountPlanType() : END");
		return new ResponseEntity<CloudResellerDiscountPlanTypeResource>(HttpStatus.OK);
	}

}