package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDetails;
import com.valuelabs.nephele.manager.controller.CloudResellerPremiumGroupQueryController;
import com.valuelabs.nephele.manager.resource.CloudResellerPremiumGroupResource;
@Slf4j
@Service
public class CloudResellerPremiumGroupAssembler extends ResourceAssemblerSupport<CloudResellerPremiumGroupDetails, CloudResellerPremiumGroupResource>{

	public CloudResellerPremiumGroupAssembler() {
		super(CloudResellerPremiumGroupQueryController.class, CloudResellerPremiumGroupResource.class);
	}

	@Override
	public CloudResellerPremiumGroupResource toResource(
			CloudResellerPremiumGroupDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + entity);
		CloudResellerPremiumGroupResource resource = instantiateResource(entity);
		resource = CloudResellerPremiumGroupResource.builder()
				.premiumGroupid(entity.getPremiumGroupId())
				.name(entity.getName())
				.description(entity.getDescription())				
				//.status(entity.getStatus())
				.resellerCount(entity.getResellerCount())	
				.createdDate(entity.getCreatedDate())
				.updatedDate(entity.getUpdatedDate())
				.serviceId(entity.getServiceId())
				.serviceName(entity.getName())
				.integrationCode(entity.getIntegrationCode())
				.build();
		
		resource.add(linkTo(methodOn(CloudResellerPremiumGroupQueryController.class).readPremiumGroup(entity.getPremiumGroupId())).withSelfRel());
		
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudResellerPremiumGroupDetails fromResource(CloudResellerPremiumGroupResource resource){
		log.debug("fromResource: START:{} ", resource);
		CloudResellerPremiumGroupDetails details = CloudResellerPremiumGroupDetails.builder()
				.premiumGroupId(resource.getPremiumGroupid())
				.name(resource.getName())
				.description(resource.getDescription())		
				.serviceId(resource.getServiceId())
				.serviceName(resource.getName())
				.integrationCode(resource.getIntegrationCode())
				//.status(resource.getStatus())				
				.build();
		log.debug("fromResouce: END");
		return details;

	}

}

