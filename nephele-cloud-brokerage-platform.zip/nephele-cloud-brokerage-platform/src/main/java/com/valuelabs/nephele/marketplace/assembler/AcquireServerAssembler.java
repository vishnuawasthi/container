package com.valuelabs.nephele.marketplace.assembler;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.AcquireServerDetails;
import com.valuelabs.nephele.marketplace.controller.CloudOrderServiceLifeCycleController;
import com.valuelabs.nephele.marketplace.resource.AcquireServerResource;
import com.valuelabs.nephele.marketplace.resource.PlaceOrderResource;

@Slf4j
@Service
public class AcquireServerAssembler extends
		ResourceAssemblerSupport<AcquireServerDetails, AcquireServerResource> {

	public AcquireServerAssembler() {
		super(CloudOrderServiceLifeCycleController.class,
				AcquireServerResource.class);
	}

	@Override
	public AcquireServerResource toResource(AcquireServerDetails entity) {
		/*
		 * log.debug("toResource() : START");
		 * log.debug("toResource() : Service: "+entity); CloudOrderResource
		 * resource=instantiateResource(entity);
		 * resource=CloudOrderResource.builder
		 * ().cloudOrderId(entity.getCloudOrderId
		 * ()).resellerId(entity.getResellerId
		 * ()).customerId(entity.getCustomerId())
		 * .status(entity.getStatus()).build();
		 * 
		 * resource.add(linkTo(methodOn(CloudOrderQueryController.class).
		 * readCloudOrder(entity.getCloudOrderId())).withSelfRel());
		 * log.debug("toResource() : resource : "+resource);
		 * log.debug("toResource() : resource Links: "+resource.getLinks());
		 * log.debug("toResource() : END");
		 */
		return null;
	}

	/*public AcquireServerDetails fromResource(AcquireServerResource resource) {
		AcquireServerDetails details = AcquireServerDetails.builder()
				.locationId(resource.getLocationId())
				.groupName(resource.getGroupName())
				.operatingSystem(resource.getOperatingSystem())
				.operatingSystemVersion(resource.getOpeatingSystemVersion())
				.ram(resource.getRam()).disk(resource.getDisk())
				.serverCount(resource.getServerCount())
				.publicAddresses(resource.getPublicAddresses())
				.loginUser(resource.getLoginUser())
				.password(resource.getPassword())
				.serverId(resource.getServerId())
				.serverName(resource.getServerName())
				.flavorId(resource.getFlavorId())
				.imageId(resource.getImageId()).build();
		return details;
	}*/
	public AcquireServerDetails fromResource(PlaceOrderResource resource) {
		log.debug("fromResource() START:{}",resource);
		AcquireServerDetails details = AcquireServerDetails.builder()
				.planId(resource.getPlanId())
				.quantity(resource.getQuantity())
				.serviceId(resource.getServiceId())
				.orderId(resource.getOrderId())
				.cloudCustomerCompanyId(resource.getCustomerId())
				.resellerCompanyId(resource.getResellerCompanyId())
				.resellerEmail(resource.getResellerEmail())
				.externalResellerCompanyCode(resource.getExternalResellerCompanyCode())
				.purchaseOrderNumber(resource.getPurchaseOrderNumber())
				.customerId(resource.getCustomerId())
				.build();
		log.debug("fromResource: END");
		return details;
	}

	/*public CloudOrderDetails createOrderDetailsFromServerDetails(
			ResizeServerResource resource) {

		CloudOrderDetails orderDetails = CloudOrderDetails.builder()
				.cloudCustomerCompany(resource.getCloudCustomerCompanyId())
				.status(resource.getStatus()).build();

		return orderDetails;
	}*/
}
