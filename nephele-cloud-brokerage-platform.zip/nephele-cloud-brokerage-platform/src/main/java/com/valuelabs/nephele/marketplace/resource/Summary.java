package com.valuelabs.nephele.marketplace.resource;

import java.util.Map;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

//@Data
@Setter
@Getter
@Builder
public class Summary {

	Map<String, Long> summary;
}
