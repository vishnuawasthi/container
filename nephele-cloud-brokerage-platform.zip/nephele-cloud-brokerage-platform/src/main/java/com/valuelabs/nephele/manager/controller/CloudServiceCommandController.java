package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.ServiceLifeCycleMQConfig.EXCHANGE_NAME;
import static com.valuelabs.nephele.manager.configuration.ServiceLifeCycleMQConfig.MARKETPLACE_PRODUCT_SYNC_BY_SERVICE_ROUTING_KEY;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.MarketPlaceProductServiceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServiceEvent;
import com.valuelabs.nephele.admin.rest.lib.event.MarketPlaceProductServiceEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ValidationException;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudServiceCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.CloudServiceResourceAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudServiceResource;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping(value = "/manager/services")
@Transactional
public class CloudServiceCommandController {
	
	@Autowired
	private CloudServiceResourceAssembler assembler;
	
	@Autowired
	RabbitTemplate rabbitTemplate;
	
	@Autowired
	CloudServiceCommandService commandService;
	
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceResource> createCloudService(@Valid @RequestBody CloudServiceResource resource,BindingResult result) throws IllegalArgumentException{
		log.info("createCloudService() : START");
		if(result.hasErrors()) {
			
			/*if(StringUtils.isEmpty(resource.getServiceCategoryId())) {
				  result.addError(new FieldError("resource", "getServiceCategoryId", resource.getServiceCategoryId(), false, null, null, null));
			}
			
			if(StringUtils.isEmpty(resource.getServiceIndustryVerticalId())) {
				  result.addError(new FieldError("resource", "getServiceIndustryVerticalId", resource.getServiceIndustryVerticalId(), false, null, null, null));
			}
			*/
			if(StringUtils.isEmpty(resource.getNepheleTimeZones())) {
				  result.addError(new FieldError("resource", "getNepheleTimeZones", resource.getNepheleTimeZones(), false, null, null, null));
			}
			
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		CloudServiceDetails serviceDetails = assembler.fromResource(resource);
		CreateServiceEvent request = new CreateServiceEvent().setServiceDetails(serviceDetails);
		
		if (request != null) {
			commandService.createCloudService(request);
		} 

		log.info("createCloudService() : END");
		return new ResponseEntity<>(HttpStatus.CREATED);

	}
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceResource> updateCloudService(@Valid @RequestBody CloudServiceResource resource, BindingResult result) throws Exception {
		log.info("updateCloudService() : START");
		CloudServiceResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		
		if(resource.getServiceId() == null){
			result.addError(new FieldError("resource", "serviceId", resource.getServiceId(), true, null, null, null));
		}
		if(result.hasErrors()){
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		// save it
		CloudServiceDetails serviceDetails = assembler.fromResource(resource);
		serviceDetails.setCheckValidation(true);

		CreateServiceEvent request = new CreateServiceEvent().setServiceDetails(serviceDetails);
		
		try{
			if (request != null) {
				commandService.updateCloudService(request);
				message = "Service updated successfully";
				
			}
		}catch(ValidationException | NepheleException e){
			message = e.getMessage();
			statusCode = HttpStatus.BAD_REQUEST;
		}
		catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		responseResource = CloudServiceResource.builder().message(message).build();
		
		log.info("updateCloudService() : END");
		return new ResponseEntity<>(responseResource, statusCode);

	}

	@RequestMapping(value = "/publishProductsAndPlans", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceResource> updateCloudServiceToPublishProductsAndPlans(@Valid @RequestBody CloudServiceResource resource, BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info("updateCloudService() : START");
		if(resource.getServiceId() == null){
			result.addError(new FieldError("resource", "serviceId", resource.getServiceId(), true, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudServiceResource>(resource,HttpStatus.BAD_REQUEST);
		}
		// save it
		CloudServiceDetails serviceDetails = assembler.fromResource(resource);

		CreateServiceEvent request = new CreateServiceEvent().setServiceDetails(serviceDetails);
		
		if (request != null) {
			commandService.updateCloudServiceToPublishProdcutsAndPlans(request);
			
			MarketPlaceProductServiceDetails productsByServiceDetails = MarketPlaceProductServiceDetails.builder().serviceId(resource.getServiceId())
																												  .isPublished(resource.getIsPublished())
																												  .build();
			MarketPlaceProductServiceEvent serviceRequest = new MarketPlaceProductServiceEvent().setManageProductsByServiceDetails(productsByServiceDetails);
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, MARKETPLACE_PRODUCT_SYNC_BY_SERVICE_ROUTING_KEY,	serviceRequest);
		} 
		
		log.info("updateCloudService() : END");
		return new ResponseEntity<>(HttpStatus.OK);

	}
	
	/**
	 * This method updates Day of billing cycle
	 * @param resource
	 * @param result
	 * @return
	 * @throws Exception
	 */
	
	@RequestMapping(value="/updateBilling",method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceResource> updateCloudServiceBilling(@Valid @RequestBody CloudServiceResource resource, BindingResult result) throws Exception {
		log.info("updateCloudServiceBilling() - start");
		HttpStatus statusCode = HttpStatus.OK;
		CloudServiceResource responseResource = null;
		String message = null;
		if(resource.getServiceId() == null){
			result.addError(new FieldError("resource", "serviceId", resource.getServiceId(), false, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudServiceResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudServiceDetails serviceDetails = assembler.fromResource(resource);
		CreateServiceEvent request = new CreateServiceEvent().setServiceDetails(serviceDetails);
		try {
			if (request != null) {
				commandService.updateCloudServiceBillingCycle(request);
			}
		} catch (NepheleException e) {
			message = e.getMessage();
			statusCode = HttpStatus.BAD_REQUEST;
		} 
		responseResource = CloudServiceResource.builder().message(message).build();
		log.info("updateCloudServiceBilling() - end");
		return new ResponseEntity<>(responseResource,statusCode);

	}
	
}
