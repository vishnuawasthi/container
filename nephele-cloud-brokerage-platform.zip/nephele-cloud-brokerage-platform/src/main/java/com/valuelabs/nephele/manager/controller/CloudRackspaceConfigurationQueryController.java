package com.valuelabs.nephele.manager.controller;

import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRackspaceConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRackspaceConfigurationsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudLocationQueryService;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudRackspaceConfigurationQueryService;
import com.valuelabs.nephele.manager.assembler.CloudRackspaceConfigurationAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResource;
import com.valuelabs.nephele.marketplace.resource.Summary;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/rackspaceConfiguration")
@Transactional
public class CloudRackspaceConfigurationQueryController {
	
	@Autowired
	private CloudRackspaceConfigurationAssembler assembler;
	
	@Autowired
	private CloudRackspaceConfigurationQueryService service;
	
	@Autowired
	CloudLocationQueryService cloudLocationQueryService;
	

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudRackspaceConfigurationResource> readRackspaceConfiguration(@PathVariable Long id) {
		log.info("readRackspaceConfiguration() START");

		ReadRackspaceConfigurationEvent request=new ReadRackspaceConfigurationEvent().setRackspaceConfigurationId(id);
		
		EntityReadEvent<CloudRackspaceConfigurationDetails> event = service.readRackspaceConfiguration(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudRackspaceConfigurationDetails entity = event.getEntity();
		log.info("readRackspaceConfiguration() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	/*@RequestMapping(value = "/configuraions/{operatingSystemid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PlansResource> getConfigurationByOperatingSystemId(@PathVariable Long operatingSystemid) throws Exception {
		
		ReadOperatingSystemEvent request = new ReadOperatingSystemEvent().setOperatingSystemId(operatingSystemid);
		
		EntitiesReadEvent<CloudRackspaceConfigurationDetails> configDetails = service.readRackspaceConfigurationByOsId(request);
		List<CloudRackspaceConfigurationDetails> configDetailsList = configDetails.getEntities();
		
		ReadCloudLocationsEvent locationRequest = new ReadCloudLocationsEvent();
		locationRequest.setStatus("PUBLISHED");
		EntitiesReadEvent<CloudLocationDetails> locationsByStatus = cloudLocationQueryService.findByNameNStatus(locationRequest);
		List<CloudLocationResource> locationResource = assembler.toResources_forLocation(locationsByStatus.getEntities());
		FlavorClassResource flavorResource = assembler.toResources_forConfiguration(configDetailsList);
		PlansResource plansResource = PlansResource.builder().locations(locationResource).flavors(flavorResource).build();
		
		return new ResponseEntity<>(plansResource, HttpStatus.OK);
		
	}*/
	
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudRackspaceConfigurationResource>> readRackspaceConfigurations(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudRackspaceConfigurationDetails> pagedAssembler) {
		log.info("readRackspaceConfigurations() START");
		ReadRackspaceConfigurationsEvent request=new ReadRackspaceConfigurationsEvent().setPageable(pageable);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudRackspaceConfigurationDetails> event=service.readRackspaceConfigurations(request);
		Page<CloudRackspaceConfigurationDetails> page=event.getPage();
		PagedResources<CloudRackspaceConfigurationResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readRackspaceConfigurations() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="/readByStatus/{status}",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudRackspaceConfigurationResource>> readRackspaceConfigurationByStatus(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PathVariable String status ,@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudRackspaceConfigurationDetails> pagedAssembler) {
		log.info("readRackspaceConfigurationByStatus() - start");
		ReadRackspaceConfigurationsEvent request=new ReadRackspaceConfigurationsEvent();
		request.setPageable(pageable);
		request.setStatus(status);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudRackspaceConfigurationDetails> event=service.readByStatus(request);
		Page<CloudRackspaceConfigurationDetails> page=event.getPage();
		PagedResources<CloudRackspaceConfigurationResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readRackspaceConfigurationByStatus() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param serviceId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/summaryByServiceId/{serviceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Summary> readSummaryByServiceId(@PathVariable Long serviceId,
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudRackspaceConfigurationDetails> pagedAssembler) {
		log.info("readSummaryByServiceId() - start");
		ReadRackspaceConfigurationsEvent request=new ReadRackspaceConfigurationsEvent().setServiceId(serviceId);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		Map<String, Long> event = service.readSummaryByServiceId(request);
		Summary summary = Summary.builder().summary(event).build();
		log.info("readSummaryByServiceId()   -end");
		return new ResponseEntity<>(summary, HttpStatus.OK);
	}
}
