package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionEditionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudSubscriptionEditionsEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadSubscriptionEditionEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudSubscriptionEditionQueryService;
import com.valuelabs.nephele.manager.assembler.CloudSubscriptionEditionAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudSubscriptionEditionResource;

@Slf4j
@RestController
@RequestMapping("/manager/subscriptionEdition")
@Transactional
public class CloudSubscriptionEditionQueryController {

	@Autowired
	private CloudSubscriptionEditionAssembler assembler;

	@Autowired
	private CloudSubscriptionEditionQueryService service;

	/**
	 * Get a record by passing id from DB
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudSubscriptionEditionResource> readSubscriptionEdition(
			@PathVariable Long id) {
		log.info("readSubscriptionEdition() START");
		EntityReadEvent<CloudSubscriptionEditionDetails> event = null;
		if (id != null) {
			ReadSubscriptionEditionEvent request = new ReadSubscriptionEditionEvent()
					.setSubscriptionEditionId(id);
			event = service.readSubscriptionEditionService(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudSubscriptionEditionDetails entity = event.getEntity();
		log.info("readSubscriptionEdition() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	/**
	 * Get all records from DB
	 * 
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudSubscriptionEditionResource>> readSubscriptionEditions(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudSubscriptionEditionDetails> pagedAssembler) {
		log.info("readSubscriptionEditions() START");
		ReadCloudSubscriptionEditionsEvent request = new ReadCloudSubscriptionEditionsEvent()
				.setPageable(pageable);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudSubscriptionEditionDetails> event = service.readSubscriptionEditionsService(request);
		Page<CloudSubscriptionEditionDetails> page = event.getPage();
		PagedResources<CloudSubscriptionEditionResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readSubscriptionEditions() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
