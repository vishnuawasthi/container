package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorUserDetails;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserService;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.manager.controller.CloudDistributorUserQueryController;
import com.valuelabs.nephele.manager.resource.CloudDistributorUserResource;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class CloudDistributorUserAssembler extends ResourceAssemblerSupport<CloudDistributorUserDetails, CloudDistributorUserResource> {

	
	@Autowired
	CloudUserService userService;
	
	@Autowired
	private NepheleUtils nepheleUtils;
	
	public CloudDistributorUserAssembler() {
		super(CloudDistributorUserQueryController.class, CloudDistributorUserResource.class);
	}

	@Override
	public CloudDistributorUserResource toResource(CloudDistributorUserDetails entity) {
		log.debug("toResource() - start ");
		CloudDistributorUserResource resource = instantiateResource(entity);
		resource = CloudDistributorUserResource.builder()
												.distributorId(entity.getDistributorId())
												.cloudDistributorCompanyId(entity.getCloudDistributorCompanyId())
												.distributorName(entity.getDistributorName())
												.firstName(entity.getFirstName())
												.lastName(entity.getLastName())
												.email(entity.getEmail())
												.resetPasswordToken(entity.getResetPasswordToken())
												.resetPasswordExpireTime(entity.getResetPasswordExpireTime())
												.apiKey(entity.getApiKey())
												.apiKeyExpireTime(entity.getApiKeyExpireTime())
												.userRoleId(entity.getUserRoleId())
												.userRoleName(entity.getUserRoleName())
												.cloudDistributorCompanyName(entity.getCloudDistributorCompanyName())
												.password(entity.getPassword())
												.newPassword(entity.getNewPassword())
												.oldPassword(entity.getOldPassword())
												.confirmPassword(entity.getConfirmPassword())
												.isEnabled(entity.getIsEnabled())
												.createdAt(entity.getCreatedAt())
												.updatedAt(entity.getUpdatedAt())
												.build();
		resource.add(linkTo(methodOn(CloudDistributorUserQueryController.class).readCloudDistributorUser(entity.getDistributorId())).withSelfRel());
		log.debug("toResource() - end");
		return resource;
	}

	public CloudDistributorUserDetails fromResource(CloudDistributorUserResource resource) {
		log.debug("fromResource: start ");
		CloudDistributorUserDetails details  =    CloudDistributorUserDetails.builder()
																			.distributorId(resource.getDistributorId())
																			.cloudDistributorCompanyId(resource.getCloudDistributorCompanyId())
																			.distributorName(resource.getDistributorName())
																			.firstName(resource.getFirstName())
																			.lastName(resource.getLastName())
																			.email(resource.getEmail())
																			.resetPasswordToken(resource.getResetPasswordToken())
																			.resetPasswordExpireTime(resource.getResetPasswordExpireTime())
																			.newPassword(resource.getNewPassword())
																			.confirmPassword(resource.getConfirmPassword())
																			.userRoleId(resource.getUserRoleId())
																			.apiKey(resource.getApiKey())
																			.apiKeyExpireTime(resource.getApiKeyExpireTime())
																			.password(resource.getPassword())
																			.newPassword(resource.getNewPassword())
																			.oldPassword(resource.getOldPassword())
																			.confirmPassword(resource.getConfirmPassword())
																			.isEnabled(resource.getIsEnabled())
																			.createdAt(resource.getCreatedAt())
																			.updatedAt(resource.getUpdatedAt())
																			.build();
		
		if(!StringUtils.isEmpty(resource.getPassword()))
			details.setPassword(nepheleUtils.encrypt(resource.getPassword()));
		
		log.debug("encrypt pass: {}", details.getPassword()) ;
		log.debug("fromResource() - end") ;
		return details;
	}

}
