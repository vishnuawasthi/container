package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppPermissionDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudUserRoleDetails;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import com.valuelabs.nephele.manager.controller.CloudUserRoleQueryController;
import com.valuelabs.nephele.manager.resource.CloudManagerAppPermissionResource;
import com.valuelabs.nephele.manager.resource.CloudUserRolePermissionsResource;
import com.valuelabs.nephele.manager.resource.CloudUserRoleResource;

@Slf4j
@Service
public class CloudUserRoleAssembler extends ResourceAssemblerSupport<CloudUserRoleDetails, CloudUserRoleResource>{
	
	public CloudUserRoleAssembler() {
		super(CloudUserRoleQueryController.class, CloudUserRoleResource.class);
	}
	
	@Override
	public CloudUserRoleResource toResource(CloudUserRoleDetails details) {
		log.debug("toResource() : START");
		CloudUserRoleResource resource = instantiateResource(details);
		resource = CloudUserRoleResource.builder()
										.roleId(details.getRoleId())
										.createdAt(details.getCreatedAt())
										.updatedAt(details.getUpdatedAt())
										.roleName(details.getRoleName())
										.roleDescription(details.getRoleDescription())
										.userCount(details.getUserCount())
										.build();
		resource.add(linkTo(
				methodOn(CloudUserRoleQueryController.class).readUserRole(
						details.getRoleId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}
	
	public CloudUserRoleDetails fromResource(CloudUserRoleResource resource) {
		log.debug("fromResource() : START");
		CloudUserRoleDetails details = CloudUserRoleDetails.builder()
															.roleId(resource.getRoleId())
															.createdAt(resource.getCreatedAt())
															.updatedAt(resource.getUpdatedAt())
															.roleName(resource.getRoleName())
															.roleDescription(resource.getRoleDescription())
															.build();
		log.debug("fromResource() : END");
		return details;
	}
	
	public CloudUserRoleDetails fromResource(CloudUserRolePermissionsResource resource) {
		log.debug("fromResource() : START");
		CloudUserRoleDetails details = CloudUserRoleDetails.builder()
															.roleId(resource.getRoleId())
															.roleName(resource.getRoleName())
															.build();
		List<CloudManagerAppPermissionDetails> permissions = new ArrayList<CloudManagerAppPermissionDetails>();
		List<CloudManagerAppPermissionResource> permissionsRequest = resource.getPermissions();
		for(CloudManagerAppPermissionResource permissionResource:NepheleValidationUtils.nullSafe(permissionsRequest)){
			CloudManagerAppPermissionDetails permission = CloudManagerAppPermissionDetails.builder().cloudManagerAppAccountId(permissionResource.getCloudManagerAppAccountId())
																									.isRead(permissionResource.getIsRead())
																									.isWrite(permissionResource.getIsWrite())
																									.build();
			permissions.add(permission);
		}
		details.setPermissions(permissions);
		log.debug("fromResource() : END");
		return details;
	}
}
