package com.valuelabs.nephele.marketplace.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.RelatedExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.resource.RelatedExternalProductResource;
import com.valuelabs.nephele.marketplace.controller.RelatedCloudProductQueryController;
import com.valuelabs.nephele.marketplace.controller.RelatedExternalProductQueryController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RelatedExternalProductAssembler extends ResourceAssemblerSupport<RelatedExternalProductDetails, RelatedExternalProductResource>{
	
	public RelatedExternalProductAssembler() {
		super(RelatedCloudProductQueryController.class, RelatedExternalProductResource.class);
	}
	
	@Override
	public RelatedExternalProductResource toResource(RelatedExternalProductDetails details) {
		log.debug("toResource() : START");
		RelatedExternalProductResource resource= instantiateResource(details);
	
		resource= RelatedExternalProductResource.builder()
												.relatedExtProductId(details.getRelatedExtProductId())	
												.externalId(details.getExternalId())
												.cloudproductId(details.getCloudProductId())
												.cloudProductName(details.getCloudProductName())
												.cloudproductDes(details.getCloudproductDes())
												.externalProducts(details.getExternalProducts())	
												.externalProductId(details.getExternalProductId())
												.externalProductName(details.getExternalProductName())
												.externalProductDes(details.getExternalProductDes())
												.serviceName(details.getServiceName())
												.serviceId(details.getServiceId())
												.status(details.getStatus())												
												.cloudProductDetails(details.getCloudProductDetails())
											    .build();
		resource.add(linkTo(methodOn(RelatedExternalProductQueryController.class).readRelatedExternalProduct(details.getRelatedExtProductId())).withSelfRel());		
		log.debug("toResource() : END");
		return resource;
	}
	
	public RelatedExternalProductDetails fromResource(RelatedExternalProductResource resource){
		log.debug("fromResource() - START");
		RelatedExternalProductDetails relatedExternalProductDetails=RelatedExternalProductDetails.builder()
																	.relatedExtProductId(resource.getRelatedExtProductId())
																	.cloudProductId(resource.getCloudproductId())
																	.externalProducts(resource.getExternalProducts())
																	.build();
		log.debug("fromResource() - END");
		return relatedExternalProductDetails;
		
	}
	

}

