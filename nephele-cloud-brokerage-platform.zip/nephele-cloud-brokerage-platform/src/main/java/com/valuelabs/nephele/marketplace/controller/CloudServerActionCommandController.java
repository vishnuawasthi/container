package com.valuelabs.nephele.marketplace.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerActionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudServerActionEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServerActionCommandService;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.CloudServerActionAssember;
import com.valuelabs.nephele.marketplace.resource.CloudServerActionResource;

@Slf4j
@RestController
@RequestMapping(value = "/marketplace/cloudServerAction")
@Transactional
public class CloudServerActionCommandController {

	@Autowired
	private CloudServerActionCommandService service;

	@Autowired
	private CloudServerActionAssember assember;


	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServerActionResource> createCloudServerAction(@Valid  @RequestBody CloudServerActionResource resource ,BindingResult result)  throws IllegalArgumentException{
		log.info("createCloudServerAction()  - START");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudServerActionResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudServerActionDetails details = assember.fromResource(resource);
		CreateCloudServerActionEvent request = new CreateCloudServerActionEvent().setCloudServerActionDetails(details);
		if (null != request) {
			service.createCloudServerAction(request);
		}
		log.info("createCloudServerAction()  -  END");
		return new ResponseEntity<CloudServerActionResource>(HttpStatus.CREATED);
	}
	

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServerActionResource> updateCloudServerAction(@Valid  @RequestBody CloudServerActionResource resource,BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateCloudServerAction() - START");
		if (resource.getCloudServerActionId() == null) {
			result.addError(new FieldError("resource", "CloudServerActionId", resource.getCloudServerActionId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudServerActionResource>(resource, HttpStatus.BAD_REQUEST);
		}
		CloudServerActionDetails details = assember.fromResource(resource);
		CreateCloudServerActionEvent requestEvent = new CreateCloudServerActionEvent().setCloudServerActionDetails(details);
		if(requestEvent != null){
			service.updateCloudServerAction(requestEvent);	
		}
		log.info("updateCloudServerAction() - END");
		return new ResponseEntity<CloudServerActionResource>(HttpStatus.OK);
	}
}
