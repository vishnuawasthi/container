package com.valuelabs.nephele.marketplace.resource;


import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResource;
import com.valuelabs.nephele.manager.resource.PlansResource;




@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudServerDetailsResource extends ResourceSupport {

	private Long serverId;
	private String name;
	private String description;
	private String status;
	private String brandCode;
	private String vendorStatus;
	private String brandName;
	private Long orderId;
	private Long customerId;
	private String customerName;
	private String publicIPV4Address;
	private String publicIPV6Address;
	private String privateIPV4Address;
	private String privateIPV6Address;
	private String username;
	private String password;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date creationDate;
	private String integrationCode;
	private String categoryName;
	private CloudOperatingSystemResource os;
	private CloudLocationResource location;
	private CloudRackspaceConfigurationResource flavor;
	private PlansResource plans;
	private List<PlansResource> upgradeDetails;
	
	
	
	
}
