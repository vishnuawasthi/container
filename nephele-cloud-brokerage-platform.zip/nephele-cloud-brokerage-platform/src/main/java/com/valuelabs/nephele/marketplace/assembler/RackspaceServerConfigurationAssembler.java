package com.valuelabs.nephele.marketplace.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.RackspaceServerConfigurationDetails;
import com.valuelabs.nephele.marketplace.controller.RackspaceServerConfigurationQueryController;
import com.valuelabs.nephele.marketplace.resource.RackspaceServerConfigurationResource;

@Slf4j
@Service
public class RackspaceServerConfigurationAssembler
		extends
			ResourceAssemblerSupport<RackspaceServerConfigurationDetails, RackspaceServerConfigurationResource> {

	public RackspaceServerConfigurationAssembler() {
		super(RackspaceServerConfigurationQueryController.class, RackspaceServerConfigurationResource.class);
	}

	@Override
	public RackspaceServerConfigurationResource toResource(RackspaceServerConfigurationDetails details) {
		log.debug("toResource() : START");
		RackspaceServerConfigurationResource resource = instantiateResource(details);
		resource = RackspaceServerConfigurationResource.builder().rackspaceServerConfigurationId(details.getId())
																 .cloudServerId(details.getCloudServerId())
																 .planId(details.getPlanId())
																 .status(details.getStatus())
																 .build();
		
		resource.add(linkTo(methodOn(RackspaceServerConfigurationQueryController.class).readRackspaceServerConfiguration(details.getId()))
				.withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}

	public RackspaceServerConfigurationDetails fromResource(RackspaceServerConfigurationResource resource) {
		log.debug("fromResource() - START");
		RackspaceServerConfigurationDetails details = RackspaceServerConfigurationDetails.builder().id(resource.getRackspaceServerConfigurationId())
																								   .cloudServerId(resource.getCloudServerId())
																								   .planId(resource.getPlanId())
																								   .status(resource.getStatus())
																								   .build();
		log.debug("fromResource() - END");
		return details;
	}

}
