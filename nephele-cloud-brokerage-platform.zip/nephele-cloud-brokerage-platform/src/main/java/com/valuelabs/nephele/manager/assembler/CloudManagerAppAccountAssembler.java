package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppAccountDetails;
import com.valuelabs.nephele.manager.controller.CloudManagerAppAccountQueryController;
import com.valuelabs.nephele.manager.resource.CloudManagerAppAccountResource;

@Service
@Slf4j 
public class CloudManagerAppAccountAssembler  extends ResourceAssemblerSupport<CloudManagerAppAccountDetails,CloudManagerAppAccountResource>{

	public CloudManagerAppAccountAssembler() {
		super(CloudManagerAppAccountQueryController.class, CloudManagerAppAccountResource.class);
	}

	@Override
	public CloudManagerAppAccountResource toResource(CloudManagerAppAccountDetails entity) {
		log.debug("toResource() -start");
		CloudManagerAppAccountResource resource =  instantiateResource(entity);
										resource =	CloudManagerAppAccountResource.builder()
													.cloudManagerAppAccountId(entity.getId())
													.name(entity.getName())
													.description(entity.getDescription())
													.build();
									   resource.add(linkTo(methodOn(CloudManagerAppAccountQueryController.class).readCloudManagerAppAccount(entity.getId())).withSelfRel());											
		log.debug("toResource() -end");											
		return resource;
	}
	
	
	public CloudManagerAppAccountDetails fromResource(CloudManagerAppAccountResource resource) {
		log.debug("fromResource() -start");
		CloudManagerAppAccountDetails details =  CloudManagerAppAccountDetails.builder()
																				.id(resource.getCloudManagerAppAccountId())
																				.name(resource.getName())
																				.description(resource.getDescription())
																				.build();
		log.debug("fromResource() -end");											
		return details;
	}

}
