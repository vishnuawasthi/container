package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudResellerCompaniesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudResellerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerCompanyQueryService;
import com.valuelabs.nephele.manager.assembler.CloudResellerCompanyAssembler;
import com.valuelabs.nephele.manager.resource.CloudResellerCompanyResource;
import com.valuelabs.nephele.marketplace.resource.Summary;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/manager/resellerCompany")
@Transactional
public class CloudResellerCompanyQueryController {

	@Autowired
	CloudResellerCompanyAssembler assembler;

	@Autowired
	CloudResellerCompanyQueryService service;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudResellerCompanyResource> readCloudResellerCompany(@PathVariable Long id) {
		log.info("readCloudResellerCompany() START");

		ReadCloudResellerCompanyEvent request = new ReadCloudResellerCompanyEvent().setResellerCompanyId(id);

		EntityReadEvent<CloudResellerCompanyDetails> event = service.readCloudResellerCompany(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudResellerCompanyDetails entity = event.getEntity();
		log.info("readCloudResellerCompany() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	/**
	 * This method returns all the reseller with search criteria, search
	 * criteria is an optional. if no search criteria is sent all the resellers
	 * will be returned.
	 * 
	 * @param companyname
	 *            , This is an search value should be sent as query string
	 * @param premiumgroupname
	 *            ,This is an search value should be sent as query string
	 * @param email
	 *            ,This is an search value should be sent as query string
	 * @param address
	 *            ,This is an search value should be sent as query string
	 * @param zipcode
	 *            ,This is an search value should be sent as query string
	 * @param status
	 *            ,This is an search value should be sent as query string
	 * @param pageable
	 * @param pagedassembler
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudResellerCompanyResource>> readResellerCompanies(
			@RequestParam(value = "companyName", required = false) String companyName,
			@RequestParam(value = "premiumGroupName", required = false) String premiumGroupName,
			@RequestParam(value = "email", required = false) String email,
			@RequestParam(value = "address", required = false) String address,
			@RequestParam(value = "zipcode", required = false) String zipcode,
			@RequestParam(value = "status", required = false) String status,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, 
			PagedResourcesAssembler<CloudResellerCompanyDetails> pagedAssembler) {
		log.info("readResellerCompanies() -start");
		ReadCloudResellerCompaniesEvent request = new ReadCloudResellerCompaniesEvent();
	
		// Building Search Criteria
		request.setPageable(pageable);
		request.setCompanyName(companyName);
		request.setPremiumGroupName(premiumGroupName);
		request.setEmail(email);
		request.setAddress(address);
		request.setZipcode(zipcode);
		request.setStatus(status);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudResellerCompanyDetails> event = service.readCloudResellerCompanies(request);
		Page<CloudResellerCompanyDetails> page = event.getPage();
		PagedResources<CloudResellerCompanyResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readResellerCompanies() -end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

	/**
	 * 
	 * @param customerId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/summaryByDistributorPriceGroupId/{distributorPriceGroupId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Summary> readResellerSummary(@PathVariable Long distributorPriceGroupId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudResellerCompanyDetails> pagedAssembler) {
		log.info("readResellerSummary() -start");
		ReadCloudResellerCompaniesEvent request = new ReadCloudResellerCompaniesEvent().setDistributorPriceGroupId(distributorPriceGroupId);
		Map<String, Long> event = service.readResellerSummary(request);
		Summary summary = Summary.builder().summary(event).build();
		log.info("readResellerSummary() -end");
		return new ResponseEntity<>(summary, HttpStatus.OK);
	}
	
	/**
	 * This method return total resellers count 
	 * @return
	 */
	@RequestMapping(value = "/count", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Long>> readResellerCount() {
		log.info("readResellerCount() -start");
		ReadCloudResellerCompaniesEvent request = new ReadCloudResellerCompaniesEvent();
		Map<String, Long> event = service.readResellerCount(request);
		log.info("readResellerCount() -end");
		return new ResponseEntity<>(event, HttpStatus.OK);
	}

}
