package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountSheetDetails;
import com.valuelabs.nephele.manager.controller.PremiumGroupDiscountSheetQueryController;
import com.valuelabs.nephele.manager.resource.PremiumGroupDiscountSheetResource;

@Slf4j
@Service
public class PremiumGroupDiscountSheetAssembler extends ResourceAssemblerSupport<PremiumGroupDiscountSheetDetails, PremiumGroupDiscountSheetResource> {

	public PremiumGroupDiscountSheetAssembler() {
		super(PremiumGroupDiscountSheetQueryController.class, PremiumGroupDiscountSheetResource.class);
	}

	@Override
	public PremiumGroupDiscountSheetResource toResource(PremiumGroupDiscountSheetDetails details) {
		log.debug("toResource() - start");
		PremiumGroupDiscountSheetResource resource = PremiumGroupDiscountSheetResource.builder().discountRuleId(details.getDiscountSheetId()).startRange(String.valueOf(details.getStartRange()))
																								.endRange(String.valueOf(details.getEndRange()))
																								.discount(String.valueOf(details.getDiscount()))
																								.premiumGroupId(details.getPremiumGroupId())
																								.premiumGroupDiscountConfigId(details.getPremiumGroupDiscountConfigId())
																								.premiumGroupName(details.getPremiumGroupName())
																								.discountPlanType(details.getDiscountPlanType())
																								.serviceId(details.getServiceId())
																								.serviceName(details.getServiceName())
																								.status(details.getStatus())
																								.build();
		resource.add(linkTo(
				methodOn((PremiumGroupDiscountSheetQueryController.class)).readGroupDiscountSheet(details.getDiscountSheetId())).withSelfRel());
		log.debug("toResource() - end");
		return resource;
	}

	public PremiumGroupDiscountSheetDetails fromResource(PremiumGroupDiscountSheetResource resource) {
		log.debug("fromResource() - start");
		PremiumGroupDiscountSheetDetails details = PremiumGroupDiscountSheetDetails.builder().discountSheetId(resource.getDiscountRuleId()).startRange(resource.getStartRange() == null ? 0 :Double.valueOf(resource.getStartRange()))
																							.endRange(resource.getEndRange() == null ? 0 : Double.valueOf(resource.getEndRange()))
																							.discount(resource.getDiscount() == null ? 0 : Double.valueOf(resource.getDiscount()))
																							.premiumGroupId(resource.getPremiumGroupId())
																							.premiumGroupDiscountConfigId(resource.getPremiumGroupDiscountConfigId())
																							.build();

		log.debug("fromResource() - end");
		return details;
	}
	
	public List<PremiumGroupDiscountSheetDetails> fromResource(List<PremiumGroupDiscountSheetResource> resourceList) {
		log.debug("fromResource() - start");
		List<PremiumGroupDiscountSheetDetails> detailsList = new ArrayList<PremiumGroupDiscountSheetDetails>();
		for(PremiumGroupDiscountSheetResource resource : resourceList )
		{
			PremiumGroupDiscountSheetDetails details = PremiumGroupDiscountSheetDetails.builder().discountSheetId(resource.getDiscountRuleId()).startRange(resource.getStartRange() == null ? 0 :Double.valueOf(resource.getStartRange()))
																								.endRange(resource.getEndRange() == null ? 0 : Double.valueOf(resource.getEndRange()))
																								.discount(resource.getDiscount() == null ? 0 : Double.valueOf(resource.getDiscount()))
																								.premiumGroupId(resource.getPremiumGroupId())
																								.premiumGroupDiscountConfigId(resource.getPremiumGroupDiscountConfigId())
																								.build();
			detailsList.add(details);
		}

		log.debug("fromResource() - end");
		return detailsList;
	}

}
