package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.ServiceCategoryDetails;
import com.valuelabs.nephele.manager.controller.ServiceCategoryQueryController;
import com.valuelabs.nephele.manager.resource.ServiceCategoryResource;

@Service
@Slf4j
public class ServiceCategoryAssembler extends ResourceAssemblerSupport<ServiceCategoryDetails,ServiceCategoryResource> {
  
  public ServiceCategoryAssembler() {
	super(ServiceCategoryQueryController.class, ServiceCategoryResource.class);
  }

  @Override
  public ServiceCategoryResource toResource(ServiceCategoryDetails entity) {
	log.debug("toResource() -start");
	ServiceCategoryResource resource = ServiceCategoryResource.builder()
                                                        		.categoryId(entity.getId())
                                                        		.name(entity.getName())
                                                        		.description(entity.getDescription())
                                                        		.build();
	resource.add(linkTo(methodOn(ServiceCategoryQueryController.class).readServiceCategory(entity.getId())).withSelfRel());
	log.debug("toResource() - end");
	return resource;
  }
  
  public ServiceCategoryDetails fromResource(ServiceCategoryResource resource) {
	log.debug("fromResource() -start");
	ServiceCategoryDetails details = ServiceCategoryDetails.builder()
                                                        		.id(resource.getCategoryId())
                                                        		.name(resource.getName())
                                                        		.description(resource.getDescription())
                                                        		.build();
	log.debug("fromResource() - end");
	return details;
  }
  

  
}
