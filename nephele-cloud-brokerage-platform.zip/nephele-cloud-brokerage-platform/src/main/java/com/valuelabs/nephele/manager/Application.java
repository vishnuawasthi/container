package com.valuelabs.nephele.manager;


import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.Arrays;


@Slf4j
@Configuration
@PropertySource({"classpath:/accountMapping.properties"})
@EnableAspectJAutoProxy
@EnableHystrixDashboard
@ConditionalOnExpression("${hystrix.enabled:true}")
@EnableHystrix
@ComponentScan(basePackages = "com.valuelabs.nephele")
@EnableAutoConfiguration
@EnableScheduling
@EnableCaching
public class Application  {

	public Application() {

	}

	public static void main(String[] args) {
		log.debug("Starting nephele-admin-public");
		ApplicationContext ctx = SpringApplication.run(Application.class, args);
		log.debug("nephele-cloud-brokerage-platform application name: {}", ctx.getApplicationName());
    log.debug("Active profiles: " + Arrays.toString(ctx.getEnvironment().getActiveProfiles()));
    log.debug("DB url: " + ctx.getEnvironment().getProperty("spring.datasource.url"));
    log.debug("DB username: " + ctx.getEnvironment().getProperty("spring.datasource.username"));
    log.debug("DB password: " + ctx.getEnvironment().getProperty("spring.datasource.password"));
  }

}