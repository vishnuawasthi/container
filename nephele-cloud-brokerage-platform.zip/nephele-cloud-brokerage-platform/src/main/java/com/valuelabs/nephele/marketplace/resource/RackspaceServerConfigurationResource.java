package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode
@Setter
@Getter
@Builder
@Accessors(chain=true)
public class RackspaceServerConfigurationResource extends ResourceSupport {
	private Long rackspaceServerConfigurationId;
	private Long cloudServerId;
	private Long planId;
	private String status;
}
