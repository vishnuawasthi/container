package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class CloudServiceEnableResource {
	
	private Long serviceId;
	private boolean authentication;
	private boolean pricing;
	private boolean discountPlan;
	private boolean billingCycle;	
	private String serviceName;
	private String serviceCode;
	private String integarionCode;
	private boolean isServicePublished;
	private boolean isServiceLive;
	private String message;
	
	
}
