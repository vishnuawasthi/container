package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceMgmtConfigDetails;
import com.valuelabs.nephele.manager.controller.CloudProductPriceMgmtConfigQueryController;
import com.valuelabs.nephele.manager.resource.CloudProductPriceMgmtConfigResource;

@Slf4j
@Service
public class CloudProductPriceMgmtAssembler extends ResourceAssemblerSupport<CloudProductPriceMgmtConfigDetails, CloudProductPriceMgmtConfigResource>{

	
	
		
		public CloudProductPriceMgmtAssembler() {
			super(CloudProductPriceMgmtConfigQueryController.class, CloudProductPriceMgmtConfigResource.class);
		}
		
		@Override
		public CloudProductPriceMgmtConfigResource toResource(CloudProductPriceMgmtConfigDetails details) {
			log.debug("toResource() : START");
			CloudProductPriceMgmtConfigResource resource = instantiateResource(details);
			resource = CloudProductPriceMgmtConfigResource.builder().priceSheetName(details.getPriceSheetName())
																	.productPriceMgmtConfigId(details.getProductPriceMgmtConfigId())
																	.activeFrom(details.getActiveFrom())
																	.activeTo(details.getActiveTo())
																	.serviceId(details.getServiceId())
																	.status(details.getStatus())
																	.build();
				
			resource.add(linkTo(
					methodOn(CloudProductPriceMgmtConfigQueryController.class)
							.readProductPriceMgmtConfig(
									details.getProductPriceMgmtConfigId())).withSelfRel());
			log.debug("toResource() : END");
			return resource;
		}
		
		public CloudProductPriceMgmtConfigDetails fromResource(CloudProductPriceMgmtConfigResource resource) {
			log.debug("fromResource() START:{}",resource);
			CloudProductPriceMgmtConfigDetails details = CloudProductPriceMgmtConfigDetails.builder().priceSheetName(resource.getPriceSheetName())
																										.productPriceMgmtConfigId(resource.getProductPriceMgmtConfigId())
																										.activeFrom(resource.getActiveFrom())
																										.activeTo(resource.getActiveTo())
																										.serviceId(resource.getServiceId())
																										.status(resource.getStatus())																										
																										.build();
			log.debug("fromResource() - END");
			return details;
		}
	
	}