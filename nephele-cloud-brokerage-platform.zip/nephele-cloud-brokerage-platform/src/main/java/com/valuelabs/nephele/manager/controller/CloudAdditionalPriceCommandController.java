package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAdditionalPriceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudAdditionalPriceEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAdditionalPriceCommandService;
import com.valuelabs.nephele.manager.assembler.CloudAdditionalPriceAssembler;
import com.valuelabs.nephele.manager.resource.CloudAdditionalPriceResource;



@Slf4j
@RestController
@RequestMapping(value = "/manager/cloudAdditionalPrice")
@Transactional
public class CloudAdditionalPriceCommandController {

	@Autowired
	private CloudAdditionalPriceCommandService service;

	@Autowired
	private CloudAdditionalPriceAssembler assembler;
	
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudAdditionalPriceResource> createCloudAdditionalPrice(@Valid @RequestBody CloudAdditionalPriceResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createCloudAdditionalPrice()  - start");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudAdditionalPriceResource>(resource, HttpStatus.BAD_REQUEST);
		}
		CloudAdditionalPriceDetails details = assembler.fromResource(resource);
		CreateCloudAdditionalPriceEvent request = new CreateCloudAdditionalPriceEvent().setCloudAdditionalPriceDetails(details);
		if (request != null) {
			service.createCloudAdditionalPrice(request);
		}
		log.info("createCloudAdditionalPrice()  - end");
		return new ResponseEntity<CloudAdditionalPriceResource>(HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudAdditionalPriceResource> updateCloudAdditionalPrice(@Valid @RequestBody CloudAdditionalPriceResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("updateCloudAdditionalPrice()  - start");
		if (resource.getAdditionalPriceId() == null) {
			result.addError(new FieldError("resource", "additionalPriceId", resource.getAdditionalPriceId(), false, null, null, ""));
		}

		if (result.hasErrors()) {
			return new ResponseEntity<CloudAdditionalPriceResource>(resource, HttpStatus.BAD_REQUEST);
		}
		CloudAdditionalPriceDetails details = assembler.fromResource(resource);
		CreateCloudAdditionalPriceEvent request = new CreateCloudAdditionalPriceEvent().setCloudAdditionalPriceDetails(details);
		if (request != null) {
			service.updateCloudAdditionalPrice(request);
		}
		log.info("updateCloudAdditionalPrice()  - end");
		return new ResponseEntity<CloudAdditionalPriceResource>(HttpStatus.OK);
	}

}
