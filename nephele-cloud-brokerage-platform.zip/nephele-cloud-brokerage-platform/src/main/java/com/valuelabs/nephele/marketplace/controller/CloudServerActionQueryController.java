package com.valuelabs.nephele.marketplace.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerActionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudServerActionEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudServerActionsEvent;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudServerActionQueryService;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.marketplace.assembler.CloudServerActionAssember;
import com.valuelabs.nephele.marketplace.resource.CloudServerActionResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/marketplace/cloudServerAction")
@Transactional
public class CloudServerActionQueryController {

	@Autowired
	private CloudServerActionQueryService service;

	@Autowired
	private CloudServerActionAssember assembler;

	@RequestMapping(value = "{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServerActionResource> readCloudServerAction(@PathVariable("id") Long id) {
		log.info("readCloudServerAction()  - START");
		ReadCloudServerActionEvent request = new ReadCloudServerActionEvent().setId(id);
		EntityReadEvent<CloudServerActionDetails> event = service.readCloudServerAction(request);
		if (!event.isFound()) {
			return new ResponseEntity<CloudServerActionResource>(HttpStatus.NO_CONTENT);
		}
		log.info("readCloudServerAction()  - END");
		return new ResponseEntity<CloudServerActionResource>(assembler.toResource(event.getEntity()), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServerActionResource>> readCloudServerActions(
        @RequestParam(value =QueryParameterConstants.SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = QueryParameterConstants.SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServerActionDetails> pagedAssembler) {
		log.info("readCloudServerActions() - START");
		ReadCloudServerActionsEvent request = new ReadCloudServerActionsEvent().setPageable(pageable);
		
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudServerActionDetails> event = service.readCloudServerActions(request);
		Page<CloudServerActionDetails> page = event.getPage();
		PagedResources<CloudServerActionResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudServerActions() - END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

}
