package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateAuditDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRateAuditEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRatesAuditEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCurrencyConversionRateAuditQueryService;
import com.valuelabs.nephele.manager.assembler.CloudCurrencyConversionRateAuditAssembler;
import com.valuelabs.nephele.manager.resource.CloudCurrencyConversionRateAuditResource;
@Slf4j
@RestController
@RequestMapping("/manager/currencyConversionAuditRate")
public class CloudCurrencyConversionRateAuditQueryController {
  
  @Autowired
  private CloudCurrencyConversionRateAuditAssembler assembler;
  
  @Autowired
  private CloudCurrencyConversionRateAuditQueryService service;
  
  
  @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudCurrencyConversionRateAuditResource> readCloudCurrencyConversionRateAudit(@PathVariable Long id) {
		log.info("readCloudCurrencyConversionRateAudit() - start");
		ReadCloudCurrencyConversionRateAuditEvent request=new ReadCloudCurrencyConversionRateAuditEvent().setId(id);
		EntityReadEvent<CloudCurrencyConversionRateAuditDetails> event = service.readCloudCurrencyConversionRateAudit(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudCurrencyConversionRateAuditDetails entity = event.getEntity();
		log.info("readCloudCurrencyConversionRateAudit() - end");
		return new ResponseEntity<CloudCurrencyConversionRateAuditResource>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudCurrencyConversionRateAuditResource>> readCloudCurrencyConversionRatesAudit(
			@RequestParam(value="id",required=false) final Long id ,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudCurrencyConversionRateAuditDetails> pagedAssembler) {
		log.info("readCloudCurrencyConversionRatesAudit() - start");
		ReadCloudCurrencyConversionRatesAuditEvent request=new ReadCloudCurrencyConversionRatesAuditEvent().setPageable(pageable).setId(id);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudCurrencyConversionRateAuditDetails> event=service.readCloudCurrencyConversionRatesAudit(request);

		Page<CloudCurrencyConversionRateAuditDetails> page=event.getPage();
		PagedResources<CloudCurrencyConversionRateAuditResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudCurrencyConversionRatesAudit() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

	 
  
}
