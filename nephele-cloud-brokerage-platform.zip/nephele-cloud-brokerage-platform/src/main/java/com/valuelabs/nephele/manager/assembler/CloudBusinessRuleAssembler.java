package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudBusinessRuleDetails;
import com.valuelabs.nephele.manager.controller.CloudBusinessRuleQueryController;
import com.valuelabs.nephele.manager.resource.CloudBusinessRuleResource;

@Slf4j
@Service
public class CloudBusinessRuleAssembler extends ResourceAssemblerSupport<CloudBusinessRuleDetails, CloudBusinessRuleResource> {

	public CloudBusinessRuleAssembler() {
		super(CloudBusinessRuleQueryController.class, CloudBusinessRuleResource.class);
	}

	@Override
	public CloudBusinessRuleResource toResource(CloudBusinessRuleDetails entity) {
		log.debug("toResource()  - start");
		CloudBusinessRuleResource resource =   CloudBusinessRuleResource.builder()
																		.ruleId(entity.getRuleId())
																		.ruleName(entity.getRuleName())
																		.ruleDescription(entity.getRuleDescription())
																		.ruleValue(entity.getRuleValue())
				.resource(entity.getResource())
																		.build();
																		
		resource.add(linkTo(methodOn(CloudBusinessRuleQueryController.class).readCloudBusinessRule(entity.getRuleId())).withSelfRel());
		log.debug("toResource()  - end");
		return resource;
	}
	public CloudBusinessRuleDetails fromResource(CloudBusinessRuleResource resource) {
		log.debug("fromResource() - start");
		CloudBusinessRuleDetails details =  CloudBusinessRuleDetails.builder()
																	.ruleId(resource.getRuleId())
																	.ruleName(resource.getRuleName())
																	.ruleDescription(resource.getRuleDescription())
																	.ruleValue(resource.getRuleValue())
				.resource(resource.getResource())
																	.build();
		log.debug("fromResource() - end");
		return details;
	}

}
