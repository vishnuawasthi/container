package com.valuelabs.nephele.manager.controller;

import java.util.Map;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.CloudPricingModel;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlanEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlansEvent;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudProductPlanQueryService;
import com.valuelabs.nephele.manager.assembler.CloudProductPlanAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudProductPlanResource;
import com.valuelabs.nephele.manager.resource.ProductPlanResource;
import com.valuelabs.nephele.marketplace.resource.Summary;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/productPlan")
public class CloudProductPlanQueryController {
	
	@Autowired
	private CloudProductPlanAssembler assembler;

	@Autowired
	private CloudProductPlanQueryService service;
	
	/**
	 * This method will get one record at a time from the DB by passing id.
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProductPlanResource> readProductPlan(
			@PathVariable Long id) {
		log.info("readProductPlan() START");
		EntityReadEvent<CloudProductPlanDetails> event = null;
		if (id != null) {
			ReadCloudProductPlanEvent request = new ReadCloudProductPlanEvent()
					.setProductPlanId(id);
			event = service.readProductPlanService(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudProductPlanDetails entity = event.getEntity();
		log.info("readProductPlan() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	/**
	 * This method will get all the records exists in DB.
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	/*@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<ProductPlanResource>> readProductPlans(
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductPlanDetails> pagedAssembler) {
		log.info("readProductPlans() START");
		ReadCloudProductPlansEvent request = new ReadCloudProductPlansEvent()
				.setPageable(pageable);

		PageReadEvent<CloudProductPlanDetails> event = service.readProductPlansService(request);
		Page<CloudProductPlanDetails> page = event.getPage();
		PagedResources<ProductPlanResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readProductPlans() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}*/
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<ProductPlanResource>> readProductPlans(
			@RequestParam(value=QueryParameterConstants.SERVICE_ID,required=false)Long serviceId ,
			@RequestParam(value=QueryParameterConstants.SERVICE_NAME,required=false)String serviceName,
			@RequestParam(value=QueryParameterConstants.OPERATING_SYSTEM_ID,required=false)Long operatingSystemId ,
			@RequestParam(value=QueryParameterConstants.OPERATING_SYSTEM_NAME,required=false)String operatingSystemName,
		    @RequestParam(value=QueryParameterConstants.LOCATION_ID,required=false) Long locationId,
		    @RequestParam(value=QueryParameterConstants.LOCATION_NAME,required=false) String locationName,
		    @RequestParam(value=QueryParameterConstants.STATUS,required=false)String status, 
		    @RequestParam(value=QueryParameterConstants.FLAG_FLAVOUR_CATEGORIES ,required=false)String flavorCategory,
		    @RequestParam(value=QueryParameterConstants.FLAG_PLAN_NAME ,required=false)String planName,
		    @RequestParam(value= QueryParameterConstants.SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value= QueryParameterConstants.SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductPlanDetails> pagedAssembler) {
		log.info("readProductPlans() START");
		ReadCloudProductPlansEvent request = new ReadCloudProductPlansEvent();
		 request.setPageable(pageable);
		 // Building Search Criteria
		 
		 request.setLocationId(locationId);
		 request.setOperatingSystemId(operatingSystemId);
		 request.setStatus(status); 
		 request.setFlavorCategory(flavorCategory);
		 request.setServiceId(serviceId);
		 request.setServiceName(serviceName);
		 request.setLocationName(locationName);
		 request.setOperatingSystemName(operatingSystemName);
		 request.setPlanName(planName);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		 
		 
		PageReadEvent<CloudProductPlanDetails> event = service.readProductPlansService(request);
		Page<CloudProductPlanDetails> page = event.getPage();
		PagedResources<ProductPlanResource> pagedResources = pagedAssembler.toResource(page, assembler);
				
		log.info("readProductPlans() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param customerId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/summary", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Summary> readProductPlansSummary(@RequestParam(value=QueryParameterConstants.SERVICE_ID ,required=false) Long serviceId ,
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readProductPlansSummary() -start");
		ReadCloudProductPlansEvent request = new ReadCloudProductPlansEvent();
		//Search Criteria
		request.setServiceId(serviceId);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		 
		
		Map<String, Long> event = service.readSummary(request);
		Summary summary=Summary.builder().summary(event).build();
		log.info("readProductPlansSummary() -end");
		return new ResponseEntity<>(summary, HttpStatus.OK);
	}

	@RequestMapping(value = "/pricingModels", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public CloudProductPlanResource getPricingModels(){
		CloudProductPlanResource response = CloudProductPlanResource.builder().pricingModels(EnumUtils.getEnumList(CloudPricingModel.class)).build();
		return response;
	}
	
}
