package com.valuelabs.nephele.manager.assembler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLicenseDetails;
import com.valuelabs.nephele.manager.controller.CloudLicensesQueryController;
import com.valuelabs.nephele.manager.resource.CloudLicenseResource;
import com.valuelabs.nephele.manager.resource.CloudLicenseResources;

import lombok.extern.slf4j.Slf4j;



@Slf4j
@Service
public class CloudLicenseAssembler extends ResourceAssemblerSupport<CloudLicenseDetails, CloudLicenseResource> {
	
	public CloudLicenseAssembler() {
		super(CloudLicensesQueryController.class, CloudLicenseResource.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CloudLicenseResource toResource(
			CloudLicenseDetails entity) {
		log.debug("toResource() : START");
		CloudLicenseResource resource = CloudLicenseResource.builder().licenseId(entity.getLicenseId())
				   .subscriptionId(entity.getSubscriptionId())
				   .status(entity.getStatus())
				   //.planId(entity.getPlanId())
				   .licenseVendorId(entity.getLicenseVendorId())
				   .licenseProvisionDate(entity.getLicenseProvisionDate())
				   //.licenseNextRenewalDate(entity.getLicenseNextRenewalDate())
				   //.licenseLastRenewalDate(entity.getLicenseLastRenewalDate())
				   //.autoRenewalOffDate(entity.getAutoRenewalOffDate())
				  // .licenseAutoRenewal(entity.isLicenseAutoRenewal())
				   .build();
		
		log.debug("toResource() : END");
		return resource;
	}

	public List<CloudLicenseDetails> fromResource(CloudLicenseResources resources){
		log.debug("fromResource: START:{} ",resources);		
		List<CloudLicenseDetails> detailsList = new ArrayList();
		for(CloudLicenseResource resource : resources.getLicenses())
		{
			CloudLicenseDetails details = CloudLicenseDetails.builder().licenseId(resource.getLicenseId())
																	   .subscriptionId(resource.getSubscriptionId())
																	   .status(resource.getStatus())
																	   .isActive(resource.getIsActive())
																	   .planId(resource.getPlanId())
																	   .licenseVendorId(resource.getLicenseVendorId())
																	   .licenseProvisionDate(resource.getLicenseProvisionDate())
																	   //.licenseNextRenewalDate(resource.getLicenseNextRenewalDate())
																	   //.licenseLastRenewalDate(resource.getLicenseLastRenewalDate())
																	   //.autoRenewalOffDate(resource.getAutoRenewalOffDate())
																	   //.licenseAutoRenewal(resource.isLicenseAutoRenewal())
																	   .build();
			detailsList.add(details);
			
		}
		log.debug("fromResouce: END");
		return detailsList;
	}
	
	public CloudLicenseDetails fromResource(CloudLicenseResource resource){
		log.debug("fromResource: START:{} ",resource);		
		CloudLicenseDetails details = CloudLicenseDetails.builder().licenseId(resource.getLicenseId())
																	   .subscriptionId(resource.getSubscriptionId())
																	   .status(resource.getStatus())
																	   .isActive(resource.getIsActive())
																	   .planId(resource.getPlanId())
																	   .licenseVendorId(resource.getLicenseVendorId())
																	   .licenseProvisionDate(resource.getLicenseProvisionDate())
																	   //.licenseNextRenewalDate(resource.getLicenseNextRenewalDate())
																	   //.licenseLastRenewalDate(resource.getLicenseLastRenewalDate())
																	   //.autoRenewalOffDate(resource.getAutoRenewalOffDate())
																	   //.licenseAutoRenewal(resource.isLicenseAutoRenewal())
																	   .build();
		
		log.debug("fromResouce: END");
		return details;
	}
	
}
