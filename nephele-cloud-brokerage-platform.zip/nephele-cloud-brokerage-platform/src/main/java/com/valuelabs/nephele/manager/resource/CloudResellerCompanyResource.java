package com.valuelabs.nephele.manager.resource;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
@Setter
@Getter
public class CloudResellerCompanyResource extends ResourceSupport {
	private Long resellerCompanyId;
	private String resellerCompanyName;
	// private Integer distributorCompanyId;
	private String firstName;
	private String lastName;
	private String email;
	private String addressLine1;
	private String addressLine2;
	private String state;
	private String city;
	private String country;
	private String zipcode;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date created;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date updated;
	private Long resellerPremiumGroupId;
	private String resellerPremiumGroupName;
	private String externalResellerCompanyCode;
	private Boolean isActive;
	private String creditCardToken; 
	private Boolean accountHoldStatus;
	//@JsonFormat(pattern = "dd-MM-yyyy")
	//private Date creditCardExpiryDate;
	private Integer creditCardExpiryYear;
    private Integer creditCardExpiryMonth;
    private String abnNumber;
    private String terrCode;
    private String creditCardType;
    private String salesPerson;
    private String countryCodeUN;
    private String countryCodeISO;
	

}
