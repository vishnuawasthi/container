package com.valuelabs.nephele.marketplace.resource;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudOrderResource extends ResourceSupport {

	private Long orderId;
	private String orderCode;
	private Long productId;
	private Long planId;
	private Long locationId;
	private Integer quantity;
	private String status;
	private Long customerId;
	private String customerName;
	private String customerCompanyName;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date creationDate;
	private String serviceName;
	private String productName;
	private String externalCustomerCode;
	private String purchaseOrderNumber;
	private Long accountId;
	private String serviceType;
	private String remarks;
	
}