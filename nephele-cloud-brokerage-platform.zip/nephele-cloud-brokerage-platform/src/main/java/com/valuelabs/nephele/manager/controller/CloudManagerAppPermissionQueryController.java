package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppPermissionDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudUserRoleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudManagerAppPermissionEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudManagerAppPermissionsEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudUserRoleEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudManagerAppPermissionQueryService;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserRoleQueryService;
import com.valuelabs.nephele.manager.assembler.CloudManagerAppPermissionAssembler;
import com.valuelabs.nephele.manager.resource.CloudManagerAppPermissionResource;
import com.valuelabs.nephele.manager.resource.CloudUserRolePermissionsResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j 
@RestController
@RequestMapping(value="/manager/cloudManagerAppPermission")
public class CloudManagerAppPermissionQueryController {
	@Autowired
	private CloudManagerAppPermissionQueryService service;
	
	@Autowired
	private CloudManagerAppPermissionAssembler assembler;
	
	@Autowired
	private CloudUserRoleQueryService cloudUserRoleQueryService ;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudManagerAppPermissionResource> readCloudManagerAppPermission(@PathVariable Long id) {
		log.info("readCloudManagerAppPermission() - start");
		ReadCloudManagerAppPermissionEvent request = new ReadCloudManagerAppPermissionEvent().setId(id);
		EntityReadEvent<CloudManagerAppPermissionDetails> event = service.readCloudManagerAppPermission(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudManagerAppPermissionDetails entity = event.getEntity();
		log.info("readCloudManagerAppPermission() - start");
		return new ResponseEntity<CloudManagerAppPermissionResource>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<PagedResources<CloudManagerAppPermissionResource>> readCloudManagerAppPermissions(
        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, 
		PagedResourcesAssembler<CloudManagerAppPermissionDetails> pagedAssembler) throws Exception{
		
		log.info("readCloudManagerAppPermissions()  - start");
		ReadCloudManagerAppPermissionsEvent request = new ReadCloudManagerAppPermissionsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudManagerAppPermissionDetails> event = service.readCloudManagerAppPermissions(request);
		Page<CloudManagerAppPermissionDetails> page = event.getPage();
		
		PagedResources<CloudManagerAppPermissionResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudManagerAppPermissions()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/*@RequestMapping(value="/permissions",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CloudManagerAppPermissionResource>> readCloudManagerAppPermissions(
			@RequestParam(value=QueryParameterConstants.ROLE_ID,required=false) Long roleId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudManagerAppPermissionDetails> pagedAssembler) {
		log.info("readCloudManagerAppPermissions()  - start");
		ReadCloudManagerAppPermissionsEvent request = new ReadCloudManagerAppPermissionsEvent().setPageable(pageable);
		
		// Search criteria
		request.setRoleId(roleId);
		
		PageReadEvent<CloudManagerAppPermissionDetails> event = service.permissions(request);
		Page<CloudManagerAppPermissionDetails> page = event.getPage();
		// PagedResources<CloudManagerAppPermissionResource> pagedResources = pagedAssembler.toResource(page, assembler);
		
		List <CloudManagerAppPermissionDetails> list = page.getContent();
		
		log.info("readCloudManagerAppPermissions()  - end");
		return new ResponseEntity<>(assembler.toResource_forPermissions(list), HttpStatus.OK);
	}*/
	
	@RequestMapping(value = "/permissions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudUserRolePermissionsResource> readPermissions(
		@RequestParam( value="roleId",required=false)Long roleId) {
		log.info("readPermissions() - start");
		
		ReadCloudUserRoleEvent request = new ReadCloudUserRoleEvent().setRoleId(roleId);
		EntityReadEvent<CloudUserRoleDetails> event = cloudUserRoleQueryService.readRolePermissions(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudUserRoleDetails entity = event.getEntity();
		CloudUserRolePermissionsResource resource = assembler.buildCloudUserRolePermissionsResource( entity); 
		log.info("readPermissions() - end");
		return new ResponseEntity<>(resource, HttpStatus.OK);
	}
	
	/*private CloudUserRolePermissionsResource buildCloudUserRolePermissionsResource(CloudUserRoleDetails entity) {
		List <CloudManagerAppPermissionResource> Permissions = new ArrayList<CloudManagerAppPermissionResource>();
		CloudUserRolePermissionsResource  resource  =  CloudUserRolePermissionsResource.builder()
																						.roleId(entity.getRoleId())
																						.roleName(entity.getRoleName())
																						.build();
		for( CloudManagerAppPermissionDetails details :NepheleValidationUtils.nullSafe(entity.getPermissions())) {
			CloudManagerAppPermissionResource  permissionResource =CloudManagerAppPermissionResource.builder()
																									.permissionId(details.getId())
																									.cloudManagerAppFeatureId(details.getCloudManagerAppFeatureId())
																									.cloudManagerAppFeatureName(details.getCloudManagerAppFeatureName())
																									.featureDescription(details.getFeatureDescription())
																									.isRead(details.getIsRead())
																									.isWrite(details.getIsWrite())
																									.build();
			Permissions.add(permissionResource);
		}
		
		resource.setPermissions(Permissions);
		return resource;
	}*/
	
	
	
	
}
