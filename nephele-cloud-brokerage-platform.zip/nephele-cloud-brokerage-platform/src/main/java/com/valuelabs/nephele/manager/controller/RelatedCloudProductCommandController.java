package com.valuelabs.nephele.manager.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.RelatedCloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateRelatedCloudProductEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.RelatedCloudProductResource;
import com.valuelabs.nephele.admin.rest.lib.service.RelatedCloudProductCommandService;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.RelatedCloudProductAssembler;

import lombok.extern.slf4j.Slf4j;



@Slf4j
@RestController
@RequestMapping(value = "/manager/relatedCloudProduct")
public class RelatedCloudProductCommandController {
	
	@Autowired
	private RelatedCloudProductCommandService service;
	
	@Autowired
	private RelatedCloudProductAssembler assembler;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RelatedCloudProductResource> createRelatedCloudProduct(@Valid @RequestBody RelatedCloudProductResource resource, BindingResult result) throws IllegalArgumentException {
		log.info("createRelatedCloudProduct() : START");
		
		RelatedCloudProductDetails relatedCloudProductDetails = assembler.fromResource(resource);		
		CreateRelatedCloudProductEvent request = new CreateRelatedCloudProductEvent().setRelatedCloudProductDetails(relatedCloudProductDetails);
		
		if (request != null) {
			service.createRelatedCloudProduct(request);
		} 

		log.info("createRelatedCloudProduct() : END");
		return new ResponseEntity<>(HttpStatus.CREATED);

	}
	
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RelatedCloudProductResource> updateRelatedCloudProduct( @Valid	@RequestBody RelatedCloudProductResource resource, BindingResult result) throws ResourceNotFoundException,IllegalArgumentException{
		log.info("updateRelatedCloudProduct() : START");
		
		if(resource.getProductId() ==null) {
			result.addError(new FieldError("resource", "relatedCloudProductId", resource.getProductId(),false, null, null, null));
		}
		if(result.hasErrors()) {
			return new ResponseEntity<RelatedCloudProductResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		
		RelatedCloudProductDetails relatedCloudProductDetails = assembler.fromResource(resource);
		CreateRelatedCloudProductEvent request = new CreateRelatedCloudProductEvent().setRelatedCloudProductDetails(relatedCloudProductDetails);
		
		if(request != null){
			service.updateRelatedCloudProduct(request);
		}
		log.info("updateRelatedCloudProduct() : END");
		return new ResponseEntity<RelatedCloudProductResource>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RelatedCloudProductResource> deleteRelatedCloudProduct(@PathVariable Long id){
		log.info("deleteRelatedCloudProduct() : START");

		if(id != null){
			service.deleteRelatedCloudProduct(id);
		}		
		
		log.info("deleteRelatedCloudProduct() : START");
		return new ResponseEntity<RelatedCloudProductResource>(HttpStatus.OK);
	}
	

}
