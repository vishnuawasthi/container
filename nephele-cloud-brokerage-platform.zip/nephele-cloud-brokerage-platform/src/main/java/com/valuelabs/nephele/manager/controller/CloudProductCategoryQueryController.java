/*package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductCategoryDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductCategoriesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductCategoryEvent;
import com.valuelabs.nephele.manager.assembler.CloudProductCategoryAssembler;
import com.valuelabs.nephele.manager.resource.CloudProductCategoryResource;
import com.valuelabs.nephele.manager.service.CloudProductCategoryQueryService;

@Slf4j
@RestController
@RequestMapping("/manager/productCategory")
public class CloudProductCategoryQueryController {

	@Autowired
	private CloudProductCategoryAssembler assembler;

	@Autowired
	private CloudProductCategoryQueryService queryService;

	*//**
	 * This method will get one record by accepting the id.
	 * 
	 * @param id
	 * @return
	 *//*
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductCategoryResource> readProductCategoryById(
			@PathVariable Long id) {
		log.info("readProductCategoryById() START");
		EntityReadEvent<CloudProductCategoryDetails> event = null;
		if (id != null) {
			ReadCloudProductCategoryEvent request = new ReadCloudProductCategoryEvent()
					.setProductCategoryId(id);
			event = queryService.readProductCategoryByIdService(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudProductCategoryDetails entity = event.getEntity();
		log.info("readProductCategoryById() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	*//**
	 * This method will get the total records available in the DB by using
	 * pagination.
	 * 
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 *//*
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductCategoryResource>> readProductCategories(
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductCategoryDetails> pagedAssembler) {
		log.info("readProductCategories() START");
		ReadCloudProductCategoriesEvent request = new ReadCloudProductCategoriesEvent()
				.setPageable(pageable);

		PageReadEvent<CloudProductCategoryDetails> event = queryService
				.readProductCategoriesService(request);
		Page<CloudProductCategoryDetails> page = event.getPage();
		PagedResources<CloudProductCategoryResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readProductCategories() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

}
*/