package com.valuelabs.nephele.manager.controller;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLicenseDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateLicenseEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudLicenseCommandService;
import com.valuelabs.nephele.manager.assembler.CloudLicenseAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudLicenseResource;
import com.valuelabs.nephele.manager.resource.CloudLicenseResources;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/license")
@Transactional
public class CloudLicensesCommandController {

	@Autowired
	private CloudLicenseAssembler assembler;

	@Autowired
	private CloudLicenseCommandService service;

	/**
	 * Create new record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudLicenseResource> createCloudLicenses(
			@Valid @RequestBody CloudLicenseResources resources,
			BindingResult result) throws IllegalArgumentException {
		log.info("createCloudLicenses() : START");		
		
		List<CloudLicenseDetails> cloudLicenseDetailsList = assembler.fromResource(resources);
		
		CreateLicenseEvent request = new CreateLicenseEvent()
				.setCloudLicenseDetailsList(cloudLicenseDetailsList);
		if (request != null) {
			service.createLicense(request);
		}
		log.info("createCloudLicenses() : END");
		return new ResponseEntity<CloudLicenseResource>(HttpStatus.CREATED);
	}

	/**
	 * Update existing record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudLicenseResource> updateCloudLicense(
			@Valid @RequestBody CloudLicenseResource resource,
			BindingResult result) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("updateCloudLicense() : START");
		if (resource.getLicenseId() == null) {
			result.addError(new FieldError("resource", "cloudLicenseId",
					resource.getLicenseId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudLicenseResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudLicenseDetails cloudLicenseDetails = assembler
				.fromResource(resource);
		CreateLicenseEvent request = new CreateLicenseEvent().setCloudLicenseDetails(cloudLicenseDetails);
				
		if (request != null) {
			service.updateeLicense(request);
		}
		log.info("updateCloudLicense() : END");
		return new ResponseEntity<CloudLicenseResource>(HttpStatus.OK);
	}

}
