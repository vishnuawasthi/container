package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerUserDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomerUserEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomerUsersEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudCustomerUserQueryService;
import com.valuelabs.nephele.manager.assembler.CloudCustomerUserAssembler;
import com.valuelabs.nephele.manager.resource.CloudCustomerUserResource;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/manager/cloudCustomerUser")
public class CloudCustomerUserQueryController {

	@Autowired
	private CloudCustomerUserAssembler assembler;

	@Autowired
	private CloudCustomerUserQueryService service;

	/**
	 * Get a record by passing id from DB
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudCustomerUserResource> readCustomerUser(
			@PathVariable Long id) {
		log.info("readCustomerUser() START");
		EntityReadEvent<CloudCustomerUserDetails> event = null;
		if (id != null) {
			ReadCloudCustomerUserEvent request = new ReadCloudCustomerUserEvent()
					.setCustomerId(id);
			event = service.readServiceCustomerUser(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudCustomerUserDetails entity = event.getEntity();
		log.info("readCustomerUser() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	/**
	 * Get all records from DB
	 * 
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudCustomerUserResource>> readCustomerUsers(
        	@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudCustomerUserDetails> pagedAssembler) {
		log.info("readCustomerUsers() START");
		ReadCloudCustomerUsersEvent request = new ReadCloudCustomerUsersEvent()
				.setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudCustomerUserDetails> event = service
				.readServiceCustomerUsers(request);
		Page<CloudCustomerUserDetails> page = event.getPage();
		PagedResources<CloudCustomerUserResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readCustomerUsers() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

}
