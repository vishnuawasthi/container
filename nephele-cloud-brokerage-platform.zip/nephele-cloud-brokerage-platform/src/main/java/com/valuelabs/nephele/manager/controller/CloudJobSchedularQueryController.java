package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.JobTypes;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudJobSchedularDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudJobSchedularEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudJobSchedularsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudJobSchedularQueryService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudJobSchedularResources;
import com.valuelabs.nephele.manager.assembler.CloudJobSchedularAssembler;
import com.valuelabs.nephele.manager.resource.JobTypeResources;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/manager/jobSchedular")
public class CloudJobSchedularQueryController {

	@Autowired
	CloudJobSchedularAssembler assembler;

	@Autowired
	CloudJobSchedularQueryService service;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudJobSchedularResources> readScheduledJob(@PathVariable Long id) {
		log.info("readScheduledJob() START");
		
		ReadCloudJobSchedularEvent request = new ReadCloudJobSchedularEvent().setJobId(id);

		EntityReadEvent<CloudJobSchedularDetails> event = service.readCloudJobSchedular(request);
		
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudJobSchedularDetails entity = event.getEntity();
		log.info("readScheduledJob() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudJobSchedularResources>> readScheduledJobs(
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
			@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudJobSchedularDetails> pagedAssembler) {
		log.info("readScheduledJobs() START");
		ReadCloudJobSchedularsEvent request = new ReadCloudJobSchedularsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudJobSchedularDetails> event = service.readCloudJobsSchedular(request);

		Page<CloudJobSchedularDetails> page = event.getPage();
		PagedResources<CloudJobSchedularResources> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readScheduledJobs() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/jobTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JobTypeResources> readAllJobTypes() {
		log.info("readAllJobTypes() START");
		
		JobTypeResources response= JobTypeResources.builder().jobTypes((EnumUtils.getEnumList(JobTypes.class))).build();
		log.info("readAllJobTypes() END");
		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}

}
