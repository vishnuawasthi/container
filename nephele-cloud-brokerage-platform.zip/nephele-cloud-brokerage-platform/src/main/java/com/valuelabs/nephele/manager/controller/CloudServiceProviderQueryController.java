package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceProviderDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceProviderEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceProvidersEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceProviderQueryService;
import com.valuelabs.nephele.manager.assembler.CloudServiceProviderAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudServiceProviderResource;

@Slf4j
@RestController
@RequestMapping(value = "/manager/serviceProvider")
public class CloudServiceProviderQueryController {
	
	@Autowired
	CloudServiceProviderAssembler assembler;
	
	@Autowired
	CloudServiceProviderQueryService service;
	

	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceProviderResource> readServiceProvider(@PathVariable Long id) {
		log.info("readServiceProvider() START");
		EntityReadEvent<CloudServiceProviderDetails> event = null;
		if (id != null) {
			ReadServiceProviderEvent request = new ReadServiceProviderEvent().setServiceProviderId(id);
			event = service.readServiceProvider(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudServiceProviderDetails entity = event.getEntity();
		log.info("readServiceProvider() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	/*@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public SimplePage<CloudServiceProvider> readServiceProviders(){
		log.info("readServiceProviders() START");
		//SimplePage<CloudServiceProvider> simplePage=service.readServicePriceModels();
		service.readServicePriceModels();
		SerializedPageWrapper<CloudServiceProvider> wrapper=new SerializedPageWrapper<CloudServiceProvider>();
		wrapper.setContent(service.readServicePriceModels());
		PageImpl<CloudServiceProvider> pageImpl =new PageImpl<>(service.readServicePriceModels());
		log.info("readServiceProviders() END");
		return null;
	}*/
	//@PageableDefault to make size default to 10 records per page 
	//@SortDefault(sort="serviceProviderId" ,direction= Direction.DESC)
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServiceProviderResource>> readServiceProviders(
              @RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
              @RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			  @PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServiceProviderDetails> pagedAssembler) {
		log.info("readServiceProviders() START");
		ReadServiceProvidersEvent request=new ReadServiceProvidersEvent().setPageable(pageable);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudServiceProviderDetails> event=service.readServiceProviders(request);
		Page<CloudServiceProviderDetails> page=event.getPage();
		PagedResources<CloudServiceProviderResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServiceProviders() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

}
