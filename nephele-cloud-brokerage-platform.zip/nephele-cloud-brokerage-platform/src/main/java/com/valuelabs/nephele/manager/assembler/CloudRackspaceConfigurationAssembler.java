package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;
import com.valuelabs.nephele.manager.constants.FlavorClasses;
import com.valuelabs.nephele.manager.controller.CloudRackspaceConfigurationQueryController;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResource;
import com.valuelabs.nephele.manager.resource.FlavorClassResource;
@Slf4j
@Service
public class CloudRackspaceConfigurationAssembler extends ResourceAssemblerSupport<CloudRackspaceConfigurationDetails, CloudRackspaceConfigurationResource> {

	public CloudRackspaceConfigurationAssembler() {
		super(CloudRackspaceConfigurationQueryController.class, CloudRackspaceConfigurationResource.class);
	}

	@Override
	public CloudRackspaceConfigurationResource toResource(
			CloudRackspaceConfigurationDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: "+entity);
		CloudRackspaceConfigurationResource resource = instantiateResource(entity);
		
		resource = CloudRackspaceConfigurationResource.builder().configurationId(entity.getConfigurationId())
					.cspResource(entity.getCspResource())
					.flavourId(entity.getFlavourId())
					.name(entity.getName())
					.size(entity.getSize())
					.configurationTypeId(entity.getConfigurationTypeId())
					.serviceId(entity.getServiceId())
					.cpu(entity.getCpu()).status(entity.getStatus()).serviceId(entity.getServiceId())
					.disk(entity.getDisk()).ram(entity.getRam()).price(String.valueOf(entity.getPrice())).properties(entity.getProperties()).status(entity.getStatus())
					.cloudServiceId(entity.getCloudServiceId()).build();
		resource.add(linkTo(methodOn(CloudRackspaceConfigurationQueryController.class).readRackspaceConfiguration(entity.getConfigurationId())).withSelfRel());
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
		
	}
	
	
	@Override
	public List<CloudRackspaceConfigurationResource> toResources(Iterable<? extends CloudRackspaceConfigurationDetails> entities) {
		log.debug("toResource() : START");
		List<CloudRackspaceConfigurationResource> configResourceList = new ArrayList<CloudRackspaceConfigurationResource>();
		for (CloudRackspaceConfigurationDetails entity : entities) {
			configResourceList.add(toResource_withOutConfigId(entity));
		}
		
		return configResourceList;
	}
	
	public FlavorClassResource toResources_forConfiguration(Iterable<? extends CloudRackspaceConfigurationDetails> entities) {
		log.debug("toResource() : START");
		
		return FlavorClassResource.builder().standard1(getResourcesByClass(entities, FlavorClasses.STANDARD1))
																		  .general1(getResourcesByClass(entities, FlavorClasses.GENERAL1))
																		  .io1(getResourcesByClass(entities, FlavorClasses.IO1))
																		  .performance1(getResourcesByClass(entities, FlavorClasses.PERFORMANCE1))
																		  .build();
		
	}
	//PlansResource.builder().flavors(
	
	public List<CloudLocationResource> toResources_forLocation(Iterable<? extends CloudLocationDetails> entities) {
		log.debug("toResource() : START");
		List<CloudLocationResource> locationResourceList = new ArrayList<CloudLocationResource>();
		for (CloudLocationDetails entity : entities) {
			CloudLocationResource resource = CloudLocationResource.builder().locationId(entity.getCloudLocationId())
																		    .name(entity.getName())
															                .build();
			locationResourceList.add(resource);
		}
		return locationResourceList; 
		
	}
	
	public CloudRackspaceConfigurationResource toResource_withOutConfigId (CloudRackspaceConfigurationDetails entity) {
		log.debug("toResource() : Service: "+entity);
		CloudRackspaceConfigurationResource resource = instantiateResource(entity);
		
		resource = CloudRackspaceConfigurationResource.builder().configurationId(entity.getConfigurationId())
					.name(entity.getName())
					.properties(entity.getProperties())
					.build();
		resource.add(linkTo(methodOn(CloudRackspaceConfigurationQueryController.class).readRackspaceConfiguration(entity.getConfigurationId())).withSelfRel());
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
		
	}
	
	private List<CloudRackspaceConfigurationResource> getResourcesByClass(Iterable<? extends CloudRackspaceConfigurationDetails> entities, FlavorClasses flavorClass) {
		List<CloudRackspaceConfigurationResource> resourceList = new ArrayList<CloudRackspaceConfigurationResource>();
		for (CloudRackspaceConfigurationDetails entity : entities) {
			if(flavorClass.name().equalsIgnoreCase(entity.getFlavorClass())) {
				resourceList.add(toResource_withOutConfigId(entity));
			}
		}
		
		return resourceList;
	}

	
	public CloudRackspaceConfigurationDetails fromResource(CloudRackspaceConfigurationResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudRackspaceConfigurationDetails details = CloudRackspaceConfigurationDetails.builder()
				.configurationId(resource.getConfigurationId()).cspResource(resource.getCspResource())
				.flavourId(resource.getFlavourId()).name(resource.getName()).size(resource.getSize())
				.configurationTypeId(resource.getConfigurationTypeId()).serviceId(resource.getServiceId()).cpu(resource.getCpu())
				.status(resource.getStatus()).cloudServiceId(resource.getCloudServiceId())
				.build();
		log.debug("fromResouce: END");
		return details;
	}
	
	
}
