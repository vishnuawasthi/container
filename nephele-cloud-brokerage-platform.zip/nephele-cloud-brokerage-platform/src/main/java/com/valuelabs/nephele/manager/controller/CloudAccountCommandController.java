package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAccountCommandService;
import com.valuelabs.nephele.manager.assembler.CloudAccountAssembler;
import com.valuelabs.nephele.manager.resource.CloudAccountResource;


@Slf4j
@RestController
@RequestMapping(value="/manager/cloudAccount")
public class CloudAccountCommandController {
  
  @Autowired
  private CloudAccountCommandService service;
  
  @Autowired
  private CloudAccountAssembler assembler;
  
  
  /**
   * This creates cloud accounts 
   * @param resource
   * @param result
   * @return
   * @throws IllegalArgumentException
   */
  @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<CloudAccountResource> createCloudAccount(
	 @Valid @RequestBody CloudAccountResource resource,
	 BindingResult result) throws IllegalArgumentException {
	log.info(" createCloudAccount()  - start");
	
	if(StringUtils.isEmpty(resource.getCustomerCompanyId())) {
	  result.addError(new FieldError("resource", "customerCompanyId", resource.getCustomerCompanyId(), false, null, null, null));
	}
	if(StringUtils.isEmpty(resource.getServiceId())) {
	  result.addError(new FieldError("resource", "serviceId", resource.getServiceId(), false, null, null, null));
	}
	if(StringUtils.isEmpty(resource.getOrderId())) {
		  result.addError(new FieldError("resource", "orderId", resource.getOrderId(), false, null, null, null));
	}
	if (result.hasErrors()) {
	  List<String> errorMessageList = new ArrayList<String>();
	  List<FieldError> errors = result.getFieldErrors();
	  if (result.hasErrors()) {
		for (FieldError fieldError : errors) {
		  errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
		}
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
		    .errorMessages(errorMessageList).build();
		return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
	  }
	}
	
	CloudAccountDetails details = assembler.fromResource(resource);
	CreateCloudAccountEvent request = new CreateCloudAccountEvent().setAccountDetails(details);
	if (request != null) {
	  try {
		service.createCloudAccount(request);
	} catch (InterruptedException e) {
		log.error("Exception in createCloudAccount()"+e.getMessage());
		e.printStackTrace();
	}
	}
	log.info(" createCloudAccount()  - end");
	return new ResponseEntity<CloudAccountResource>(HttpStatus.CREATED);
  }
  
  
  /**
   * This  method updates cloud account details
   * @param resource
   * @param result
   * @return
   * @throws IllegalArgumentException
   */
  @RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<CloudAccountResource> updateCloudAccountR(
	 @Valid @RequestBody CloudAccountResource resource,
	 BindingResult result) throws IllegalArgumentException {
	 log.info("updateCloudAccountR()  - start");
	 if (resource.getAccountId() == null) {
	   result.addError(new FieldError("resource", "accountId", resource.getAccountId(), false, null, null, ""));
	 }

	if (result.hasErrors()) {
	  List<String> errorMessageList = new ArrayList<String>();
	  List<FieldError> errors = result.getFieldErrors();
	  if (result.hasErrors()) {
		for (FieldError fieldError : errors) {
		  errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
		}
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
		    .errorMessages(errorMessageList).build();
		return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
	  }
	}
	CloudAccountDetails details = assembler.fromResource(resource);
	CreateCloudAccountEvent request = new CreateCloudAccountEvent().setAccountDetails(details);
	if (request != null) {
	  			service.updateCloudAccount(request);
	}
	log.info("updateCloudAccountR()  - end");
	return new ResponseEntity<CloudAccountResource>(HttpStatus.OK);
  }

}
