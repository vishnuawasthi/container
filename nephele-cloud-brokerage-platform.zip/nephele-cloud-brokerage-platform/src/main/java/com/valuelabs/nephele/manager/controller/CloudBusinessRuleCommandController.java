package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudBusinessRuleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudBusinessRuleEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudBusinessRuleCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.CloudBusinessRuleAssembler;
import com.valuelabs.nephele.manager.resource.CloudBusinessRuleResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/cloudBusinessRule")
@Transactional
public class CloudBusinessRuleCommandController {

	@Autowired
	private CloudBusinessRuleAssembler assembler;

	@Autowired
	private CloudBusinessRuleCommandService service;

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudBusinessRuleResource> updateCloudBusinessRule(
			@Valid @RequestBody CloudBusinessRuleResource resource, 
			BindingResult result)throws IllegalStateException {
		log.info("updateCloudBusinessRule()  - start");
		
		if (resource.getRuleId() == null) {
			result.addError(new FieldError("resource", "ruleId", resource.getRuleId(), false, null, null, ""));
		}
		
		List<String> errorMessageList = new ArrayList<String>();
		List<FieldError> errors = result.getFieldErrors();
		if (result.hasErrors()) {
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " "+ fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		
		CloudBusinessRuleDetails details = assembler.fromResource(resource);
		CreateCloudBusinessRuleEvent request = new CreateCloudBusinessRuleEvent().setCloudBusinessRuleDetails(details);
		if (request != null) {
			service.updateCloudBusinessRule(request);
		}
		log.info("updateCloudBusinessRule()  - end");
		return new ResponseEntity<CloudBusinessRuleResource>(HttpStatus.OK);
	}

}
