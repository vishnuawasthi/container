package com.valuelabs.nephele.marketplace.resource;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
@Accessors(chain=true)
@JsonInclude(Include.NON_DEFAULT)
public class PlaceOrderResources extends ResourceSupport {
	
	private List<PlaceOrderResource> cart;
	private String message;

}
