package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductSyncDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.RelatedExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.B2BSolarProductSyncEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateRelatedExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.event.RelatedExternalProductCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.RelatedExternalProductResource;
import com.valuelabs.nephele.admin.rest.lib.service.RelatedExternalProductCommandService;
import com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.RelatedExternalProductAssembler;



@Slf4j
@RestController
@RequestMapping(value = "/manager/relatedexternalproducts")
public class RelatedExternalProductCommandController {
	
	@Autowired
	private RelatedExternalProductCommandService service;
	
	@Autowired
	private RelatedExternalProductAssembler assembler;
	

	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RelatedExternalProductResource> createRelatedExternalProduct(@Valid @RequestBody RelatedExternalProductResource resource, BindingResult result) throws IllegalArgumentException {
		log.info("createRelatedExternalProduct() : START");
		
		RelatedExternalProductDetails relatedExternalProductDetails = assembler.fromResource(resource);		
		CreateRelatedExternalProductEvent request = new CreateRelatedExternalProductEvent().setRelatedExternalProductDetails(relatedExternalProductDetails);
		RelatedExternalProductCreatedEvent event = null;
		if (request != null) {
		  event =service.createRelatedExternalProduct(request);
		} 
		if(null != event){
		  ExternalProductSyncDetails details = new ExternalProductSyncDetails();
		  details.setExternalIdList(event.getExternalIdList());
		  details.setIsBulkSync(false);
		  B2BSolarProductSyncEvent externalProductSyncEvent = new B2BSolarProductSyncEvent().setExternalProductSyncDetails(details);
		  log.info("Solr ExternalProduct  request:{}"+externalProductSyncEvent.getBundleDetails());
		  rabbitTemplate.convertAndSend(B2BServiceIntegrationMQConfig.EXCHANGE_NAME, SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY,	externalProductSyncEvent);
		
		}
		log.info("createRelatedExternalProduct() : END");
		return new ResponseEntity<>(HttpStatus.CREATED);

	}
	
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RelatedExternalProductResource> updateRelatedExternalProduct( @Valid	@RequestBody RelatedExternalProductResource resource, BindingResult result) throws ResourceNotFoundException,IllegalArgumentException{
		log.info("updateRelatedExternalProduct() : START");
		
		if(resource.getRelatedExtProductId() == null) {
			result.addError(new FieldError("resource", "relatedCloudProductId", resource.getRelatedExtProductId(),false, null, null, null));
		}
		if(result.hasErrors()) {
			return new ResponseEntity<RelatedExternalProductResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		
		RelatedExternalProductDetails relatedExternalProductDetails = assembler.fromResource(resource);
		CreateRelatedExternalProductEvent request = new CreateRelatedExternalProductEvent().setRelatedExternalProductDetails(relatedExternalProductDetails);
		RelatedExternalProductCreatedEvent event = null;
		if(request != null){
		  event=	service.updateRelatedExternalProduct(request);
		}
	if (null != event) {
	  ExternalProductSyncDetails details = new ExternalProductSyncDetails();
	  details.setExternalIdList(event.getExternalIdList());
	  details.setIsBulkSync(false);
	  B2BSolarProductSyncEvent externalProductSyncEvent = new B2BSolarProductSyncEvent().setExternalProductSyncDetails(details);
	  log.info("Solr ExternalProduct  request:{}" + externalProductSyncEvent.getBundleDetails());
	  rabbitTemplate.convertAndSend(B2BServiceIntegrationMQConfig.EXCHANGE_NAME, SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY,
		  externalProductSyncEvent);
	  }
		log.info("updateRelatedExternalProduct() : END");
		return new ResponseEntity<RelatedExternalProductResource>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RelatedExternalProductResource> deleteRelatedExternalProduct(@PathVariable Long id){
		log.info("deleteRelatedExternalProduct() : START");

		if(id != null){
			service.deleteRelatedExternalProduct(id);
		}		
		
		log.info("deleteRelatedExternalProduct() : START");
		return new ResponseEntity<RelatedExternalProductResource>(HttpStatus.OK);
	}
	

}
