package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceUsageDataDetails;
import com.valuelabs.nephele.manager.controller.CloudRackspaceUsageDataQueryController;
import com.valuelabs.nephele.manager.resource.CloudRackspaceUsageDataResource;
@Slf4j
@Service
public class CloudRackspaceUsageDataAssembler extends ResourceAssemblerSupport<CloudRackspaceUsageDataDetails, CloudRackspaceUsageDataResource> {

	public CloudRackspaceUsageDataAssembler() {
		super(CloudRackspaceUsageDataQueryController.class, CloudRackspaceUsageDataResource.class);
	}

	@Override
	public CloudRackspaceUsageDataResource toResource(CloudRackspaceUsageDataDetails entity) {
		log.debug("toResource() - start");
		CloudRackspaceUsageDataResource resource = instantiateResource(entity);
		resource = CloudRackspaceUsageDataResource.builder().CloudRackspaceUsageDataId(entity.getId())
				.cloudCustomerCompanyId(entity.getCloudCustomerCompanyId()).cloudServerId(entity.getCloudServerId()).cloudServiceId(entity.getCloudServiceId())
				.cspServerId(entity.getCspServerId()).serverName(entity.getServerName()).currency(entity.getCurrency())
				.productType(entity.getProductType()).flavourName(entity.getFlavourName()).serviceType(entity.getServiceType())
				.totalPrice(entity.getTotalPrice()).unitPrice(entity.getUnitPrice()).usageQuantity(entity.getUsageQuantity())
				.unitPrice(entity.getUnitPrice()).build();
		resource.add(linkTo(methodOn(CloudRackspaceUsageDataQueryController.class).readCloudRackspaceUsageData(entity.getId())).withSelfRel());
		log.debug("toResource() - end");
		return resource;
	}

	public CloudRackspaceUsageDataDetails fromResource(CloudRackspaceUsageDataResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudRackspaceUsageDataDetails details = CloudRackspaceUsageDataDetails.builder().id(resource.getCloudRackspaceUsageDataId())
				.cloudCustomerCompanyId(resource.getCloudCustomerCompanyId()).cloudServerId(resource.getCloudServerId())
				.cloudServiceId(resource.getCloudServiceId()).cspServerId(resource.getCspServerId()).serverName(resource.getServerName())
				.currency(resource.getCurrency()).productType(resource.getProductType()).flavourName(resource.getFlavourName())
				.serviceType(resource.getServiceType()).totalPrice(resource.getTotalPrice())
				.unitPrice(resource.getUnitPrice()).usageQuantity(resource.getUsageQuantity()).unitPrice(resource.getUnitPrice()).build();
		log.debug("fromResouce: END");
		return details;
	}

}
