package com.valuelabs.nephele.manager.configuration;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class MeteringDataFeedMQConfig {

	@Autowired
	AmqpAdmin rabbitAdmin;

	public static final String EXCHANGE_NAME = "nephele.cloud.rackspace.metering.data.feed.exchange";

	public static final String RACKSPACE_METERING_DATA_FEED_QUEUE_NAME = "nephele.cloud.rackspace.metering.data.feed.queue";
	public static final String RACKSPACE_METERING_DATA_FEED_ROUTING_KEY = "nephele.cloud.rackspace.metering.data.feed.syncKey";

	@Bean(name = "createRackspaceMeteringDataFeedQueue")
	public Queue getRackspaceMeteringDataFeedQueue() {
		return new Queue(RACKSPACE_METERING_DATA_FEED_QUEUE_NAME, true);
	}

	@Bean(name = "rackspaceMeteringDataFeedDirectExchange")
	public DirectExchange getRackspaceMeteringDataFeedDirectExchange() {
		return new DirectExchange(EXCHANGE_NAME, true, false);
	}

	@Bean(name = "rackspaceMeteringDataFeedBinding")
	Binding getRackspaceMeteringDataFeedBinding(Queue createRSMeteringDataFeedQueue,
			DirectExchange rsMeteringDataFeedDirectExchange) {
		return BindingBuilder.bind(createRSMeteringDataFeedQueue).to(rsMeteringDataFeedDirectExchange)
				.with(RACKSPACE_METERING_DATA_FEED_ROUTING_KEY);
	}

	@PostConstruct
	public void initializeRSMeteringDataFeedQueue() {
		log.debug("initializeRSMeteringDataFeedQueue");

		DirectExchange rsMeteringDataFeedDirectExchange = getRackspaceMeteringDataFeedDirectExchange();

		Queue createRSMeteringDataFeedQueue = getRackspaceMeteringDataFeedQueue();
		Binding createRSMeteringDataFeedBinding = getRackspaceMeteringDataFeedBinding(createRSMeteringDataFeedQueue,
				rsMeteringDataFeedDirectExchange);

		rabbitAdmin.declareExchange(rsMeteringDataFeedDirectExchange);

		rabbitAdmin.declareQueue(createRSMeteringDataFeedQueue);
		rabbitAdmin.declareBinding(createRSMeteringDataFeedBinding);

	}

}
