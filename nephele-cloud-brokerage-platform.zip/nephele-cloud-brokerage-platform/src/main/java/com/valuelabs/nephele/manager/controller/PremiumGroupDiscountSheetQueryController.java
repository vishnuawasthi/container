package com.valuelabs.nephele.manager.controller;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountSheetDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadPremiumGroupDiscountSheetEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadPremiumGroupDiscountSheetsEvent;
import com.valuelabs.nephele.admin.rest.lib.service.PremiumGroupDiscountSheetQueryService;
import com.valuelabs.nephele.manager.assembler.PremiumGroupDiscountSheetAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.PremiumGroupDiscountSheetResource;

@Slf4j
@RestController
@RequestMapping("/")
@Transactional
public class PremiumGroupDiscountSheetQueryController {

	@Autowired
	private PremiumGroupDiscountSheetQueryService service;
	
	@Autowired
	private PremiumGroupDiscountSheetAssembler assembler;

	@RequestMapping(value = "manager/discounts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PremiumGroupDiscountSheetResource> readGroupDiscountSheet(@PathVariable Long id) {
		log.info("readGroupDiscountSheet() - start");
		ReadPremiumGroupDiscountSheetEvent request = new ReadPremiumGroupDiscountSheetEvent().setId(id);
		EntityReadEvent<PremiumGroupDiscountSheetDetails> event = service.readGroupDiscountSheetDetails(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		PremiumGroupDiscountSheetDetails entity = event.getEntity();
		log.info("readGroupDiscountSheet() - start");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(value = "manager/discounts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<PremiumGroupDiscountSheetResource>> readGroupDiscountSheets(
			@RequestParam(value = "groupName" ,required=false) String groupName,
			@RequestParam(value = "serviceId" ,required=false) Long serviceId,
			@RequestParam(value = "planType" ,required=false) String planType,
			@RequestParam(value = "sheetId" ,required=false) Long sheetId,
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<PremiumGroupDiscountSheetDetails> pagedAssembler) {
		log.info("readGroupDiscountSheets()  - start");
		ReadPremiumGroupDiscountSheetsEvent request = new ReadPremiumGroupDiscountSheetsEvent().setPageable(pageable);
		request.setGroupName(groupName);
		request.setServiceId(serviceId);
		request.setPlanType(planType);
		request.setSheetId(sheetId);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		
		PageReadEvent<PremiumGroupDiscountSheetDetails> event = service.readGroupDiscountSheetsDetails(request);
		Page<PremiumGroupDiscountSheetDetails> page = event.getPage();
		PagedResources<PremiumGroupDiscountSheetResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readGroupDiscountSheets()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/discountSheet", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<PremiumGroupDiscountSheetResource>> readGroupDiscountSheetsBySheetName(@RequestParam("sheetName") String sheetName,
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<PremiumGroupDiscountSheetDetails> pagedAssembler) {
		log.info("readGroupDiscountSheetsBySheetName()  - start");
		ReadPremiumGroupDiscountSheetsEvent request = new ReadPremiumGroupDiscountSheetsEvent().setPageable(pageable);
		request.setSheetName(sheetName);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		
		PageReadEvent<PremiumGroupDiscountSheetDetails> event = service.readGroupDiscountSheetsBySheetName(request);
		Page<PremiumGroupDiscountSheetDetails> page = event.getPage();
		PagedResources<PremiumGroupDiscountSheetResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readGroupDiscountSheetsBySheetName()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	// marketplace/discounts?serviceId=1&externalResellerId=abc
	@RequestMapping(value = "marketplace/discounts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<PremiumGroupDiscountSheetResource>> readDiscounts(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@RequestParam(value = "serviceId" ,required=false) Long serviceId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<PremiumGroupDiscountSheetDetails> pagedAssembler,
			ServletRequest servletRequest) {
		log.info("readGroupDiscountSheets()  - start");
		HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
		String externalResellerCode = httpServletRequest.getHeader("X-RESELLER-KEY");
		ReadPremiumGroupDiscountSheetsEvent request = new ReadPremiumGroupDiscountSheetsEvent().setPageable(pageable);
		request.setServiceId(serviceId);
		request.setStatus(ChangeManagementConfigStatus.ACTIVE);
		request.setExternalResellerCode(externalResellerCode);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		
		//service.readGroupDiscountSheetsDetails(request);
		PageReadEvent<PremiumGroupDiscountSheetDetails> event = service.readGroupDiscountSheetsDetailsByServiceId(request);
		Page<PremiumGroupDiscountSheetDetails> page = event.getPage();
		PagedResources<PremiumGroupDiscountSheetResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readGroupDiscountSheets()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	
}
