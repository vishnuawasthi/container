package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudLocationEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudLocationCommandService;
import com.valuelabs.nephele.manager.assembler.CloudLocationAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;
import com.valuelabs.nephele.manager.resource.CloudLocationResources;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping("/manager/cloudLocation")
@Transactional
public class CloudLocationCommandController {
	

	@Autowired
	CloudLocationAssembler assembler;

	@Autowired
	private CloudLocationCommandService service;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudLocationResource> createCloudLocation(@Valid @RequestBody CloudLocationResource resource,BindingResult result) throws IllegalStateException{
		log.info("createCloudLocation(): START");
		if(result.hasErrors()){
			return new ResponseEntity<CloudLocationResource>(HttpStatus.BAD_REQUEST);
		}
		CloudLocationDetails details = assembler.fromResource(resource);
		CreateCloudLocationEvent request = new CreateCloudLocationEvent().setCloudLocationDetails(details);
		if (request != null) {
			
			service.createCloudLocation(request);
		}
		log.info("createCloudLocation(): END");
		return new ResponseEntity<CloudLocationResource>(HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudLocationResource> updateCloudLocation(@Valid @RequestBody CloudLocationResource resource, BindingResult result)throws ResourceNotFoundException,IllegalStateException {
		log.info(" updateCloudLocation() : START");
		if(resource.getLocationId() == null){
			result.addError(new FieldError("resource", "cloudLocationId", resource.getLocationId(), true, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudLocationResource>(HttpStatus.BAD_REQUEST);
		}
		CloudLocationDetails details = assembler.fromResource(resource);
		CreateCloudLocationEvent request = new CreateCloudLocationEvent().setCloudLocationDetails(details);
		if (request != null) {
			service.updateCloudLocation(request);
		}
		log.info("updateCloudLocation(): END");
		return new ResponseEntity<CloudLocationResource>(HttpStatus.OK);
	}
	
	@RequestMapping(value="/updateStatusById",method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudLocationResources> updatStatusById(@RequestBody CloudLocationResources resources) {
		log.info("updateStatusById - start");
		int errorCounter = 0;
		List<CloudLocationDetails> detailsList = new ArrayList<CloudLocationDetails>();
		for (CloudLocationResource resource : resources.getResources()) {
			if (resource.getLocationId() == null) {
				errorCounter++;
			}
			CloudLocationDetails details = CloudLocationDetails.builder().cloudLocationId(resource.getLocationId()).status(resource.getStatus()) .build();
			detailsList.add(details);
		}
		if (errorCounter != 0) {
			return new ResponseEntity<CloudLocationResources>(resources, HttpStatus.BAD_REQUEST);
		}
		CreateCloudLocationEvent request = new CreateCloudLocationEvent().setCloudLocationDetailsList(detailsList);
		service.updateStatusById(request);
		log.info("updateStatusById - end");
		return new ResponseEntity<CloudLocationResources>(HttpStatus.OK);
	}
	
	
	
	
}
