package com.valuelabs.nephele.manager.assembler;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppPermissionDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudUserRoleDetails;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import com.valuelabs.nephele.manager.controller.CloudManagerAppPermissionQueryController;
import com.valuelabs.nephele.manager.resource.CloudManagerAppPermissionResource;
import com.valuelabs.nephele.manager.resource.CloudPermissionResource;
import com.valuelabs.nephele.manager.resource.CloudPermissionsResource;
import com.valuelabs.nephele.manager.resource.CloudUserRolePermissionsResource;

@Service
@Slf4j
public class CloudManagerAppPermissionAssembler  extends ResourceAssemblerSupport<CloudManagerAppPermissionDetails, CloudManagerAppPermissionResource>{

	public CloudManagerAppPermissionAssembler() {
		super(CloudManagerAppPermissionQueryController.class, CloudManagerAppPermissionResource.class);
	}

	@Override
	public CloudManagerAppPermissionResource toResource(CloudManagerAppPermissionDetails entity) {
		log.debug("toResource() - start");
		CloudManagerAppPermissionResource   resource = instantiateResource(entity);
											resource = CloudManagerAppPermissionResource.builder()
																						.permissionId(entity.getId())
																						.isWrite(entity.getIsWrite())
																						.isRead(entity.getIsRead())
																						.accountName(entity.getCloudManagerAppAccountName())
																						.roleId(entity.getRoleId())
																						.roleName(entity.getRoleName())
																						.build();
		log.debug("toResource() - end");
		return resource;
	}
	
	public CloudManagerAppPermissionDetails fromResource(CloudManagerAppPermissionResource resource) {
		log.debug("fromResource() - start");
		CloudManagerAppPermissionDetails   details  = CloudManagerAppPermissionDetails.builder()
																					 .id(resource.getPermissionId())
																					 .isRead(resource.getIsRead())
																					 .isWrite(resource.getIsWrite())
																					 .roleId(resource.getRoleId())
																					 .roleName(resource.getRoleName())
																					 .cloudManagerAppAccountName(resource.getAccountName())
																					 .build();
		log.debug("fromResource() - end");
		return details;
	}
	
	public List<CloudManagerAppPermissionDetails> fromResource(CloudPermissionsResource resource){
		log.debug("fromResource() - start");
		
		List<CloudManagerAppPermissionDetails> permissionsDetails = new ArrayList<CloudManagerAppPermissionDetails>();
		List<CloudPermissionResource> permissionsResource = resource.getPermissions();
		for(CloudPermissionResource permission:permissionsResource){
			
			CloudManagerAppPermissionDetails details =  CloudManagerAppPermissionDetails.builder()
																						.id(permission.getPermissionId())
																						.isRead(permission.getIsRead())
																						.isWrite(permission.getIsWrite())
																						.build();
			permissionsDetails.add(details);
		}
		
		log.debug("fromResource() - end");
		
		return permissionsDetails;
		
	}
	
	public CloudUserRolePermissionsResource buildCloudUserRolePermissionsResource(CloudUserRoleDetails entity) {
		List <CloudManagerAppPermissionResource> Permissions = new ArrayList<CloudManagerAppPermissionResource>();
		CloudUserRolePermissionsResource  resource  =  CloudUserRolePermissionsResource.builder()
																						.roleId(entity.getRoleId())
																						.roleName(entity.getRoleName())
																						.build();
		for( CloudManagerAppPermissionDetails details :NepheleValidationUtils.nullSafe(entity.getPermissions())) {
			CloudManagerAppPermissionResource  permissionResource =CloudManagerAppPermissionResource.builder()
																									.permissionId(details.getId())
																									.accountName(details.getCloudManagerAppAccountName())
																									.isRead(details.getIsRead())
																									.isWrite(details.getIsWrite())
																									.build();
			Permissions.add(permissionResource);
		}
		
		resource.setPermissions(Permissions);
		return resource;
	}
	/*
	public List<CloudManagerAppPermissionResource> toResource_forPermissions(List <CloudManagerAppPermissionDetails> entities) {
		log.debug("toResource_forPermissions() - start");
		List<CloudManagerAppPermissionResource> resourceList = new ArrayList<CloudManagerAppPermissionResource>();
		for(CloudManagerAppPermissionDetails details  :entities ) {
			CloudManagerAppPermissionResource	resource = CloudManagerAppPermissionResource.builder()
																							.roleId(details.getRoleId())
																							.roleName(details.getRoleName())
																							.build();
			CloudManagerAppFeatureDetails featureAppDetails  =	details.getAppFeatureDetails();
			CloudManagerAppFeatureResource featureResource = CloudManagerAppFeatureResource.builder()
																							.cloudManagerAppFeatureId(featureAppDetails.getId())
																							.name(featureAppDetails.getName())
																							.build();
			resource.setFeatures(featureResource);																			
			resourceList.add(resource);
		}
		log.debug("toResource_forPermissions() - end");
		return resourceList;
	}*/
	

}
