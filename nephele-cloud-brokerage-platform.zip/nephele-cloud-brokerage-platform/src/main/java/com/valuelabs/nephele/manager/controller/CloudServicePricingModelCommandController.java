package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServicePricingModelDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServicePricingModelEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServicePricingModelCommandService;
import com.valuelabs.nephele.manager.assembler.CloudServicePricingModelAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudServicePricingModelResource;

@Slf4j
@RestController
@RequestMapping("/manager/servicePricingModel")
@Transactional
public class CloudServicePricingModelCommandController {
	
	@Autowired
	CloudServicePricingModelAssembler assembler;
	
	@Autowired
	CloudServicePricingModelCommandService commandService;
	
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServicePricingModelResource> createCloudServicePricingModel(@Valid @RequestBody CloudServicePricingModelResource resource,BindingResult result) throws IllegalArgumentException {
		log.info("createCloudServicePricingModel() : START");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudServicePricingModelResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudServicePricingModelDetails pricingModelDetails=assembler.fromResource(resource);
		CreateServicePricingModelEvent request=new CreateServicePricingModelEvent()
												.setCloudServicePricingModelDetails(pricingModelDetails);
		
		if(request != null){
		commandService.createServicePricingModel(request);	
		}
		log.info("createCloudServicePricingModel() : END");
		return new ResponseEntity<CloudServicePricingModelResource>(HttpStatus.CREATED);
	}
	
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServicePricingModelResource> updateCloudServicePricingModel(@Valid @RequestBody CloudServicePricingModelResource resource,BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info("updateCloudServicePricingModel() : START");
		if(resource.getServicePricingModelId() == null){
			result.addError(new FieldError("resource", "servicePricingModelId", resource.getServicePricingModelId(), true, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudServicePricingModelResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudServicePricingModelDetails pricingModelDetails=assembler.fromResource(resource);
		CreateServicePricingModelEvent request=new CreateServicePricingModelEvent()
												.setCloudServicePricingModelDetails(pricingModelDetails);
		
		if(request != null){
		commandService.updateServicePricingModel(request);	
		}
		log.info("updateCloudServicePricingModel() : END");
		return new ResponseEntity<CloudServicePricingModelResource>(HttpStatus.OK);
	}

}
