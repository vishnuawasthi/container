package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.InventorySyncMQConfig.CREATE_INVENTORY_SYNC_ROUTING_KEY;
import static com.valuelabs.nephele.manager.configuration.InventorySyncMQConfig.EXCHANGE_NAME;
import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.manager.resource.CloudInventorySyncResources;

@Slf4j
@RestController
@RequestMapping(value = "/manager/rackspaceInventorySync")
public class CloudInventorySynchronisationQueryController {

	@Autowired
	RabbitTemplate rabbitTemplate;

	@RequestMapping(method = RequestMethod.GET)
	public HttpEntity<CloudInventorySyncResources> runInventorySynchronisation() {

		log.info("runInventorySynchronisation()  - START");

		try {

			rabbitTemplate.convertAndSend(EXCHANGE_NAME, CREATE_INVENTORY_SYNC_ROUTING_KEY, "InventorySync");

		} catch (Exception e) {
			log.error("Exception in Synchronisation:" + e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.info("runInventorySynchronisation()  - END");
		return new ResponseEntity<CloudInventorySyncResources>(HttpStatus.OK);
	}

}
