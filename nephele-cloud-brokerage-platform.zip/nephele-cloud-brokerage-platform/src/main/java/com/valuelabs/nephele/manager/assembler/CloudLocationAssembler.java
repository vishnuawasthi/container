package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.manager.controller.CloudLocationQueryController;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;

@Slf4j
@Service
public class CloudLocationAssembler extends ResourceAssemblerSupport<CloudLocationDetails,CloudLocationResource>{
	public CloudLocationAssembler() {
		super(CloudLocationQueryController.class, CloudLocationResource.class);
	}

	@Override
	public CloudLocationResource toResource(
			CloudLocationDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: "+entity);
		CloudLocationResource resource=instantiateResource(entity);
		resource=CloudLocationResource.builder()
										.name(entity.getName())
										.locationCode(entity.getLocationCode())
										.locationId(entity.getCloudLocationId())
										.status(entity.getStatus())
										//.cspResource(entity.getCspResource())
										.geographyCode(entity.getGeographyCode())
										.geographyName(entity.getGeographyName())
										.currency(entity.getCurrency())
										.serviceId(entity.getCloudServiceId())
										.serviceName(entity.getCloudServiceName())
										.build();
		
		resource.add(linkTo(methodOn(CloudLocationQueryController.class).readCloudLocation(entity.getCloudLocationId())).withSelfRel());
		
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudLocationDetails fromResource(CloudLocationResource resource){
		log.debug("fromResource: START:{} ",resource);
		CloudLocationDetails details=CloudLocationDetails.builder()
														.name(resource.getName())
														.locationCode(resource.getLocationCode())
														.cloudLocationId(resource.getLocationId())
														.status(resource.getStatus())
														//.cspResource(resource.getCspResource())
														.geographyCode(resource.getGeographyCode())
														.geographyName(resource.getGeographyName())
														.currency(resource.getCurrency())
														.cloudServiceId(resource.getServiceId())
														.cloudServiceName(resource.getServiceName())
														.build();
		log.debug("fromResouce: END");
		return details;

	}

}
