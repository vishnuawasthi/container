package com.valuelabs.nephele.marketplace.assembler;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.marketplace.controller.CloudProductQueryController;
import com.valuelabs.nephele.marketplace.resource.BundleResource;

@Service
@Slf4j
public class BundleAssembler extends ResourceAssemblerSupport<BundleDetails, BundleResource> {

  public BundleAssembler() {
	super(CloudProductQueryController.class, BundleResource.class);
  }

  @Override
  public BundleResource toResource(BundleDetails entity) {
	log.debug("toResource() - start");
	BundleResource resource = instantiateResource(entity);
	resource = BundleResource.builder()
                            		.bundleId(entity.getId())
                            		.description(entity.getDescription())
                            		.logoCode(entity.getLogoCode())
                            		.name(entity.getName())
                            		.status(entity.getStatus())
                            		.created(entity.getCreated())
                            		.updated(entity.getUpdated())
                            		.cloudProductList(entity.getCloudProductList())
                            		.externalProductList(entity.getExternalProductList())
                            		.build();
	// TO DO - Need to add the link
	log.debug("toResource() - end");
	return resource;
  }
  
  public BundleDetails fromResource(BundleResource resource) {
	log.debug("fromResource() - start");
	BundleDetails details = BundleDetails.builder()
                                  		.id(resource.getBundleId())
                                  		.name(resource.getName())
                                  		.description(resource.getDescription())
                                  		.logoCode(resource.getLogoCode())
                                  		.status(resource.getStatus())
                                  		.bundleCloudproducts(resource.getCloudproducts())
                                  		.bundleExternalproducts(resource.getExternalproducts())
                                  		.build();
	log.debug("fromResource() - end");
	return details;
  }
  

}
