package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceMgmtConfigDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudProductPriceMgmtConfigCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateProductPriceMgmtConfigEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadProductPriceMgmtConfigEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ValidationException;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudProductPriceMgmtConfigCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.CloudProductPriceMgmtAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudProductPriceMgmtConfigResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Transactional
@RequestMapping("/manager/priceManagementConfig")
public class CloudProductPriceMgmtConfigCommandController {

	
	@Autowired
	private CloudProductPriceMgmtAssembler assembler;

	@Autowired
	private CloudProductPriceMgmtConfigCommandService service;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductPriceMgmtConfigResource> createProductPriceMgmtConfig(
			@Valid @RequestBody CloudProductPriceMgmtConfigResource resource,
			BindingResult result) throws IllegalArgumentException {	
		log.info("createProductPriceMgmtConfig() : START");	
		CloudProductPriceMgmtConfigResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;		
		CloudProductPriceMgmtConfigCreatedEvent eventResponse = null;
		try{
			CloudProductPriceMgmtConfigDetails productPriceMgmtConfigDetails = assembler.fromResource(resource);
			CreateProductPriceMgmtConfigEvent request = new CreateProductPriceMgmtConfigEvent()
					.setProductPriceMgmtConfigDetails(productPriceMgmtConfigDetails);
			
			if (request != null) {			
				eventResponse = service.createProductPriceMgmtConfig(request);
				responseResource = CloudProductPriceMgmtConfigResource.builder().productPriceMgmtConfigId(eventResponse.getProductPriceMgmtConfigDetails().getProductPriceMgmtConfigId()).
						priceSheetName(eventResponse.getProductPriceMgmtConfigDetails().getPriceSheetName()).build();
			}
		}catch(NepheleException | ValidationException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);
			responseResource = CloudProductPriceMgmtConfigResource.builder().message(message).build();
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);
			responseResource = CloudProductPriceMgmtConfigResource.builder().message(message).build();
		}
		
		log.info("createProductPriceMgmtConfig() : END");
		return new ResponseEntity<CloudProductPriceMgmtConfigResource>(responseResource, statusCode);		
	}
	
	/**This method updates list of the price's of the CloudProductPlan entity by accepting http requests.
	 * @param resources
	 * @return
	 * @throws ResourceNotFoundException
	 * @throws IllegalArgumentException
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductPriceMgmtConfigResource> updateProductPriceMgmtConfig(@Valid @RequestBody CloudProductPriceMgmtConfigResource resource, BindingResult result)
			throws ResourceNotFoundException, IllegalArgumentException {
		log.info(" updateProductPriceMgmtConfig() : START");
		CloudProductPriceMgmtConfigResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		if(resource.getProductPriceMgmtConfigId() == null){
			result.addError(new FieldError("resource", "cloudLocationId is may not null", resource.getProductPriceMgmtConfigId(), true, null, null, null));
		}		
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		try{
			CloudProductPriceMgmtConfigDetails details = assembler.fromResource(resource);
			CreateProductPriceMgmtConfigEvent request = new CreateProductPriceMgmtConfigEvent().setProductPriceMgmtConfigDetails(details);
			if (request != null) {				
				service.upateProductPriceMgmtConfig(request);
				message = "PricemanagementConfigSheet updated successfully";
			}
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = CloudProductPriceMgmtConfigResource.builder().message(message).build();
		log.info("updateProductPriceMgmtConfig(): END");
		return new ResponseEntity<CloudProductPriceMgmtConfigResource>(responseResource, statusCode);	
	}
	
	@RequestMapping(value = "/schedule",method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductPriceMgmtConfigResource> scheduleProductPriceMgmtConfig( @RequestParam(value = "id", required=false) Long sheetId, 
																							@RequestParam(value = "eventName", required=false) String eventName,
																							@RequestParam(value = "comments", required=false) String comments,
																							@RequestParam(value = "customDate", required=false) String customDate)
			throws ResourceNotFoundException, IllegalArgumentException {
		
		log.info(" scheduleProductPriceMgmtConfig() : START" );
		CloudProductPriceMgmtConfigResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		try{
			ReadProductPriceMgmtConfigEvent request=new ReadProductPriceMgmtConfigEvent().setId(sheetId).setScheduleType(eventName).setComments(comments).setCustomDate(customDate);		
			if (request != null) {
				service.scheduleProductPriceMgmtConfig(request);
				message = "priceManagementsheet scheduled successfully";
			}
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = CloudProductPriceMgmtConfigResource.builder().message(message).build();
		log.info("scheduleProductPriceMgmtConfig(): END");
		return new ResponseEntity<CloudProductPriceMgmtConfigResource>(responseResource, statusCode);
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
	public HttpEntity<CloudProductPriceMgmtConfigResource> deleteProductPriceMgmtConfig( @PathVariable Long id) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("deleteProductPriceMgmtConfig() - START");
		if(id == null) {
			return new ResponseEntity<CloudProductPriceMgmtConfigResource>(HttpStatus.BAD_REQUEST);
		}
		ReadProductPriceMgmtConfigEvent request=new ReadProductPriceMgmtConfigEvent().setId(id);
		service.deleteProductPriceMgmtConfig(request);
		log.info("deleteProductPriceMgmtConfig() - END");
		return new ResponseEntity<CloudProductPriceMgmtConfigResource>(HttpStatus.OK);
	}
}
