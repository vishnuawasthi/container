package com.valuelabs.nephele.marketplace.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerActionDetails;
import com.valuelabs.nephele.marketplace.controller.CloudServerActionQueryController;
import com.valuelabs.nephele.marketplace.resource.CloudServerActionResource;

@Slf4j
@Service
public class CloudServerActionAssember extends ResourceAssemblerSupport<CloudServerActionDetails, CloudServerActionResource> {

	public CloudServerActionAssember() {
		super(CloudServerActionQueryController.class, CloudServerActionResource.class);
	}

	@Override
	public CloudServerActionResource toResource(CloudServerActionDetails entity) {
		log.debug("toResource() : START");
		CloudServerActionResource resource = instantiateResource(entity);
		resource = CloudServerActionResource.builder()
											.CloudServerActionId(entity.getId())
											.action(entity.getAction())
											.cloudServerId(entity.getCloudServerId())
											.status(entity.getStatus())
											.build();
		resource.add(linkTo(methodOn(CloudServerActionQueryController.class).readCloudServerAction(entity.getId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudServerActionDetails fromResource(CloudServerActionResource resource) {
		log.debug("fromResource() START:{}", resource);
		CloudServerActionDetails details = CloudServerActionDetails.builder()
																	.id(resource.getCloudServerActionId())
																	.action(resource.getAction())
																	.cloudServerId(resource.getCloudServerId())
																	.status(resource.getStatus())
																	.build();
		log.debug("fromResource() - END");
		return details;
	}
}
