package com.valuelabs.nephele.marketplace.resource;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerCompanyDetails;


@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
public class CloudInvoiceResource extends ResourceSupport {

  private Integer cloudInvoiceId;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private Date closedDate;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private Date createdDate;

  private String currency;

  @JsonFormat(pattern = "yyyy-MM-dd")
  private Date dueDate;

  private Double grossTotal;

  //private Boolean closed;
  private String status;

  private Double netTotal;

  private Double tax;

  private CloudResellerCompanyDetails cloudResellerCompany;


}
