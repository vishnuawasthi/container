package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import com.valuelabs.nephele.manager.controller.CloudResellerCompanyQueryController;
import com.valuelabs.nephele.manager.resource.CloudResellerCompanyResource;
import com.valuelabs.nephele.manager.resource.CloudResellerCompanyResources;

@Slf4j
@Service
public class CloudResellerCompanyAssembler
		extends
		ResourceAssemblerSupport<CloudResellerCompanyDetails, CloudResellerCompanyResource> {

	

	public CloudResellerCompanyAssembler() {
		super(CloudResellerCompanyQueryController.class, CloudResellerCompanyResource.class);
	}

	@Override
	public CloudResellerCompanyResource toResource(
			CloudResellerCompanyDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + entity);
		CloudResellerCompanyResource resource = instantiateResource(entity);

		resource = CloudResellerCompanyResource.builder()
				.resellerCompanyId(entity.getResellerCompanyId())
				//.distributorCompanyId(entity.getDistributerCompanyId())
				.resellerCompanyName(entity.getResellerCompanyName())
				.firstName(entity.getFirstName())
				.lastName(entity.getLastName())
				.externalResellerCompanyCode(entity.getExternalResellerCompanyCode())
				.addressLine1(entity.getAddressLine1())
				.addressLine2(entity.getAddressLine2())
				.city(entity.getCity())
				.state(entity.getState())
				.country(entity.getCountry())
				.email(entity.getEmail())
				.zipcode(entity.getZipCode())
				.created(entity.getCreated())
				.updated(entity.getUpdated())
				.isActive(entity.getIsActive())
				.resellerPremiumGroupName(entity.getResellerPremiumGroupName())
				.resellerPremiumGroupId(entity.getResellerPremiumGroupId())
				.creditCardToken(entity.getCreditCardToken())
				.accountHoldStatus(entity.getAccountHoldStatus())
				//.creditCardExpiryDate(entity.getCreditCardExpiryDate())
				//.distributerPriceGroupId(entity.getDistributerPriceGroupId())
				.creditCardExpiryYear(entity.getCreditCardExpiryYear())
				.creditCardExpiryMonth(entity.getCreditCardExpiryMonth())
				.abnNumber(entity.getAbnNumber())
				.terrCode(entity.getTerrCode())
				.creditCardType(entity.getCreditCardType())
				.salesPerson(entity.getSalesPerson())
				.countryCodeISO(entity.getCountryCodeISO())
				.countryCodeUN(entity.getCountryCodeUN())
				.build();
		resource.add(linkTo(
				methodOn(CloudResellerCompanyQueryController.class)
						.readCloudResellerCompany(
								entity.getResellerCompanyId()))
				.withSelfRel());
		log.debug("toResource() : resource : " + resource);
		log.debug("toResource() : resource Links: " + resource.getLinks());
		log.debug("toResource() : END");
		return resource;

	}

	public CloudResellerCompanyDetails fromResource(
			CloudResellerCompanyResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudResellerCompanyDetails details = CloudResellerCompanyDetails
				.builder()
				.resellerCompanyId(resource.getResellerCompanyId())
				.resellerCompanyName(resource.getResellerCompanyName())
				//.distributerCompanyId(resource.getDistributorCompanyId())
				.firstName(resource.getFirstName())
				.lastName(resource.getLastName())
				.externalResellerCompanyCode(resource.getExternalResellerCompanyCode())
				.addressLine1(resource.getAddressLine1())
				.addressLine2(resource.getAddressLine2())
				.city(resource.getCity())
				.state(resource.getState())
				.country(resource.getCountry())
				.email(resource.getEmail())
				.zipCode(resource.getZipcode())
				.created(resource.getCreated())
				.updated(resource.getUpdated())
				.isActive(resource.getIsActive())
				.accountHoldStatus(resource.getAccountHoldStatus())
				//.creditCardExpiryDate(resource.getCreditCardExpiryDate())
				.creditCardExpiryYear(resource.getCreditCardExpiryYear())
				.creditCardExpiryMonth(resource.getCreditCardExpiryMonth())
				.abnNumber(resource.getAbnNumber())
				.terrCode(resource.getTerrCode())
				.creditCardType(resource.getCreditCardType())
				.salesPerson(resource.getSalesPerson())
				//.distributerPriceGroupId(resource.getDistributerPriceGroupId())
				.resellerPremiumGroupId(resource.getResellerPremiumGroupId())
				.creditCardToken(resource.getCreditCardToken())
				.countryCodeISO(resource.getCountryCodeISO())
				.countryCodeUN(resource.getCountryCodeUN())
				.build();
		log.debug("fromResouce: END");
		return details;
	}
	
	public List<CloudResellerCompanyDetails> fromResource(
			CloudResellerCompanyResources resourceList) {
		log.debug("fromResource: START:{} ",resourceList);
		List<CloudResellerCompanyDetails> detailsList=new ArrayList<>();
		for(CloudResellerCompanyResource resource:NepheleValidationUtils.nullSafe(resourceList.getResellers())){
		CloudResellerCompanyDetails details = CloudResellerCompanyDetails
				.builder()
				.resellerCompanyId(resource.getResellerCompanyId())
				.resellerCompanyName(resource.getResellerCompanyName())
				//.distributerCompanyId(resource.getDistributorCompanyId())
				.firstName(resource.getFirstName())
				.lastName(resource.getLastName())
				.externalResellerCompanyCode(resource.getExternalResellerCompanyCode())
				.addressLine1(resource.getAddressLine1())
				.addressLine2(resource.getAddressLine2())
				.city(resource.getCity())
				.state(resource.getState())
				.country(resource.getCountry())
				.email(resource.getEmail())
				.zipCode(resource.getZipcode())
				.created(resource.getCreated())
				.updated(resource.getUpdated())
				.isActive(resource.getIsActive())
				.creditCardToken(resource.getCreditCardToken())
				//.distributerPriceGroupId(resource.getDistributerPriceGroupId())
				.accountHoldStatus(resource.getAccountHoldStatus())
				//.creditCardExpiryDate(resource.getCreditCardExpiryDate())
				.creditCardExpiryYear(resource.getCreditCardExpiryYear())
				.creditCardExpiryMonth(resource.getCreditCardExpiryMonth())
				.abnNumber(resource.getAbnNumber())
				.terrCode(resource.getTerrCode())
				.creditCardType(resource.getCreditCardType())
				.salesPerson(resource.getSalesPerson())
				.countryCodeISO(resource.getCountryCodeISO())
				.countryCodeUN(resource.getCountryCodeUN())
				.build();
		detailsList.add(details);
		}
		log.debug("fromResouce: END");
		return detailsList;
	}
}
