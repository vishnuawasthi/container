package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
//@Setter
//@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudLocationResource extends ResourceSupport{
	
	private Long locationId;
	private String name;
	private String locationCode;
	private String status;
	//private String cspResource;
	private Long serviceId; 
	private String serviceName;
	private String geographyCode;
	private String geographyName;
	private String currency;
	

}
