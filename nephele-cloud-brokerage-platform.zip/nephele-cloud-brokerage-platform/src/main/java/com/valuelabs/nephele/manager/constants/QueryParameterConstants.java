package com.valuelabs.nephele.manager.constants;

public class QueryParameterConstants {
  public static final String PRODUCT_ID = "productId";
  public static final String SERVER_ID = "serverId";
  public static final String SERVER_DESCRIPTION = "serverDescription";
  
  public static final String SERVICE_ID = "serviceId";
  public static final String LOCATION_ID = "locationId";
  public static final String LOCATION_NAME = "locationName";
  public static final String PRODUCT_NAME = "productName";
  public static final String IS_FEATURED = "isFeatured";
  public static final String HAS_RELATED_PRODUCTS = "hasRelatedProducts";
  
  public static final String OPERATING_SYSTEM_ID = "operatingSystemId";
  public static final String OPERATING_SYSTEM_NAME="operatingSystemName";
  
  public static final String STATUS = "status";
  public static final String CREATED_DATE = "createdDate";
  public static final String IS_ENABLED = "isEnabled";
  
  public static final String FIRST_NAME = "firstName";
  public static final String LAST_NAME = "lastName";
  public static final String EMAIL = "email";
  
   public static final String BRAND_NAME ="brandName";
   public static final String SERVICE_NAME ="serviceName";
   
   public static final String BUSINESS_RULE_NAME ="ruleName";
   
   public static final String UPDATED_DATE = "updatedDate";
  
  // Flags for making the search specific resource call
  
  public static final String FLAG_PLAN_OS = "plansOS";
  public static final String FLAG_PLAN_NAME = "planName";
  public static final String FLAG_PLAN_LOCATION = "planLocations";
  public static final String FLAG_PLAN_CATEGORIES = "plansCategories";
  public static final String FLAG_FLAVOUR_CATEGORIES = "flavorCategory";
  
  public static final String ROLE_ID="roleId";
  public static final String ROLE_NAME="roleName";
  
  public static final String GEOGRAPHY_CODE= "geographyCode";
  
  public static final String LOCATION_CODE= "locationCode";
  
  public static final String CLOUD_SERVICE_PROVIDER_ID= "providerId";
  public static final String SERVICE_CATEGORY_ID= "categoryId";
  public static final String EXTERNAL_RESELLER_CODE ="externalResellerCode";
  
  public static final String CUSTOMER_COMPANY_ID ="customerCompanyId";
  public static final String CLOUD_ACCOUNT_ID = "accountId";
  public static final String EXTERNAL_CUSTOMER_CODE ="externalCustomerCode";
  
  public static final String CATEGORY_ID ="categoryId";
  
  
	public static final String ORDER_ID = "orderId";
	public static final String ORDER_CODE = "orderCode";
	public static final String FROM_DATE = "fromDate";
	public static final String TO_DATE = "toDate";
	public static final String DESCRIPTION ="description";
	public static final String PURCHASE_ORDER_NUMBER ="purchaseOrderNumber";
	public static final String KEYWORD_FILTER ="keywordFilter";
	public static final String SERVICE_TYPE ="serviceType";
	
	public static final  String SORT_DIRECTION=  "sortDirection";
	public static final  String SORT_COLUMN_NAME ="sortColumnName";
	
	
  

}
