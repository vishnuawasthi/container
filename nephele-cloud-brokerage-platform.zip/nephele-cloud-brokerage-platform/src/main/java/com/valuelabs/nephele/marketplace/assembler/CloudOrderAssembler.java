package com.valuelabs.nephele.marketplace.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderDetails;
import com.valuelabs.nephele.marketplace.controller.CloudOrderQueryController;
import com.valuelabs.nephele.marketplace.resource.CloudOrderResource;

@Slf4j
@Service
public class CloudOrderAssembler extends
		ResourceAssemblerSupport<CloudOrderDetails, CloudOrderResource> {

	public CloudOrderAssembler() {
		super(CloudOrderQueryController.class, CloudOrderResource.class);
	}
	
	@Override
	public CloudOrderResource toResource(CloudOrderDetails details) {
		log.debug("toResource() : START");
		CloudOrderResource resource = instantiateResource(details);
		resource = CloudOrderResource.builder()
				.orderId(details.getOrderId())
				.status(details.getStatus())
				.customerId(details.getCustomerId())
				.productId(details.getProductId())
										.planId(details.getPlanId())
										.quantity(details.getQuantity())
										.locationId(details.getLocationId())
										.customerName(details.getCustomerName())
										.customerCompanyName(details.getCustomerCompanyName())
										.productName(details.getProductName())
										.creationDate(details.getCreationDate())
										.serviceName(details.getServiceName())
										.externalCustomerCode(details.getExternalCustomerCode())
										.purchaseOrderNumber(details.getPurchaseOrderNumber())
										.orderCode(details.getOrderCode())
										.accountId(details.getAccountId())
										.serviceType(details.getServiceType())
										.remarks(details.getRemarks())
										.build();
		resource.add(linkTo(
				methodOn(CloudOrderQueryController.class).readCloudOrder(
						details.getOrderId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudOrderDetails fromResource(CloudOrderResource resource) {
		log.debug("fromResource() START:{}",resource);
		CloudOrderDetails details = CloudOrderDetails.builder()
				.orderId(resource.getOrderId())
				.status(resource.getStatus())
				.customerId(resource.getCustomerId())
				.productId(resource.getProductId())
										.planId(resource.getPlanId())
										.quantity(resource.getQuantity())
										.locationId(resource.getLocationId())
										.orderCode(resource.getOrderCode())
										.serviceType(resource.getServiceType())
										.build();
		log.debug("fromResource() - END");
		return details;
	}
}
