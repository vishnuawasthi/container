package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceProviderDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServiceProviderEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ServiceProviderCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceProviderCommandService;
import com.valuelabs.nephele.manager.assembler.CloudServiceProviderAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudServiceProviderResource;

@Slf4j
@RestController
@RequestMapping(value = "/manager/serviceProvider")
@Transactional
public class CloudServiceProviderCommandController {

	@Autowired
	private CloudServiceProviderAssembler assembler;

	@Autowired
	private CloudServiceProviderCommandService service;


	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceProviderResource> createServiceProvider(
		  @Valid	@RequestBody CloudServiceProviderResource resource,BindingResult result) throws IllegalArgumentException{
		log.info("createServiceProvider() : START");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudServiceProviderResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudServiceProviderDetails serviceProviderDetails = assembler.fromResource(resource);
		CreateServiceProviderEvent request = new CreateServiceProviderEvent().setCloudServiceProviderDetails(serviceProviderDetails);
		ServiceProviderCreatedEvent serviceProviderCreatedEvent = null;
		if (request != null) {
			serviceProviderCreatedEvent = service.createServiceProvider(request);
		}
		CloudServiceProviderResource responseResource = CloudServiceProviderResource.builder().serviceProviderId(serviceProviderCreatedEvent.getCloudServiceProviderDetails().getServiceProviderId()).build();
		log.info("createServiceProvider() : END");
		return new ResponseEntity<CloudServiceProviderResource>(responseResource, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceProviderResource> updateServiceProvider(
		 @Valid	@RequestBody CloudServiceProviderResource resource,BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info("updateServiceProvider() : START");
		if(resource.getServiceProviderId() ==null) {
			result.addError(new FieldError("resource", "serviceProviderId", resource.getServiceProviderId(),false, null, null, null));
		}
		if(result.hasErrors()) {
			return new ResponseEntity<CloudServiceProviderResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudServiceProviderDetails serviceProviderDetails = assembler
				.fromResource(resource);
		
		CreateServiceProviderEvent request = new CreateServiceProviderEvent()
				.setCloudServiceProviderDetails(serviceProviderDetails);

		if (request != null) {
			service.updateServiceProvider(request);
		}

		log.info("updateServiceProvider() : END");
		return new ResponseEntity<CloudServiceProviderResource>(HttpStatus.OK);
	}
}
