package com.valuelabs.nephele.marketplace.controller;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudProductEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudProductResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudProductCommandService;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.CloudProductAssembler;



@Slf4j
@RestController
@RequestMapping(value = "/")
public class CloudProductCommandController {
	/*
	@Autowired
	private CloudServiceResourceAssembler assembler;*/
	
	@Autowired
	private CloudProductCommandService service;
	
	@Autowired
	private CloudProductAssembler assembler;
	
	@RequestMapping(value = "marketplace/cloudProduct/loadProducts/{serviceName}", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	public void loadProducts(@PathVariable String serviceName) {
		log.info("loadProducts() : START");
		service.loadProducts(serviceName);
		log.info("loadProducts() : END");
	}
	
	
	@RequestMapping(value = "marketplace/cloudProduct", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductResource> updateCloudProduct( @Valid	@RequestBody CloudProductResource resource, BindingResult result) throws ResourceNotFoundException,IllegalArgumentException{
		log.info("updateCloudProduct() : START");
		
		if(resource.getProductId() ==null) {
			result.addError(new FieldError("resource", "cloudProductId", resource.getProductId(),false, null, null, null));
		}
		if(result.hasErrors()) {
			return new ResponseEntity<CloudProductResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		
		CloudProductDetails cloudProductDetails=assembler.fromResource(resource);
		CreateCloudProductEvent request=new CreateCloudProductEvent()
												.setCloudProductDetails(cloudProductDetails);
		if(request != null){
			service.updateCloudProduct(request);
		}
		log.info("updateServiceProvider() : END");
		return new ResponseEntity<CloudProductResource>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/cloudProduct", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductResource> updateCloudProductForManager( @Valid	@RequestBody CloudProductResource resource, BindingResult result) throws ResourceNotFoundException,IllegalArgumentException{
		log.info("updateCloudProduct() : START");
		
		if(resource.getProductId() ==null) {
			result.addError(new FieldError("resource", "cloudProductId", resource.getProductId(),false, null, null, null));
		}
		if(result.hasErrors()) {
			return new ResponseEntity<CloudProductResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		
		CloudProductDetails cloudProductDetails=assembler.fromResource(resource);
		CreateCloudProductEvent request=new CreateCloudProductEvent()
												.setCloudProductDetails(cloudProductDetails);
		if(request != null){
			service.updateCloudProduct(request);
		}
		log.info("updateServiceProvider() : END");
		return new ResponseEntity<CloudProductResource>(HttpStatus.OK);
	}
	

}
