package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode(callSuper=false)
@Setter
@Getter
@Builder
@Accessors(chain=true)
@JsonInclude(Include.NON_DEFAULT)
public class PlaceOrderResource extends ResourceSupport {
	
	private Long customerId;
	
	private String externalCustomerCompanyCode;
	
	private Long resellerCompanyId;
	
	private String externalResellerCompanyCode;
	
	private String resellerEmail;
	
	//private Integer productId;
	
	private Long planId;
	
	private Integer quantity;
	
	private String purchaseOrderNumber;
	
	//private OrderPlanResource plan;
		
	private Long orderId;
	
	private Long serviceId;
	
	private String integrationCode;
	
	private String ruleValue;

}
