package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.event.CreateExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudProductResource;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.BundleExternalProductCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.ExternalProductCommandService;
import com.valuelabs.nephele.manager.assembler.ExternalProductsAssembler;
import com.valuelabs.nephele.manager.resource.ExternalProductResource;
import com.valuelabs.nephele.marketplace.resource.BundleResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController

public class BundleExternalProductCommandController {
	
	@Autowired
	private BundleExternalProductCommandService service;
	
	@Autowired
	private ExternalProductCommandService externalProductCommandService;
	
	@Autowired
	private ExternalProductsAssembler externalProductsAssembler;
	
	@RequestMapping(value="/manager/bundleExternalProduct/{id}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<BundleResource> deleteBundleExternalProduct(@PathVariable Long id){
		log.info("deleteBundleCloudProduct() : START");

		if(id != null){
			service.deleteBundleExternalProduct(id);
		}		
		
		log.info("deleteBundleCloudProduct() : START");
		return new ResponseEntity<BundleResource>(HttpStatus.OK);
	}
	@RequestMapping(value="/manager/bundleExternalProduct",method = RequestMethod.PUT , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductResource> updateBundleExternalProduct(@RequestBody ExternalProductResource  resource,BindingResult result){
		log.info("updateBundleExternalProduct() : start");
		if (resource.getExternalProductId() == null) {
			result.addError(new FieldError("resource",
					"productId", resource.getExternalProductId(), false, null, null,"externalProductId should not be empty"));
		}
		if (result.hasErrors()) {
			List <String> errorMessageList  = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " "+ fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}	
		
		CreateExternalProductEvent request = new CreateExternalProductEvent();
		request.setExternalProductDetails(externalProductsAssembler.fromResource(resource));
		
		if(request!=null){
			externalProductCommandService.updateExternalProduct(request);
		}
		
		log.info("updateBundleExternalProduct() : end");
		return new ResponseEntity<CloudProductResource>(HttpStatus.OK);
	}

}
