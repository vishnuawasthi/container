package com.valuelabs.nephele.manager.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadExternalProductsEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.service.ExternalProductsQueryService;
import com.valuelabs.nephele.manager.assembler.ExternalProductsAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.ExternalProductResource;
import com.valuelabs.nephele.marketplace.resource.BundleResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/")
public class ExternalCloudProductQueryController {
	
	@Autowired
	private ExternalProductsQueryService extProductQueryService;
	
	@Autowired
	private ExternalProductsAssembler extProductsAssembler;
	
	@RequestMapping(value="manager/externalProducts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<ExternalProductResource>> readExternalProudctsForManager(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<ExternalProductDetails> pagedAssembler) {
		
		log.info("readExternalProudctsForManager() START");		
		ReadExternalProductsEvent request=new ReadExternalProductsEvent().setPageable(pageable);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<ExternalProductDetails> event=extProductQueryService.readExternalProducts(request);

		Page<ExternalProductDetails> page=event.getPage();
		PagedResources<ExternalProductResource> pagedResources = pagedAssembler.toResource(page, extProductsAssembler);
		log.info("readExternalProudctsForManager() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/manager/externalProducts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ExternalProductResource> readExternalProudctByIdForManager(@PathVariable Long externalProductId){
		log.info("readCloudBundleByIdForManager() - start");
		EntityReadEvent<ExternalProductDetails> event=null;
		if (externalProductId != null) {
			ReadExternalProductEvent request=new ReadExternalProductEvent().setExternalProductId(externalProductId);
			event = extProductQueryService.readExternalProduct(request);
		}
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		ExternalProductDetails entity=event.getEntity();
		log.info("readCloudBundleByIdForManager() - end");
		return new ResponseEntity<>(extProductsAssembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(value="manager/externalProducts/searchByProductName", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ExternalProductResource> readExternalProudctByProductNameForManager(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@RequestParam(value = "productName",required=true) String productName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<BundleDetails> pagedAssembler) {		
		log.info("readExternalProudctByProductNameForManager() START");		
		EntityReadEvent<ExternalProductDetails> event=null;
		if (productName != null) {
			ReadExternalProductEvent request=new ReadExternalProductEvent().setProductName(productName);
			 request.setSortDirection(sortDirection);
			 request.setSortColumnName(sortColumnName);
			try{
				event = extProductQueryService.readExternalProductByProductName(request);
			}catch(ResourceNotFoundException ex){
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		}
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		ExternalProductDetails entity=event.getEntity();
		log.info("readCloudBundleByIdForManager() - end");
		return new ResponseEntity<>(extProductsAssembler.toResource(entity), HttpStatus.OK);
	}

}
