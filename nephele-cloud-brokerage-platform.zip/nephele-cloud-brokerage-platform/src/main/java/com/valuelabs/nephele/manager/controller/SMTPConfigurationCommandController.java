package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.SMTPConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateSMTPConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.SMTPConfigurationCommandService;
import com.valuelabs.nephele.manager.assembler.SMTPConfigurationResourceAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.SMTPConfigurationResource;

@Slf4j
@RestController
@RequestMapping("/manager/smtpConfiguration")
public class SMTPConfigurationCommandController {

  @Autowired
  private SMTPConfigurationResourceAssembler assembler;

  @Autowired
  private SMTPConfigurationCommandService service;

  @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<SMTPConfigurationResource> createSMTPConfiguration(
	  @Valid @RequestBody SMTPConfigurationResource resource, BindingResult result) throws IllegalArgumentException {
	log.info("createSMTPConfiguration() : start");
	if (result.hasErrors()) {
	  return new ResponseEntity<SMTPConfigurationResource>(resource, HttpStatus.BAD_REQUEST);
	}
	SMTPConfigurationDetails smtpConfigurationDetails = assembler.fromResource(resource);
	CreateSMTPConfigurationEvent request = new CreateSMTPConfigurationEvent()
	    .setSmtpConfigurationDetails(smtpConfigurationDetails);
	if (request != null) {
	  service.createSMTPConfiguration(request);
	}
	log.info("createSMTPConfiguration() : end");
	return new ResponseEntity<SMTPConfigurationResource>(HttpStatus.CREATED);
  }

  @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<SMTPConfigurationResource> updateSMTPConfiguration(
	  @Valid @RequestBody SMTPConfigurationResource resource, BindingResult result) throws IllegalArgumentException,
	  ResourceNotFoundException {
	log.info("updateSMTPConfiguration() : start");
	if (resource.getSmptConfigurationId() == null) {
	  result.addError(new FieldError("resource", "smptConfigurationId", resource.getSmptConfigurationId(), false, null,null, null));
	}
	if (result.hasErrors()) {
	  	List<String> errorMessageList = new ArrayList<String>();
		List<FieldError> errors = result.getFieldErrors();
		for (FieldError fieldError : errors) {
			errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
		}
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
		return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
	}
	SMTPConfigurationDetails smtpConfigurationDetails = assembler.fromResource(resource);
	CreateSMTPConfigurationEvent request = new CreateSMTPConfigurationEvent()
	    .setSmtpConfigurationDetails(smtpConfigurationDetails);
	if (request != null) {
	  service.updateSMTPConfiguration(request);
	}
	log.info("updateSMTPConfiguration() : start");
	return new ResponseEntity<SMTPConfigurationResource>(HttpStatus.OK);
  }

}
