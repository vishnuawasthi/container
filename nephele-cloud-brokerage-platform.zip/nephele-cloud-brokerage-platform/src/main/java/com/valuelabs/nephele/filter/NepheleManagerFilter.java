package com.valuelabs.nephele.filter;

import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.API_KEY;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.AUTHORIZATION;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.MANAGER;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.MARKETPLACE;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.OPTIONS;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_CUSTOMER_KEY;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_MARKETPLACE_SECRET_KEY;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_RESELLER_KEY;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.NoResultException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.filter.DelegatingFilterProxy;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudDistributorUser;
import com.valuelabs.nephele.admin.data.entity.CloudManagerAppPermission;
import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;
import com.valuelabs.nephele.admin.data.repository.CloudDistributorUserRepository;
import com.valuelabs.nephele.admin.data.repository.CloudManagerAppPermissionRepository;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerCompanyQueryService;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCustomerCompanyQueryService;
import com.valuelabs.nephele.admin.rest.lib.util.InvoiceUtility;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.manager.security.configuration.CustomAuthenticationProvider;
import com.valuelabs.nephele.manager.security.service.CloudUserDetails;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Srikanth Nagaboina, ValueLabs
 */

@Slf4j
public class NepheleManagerFilter extends DelegatingFilterProxy {

  boolean exceptionFlag = true;
  boolean isValid = false;
  String apiKey = null;

  CustomAuthenticationProvider provider;

  private CloudDistributorUserRepository userRepository;

  private CloudUserService userService;

  private CloudResellerCompanyQueryService cloudResellerCompanyQueryService;

  private CloudCustomerCompanyQueryService cloudCustomerCompanyQueryService;
  
  private Environment environment;
  
  private CloudManagerAppPermissionRepository permissionRepository;
  
  private NepheleUtils nepheleUtils;
  
  private String marketplaceSecretKey;

  public NepheleManagerFilter(CustomAuthenticationProvider provider, CloudDistributorUserRepository userRepository,
                              CloudResellerCompanyQueryService cloudResellerCompanyQueryService,
                              CloudCustomerCompanyQueryService cloudCustomerCompanyQueryService, CloudUserService userService, CloudManagerAppPermissionRepository permissionRepository, 
                              Environment environment, NepheleUtils nepheleUtils,String marketplaceSecretKey) {
    this.provider = provider;
    this.userRepository = userRepository;
    this.cloudResellerCompanyQueryService = cloudResellerCompanyQueryService;
    this.cloudCustomerCompanyQueryService = cloudCustomerCompanyQueryService;
    this.userService = userService;
    this.environment = environment;
    this.permissionRepository = permissionRepository;
    this.nepheleUtils = nepheleUtils;
    this.marketplaceSecretKey=marketplaceSecretKey;
  }


  @Override
  public void doFilter(ServletRequest request, ServletResponse response,
                       FilterChain filterChain) throws ServletException, IOException {

    HttpServletRequest httpServletRequest = (HttpServletRequest) request;
    HttpServletResponse httpServletResponse = (HttpServletResponse) response;
    httpServletResponse.setHeader("Access-Control-Allow-Origin", "*");
    httpServletResponse.setHeader("Access-Control-Allow-Methods", "POST, GET,PUT, OPTIONS, DELETE");
    httpServletResponse.setHeader("Access-Control-Max-Age", "3600");
    httpServletResponse.setHeader("Access-Control-Allow-Credentials", "true");
    httpServletResponse.setHeader("Access-Control-Allow-Headers", API_KEY + "," + AUTHORIZATION + ",content-type,x-requested-with");

    String serviceType = null;
    isValid = false;
    if (!StringUtils.isEmpty(httpServletRequest.getRequestURL().toString())) {
      String[] urlsArray = httpServletRequest.getRequestURL().toString().split("/");
      if (urlsArray.length > 3) {
        serviceType = urlsArray[3];
      }
    }
    if (!StringUtils.isEmpty(serviceType) && (MANAGER.equals(serviceType) /*|| GLOBAL_LOGOUT.equals(serviceType)*/)
        && !httpServletRequest.getMethod().equalsIgnoreCase(OPTIONS))
      validateApiKey(httpServletRequest, httpServletResponse);
    else if (!StringUtils.isEmpty(serviceType) && MARKETPLACE.equals(serviceType))
      validateResellerAuthentication(httpServletRequest, httpServletResponse);
    else {
      isValid = true;
      exceptionFlag = false;
    }
    if (isValid && !exceptionFlag) {
      filterChain.doFilter(request, response);
    }
  }

  private boolean isUserAuthenticated(HttpServletRequest request, HttpServletResponse response, String authString) {
    boolean returnVal = false;
    // Header is in the format "Basic 5tyc0uiDat4"
    // We need to extract data before decoding it back to original string
    String[] authParts = authString.split("\\s+");
    String authInfo = authParts[1];
    // Decode the data back to original string
    try {
      byte[] bytes = Base64.decodeBase64(authInfo);
      String decodedAuth = new String(bytes);
      String[] userCredentials = decodedAuth.split("[:]");
      //if(validateUserPermissions(request,response,distributorUser)){
      log.debug("From pre User Authentication while supplying username and password fields: ", InvoiceUtility.getCurrentDateAndTime());
      CloudDistributorUser distributorUser = userRepository.findUserByUserName(userCredentials[0]);
      if (null != distributorUser && null != userCredentials[1] && userCredentials[1].equals(nepheleUtils.decrypt(distributorUser.getPassword()))) {
    	  if(validateUserPermissions(request,response,distributorUser)){
    		  	CloudUserDetails details = new CloudUserDetails(distributorUser);
		        User user = new User(details.getEmail(), details.getPassword(), details.getAuthorities());
		        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(user, details.getPassword(), details.getAuthorities());
		        authRequest.setDetails(user);
		        Authentication authentication = provider.authenticate(authRequest);
		        SecurityContextHolder.getContext().setAuthentication(authentication);
		        if (null != SecurityContextHolder.getContext().getAuthentication().getPrincipal()) {
		          isValid = true;
		          exceptionFlag = false;
		          returnVal = true;
		        }
    	  }else{
    		  response.setStatus(HttpStatus.SC_FORBIDDEN);
    	  }
        
      }else
          response.setStatus(HttpStatus.SC_UNAUTHORIZED);
      log.debug("From post User Authentication while supplying username and password fields: ", InvoiceUtility.getCurrentDateAndTime());
    } catch (Exception e) {
      log.debug("Result not found with given Basic authentication details ::::::: " + authString + ":" + e);
    }
    return returnVal;
  }

  private boolean validateResellerAuthentication(HttpServletRequest request, HttpServletResponse response) {
    boolean returnVal = false;
    String resellerKey = request.getHeader(X_RESELLER_KEY);
    String customerKey = request.getHeader(X_CUSTOMER_KEY);
    String secretKey= request.getHeader(X_MARKETPLACE_SECRET_KEY);
    try {
      CloudResellerCompany resellerCompany  =null;
      if(!StringUtils.isEmpty(resellerKey)) {
        log.debug("From before X_RESELLER_KEY validation for marketplace API: ", InvoiceUtility.getCurrentDateAndTime());
        resellerCompany = cloudResellerCompanyQueryService.findByExternalResellerCode(resellerKey);
        log.debug("From after X_RESELLER_KEY validation for marketplace API: ", InvoiceUtility.getCurrentDateAndTime());
      }
      if (null != resellerCompany    && validateMarketPlaceSecretKey(secretKey)) {
        final UserDetails principal = new User(resellerCompany.getResellerCompanyCode(), resellerCompany.getResellerCompanyName(), getAuthorities());
        Authentication auth = new UsernamePasswordAuthenticationToken(principal, resellerCompany.getResellerCompanyCode(), getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(auth);
        if (null != SecurityContextHolder.getContext().getAuthentication().getPrincipal()) {
          returnVal = true;
          isValid = true;
          exceptionFlag = false;
        } else
          response.setStatus(HttpStatus.SC_UNAUTHORIZED);
      } else
        response.setStatus(HttpStatus.SC_UNAUTHORIZED);
      try {
        if (null != customerKey) {

          log.debug("From before X_CUSTOMER_KEY validation for marketplace API: ", InvoiceUtility.getCurrentDateAndTime());
          CloudCustomerCompany customerCompany = cloudCustomerCompanyQueryService.findByExternalCompanyCode(customerKey);
          log.debug("From after X_CUSTOMER_KEY validation for marketplace API: ", InvoiceUtility.getCurrentDateAndTime());
          if (null != customerCompany)
            request.setAttribute("X-CUSTOMER-ID", customerCompany.getId());
        }
      } catch (Exception e) {
        log.debug("Result not found with given X-CUSTOMER-KEY  :::::::" + e);
      }
    } catch (NoResultException exception) {
      response.setStatus(HttpStatus.SC_UNAUTHORIZED);
      log.debug("Result not found with given X-RESELLER-KEY or X-CUSTOMER-KEY  :::::::" + exception);
    } catch (Exception exception) {
    	 response.setStatus(HttpStatus.SC_UNAUTHORIZED);
         log.debug("Result not found with given X-RESELLER-KEY or X-CUSTOMER-KEY  :::::::" + exception);
	}
    return returnVal;
  }

  private boolean validateApiKey(HttpServletRequest request, HttpServletResponse response) {
    boolean returnVal = false;
    apiKey = request.getHeader(API_KEY);
    String authorizationKey = request.getHeader(AUTHORIZATION);
    if (!StringUtils.isEmpty(apiKey)) {
      try {
        String decodedApiKey = nepheleUtils.decrypt(apiKey);
        if (null != decodedApiKey) {
          log.debug("From pre User Authentication while supplying API_KEY for manager API: ", InvoiceUtility.getCurrentDateAndTime());
          CloudDistributorUser distributorUser = userRepository.findUserByApiKey(decodedApiKey);
          //Commented because session expire logic is handling in the UI itself.
          if (null != distributorUser /*&& null != distributorUser.getApiKeyExpireTime() && distributorUser.getApiKeyExpireTime().after(new Date())*/) {
        	  if(validateUserPermissions(request,response,distributorUser)){
        		  CloudUserDetails details = new CloudUserDetails(distributorUser);
                  User user = new User(details.getEmail(), details.getPassword(), details.getAuthorities());
                  UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(user, details.getPassword(), details.getAuthorities());
                  authRequest.setDetails(user);
                  Authentication authentication = provider.authenticate(authRequest);
                  SecurityContextHolder.getContext().setAuthentication(authentication);
                  if (null != SecurityContextHolder.getContext().getAuthentication().getPrincipal()) {
                    //Commented because session expire logic is handling in the UI itself.
                    //userService.updateApiKeyExpireTime(distributorUser);
                    returnVal = true;
                    isValid = true;
                    exceptionFlag = false;
                  } else
                    response.setStatus(HttpStatus.SC_UNAUTHORIZED);
        	  } else{
        		  response.setStatus(HttpStatus.SC_FORBIDDEN);
        	  }
          } else
            response.setStatus(HttpStatus.SC_UNAUTHORIZED);
          
        } else
          response.setStatus(HttpStatus.SC_UNAUTHORIZED);
      } catch (NoResultException exception) {
        response.setStatus(HttpStatus.SC_UNAUTHORIZED);
        log.debug("Result not found with given apiKey ::::::: " + API_KEY + ":" + exception);
      } catch (Exception e) {
        response.setStatus(HttpStatus.SC_UNAUTHORIZED);
        log.debug("Result not found with given apiKey ::::::: " + API_KEY + ":" + e);
      }
    } else if (!StringUtils.isEmpty(authorizationKey)) {
        isUserAuthenticated(request, response, authorizationKey);
     } else
       response.setStatus(HttpStatus.SC_UNAUTHORIZED);
    log.debug("From post User Authentication while supplying API_KEY for manager API: ", InvoiceUtility.getCurrentDateAndTime());
     return returnVal;
  }
  
  private boolean validateUserPermissions(HttpServletRequest request,HttpServletResponse response, CloudDistributorUser distributorUser) {
	  Boolean validUser = false;
	  Long roleId = distributorUser.getUserRole().getId();
	  if(!StringUtils.isEmpty(roleId)){
		  String uriPath = request.getRequestURL().toString();
		  log.debug("In filter the uri is " + uriPath);
		  String[] temp = uriPath.split("/");
		  StringBuffer baseUrl = new StringBuffer();
		  for (int i = 3; i < 5; i++) {
			  baseUrl.append(temp[i]);
			  baseUrl.append("/");
		  }
		  String account = environment.getProperty(baseUrl.toString());
		  Map<String, CloudManagerAppPermission> permissionMap = getCloudManagerAppPermissionMap(distributorUser);
		  if(!StringUtils.isEmpty(account) && !CollectionUtils.isEmpty(permissionMap) && permissionMap.containsKey(account)){
			  CloudManagerAppPermission permission = permissionMap.get(account);
			  if((request.getMethod().equals(RequestMethod.POST.toString()) || request.getMethod().equals(RequestMethod.PUT.toString()) || request.getMethod().equals(RequestMethod.DELETE.toString())) && permission.getIsWrite())
					validUser=true;  
			   else if(request.getMethod().equals(RequestMethod.GET.toString()) && permission.getIsRead())
					validUser=true;  
		  }
	  }
	return validUser;
  }
  
  private boolean  validateMarketPlaceSecretKey(String secretKey) {
	if(!StringUtils.isEmpty(secretKey)) {
	  return marketplaceSecretKey.equals(secretKey);
	}
	return false;
  }
  
  private Map<String, CloudManagerAppPermission> getCloudManagerAppPermissionMap(CloudDistributorUser distributorUser){
	  Map<String, CloudManagerAppPermission> permissionMap = new HashMap<>();
	  if(null != distributorUser && null != distributorUser.getUserRole() && !CollectionUtils.isEmpty(distributorUser.getUserRole().getCloudManagerAppPermission())) {
		  for(CloudManagerAppPermission permission : distributorUser.getUserRole().getCloudManagerAppPermission()) {
			  if(null != permission.getCloudManagerAppAccount())
				  permissionMap.put(permission.getCloudManagerAppAccount().getName(), permission);
		  }
	  }
	  return permissionMap;
  }

  public Collection<? extends GrantedAuthority> getAuthorities() {
    Collection<GrantedAuthority> authorities = new ArrayList<>();
    SimpleGrantedAuthority authority = new SimpleGrantedAuthority("USER");
    authorities.add(authority);
    return authorities;
  }

}
