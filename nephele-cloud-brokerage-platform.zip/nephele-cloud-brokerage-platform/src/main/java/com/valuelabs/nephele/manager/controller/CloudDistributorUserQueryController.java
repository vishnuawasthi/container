package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorUserDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudDistributorUserEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudDistributorUsersEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudDistributorUserQueryService;
import com.valuelabs.nephele.manager.assembler.CloudDistributorUserAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudDistributorUserResource;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/manager/cloudDistributorUser")
@Transactional
public class CloudDistributorUserQueryController {

	@Autowired
	private CloudDistributorUserQueryService service;

	@Autowired
	private CloudDistributorUserAssembler assembler;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudDistributorUserResource> readCloudDistributorUser(@PathVariable Long id) {
		log.info("readCloudDistributorUser() - start");
		ReadCloudDistributorUserEvent request = new ReadCloudDistributorUserEvent().setId(id);
		EntityReadEvent<CloudDistributorUserDetails> event = service.readCloudDistributorUser(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudDistributorUserDetails entity = event.getEntity();
		log.info("readCloudDistributorUser() - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudDistributorUserResource>> readCloudDistributorUsers(
        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudDistributorUserDetails> pagedAssembler) {
		log.info("readCloudDistributorUsers()  - start");
		ReadCloudDistributorUsersEvent request = new ReadCloudDistributorUsersEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudDistributorUserDetails> event = service.readCloudDistributorUsers(request);
		Page<CloudDistributorUserDetails> page = event.getPage();
		PagedResources<CloudDistributorUserResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudDistributorUsers()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/user",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<PagedResources<CloudDistributorUserResource>> readCloudDistributorUsers(
		@RequestParam(value=QueryParameterConstants.FIRST_NAME,required=false) final String firstName ,
		@RequestParam(value=QueryParameterConstants.LAST_NAME,required=false) final String lastName ,
		@RequestParam(value=QueryParameterConstants.EMAIL,required=false) final String email ,
		@RequestParam(value=QueryParameterConstants.IS_ENABLED,required=false) final Boolean isEnabled ,
		@RequestParam(value=QueryParameterConstants.CREATED_DATE,required=false) final String createdDate ,
		@RequestParam(value=QueryParameterConstants.UPDATED_DATE,required=false) final String updatedDate ,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
	    @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
		PagedResourcesAssembler<CloudDistributorUserDetails> pagedAssembler) throws Exception{
		
		log.info("readCloudDistributorUsersFiltering()  - start");
		ReadCloudDistributorUsersEvent request = new ReadCloudDistributorUsersEvent().setPageable(pageable).setFirstName(firstName).setLastName(lastName)
				.setEmail(email).setIsEnabled(isEnabled).setCreatedDate(createdDate).setUpdatedDate(updatedDate);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudDistributorUserDetails> event = service.readCloudDistributorUsersFilter(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		Page<CloudDistributorUserDetails> page = event.getPage();
		PagedResources<CloudDistributorUserResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudDistributorUsersFiltering()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
		
	}
	
}
