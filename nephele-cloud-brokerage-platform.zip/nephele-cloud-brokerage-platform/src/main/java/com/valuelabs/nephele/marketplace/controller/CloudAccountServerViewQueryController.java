package com.valuelabs.nephele.marketplace.controller;

import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_CUSTOMER_KEY;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_RESELLER_KEY;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountServerViewDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadAccountServerViewEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServersEvent;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudProductPlanQueryService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAccountServerViewQueryService;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.marketplace.assembler.CloudAccountServerViewAssembler;
import com.valuelabs.nephele.marketplace.resource.CloudAccountServerViewResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/marketplace")
public class CloudAccountServerViewQueryController {

	@Autowired
	private CloudAccountServerViewAssembler assembler;

	@Autowired
	private CloudAccountServerViewQueryService service;
	
	@Autowired
	CloudProductPlanQueryService productPlanQueryService;

	@RequestMapping(value = "/consolidateView", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudAccountServerViewResource>> readServerAccountConsolidateView(
			@RequestHeader(value = X_RESELLER_KEY, required=true) String externalResellerCode,
			@RequestHeader(value = X_CUSTOMER_KEY, required=false) String externalCustomerCode,
			@RequestParam(value=QueryParameterConstants.STATUS,required=false) String status,
			@RequestParam(value=QueryParameterConstants.FROM_DATE,required=false) @DateTimeFormat(pattern="yyyy-MM-dd") Date fromDate,
			@RequestParam(value=QueryParameterConstants.TO_DATE,required=false) @DateTimeFormat(pattern="yyyy-MM-dd") Date toDate,
			@RequestParam(value=QueryParameterConstants.ORDER_ID,required=false) Long orderId,
			@RequestParam(value=QueryParameterConstants.ORDER_CODE,required=false) String orderCode,
			@RequestParam(value=QueryParameterConstants.DESCRIPTION,required=false) String description,
			@RequestParam(value=QueryParameterConstants.SERVICE_CATEGORY_ID,required=false) Long categoryId,
			@RequestParam(value=QueryParameterConstants.CLOUD_SERVICE_PROVIDER_ID,required=false) Long providerId,
			@RequestParam(value=QueryParameterConstants.PURCHASE_ORDER_NUMBER,required=false) String purchaseOrderNumber,
			@RequestParam(value=QueryParameterConstants.KEYWORD_FILTER,required=false) String keywordFilter,
            @RequestParam(value = QueryParameterConstants.SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = QueryParameterConstants.SORT_DIRECTION, required = false) String sortDirection,

			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, 
			PagedResourcesAssembler<CloudAccountServerViewDetails> pagedAssembler) {
		log.info("readServerAccountConsolidateView() -START");
		if(!StringUtils.isEmpty(fromDate)) {
			List<String> errorMessageList = new ArrayList<String>();
			if (StringUtils.isEmpty(toDate)) {
					errorMessageList.add("toDate  should not be empty ");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}
			if (fromDate.compareTo(toDate) > 0) {
					errorMessageList.add("fromDate should not be greater than toDate");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}
		}
		ReadAccountServerViewEvent request = new ReadAccountServerViewEvent().setExternalResellerCode(externalResellerCode)
														 .setExternalCustomerCode(externalCustomerCode)
														 .setStatus(status)
														 .setFromDate(fromDate)
														 .setToDate(toDate)
														 .setOrderId(orderId)
														 .setOrderCode(orderCode)
														 .setDescription(description)
														 .setProviderId(providerId)
														 .setCategoryId(categoryId)
														 .setPurchaseOrderNumber(purchaseOrderNumber)
														 .setKeywordFilter(keywordFilter)
														 .setSortColumnName(sortColumnName)
														 .setSortDirection(sortDirection)
														 .setPageable(pageable);
		PageReadEvent<CloudAccountServerViewDetails> event = service.readAccountServerViewByFilter(request);
		Page<CloudAccountServerViewDetails> page = event.getPage();
		PagedResources<CloudAccountServerViewResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServerAccountConsolidateView() -END");
		
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/consolidateView/summary/customer", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Long>> readServerSummaryByCustomer(
		    @RequestHeader(value = NepheleConstants.X_CUSTOMER_KEY, required=true) String externalCustomerCode,
			@RequestParam(value = QueryParameterConstants.SERVICE_ID, required=false) Long serviceId,
			@RequestParam(value = QueryParameterConstants.CATEGORY_ID, required=false) Long categoryId,
			@RequestParam(value=QueryParameterConstants.STATUS,required=false) String status,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerSummaryByCustomer() -start");
		ReadServersEvent request = new ReadServersEvent();
		
		request.setExternalCustomerCode(externalCustomerCode);
		request.setServiceId(serviceId);
		request.setCategoryId(categoryId);
		request.setStatus(status);
		
		Map<String, Long> event = service.readServerSummaryByCustomer(request);
		//Summary summary = Summary.builder().summary(event).build();
		log.info("readServerSummaryByCustomer() -end");
		return new ResponseEntity<Map<String, Long>>(event, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/consolidateView/summary/reseller", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Long>> readServerSummaryByReseller(
		    @RequestHeader(value = NepheleConstants.X_RESELLER_KEY, required=true) String externalResellerCode,
		    @RequestHeader(value = NepheleConstants.X_CUSTOMER_KEY, required=false) String externalCustomerCode,
			@RequestParam(value = QueryParameterConstants.SERVICE_ID, required=false) Long serviceId,
			@RequestParam(value = QueryParameterConstants.CATEGORY_ID, required=false) Long categoryId,
			@RequestParam(value=QueryParameterConstants.STATUS,required=false) String status,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerSummaryByReseller() -start");
		ReadServersEvent request = new ReadServersEvent();
		
		request.setExternalResellerCode(externalResellerCode);
		request.setExternalCustomerCode(externalCustomerCode);
		request.setServiceId(serviceId);
		request.setCategoryId(categoryId);
		request.setStatus(status);
		
		//Map<String, Long> event = service.readServerSummaryByResellerAndServiceId(request);
		Map<String, Long> event = service.readServerSummaryByReseller(request);
		//Summary summary = Summary.builder().summary(event).build();
		log.info("readServerSummaryByReseller() -end");
		return new ResponseEntity<Map<String, Long>>(event, HttpStatus.OK);
	}
	

}
