package com.valuelabs.nephele.manager.resource;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
@JsonInclude(Include.NON_NULL)
public class CloudProductPlanResources {
	private List<ProductPlanResource> productPlans;
	private String message;
	
	@Override
    public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + ((message == null) ? 0 : message.hashCode());
	  result = prime * result + ((productPlans == null) ? 0 : productPlans.hashCode());
	  return result;
    }
	@Override
    public boolean equals(Object obj) {
	  if (this == obj)
	    return true;
	  if (obj == null)
	    return false;
	  if (getClass() != obj.getClass())
	    return false;
	  CloudProductPlanResources other = (CloudProductPlanResources) obj;
	  if (message == null) {
	    if (other.message != null)
		  return false;
	  } else if (!message.equals(other.message))
	    return false;
	  if (productPlans == null) {
	    if (other.productPlans != null)
		  return false;
	  } else if (!productPlans.equals(other.productPlans))
	    return false;
	  return true;
    }

}
