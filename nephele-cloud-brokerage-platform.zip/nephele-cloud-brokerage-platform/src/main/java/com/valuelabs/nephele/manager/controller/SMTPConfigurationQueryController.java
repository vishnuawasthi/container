package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.SMTPConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadSMTPConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadSMTPConfigurationsEvent;
import com.valuelabs.nephele.admin.rest.lib.service.SMTPConfigurationQueryService;
import com.valuelabs.nephele.manager.assembler.SMTPConfigurationResourceAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.SMTPConfigurationResource;


@Slf4j
@RestController
@RequestMapping("/manager/smtpConfiguration")
public class SMTPConfigurationQueryController {

  @Autowired
  private SMTPConfigurationResourceAssembler assembler;
  
  @Autowired
  private SMTPConfigurationQueryService service;
  
  	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SMTPConfigurationResource> readSMTPConfiguration(@PathVariable Long id) {
		log.info("readSMTPConfiguration() - start");
		ReadSMTPConfigurationEvent request = new ReadSMTPConfigurationEvent().setId(id);
		EntityReadEvent<SMTPConfigurationDetails> event = service.readSMTPConfiguration(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		SMTPConfigurationDetails entity = event.getEntity();
		log.info("readSMTPConfiguration() - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
  
  	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<SMTPConfigurationResource>> readSMTPConfiguration(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<SMTPConfigurationDetails> pagedAssembler) {
		log.info("readSMTPConfiguration()  - start");
		ReadSMTPConfigurationsEvent  request = new ReadSMTPConfigurationsEvent().setPageable(pageable);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<SMTPConfigurationDetails> event = service.readSMTPConfigurations(request);
		Page<SMTPConfigurationDetails> page = event.getPage();
		PagedResources<SMTPConfigurationResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readSMTPConfiguration()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
  
  
}
