package com.valuelabs.nephele.manager.assembler;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionDetails;
import com.valuelabs.nephele.manager.controller.CloudSubscriptionQueryController;
import com.valuelabs.nephele.manager.resource.CloudSubscriptionResource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;



@Slf4j
@Service
public class CloudSubscriptionAssembler extends ResourceAssemblerSupport<CloudSubscriptionDetails, CloudSubscriptionResource> {
	
	@Autowired
	private CloudServiceResourceAssembler cloudServiceResourceAssembler;
	
	@Autowired
	private CloudProductPlanAssembler CloudProductPlanAssembler;
	
	public CloudSubscriptionAssembler() {
		super(CloudSubscriptionQueryController.class, CloudSubscriptionResource.class);
		// TODO Auto-generated constructor stub
	}
	
	

	@Override
	public CloudSubscriptionResource toResource(
			CloudSubscriptionDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: "+entity);
    //CloudServiceResource serviceResource = cloudServiceResourceAssembler.toResource(entity.getCloudServiceDetails());
    //ProductPlanResource planResource = CloudProductPlanAssembler.toResource(entity.getCloudProductPlanDetails());
    CloudSubscriptionResource resource=instantiateResource(entity);
    resource = CloudSubscriptionResource.builder().subscriptionId(entity.getSubscriptionId()).customerId(entity.getCustomerId()).customerName(entity.getCustomerName())
        //.serviceDetails(serviceResource)
        //.planDetails(planResource)
        .resellerId(entity.getResellerId()).resellerName(entity.getResellerName()).orderId(entity.getOrderId()).productId(entity.getProductId()).accountId(entity.getAccountId()).cloudProductPlanId(entity.getCloudProductPlanId()).planName(entity.getPlanName()).description(entity.getDescription()).
				lastInvoicedDate(entity.getLastInvoicedDate()).licenseCount(entity.getLicenseCount()).orderId(entity.getOrderId()).
				subscriptionDate(entity.getSubscriptionDate()).vendorSubscriptionId(entity.getVendorSubscriptionId()).isNewSubArrearInvoiced(entity.isNewSubArrearInvoiced())
				.subscriptionStatus(entity.getSubscriptionStatus().toString())
				.subscriptionLastRenewalDate(entity.getSubscriptionLastRenewalDate())
				.autoRenewalOffDate(entity.getAutoRenewalOffDate())
			    .licenseAutoRenewal(entity.isLicenseAutoRenewal())
				.build();
		resource.add(linkTo(methodOn(CloudSubscriptionQueryController.class).readSubscription(entity.getSubscriptionId())).withSelfRel());
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudSubscriptionDetails fromResource(CloudSubscriptionResource resource){
		log.debug("fromResource: START:{} ",resource);
		CloudSubscriptionDetails details=CloudSubscriptionDetails.builder().subscriptionId(resource.getSubscriptionId()).customerId(resource.getCustomerId())
				.resellerId(resource.getResellerId()).orderId(resource.getOrderId())
				.productId(resource.getProductId()).accountId(resource.getAccountId()).cloudProductPlanId(resource.getCloudProductPlanId()).description(resource.getDescription()).
				lastInvoicedDate(resource.getLastInvoicedDate()).licenseCount(resource.getLicenseCount()).orderId(resource.getOrderId()).orderLineId(resource.getOrderId()).
				subscriptionDate(resource.getSubscriptionDate()).vendorSubscriptionId(resource.getVendorSubscriptionId()).isNewSubArrearInvoiced(resource.isNewSubArrearInvoiced())
				.subscriptionStatus(resource.getSubscriptionStatus())
				.subscriptionLastRenewalDate(resource.getSubscriptionLastRenewalDate())
				.autoRenewalOffDate(resource.getAutoRenewalOffDate())
			    .licenseAutoRenewal(resource.isLicenseAutoRenewal())
				.build();
		log.debug("fromResouce: END");
		return details;
	}
	
}
