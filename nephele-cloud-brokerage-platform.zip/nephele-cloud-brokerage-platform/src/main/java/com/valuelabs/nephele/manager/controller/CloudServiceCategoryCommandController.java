package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.ServiceCategoryDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServiceCategoryEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ServiceCategoryCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceCategoryCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.ServiceCategoryAssembler;
import com.valuelabs.nephele.manager.resource.ServiceCategoryResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/manager/serviceCategory")
@Transactional
public class CloudServiceCategoryCommandController {

  @Autowired
  private ServiceCategoryAssembler assembler;

  @Autowired
  CloudServiceCategoryCommandService commandService;

  @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE,
	  produces = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<ServiceCategoryResource> createCloudServiceCategory(
	  @Valid @RequestBody ServiceCategoryResource resource, BindingResult result) throws IllegalArgumentException {
	log.info("createCloudServiceCategory() : START");
	if (result.hasErrors()) {
	  List<String> errorMessageList = new ArrayList<String>();
	  List<FieldError> errors = result.getFieldErrors();
	  for (FieldError fieldError : errors) {
		errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
	  }
	  CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
		  .errorMessages(errorMessageList).build();
	  return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
	}
	ServiceCategoryDetails details = assembler.fromResource(resource);
	CreateServiceCategoryEvent request = new CreateServiceCategoryEvent().setServiceCategoryDetails(details);

	if (request != null) {
		ServiceCategoryCreatedEvent event=commandService.createServiceCategory(request);
		details=event.getServiceCategoryDetail();
	}

	log.info("createCloudServiceCategory() : END");
	return new ResponseEntity<>(assembler.toResource(details),HttpStatus.CREATED);

  }

  @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE,
	  produces = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<ServiceCategoryResource> updateCloudServiceCategory(
	  @Valid @RequestBody ServiceCategoryResource resource, BindingResult result) throws Exception {
	log.info("updateCloudServiceCategory() : START");
	
	if (resource.getCategoryId() == null) {
	  result.addError(new FieldError("resource", "Id", resource.getCategoryId(), true, null, null, null));
	}
	if (result.hasErrors()) {
	  List<String> errorMessageList = new ArrayList<String>();
	  List<FieldError> errors = result.getFieldErrors();
	  for (FieldError fieldError : errors) {
		errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
	  }
	  CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
		  .errorMessages(errorMessageList).build();
	  return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
	}
	// save it
	ServiceCategoryDetails details = assembler.fromResource(resource);

	CreateServiceCategoryEvent request = new CreateServiceCategoryEvent().setServiceCategoryDetails(details);
	if (request != null) {
	  commandService.updateServiceCategory(request);
	}

	log.info("updateCloudServiceCategory() : END");
	return new ResponseEntity<ServiceCategoryResource>(HttpStatus.OK);

  }

}
