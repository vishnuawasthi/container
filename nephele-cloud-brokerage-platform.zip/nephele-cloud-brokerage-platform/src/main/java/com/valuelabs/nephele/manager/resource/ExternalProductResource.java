package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class ExternalProductResource extends ResourceSupport{
	
	private Long externalProductId;
	//private String externalId;
	private String productName;
	private String description;
	private String brandName;
	private String status;
	private String type;
	private String name;
	private String serviceName;
	private String label;
	

}
