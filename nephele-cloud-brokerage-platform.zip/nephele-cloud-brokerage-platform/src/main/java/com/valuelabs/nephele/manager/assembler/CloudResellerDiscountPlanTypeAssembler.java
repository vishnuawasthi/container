package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerDiscountPlanTypeDetails;
import com.valuelabs.nephele.manager.controller.CloudResellerDiscountPlanTypeQueryController;
import com.valuelabs.nephele.manager.resource.CloudResellerDiscountPlanTypeResource;


@Slf4j
@Service
public class CloudResellerDiscountPlanTypeAssembler extends ResourceAssemblerSupport<CloudResellerDiscountPlanTypeDetails, CloudResellerDiscountPlanTypeResource>{
	
	public CloudResellerDiscountPlanTypeAssembler() {
		super(CloudResellerDiscountPlanTypeQueryController.class,  CloudResellerDiscountPlanTypeResource.class);
	}

    @Override
	public CloudResellerDiscountPlanTypeResource toResource(
			CloudResellerDiscountPlanTypeDetails entity) {
    	log.debug("toResource : START : {} ", entity);
    	CloudResellerDiscountPlanTypeResource resource = instantiateResource(entity);
    	resource=CloudResellerDiscountPlanTypeResource.builder()
    	    .discountPlanTypeId(entity.getDiscountPlanTypeId())
    		.typeName(entity.getTypeName())
    		.description(entity.getDescription())
    		.build();
    	
    	resource.add(linkTo(methodOn(CloudResellerDiscountPlanTypeQueryController.class).readResellerDiscountPlanType(entity.getDiscountPlanTypeId())).withSelfRel());
    	log.debug("toResource : END : {} ", resource);
		return resource;
	}
    
   
	public CloudResellerDiscountPlanTypeDetails fromResource(
			CloudResellerDiscountPlanTypeResource resource) {
		log.debug("fromResource : START : {} ", resource);
    	
		CloudResellerDiscountPlanTypeDetails details = CloudResellerDiscountPlanTypeDetails.builder()
				.discountPlanTypeId(resource.getDiscountPlanTypeId())
				.typeName(resource.getTypeName())
				.description(resource.getDescription())
				.build();
        
		log.debug("fromResource : END : {} ", details);
		return details;
	}

}
