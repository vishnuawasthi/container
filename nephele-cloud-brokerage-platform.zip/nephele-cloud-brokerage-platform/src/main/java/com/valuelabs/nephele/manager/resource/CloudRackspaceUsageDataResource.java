package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
public class CloudRackspaceUsageDataResource extends ResourceSupport {
	private Long CloudRackspaceUsageDataId;
	
	private Long cloudCustomerCompanyId;
	
	private Long cloudServerId;
	
	private String cspServerId;

	private String serverName;
	
	private String productType;

	private Long cloudServiceId;

	private String serviceType;

	private String flavourName;

	private Double usageQuantity;

	private Double unitPrice;

	private String currency;

    private Double totalPrice;

    private MeteringDataInvoiceStatus customerInvoiceStatus;

    private MeteringDataInvoiceStatus resellerInvoiceStatus;

}
