package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class ProductPlanResource extends ResourceSupport {
	
	private Long planId;
	private String planName;
	private String planCode;
	private String details;
	private String status;
	private String price;
	private String vendorPrice;
	private Long configurationId;
	private String configurationName;
	private String flavorCategory;
	private Long productId;
	private Long locationId;
	private Long serviceId;
	private String productName;
	private String productDescription;
	private String productType;
	private String locationName;
	private String serviceName;
	private Long operatingSystemId;
	private String operatingSystemName;
	private String vendorPlanCode;
	private Boolean isTrialPlan;
	private String pricingModel;
	private String description;
	
	
}
