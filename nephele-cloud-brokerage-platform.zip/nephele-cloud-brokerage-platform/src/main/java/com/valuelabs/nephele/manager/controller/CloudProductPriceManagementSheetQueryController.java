package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceManagementSheetDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPriceManagementSheetEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPriceManagementSheetsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudProductPriceManagementSheetQueryService;
import com.valuelabs.nephele.manager.assembler.CloudProductPriceManagementSheetAssembler;
import com.valuelabs.nephele.manager.resource.CloudProductPriceManagementSheetResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/manager/priceManagementSheet")
@Transactional
public class CloudProductPriceManagementSheetQueryController {

	@Autowired
	private CloudProductPriceManagementSheetQueryService service;

	@Autowired
	private CloudProductPriceManagementSheetAssembler assembler;
	
	

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductPriceManagementSheetResource> readCloudProductPriceManagementSheet(
			@PathVariable("id") Long id) {
		log.info("readCloudProductPriceManagementSheet() - start");
		ReadCloudProductPriceManagementSheetEvent request = new ReadCloudProductPriceManagementSheetEvent()
				.setPriceManagementSheetId(id);

		EntityReadEvent<CloudProductPriceManagementSheetDetails> event = service
				.readProductPriceManagementSheet(request);
		if (!event.isFound()) {
			return new ResponseEntity<CloudProductPriceManagementSheetResource>(HttpStatus.NO_CONTENT);
		}
		log.info("readCloudProductPriceManagementSheet() - end");
		return new ResponseEntity<CloudProductPriceManagementSheetResource>(assembler.toResource(event.getEntity()),
				HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductPriceManagementSheetResource>> readCloudProductPriceManagementSheets(
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
	    	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductPriceManagementSheetDetails> pagedAssembler) {
		log.info("readCloudProductPriceManagementSheets() - start ");
		ReadCloudProductPriceManagementSheetsEvent request = new ReadCloudProductPriceManagementSheetsEvent()
				.setPageable(pageable);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudProductPriceManagementSheetDetails> event = service
				.readProductPriceManagementSheets(request);

		Page<CloudProductPriceManagementSheetDetails> page = event.getPage();
		PagedResources<CloudProductPriceManagementSheetResource> pagedResources = pagedAssembler.toResource(page,
				assembler);
		log.info("readCloudProductPriceManagementSheets() - start ");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/sheetName", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductPriceManagementSheetResource>> readCloudProductPriceManagementSheetBySheetName(
			@RequestParam("sheetName") String sheetName, 
			@RequestParam(value = "serviceId", required=false) Long serviceId,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
		    @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductPriceManagementSheetDetails> pagedAssembler) {
		log.info("readCloudProductPriceManagementSheetBySheetName() - start");

		ReadCloudProductPriceManagementSheetsEvent request = new ReadCloudProductPriceManagementSheetsEvent()
				.setPageable(pageable).setPriceSheetName(sheetName).setServiceId(serviceId);

		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		
		PageReadEvent<CloudProductPriceManagementSheetDetails> event = service.readProductPriceManagementSheetBySheetName(request);

		Page<CloudProductPriceManagementSheetDetails> page = event.getPage();
		PagedResources<CloudProductPriceManagementSheetResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudProductPriceManagementSheetBySheetName() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/sheetStatus", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductPriceManagementSheetResource>>readCloudProductPriceManagementSheetBySheetStatus(
			@RequestParam("status") String status, 
			@RequestParam(value = "serviceId", required=false) Long serviceId,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
		    @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductPriceManagementSheetDetails> pagedAssembler) {
		log.info("readCloudProductPriceManagementSheetBySheetStatus() - start");

		ReadCloudProductPriceManagementSheetsEvent request = new ReadCloudProductPriceManagementSheetsEvent()
				.setPageable(pageable).setStatus(status).setServiceId(serviceId);

		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudProductPriceManagementSheetDetails> event = service
				.readProductPriceManagementSheetBySheetStatus(request);
		
		Page<CloudProductPriceManagementSheetDetails> page = event.getPage();
		PagedResources<CloudProductPriceManagementSheetResource> pagedResources = pagedAssembler.toResource(page,
				assembler);
		
		log.info("readCloudProductPriceManagementSheetBySheetStatus() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}


}
