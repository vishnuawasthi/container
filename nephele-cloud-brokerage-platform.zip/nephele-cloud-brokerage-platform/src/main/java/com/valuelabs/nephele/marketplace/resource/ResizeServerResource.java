package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode
@Setter
@Getter
@Builder
@Accessors(chain=true)
public class ResizeServerResource {

	private Long serverId;
	private String serverName;
	private String flavourId;
	private Long planId;
	private Boolean confirmResize;
}
