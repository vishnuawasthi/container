package com.valuelabs.nephele.marketplace.assembler;


import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.RackspaceServerConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntitiesReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlanEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRackspaceConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudRackspaceConfigurationQueryService;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudProductPlanQueryService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudProductQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.RackspaceServerConfigurationQueryService;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import com.valuelabs.nephele.manager.assembler.CloudRackspaceConfigurationAssembler;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResource;
import com.valuelabs.nephele.manager.resource.PlansResource;
import com.valuelabs.nephele.marketplace.controller.CloudServerQueryController;
import com.valuelabs.nephele.marketplace.resource.CloudServerDetailsResource;
import com.valuelabs.nephele.marketplace.resource.CloudServerResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CloudServerAssembler extends ResourceAssemblerSupport<CloudServerDetails, CloudServerResource> {
	
	@Autowired
	RackspaceServerConfigurationQueryService rackspaceServerConfigurationQueryService;
	
	@Autowired
	CloudRackspaceConfigurationQueryService cloudRackspaceConfigurationQueryService;
	
	@Autowired
	CloudRackspaceConfigurationAssembler configAssembler;
	
	@Autowired
	CloudProductQueryService service;
	
	@Autowired
	CloudProductPlanQueryService cloudProductPlanQueryService;
	
	

	public CloudServerAssembler() {
		super(CloudServerQueryController.class, CloudServerResource.class);
	}
	
	@Override
	public CloudServerResource toResource(CloudServerDetails entity) {

		log.debug("toResource() : START");
		CloudServerResource resource = instantiateResource(entity);
		
		resource = CloudServerResource.builder().serverId(entity.getServerId())
												.name(entity.getName())
												.description(entity.getDescription())
												.status(entity.getStatus())
												.brandCode(entity.getBrandCode())
												.brandName(entity.getBrandName())
												.orderId(entity.getCloudOrderId())
												.customerId(entity.getCustomerId())
												.customerName(entity.getCustomerName())
												.publicIPV4Address(entity.getPublicIPv4Address())
												.publicIPV6Address(entity.getPublicIPv6Address())
												.privateIPV4Address(entity.getPrivateIPv4Address())
												.privateIPV6Address(entity.getPrivateIPv6Address())
												.username(entity.getUsername())
												.password(entity.getPassword())
												.creationDate(entity.getCreationDate())
												//.productId(entity.getCloudProductId())
												.vendorStatus(entity.getVendorStatus())
												.integrationCode(entity.getIntegrationCode())
												.categoryName(entity.getCategoryName())
												.build();
		
		resource.add(linkTo(methodOn(CloudServerQueryController.class).readCloudServer(entity.getServerId())).withSelfRel());
		log.debug("toResource() : END");

		return resource;
	}
	
	public CloudServerDetailsResource toResource_details(CloudServerDetails entity) {
		log.debug("toResource() : START");
		List<PlansResource> upgradeDetails = new ArrayList<PlansResource>();
		CloudLocationResource locationResource = CloudLocationResource.builder().name(entity.getLocationName()).build();
		
		ReadCloudProductPlanEvent readPlanEvent = new ReadCloudProductPlanEvent().setProductPlanId(entity.getPlanId());
		EntityReadEvent<CloudProductPlanDetails> event = cloudProductPlanQueryService.readProductPlanService(readPlanEvent);
		CloudProductPlanDetails planDetails = event.getEntity();
		
		CloudOperatingSystemResource osResource = CloudOperatingSystemResource.builder().operatingSystemId(planDetails.getOperatingSystemId())
																					    .name(planDetails.getOperatingSystemName())
																					    .build();
		
		ReadRackspaceConfigurationEvent configEvent = new ReadRackspaceConfigurationEvent().setRackspaceConfigurationId(planDetails.getFlavorId())
																					 .setOperatingSystemId(planDetails.getOperatingSystemId());
		EntityReadEvent<CloudRackspaceConfigurationDetails> configDetailsEvent = cloudRackspaceConfigurationQueryService.readRackspaceConfigurationWithPrice(configEvent);
		CloudRackspaceConfigurationDetails configDetails = configDetailsEvent.getEntity();
		CloudRackspaceConfigurationResource flavorResource = configAssembler.toResource_withOutConfigId(configDetails);
		
		PlansResource planResource = PlansResource.builder().planId(planDetails.getProductPlanId())
															.price(String.valueOf(planDetails.getPrice()))
															.os(osResource)
															.location(locationResource)
															.flavor(flavorResource)
															.build();
		
		
		
		EntitiesReadEvent<RackspaceServerConfigurationDetails> serverConfigDetails = rackspaceServerConfigurationQueryService.readListOfUpgrades(entity.getServerId(), InventoryStatus.PUBLISHED.name());
		List<RackspaceServerConfigurationDetails> detailsEntity = serverConfigDetails.getEntities();
		for (RackspaceServerConfigurationDetails rackspaceServerCnfgurationDetails : detailsEntity) {
			//CloudLocationResource locationResrce = CloudLocationResource.builder().name(entity.getLocationName()).build();
			ReadCloudProductPlanEvent readPlnEvent = new ReadCloudProductPlanEvent().setProductPlanId(rackspaceServerCnfgurationDetails.getPlanId());
			EntityReadEvent<CloudProductPlanDetails> evnt = cloudProductPlanQueryService.readProductPlanService(readPlnEvent);
			CloudProductPlanDetails plnDetails = evnt.getEntity();
			CloudOperatingSystemResource osResrce = CloudOperatingSystemResource.builder().operatingSystemId(planDetails.getOperatingSystemId())
																						    .name(planDetails.getOperatingSystemName())
																						    .build();
			
			ReadRackspaceConfigurationEvent confgEvent = new ReadRackspaceConfigurationEvent().setRackspaceConfigurationId(planDetails.getFlavorId())
																						 .setOperatingSystemId(planDetails.getOperatingSystemId());
			EntityReadEvent<CloudRackspaceConfigurationDetails> confgDetailsEvent = cloudRackspaceConfigurationQueryService.readRackspaceConfigurationWithPrice(confgEvent);
			CloudRackspaceConfigurationDetails confgDetails = confgDetailsEvent.getEntity();
			CloudRackspaceConfigurationResource flavrResource = configAssembler.toResource_withOutConfigId(confgDetails);
			PlansResource upgradePlanResource = PlansResource.builder().planId(plnDetails.getProductPlanId())
					.price(String.valueOf(plnDetails.getPrice()))
					.os(osResrce)
					.location(locationResource)
					.flavor(flavrResource)
					.build();
			upgradeDetails.add(upgradePlanResource);
			
		}
		
		
		CloudServerDetailsResource resource = CloudServerDetailsResource.builder().serverId(entity.getServerId())
																				  .name(entity.getName())
																				  .description(entity.getDescription())
																				  .status(entity.getStatus())
																				  .brandCode(entity.getBrandCode())
																				  .brandName(entity.getBrandName())
																				  .orderId(entity.getCloudOrderId())
																				  .customerId(entity.getCustomerId())
																				  .customerName(entity.getCustomerName())
																				  .publicIPV4Address(entity.getPublicIPv4Address())
																				  .publicIPV6Address(entity.getPublicIPv6Address())
																				  .privateIPV4Address(entity.getPrivateIPv4Address())
																				  .privateIPV6Address(entity.getPrivateIPv6Address())
																				  .username(entity.getUsername())
																				  .password(entity.getPassword())
																				  .creationDate(entity.getCreationDate())
																				  //.productId(entity.getCloudProductId())
																				  .plans(planResource)
																				  .upgradeDetails(upgradeDetails)
																				  .vendorStatus(entity.getVendorStatus())
																				  //.os(osResource)
																				  //.location(locationResource)
																				  //.flavor(flavorResource)
																				  .integrationCode(entity.getIntegrationCode())
																				  .categoryName(entity.getCategoryName())
																				  .build();
		
		resource.add(linkTo(methodOn(CloudServerQueryController.class).readCloudServer(entity.getServerId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudServerDetails fromResource(CloudServerResource resource) {
		log.debug("fromResource()  - START");
		CloudServerDetails serviceDetails = CloudServerDetails.builder().serverId(resource.getServerId())
																		.name(resource.getName())
																		.description(resource.getDescription())
																		.status(resource.getStatus())
																		.brandCode(resource.getBrandCode())
																		.brandName(resource.getBrandName())
																		//.cspServerId(resource.getCspServerId())
																		.customerId(resource.getCustomerId())
																		.customerName(resource.getCustomerName())
																		//.cloudProductId(resource.getProductId())
																		//.cloudServiceId(resource.getCloudServiceId())
																		.cloudOrderId(resource.getOrderId())
																		.username(resource.getUsername())
																		.password(resource.getPassword())
																		.creationDate(resource.getCreationDate())
																		.build();
		log.debug("fromResource() - END");
		return serviceDetails;
	}
	
	public List<CloudServerResource> toResourceList(List<CloudServerDetails> entities) {
	 log.debug("toResourceList - start");
	  List<CloudServerResource> resourceList = new ArrayList<>();
	  
	  for(CloudServerDetails details : NepheleValidationUtils.nullSafe(entities) ) {
		CloudServerResource resource = CloudServerResource.builder()
                                            			.serverId(details.getServerId())
                                            			.name(details.getName())
                                            			.status(details.getStatus())
                                            			.vendorStatus(details.getVendorStatus())
                                            			.build();
		resourceList.add(resource);
	  }
	  log.debug("toResourceList - end");
	  return  resourceList;
	}
	

}
