package com.valuelabs.nephele.manager.assembler;

import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;
import com.valuelabs.nephele.manager.controller.CloudCurrencyConversionRateQueryController;
import com.valuelabs.nephele.manager.resource.CloudCurrencyConversionRateResource;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

@Service
@Slf4j
public class CloudCurrencyConversionRateAssembler extends ResourceAssemblerSupport<CloudCurrencyConversionRateDetails, CloudCurrencyConversionRateResource> {
 
  public CloudCurrencyConversionRateAssembler() {
	super(CloudCurrencyConversionRateQueryController.class , CloudCurrencyConversionRateResource.class);
  }

  @Override
  public CloudCurrencyConversionRateResource toResource(CloudCurrencyConversionRateDetails details) {
	log.debug("toResource() -start");
	CloudCurrencyConversionRateResource resource = CloudCurrencyConversionRateResource.builder()
                                                                                  	.conversionRateId(details.getId())
                                                                                  	.activeFrom(details.getActiveFrom())
                                                                                  	.activeTo(details.getActiveTo())
                                                                                  	.conversionRate(details.getConversionRate())
                                                                                  	.sourceCurrency(details.getSourceCurrency())
                                                                                  	.status(details.getStatus())
                                                                                  	.targetCurrency(details.getTargetCurrency())
                                                                                  	.build();
	
	resource.add(linkTo(methodOn(CloudCurrencyConversionRateQueryController.class).readCloudCurrencyConversionRate(details.getId())).withSelfRel());
	log.debug("toResource() -end");
	return resource;
  }
  public CloudCurrencyConversionRateDetails fromResource(CloudCurrencyConversionRateResource resource) {
	log.debug("fromResource() -start");
	CloudCurrencyConversionRateDetails details = CloudCurrencyConversionRateDetails.builder()
                                                                                  	.id(resource.getConversionRateId())
                                                                                  	.activeFrom(resource.getActiveFrom())
                                                                                  	.activeTo(resource.getActiveTo())
                                                                                  	.conversionRate(resource.getConversionRate())
                                                                                  	.sourceCurrency(resource.getSourceCurrency())
                                                                                  	.status(resource.getStatus())
                                                                                  	.targetCurrency(resource.getTargetCurrency())
                                                                                  	.build();
	log.debug("fromResource() -end");
	return details;
  }
  
}
