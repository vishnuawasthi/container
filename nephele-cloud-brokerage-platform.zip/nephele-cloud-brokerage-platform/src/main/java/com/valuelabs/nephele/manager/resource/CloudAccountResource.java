package com.valuelabs.nephele.manager.resource;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
@JsonInclude(Include.NON_NULL)
public class CloudAccountResource extends ResourceSupport {
  private Long accountId;
  private String vendorAccountId;
  private String username;
  private String password;
  private String vendorStatus;
  private String nepheleStatus;
  private String superUsername;
  private String superPassword;
  private String superAPIKey;
  private Long customerCompanyId;
  private String customerCompanyName;
  private Long orderId;  
  private String orderCode;
  private Long serviceId;
  private String serviceName;
  private CloudServiceResource serviceDetails;
  private List<CloudSubscriptionResource> subscriptionDetails;
  private Boolean trialAccount;
  private Long monthlyLicenseCount;
  private Long yearlyLicenseCount;
  private Boolean isTrial;
  @JsonFormat(pattern = "yyyy-MM-dd")
  private Date provisionDate;
  
  
}
