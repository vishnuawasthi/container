package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.manager.controller.CloudOperatingSystemQueryController;

@Slf4j
@Service
public class CloudOperatingSystemAssembler extends ResourceAssemblerSupport<CloudOperatingSystemDetails, CloudOperatingSystemResource> {

	public CloudOperatingSystemAssembler() {
		super(CloudOperatingSystemQueryController.class, CloudOperatingSystemResource.class);
	}

	@Override
	public CloudOperatingSystemResource toResource(
			CloudOperatingSystemDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: "+entity);
		CloudOperatingSystemResource resource = instantiateResource(entity);
		
		resource = CloudOperatingSystemResource.builder().operatingSystemId(entity.getOperatingSystemId()).cspResource(entity.getCspResource()).imageId(entity.getImageId()).name(entity.getName())
				  .status(entity.getStatus()).minDisk(entity.getMinDisk()).minRam(entity.getMinRam()).serviceId(entity.getServiceId()).build();
		resource.add(linkTo(methodOn(CloudOperatingSystemQueryController.class).readOperatingSystem(entity.getOperatingSystemId())).withSelfRel());
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
		
	}
	
	public CloudOperatingSystemDetails fromResource(CloudOperatingSystemResource resource){
		log.debug("fromResource: START:{} ",resource);
		CloudOperatingSystemDetails details=CloudOperatingSystemDetails.builder().operatingSystemId(resource.getOperatingSystemId())
				.imageId(resource.getImageId())
				.name(resource.getName())
				.status(resource.getStatus())
				.minRam(resource.getMinRam())
				.minDisk(resource.getMinDisk())
				.cspResource(resource.getCspResource())
				.serviceId(resource.getServiceId())
				.build();
		log.debug("fromResouce: END");
		return details;
	}
	

}
