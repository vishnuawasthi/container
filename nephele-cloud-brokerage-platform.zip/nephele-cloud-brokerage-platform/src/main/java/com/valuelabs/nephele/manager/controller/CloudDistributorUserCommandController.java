package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorUserDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudDistributorUserEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudDistributorUserCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.CloudDistributorUserAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudDistributorUserResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/cloudDistributorUser")
@Transactional
public class CloudDistributorUserCommandController {

	@Autowired
	private CloudDistributorUserAssembler assembler;

	@Autowired
	private CloudDistributorUserCommandService service;

	//@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudDistributorUserResource> createCloudDistributorUser(@Valid @RequestBody CloudDistributorUserResource resource,BindingResult result)  throws IllegalArgumentException ,ConstraintViolationException{
		log.info("createCloudDistributorUser()  - start");
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		CloudDistributorUserDetails details = assembler.fromResource(resource);
		CreateCloudDistributorUserEvent request = new CreateCloudDistributorUserEvent().setCloudDistributorUserDetails(details);
		if (request != null) {
			service.createCloudDistributorUser(request);
		}
		log.info("createCloudDistributorUser()  - end");
		return new ResponseEntity<CloudDistributorUserResource>(HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudDistributorUserResource> updateCloudDistributorUser(@Valid @RequestBody CloudDistributorUserResource resource ,BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateCloudDistributorUser()  - start");
		if(resource.getDistributorId() == null) {
			result.addError(new FieldError("resource", "distributorId", resource.getDistributorId(), false, null, null, null));
		}	
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		CloudDistributorUserDetails details = assembler.fromResource(resource);
		CreateCloudDistributorUserEvent request = new CreateCloudDistributorUserEvent().setCloudDistributorUserDetails(details);
		if (request != null) {
			service.updateCloudDistributorUser(request);
		}
		log.info("updateCloudDistributorUser()  - end");
		return new ResponseEntity<CloudDistributorUserResource>(HttpStatus.OK);
	}
	
	

}
