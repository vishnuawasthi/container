package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode(callSuper=false)
@Setter
@Getter
@Builder
@Accessors(chain=true)
@JsonInclude(Include.NON_DEFAULT)
public class ExternalProductResource extends ResourceSupport {
	
	private Long externalProductId;
	private String ExternalID;

	private String Name;

	private String BrandName;

	private String CategoryName;

	private String ShortDescription;
	
	private String status;
	
	private String type;
	
}
