package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAdditionalPriceDetails;
import com.valuelabs.nephele.manager.controller.CloudAdditionalPriceQueryController;
import com.valuelabs.nephele.manager.resource.CloudAdditionalPriceResource;

@Slf4j
@Service
public class CloudAdditionalPriceAssembler extends ResourceAssemblerSupport<CloudAdditionalPriceDetails, CloudAdditionalPriceResource> {

	public CloudAdditionalPriceAssembler() {
		super(CloudAdditionalPriceQueryController.class, CloudAdditionalPriceResource.class);
	}

	@Override
	public CloudAdditionalPriceResource toResource(CloudAdditionalPriceDetails details) {
		log.debug("toResource() - start");
		CloudAdditionalPriceResource resource = CloudAdditionalPriceResource.builder().additionalPriceId(details.getAdditionalPriceId())
				.serviceId(details.getCloudServiceId()).name(details.getName()).price(String.valueOf(details.getPrice()))
				.location(details.getLocation())
				.description(details.getDescription())
				.status(details.getStatus())
				.serviceName(details.getServiceName())
				.planCode(details.getPlanCode())
				.vendorPrice(null !=details.getVendorPrice()?String.valueOf(details.getVendorPrice()):"0.0")
				.build();
		resource.add(linkTo(
				methodOn((CloudAdditionalPriceQueryController.class)).readCloudAdditionalPrice(details.getAdditionalPriceId())).withSelfRel());
		log.debug("toResource() - end");
		return resource;
	}

	public CloudAdditionalPriceDetails fromResource(CloudAdditionalPriceResource resource) {
		log.debug("fromResource() - start");
		CloudAdditionalPriceDetails details = CloudAdditionalPriceDetails.builder().additionalPriceId(resource.getAdditionalPriceId())
				.cloudServiceId(resource.getServiceId()).name(resource.getName()).price(Double.valueOf(resource.getPrice()))
				.location(resource.getLocation())
				.description(resource.getDescription())
				.status(resource.getStatus())
				.vendorPrice(null !=resource.getVendorPrice()?Double.valueOf(resource.getVendorPrice()):0)
				.build();

		log.debug("fromResource() - end");
		return details;
	}

}
