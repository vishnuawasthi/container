package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceManagementSheetDetails;
import com.valuelabs.nephele.manager.controller.CloudProductPriceManagementSheetQueryController;
import com.valuelabs.nephele.manager.resource.CloudProductPriceManagementSheetResource;

@Slf4j
@Service
public class CloudProductPriceManagementSheetAssembler extends
		ResourceAssemblerSupport<CloudProductPriceManagementSheetDetails, CloudProductPriceManagementSheetResource> {

	public CloudProductPriceManagementSheetAssembler() {
		super(CloudProductPriceManagementSheetQueryController.class, CloudProductPriceManagementSheetResource.class);
	}

	@Override
	public CloudProductPriceManagementSheetResource toResource(CloudProductPriceManagementSheetDetails details) {
		log.debug("toResource() - start");
		CloudProductPriceManagementSheetResource resource = instantiateResource(details);
		resource = CloudProductPriceManagementSheetResource.builder().productPriceManagementSheetId(details.getId())
				.price(details.getPrice())
				.cloudProductPlanId(details.getCloudProductPlanId())
				.priceManagementConfigId(details.getPriceManagementConfigId())
				.sheetName(details.getSheetName())
				.planDetails(details.getPlanDetails())
				.vendorPrice(details.getVendorPrice())
				.build();
		//resource.add(linkTo(methodOn(CloudProductPriceManagementSheetQueryController.class).readCloudProductPriceManagementSheet(details.getId())).withSelfRel());
		resource.add(linkTo(methodOn(CloudProductPriceManagementSheetQueryController.class).readCloudProductPriceManagementSheet(details.getId())).withSelfRel());
		log.debug("toResource() - end");
		return resource;
	}

	public CloudProductPriceManagementSheetDetails fromResource(CloudProductPriceManagementSheetResource resource) {
		log.debug("fromResource: START:{} ", resource);
		CloudProductPriceManagementSheetDetails details = CloudProductPriceManagementSheetDetails.builder()
				.id(resource.getProductPriceManagementSheetId()).price(resource.getPrice())
				.cloudProductPlanId(resource.getCloudProductPlanId())
				.priceManagementConfigId(resource.getPriceManagementConfigId()).vendorPrice(resource.getVendorPrice()).build();

		log.debug("fromResource() - end");
		return details;
	}

}
