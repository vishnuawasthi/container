package com.valuelabs.nephele.marketplace.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudOrderEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudOrderCommandService;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.CloudOrderAssembler;
import com.valuelabs.nephele.marketplace.resource.CloudOrderResource;

@Slf4j
@RestController
@Transactional
@RequestMapping("/marketplace/cloudOrder")
public class CloudOrderCommandController {

	@Autowired
	private CloudOrderAssembler assembler;

	@Autowired
	private CloudOrderCommandService commandService;

	/**
	 * Create new record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudOrderResource> createCloudOrder(
			@Valid @RequestBody CloudOrderResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createCloudOrder() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudOrderResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudOrderDetails cloudOrderDetails = assembler.fromResource(resource);
		CreateCloudOrderEvent request = new CreateCloudOrderEvent()
				.setCloudOrderDetails(cloudOrderDetails);
		if (request != null) {
			commandService.createServiceCloudOrder(request);
		}
		log.info("createCloudOrder() : END");
		return new ResponseEntity<CloudOrderResource>(HttpStatus.CREATED);
	}

	/**
	 * Update existing record in DB
	 * 
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 * @throws ResourceNotFoundException
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudOrderResource> updateCloudOrder(
			@Valid @RequestBody CloudOrderResource resource,
			BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateCloudOrder() : START");
		if (resource.getOrderId() == null) {
			result.addError(new FieldError("resource", "cloudOrderId", resource
					.getOrderId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudOrderResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudOrderDetails orderDetails = assembler.fromResource(resource);
		CreateCloudOrderEvent request = new CreateCloudOrderEvent()
				.setCloudOrderDetails(orderDetails);
		if (request != null) {
			commandService.updateServiceCloudOrder(request);
		}
		log.info("updateCloudOrder() : END");
		return new ResponseEntity<CloudOrderResource>(HttpStatus.OK);
	}

}