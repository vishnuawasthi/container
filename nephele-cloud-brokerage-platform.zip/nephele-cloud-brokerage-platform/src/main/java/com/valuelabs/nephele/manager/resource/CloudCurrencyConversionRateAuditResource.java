package com.valuelabs.nephele.manager.resource;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudCurrencyConversionRateAuditResource extends ResourceSupport {
  private Long auditId;
  private Double conversionRate;
  @JsonFormat(pattern = "yyyy-MM-dd")
  private Date createdOn;
  private Long ConversionRateId;
  private String sourceCurrency;
  private String targetCurrency;
}
