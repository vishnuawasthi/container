package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudUserRoleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudUserRoleEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudUserRolesEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserRoleQueryService;
import com.valuelabs.nephele.manager.assembler.CloudUserRoleAssembler;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.*;
import com.valuelabs.nephele.manager.resource.CloudUserRoleResource;

@Slf4j
@RestController
@RequestMapping("/manager/userRole")
public class CloudUserRoleQueryController {
	
	@Autowired
	private CloudUserRoleAssembler assembler;

	@Autowired
	private CloudUserRoleQueryService queryService;
	
	/**
	 * This method will get single record from DB
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudUserRoleResource> readUserRole( @PathVariable Long id) {
		log.info("readUserRole() START");
	
		ReadCloudUserRoleEvent request = new ReadCloudUserRoleEvent().setRoleId(id);
		
		EntityReadEvent<CloudUserRoleDetails> event =  queryService.readUserRoleService(request);
		
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudUserRoleDetails entity = event.getEntity();
		log.info("readUserRole() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	
	/**
	 * This method will get all records from DB by pagination.
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudUserRoleResource>> readUserRoles(
			@RequestParam(value=ROLE_NAME,required=false) String roleName,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudUserRoleDetails> pagedAssembler) {
		log.info("readUserRoles() START");
		ReadCloudUserRolesEvent request = new ReadCloudUserRolesEvent();
		request.setRoleName(roleName);
		request.setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudUserRoleDetails> event = queryService.readUserRolesService(request);
		Page<CloudUserRoleDetails> page = event.getPage();
		PagedResources<CloudUserRoleResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readUserRoles() END");
		
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
