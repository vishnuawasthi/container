package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceCredentialDetails;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudServiceCredentialResource;
import com.valuelabs.nephele.manager.controller.CloudServiceCredentialQueryController;

@Slf4j
@Service
public class CloudServiceCredentialResourceAssembler
		extends
		ResourceAssemblerSupport<CloudServiceCredentialDetails, CloudServiceCredentialResource> {

	public CloudServiceCredentialResourceAssembler() {
		super(CloudServiceCredentialQueryController.class,
				CloudServiceCredentialResource.class);
	}

	@Override
	public CloudServiceCredentialResource toResource(
			CloudServiceCredentialDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + entity);
		CloudServiceCredentialResource resource = instantiateResource(entity);

		resource = CloudServiceCredentialResource.builder()
				.serviceCredentialId(entity.getServiceCredentialId())
				.apiKey(entity.getApiKey())
				.username(entity.getUsername())
				.serviceId(entity.getServiceId())
				.accountNumber(entity.getAccountNo())
				.password(entity.getPassword())
				.build();
		resource.add(linkTo(
				methodOn(CloudServiceCredentialQueryController.class)
						.readServiceCredential(
								entity.getServiceCredentialId())).withSelfRel());
		log.debug("toResource() : resource : " + resource);
		log.debug("toResource() : resource Links: " + resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudServiceCredentialDetails fromResource(
			CloudServiceCredentialResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudServiceCredentialDetails details = CloudServiceCredentialDetails
				.builder()
				.serviceCredentialId(resource.getServiceCredentialId())
				.apiKey(resource.getApiKey())
				.username(resource.getUsername())
				.serviceId(resource.getServiceId())
				.accountNo(resource.getAccountNumber())
				.password(resource.getPassword())
				.build();
		log.debug("fromResource : END");
		return details;

	}
}
