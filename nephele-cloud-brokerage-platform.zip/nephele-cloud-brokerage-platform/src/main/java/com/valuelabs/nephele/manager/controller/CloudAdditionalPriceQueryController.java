package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAdditionalPriceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAdditionalPriceEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAdditionalPricesEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAdditionalPriceQueryService;
import com.valuelabs.nephele.manager.assembler.CloudAdditionalPriceAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudAdditionalPriceResource;
import static  com.valuelabs.nephele.manager.constants.QueryParameterConstants.*;

@Slf4j
@RestController
@RequestMapping("/manager/cloudAdditionalPrice")
@Transactional
public class CloudAdditionalPriceQueryController {

	@Autowired
	private CloudAdditionalPriceQueryService service;
	@Autowired
	private CloudAdditionalPriceAssembler assembler;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudAdditionalPriceResource> readCloudAdditionalPrice(@PathVariable Long id) {
		log.info("CloudAdditionalPrice() - start");
		ReadCloudAdditionalPriceEvent request = new ReadCloudAdditionalPriceEvent().setId(id);
		EntityReadEvent<CloudAdditionalPriceDetails> event = service.readCloudAdditionalPrice(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudAdditionalPriceDetails entity = event.getEntity();
		log.info("CloudAdditionalPrice() - start");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	/*@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudAdditionalPriceResource>> readCloudAdditionalPrices(
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudAdditionalPriceDetails> pagedAssembler) {
		log.info("readCloudAdditionalPrices()  - start");
		ReadCloudAdditionalPricesEvent request = new ReadCloudAdditionalPricesEvent().setPageable(pageable);
		PageReadEvent<CloudAdditionalPriceDetails> event = service.readCloudAdditionalPrices(request);
		Page<CloudAdditionalPriceDetails> page = event.getPage();
		PagedResources<CloudAdditionalPriceResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudAdditionalPrices()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}*/
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<PagedResources<CloudAdditionalPriceResource>> readCloudAdditionalPricesByCloudServiceAndStatus(
		@RequestParam(value=QueryParameterConstants.SERVICE_ID,required=false) final Long serviceId ,
		@RequestParam(value="status",required=false) final String status ,
        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudAdditionalPriceDetails> pagedAssembler) throws Exception{
		log.info("readCloudAdditionalPricesByCloudService()  - start");
		ReadCloudAdditionalPricesEvent request = new ReadCloudAdditionalPricesEvent().setPageable(pageable).setServiceId(serviceId);
		request.setStatus(status);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudAdditionalPriceDetails> event = service.readCloudAdditionalPricesByCloudService(request);
		Page<CloudAdditionalPriceDetails> page = event.getPage();
		
		PagedResources<CloudAdditionalPriceResource> pagedResources = pagedAssembler.toResource(page, assembler);
		
		log.info("readCloudAdditionalPricesByCloudService()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
