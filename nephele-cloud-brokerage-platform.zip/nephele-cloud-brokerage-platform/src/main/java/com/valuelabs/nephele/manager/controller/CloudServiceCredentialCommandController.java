package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.jclouds.rest.AuthorizationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceCredentialDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServiceCredentialsEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceCredentialCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudServiceCredentialResource;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServiceQueryService;
import com.valuelabs.nephele.cloud.connection.factory.CloudTypes;
import com.valuelabs.nephele.cloud.service.dispatcher.ServiceDispatcher;
import com.valuelabs.nephele.manager.assembler.CloudServiceCredentialResourceAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.dispatcher.factory.CloudConnectionFactory;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/manager/serviceCredential")
@Transactional
public class CloudServiceCredentialCommandController {

	@Value("${userLogin.UNAUTHORIZED}")
	private String unauthorizedUser;
	
	@Value("${nepheleServer.service_credentials_saved}")
	private String credentialsSaved;
	
	@Value("${nepheleServer.invalid_service_credentials}")
	private String invalidServiceCredentials;
	
	@Autowired
	CloudServiceCredentialResourceAssembler assembler;

	@Autowired
	CloudServiceCredentialCommandService service;
	
	@Autowired
	CloudServiceQueryService cloudServiceQueryService;
	
	@Autowired
	@Qualifier("cloudConnectionFactory")
	CloudConnectionFactory cloudConnectionFactory;
	

	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<?> createServiceCredential(@Valid @RequestBody CloudServiceCredentialResource resource, BindingResult result) throws IllegalArgumentException {
		log.info("createServiceCredential() : START");
		 List<String> errorMessageList = new ArrayList<String>();
		 CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().build();
		if(result.hasErrors()) {
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity<CloudWebserviceErrorResource>(errorResource, HttpStatus.BAD_REQUEST);
		}
		Boolean isConnected = false;
		String message = null;
		HttpStatus statusCode = HttpStatus.CREATED;
		
		
				
		// check server connection with given credentials
		ReadServiceEvent readServiceEvent = new ReadServiceEvent().setId(resource.getServiceId());
		EntityReadEvent<CloudServiceDetails> cloudServiceDetailsEvent = cloudServiceQueryService.readService(readServiceEvent);
		CloudServiceDetails cloudServiceDetails = cloudServiceDetailsEvent.getEntity();
		String integrationCode = cloudServiceDetails.getIntegrationCode();
		
		if(integrationCode.equals(CloudTypes.rackspace.name())){
			if(resource.getAccountNumber() == null)
				errorMessageList.add("AccountNo Field must not be null");
		}
	
		if(integrationCode.equals(CloudTypes.rackspace.name()) || integrationCode.equals(CloudTypes.softlayer.name())){
			if (resource.getApiKey() == null) 
				errorMessageList.add("ApiKey Field must not be null");
		}

		if (resource.getUsername() == null) 
			errorMessageList.add("Username Field must not be null");
		
		if(integrationCode.equals(CloudTypes.nomadesk.name())){
			if(resource.getPassword() == null)
				errorMessageList.add("Password Field must not be null");
		}
		
		if (!errorMessageList.isEmpty()) {
			return new ResponseEntity<CloudWebserviceErrorResource>(errorResource.setErrorMessages(errorMessageList),HttpStatus.BAD_REQUEST);
		}
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
		try {
			isConnected = dispatchService.checkServerConnection(resource);
		} catch(AuthorizationException e){
			String errorMessage="Invalid "+cloudServiceDetails.getName()+" "+invalidServiceCredentials;
			resource.setMessage(errorMessage);
			return new ResponseEntity<CloudServiceCredentialResource>(resource,HttpStatus.BAD_REQUEST);
		}catch (Exception e) {
			log.error("Exception while saving credentials into db");
		}
		
		if(isConnected){
			CloudServiceCredentialDetails serviceCredentialDetails = assembler.fromResource(resource);
			CreateServiceCredentialsEvent request = new CreateServiceCredentialsEvent().setCloudServiceCredentialDetails(serviceCredentialDetails);

			if (request != null) {
				service.createSeviceCredetials(request);
			}
			
			resource.setMessage(credentialsSaved);
		}else{
			
			String errorMessage="Invalid "+cloudServiceDetails.getName()+" "+invalidServiceCredentials;
			resource.setMessage(errorMessage);
			return new ResponseEntity<CloudServiceCredentialResource>(resource,HttpStatus.BAD_REQUEST);
         }
		
		log.info("createServiceCredential() : END");
		return new ResponseEntity<CloudServiceCredentialResource>(resource, HttpStatus.OK);
	}

	@RequestMapping( method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceCredentialResource> updateServiceCredential(@Valid @RequestBody CloudServiceCredentialResource resource,BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info("updateServiceCredential() - start");
		Boolean isConnected = false;
		
		if(resource.getServiceCredentialId() == null){
			result.addError(new FieldError("resource", "serviceCredentialId", resource.getServiceCredentialId(), true, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudServiceCredentialResource>(resource,HttpStatus.BAD_REQUEST);
		}
		
		// check server connection with given credentials
		ReadServiceEvent readServiceEvent = new ReadServiceEvent().setId(resource.getServiceId());
		EntityReadEvent<CloudServiceDetails> cloudServiceDetailsEvent = cloudServiceQueryService.readService(readServiceEvent);
		CloudServiceDetails cloudServiceDetails = cloudServiceDetailsEvent.getEntity();
		String integrationCode = cloudServiceDetails.getIntegrationCode();
		
		ServiceDispatcher dispatchService = cloudConnectionFactory.getInstance(CloudTypes.valueOf(integrationCode));
		try {
			isConnected = dispatchService.checkServerConnection(resource);
		} catch(AuthorizationException e){
			String errorMessage="Invalid "+cloudServiceDetails.getName()+" "+invalidServiceCredentials;
			resource.setMessage(errorMessage);
			return new ResponseEntity<CloudServiceCredentialResource>(resource,HttpStatus.BAD_REQUEST);
		}catch (Exception e) {
			log.error("Exception while saving credentials into db");
		}
		
		if(isConnected){
			CloudServiceCredentialDetails serviceCredentialDetails = assembler.fromResource(resource);
			CreateServiceCredentialsEvent request = new CreateServiceCredentialsEvent().setCloudServiceCredentialDetails(serviceCredentialDetails);
			if (serviceCredentialDetails != null) {
				service.updateSeviceCredetials(request);
				resource.setMessage(credentialsSaved);
			}
		}else{
			String errorMessage="Invalid "+cloudServiceDetails.getName()+" "+invalidServiceCredentials;
			resource.setMessage(errorMessage);
			return new ResponseEntity<CloudServiceCredentialResource>(resource,HttpStatus.BAD_REQUEST);
		}
		
		log.info("updateServiceCredential() - end");
		return new ResponseEntity<CloudServiceCredentialResource>(resource, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceCredentialResource> deleteServiceCredential(@RequestBody CloudServiceCredentialResource resource) {
		log.info("deleteServiceCredential() - start");
		CloudServiceCredentialDetails serviceCredentialDetails = assembler.fromResource(resource);
		CreateServiceCredentialsEvent request = new CreateServiceCredentialsEvent().setCloudServiceCredentialDetails(serviceCredentialDetails);
		if (serviceCredentialDetails != null) {
			service.deleteSeviceCredetials(request);
		}
		log.info("deleteServiceCredential() - end");
		return new ResponseEntity<CloudServiceCredentialResource>(HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceCredentialResource> deleteById(@PathVariable("id") Long id) {
		log.info("deleteServiceCredential() - start");
		CloudServiceCredentialDetails serviceCredentialDetails = CloudServiceCredentialDetails.builder().serviceCredentialId(id).build();
		CreateServiceCredentialsEvent request = new CreateServiceCredentialsEvent().setCloudServiceCredentialDetails(serviceCredentialDetails);
		if (serviceCredentialDetails != null) {
			service.deleteById(request);
		}
		log.info("deleteServiceCredential() - end");
		return new ResponseEntity<CloudServiceCredentialResource>(HttpStatus.OK);
	}

}
