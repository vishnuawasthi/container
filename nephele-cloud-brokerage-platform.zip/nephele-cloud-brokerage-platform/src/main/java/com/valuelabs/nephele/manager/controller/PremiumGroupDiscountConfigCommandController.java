package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountConfigDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreatePremiumGroupDiscountConfigEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PremiumGroupDiscountConfigCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadPremiumGroupDiscountConfigEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ValidationException;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.PremiumGroupDiscountConfigCommandService;
import com.valuelabs.nephele.manager.assembler.PremiumGroupDiscountAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.PremiumGroupDiscountConfigResource;

@Slf4j
@RestController
@RequestMapping("/manager/PremiumGroupDiscountConfig")
@Transactional
public class PremiumGroupDiscountConfigCommandController {

	
	@Autowired
	private PremiumGroupDiscountAssembler assembler;

	@Autowired
	private PremiumGroupDiscountConfigCommandService service;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountConfigResource> createPremiumGroupDiscountConfig(
			@Valid @RequestBody PremiumGroupDiscountConfigResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createPremiumGroupDiscountConfig() : START");
		PremiumGroupDiscountConfigResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		try{
			PremiumGroupDiscountConfigDetails premiumGroupDiscountConfigDetails = assembler.fromResource(resource);
			CreatePremiumGroupDiscountConfigEvent request = new CreatePremiumGroupDiscountConfigEvent()
					.setPremiumGroupDiscountConfigDetails(premiumGroupDiscountConfigDetails);
			PremiumGroupDiscountConfigCreatedEvent eventResponse = null;
			if (request != null) {		
				eventResponse = service.createPremiumGroupDiscountConfig(request);
				responseResource = PremiumGroupDiscountConfigResource.builder().premiumGroupDiscountConfigId(eventResponse.getPremiumGroupDiscountConfigDetails().getPremiumGroupDiscountConfigId())
							.discountSheetName(eventResponse.getPremiumGroupDiscountConfigDetails().getDiscountSheetName()).build();		
			
			}			
		}catch(NepheleException | ValidationException  e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);	
			responseResource = PremiumGroupDiscountConfigResource.builder().message(message).build();
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);
			responseResource = PremiumGroupDiscountConfigResource.builder().message(message).build();
		}			
		log.info("createPremiumGroupDiscountConfig() : END");
		return new ResponseEntity<PremiumGroupDiscountConfigResource>(responseResource, statusCode);
	}
	
	/**This method updates list of the price's of the CloudProductPlan entity by accepting http requests.
	 * @param resources
	 * @return
	 * @throws ResourceNotFoundException
	 * @throws IllegalArgumentException
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountConfigResource> updatePremiumGroupDiscountConfig(@Valid @RequestBody PremiumGroupDiscountConfigResource resource, BindingResult result)
			throws ResourceNotFoundException, IllegalArgumentException {
		log.info(" updatePremiumGroupDiscountConfig() : START");
		PremiumGroupDiscountConfigResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		if(resource.getPremiumGroupDiscountConfigId() == null){
			result.addError(new FieldError("resource", "cloudLocationId shoudl not be null", resource.getPremiumGroupDiscountConfigId(), true, null, null, null));
		}
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		try{
			PremiumGroupDiscountConfigDetails details = assembler.fromResource(resource);
			CreatePremiumGroupDiscountConfigEvent request = new CreatePremiumGroupDiscountConfigEvent().setPremiumGroupDiscountConfigDetails(details);
			if (request != null) {		
				service.updatePremiumGroupDiscountConfig(request);
				message = "PremiumGroupDiscountConfig updated successfully";
			}
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = PremiumGroupDiscountConfigResource.builder().message(message).build();
		log.info("updatePremiumGroupDiscountConfig(): END");
		return new ResponseEntity<PremiumGroupDiscountConfigResource>(responseResource, statusCode);
	}
	
	@RequestMapping(value="/schedule", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountConfigResource> schedulePremiumGroupDiscountConfig(@RequestParam(value = "id", required=false) Long configId, @RequestParam(value = "eventName", required=false) String eventName
			, @RequestParam(value = "comments", required=false) String comments
			, @RequestParam(value = "customDate", required=false) String customDate)
			throws ResourceNotFoundException, IllegalArgumentException {
		log.info(" schedulePremiumGroupDiscountConfig() : START");
		PremiumGroupDiscountConfigResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		try{
			ReadPremiumGroupDiscountConfigEvent request=new ReadPremiumGroupDiscountConfigEvent().setId(configId).setScheduleType(eventName).setComments(comments).setCustomDate(customDate);				
			if (request != null) {
				service.schedulePremiumGroupDiscountConfig(request);
				message = "PremiumGroupDiscountConfig scheduled successfully";
			}
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = PremiumGroupDiscountConfigResource.builder().message(message).build();
		log.info("schedulePremiumGroupDiscountConfig(): END");
		return new ResponseEntity<PremiumGroupDiscountConfigResource>(responseResource, statusCode);
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
	public HttpEntity<PremiumGroupDiscountConfigResource> deletePremiumGroupDiscountConfig( @PathVariable Long id) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("deletePremiumGroupDiscountConfig() - START");
		if(id == null) {
			return new ResponseEntity<PremiumGroupDiscountConfigResource>(HttpStatus.BAD_REQUEST);
		}
		PremiumGroupDiscountConfigDetails details = PremiumGroupDiscountConfigDetails.builder().premiumGroupDiscountConfigId(id).build();
		CreatePremiumGroupDiscountConfigEvent request = new CreatePremiumGroupDiscountConfigEvent().setPremiumGroupDiscountConfigDetails(details);
		service.deletePremiumGroupDiscountConfig(request);
		log.info("deletePremiumGroupDiscountConfig() - END");
		return new ResponseEntity<PremiumGroupDiscountConfigResource>(HttpStatus.OK);
	}
	
	
}
