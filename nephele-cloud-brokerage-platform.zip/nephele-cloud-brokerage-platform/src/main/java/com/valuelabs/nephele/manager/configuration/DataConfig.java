package com.valuelabs.nephele.manager.configuration;

import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.data.web.config.HateoasAwareSpringDataWebConfiguration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;

@Configuration
public class DataConfig extends HateoasAwareSpringDataWebConfiguration {
	@Override
	public void addArgumentResolvers(
			List<HandlerMethodArgumentResolver> argumentResolvers) {
		PageableHandlerMethodArgumentResolver pageableResolver=new PageableHandlerMethodArgumentResolver();
		//Edit the below to change the size.
		/*pageableResolver.setMaxPageSize(2000);*/
		//pageableResolver.setOneIndexedParameters(true);
		argumentResolvers.add(pageableResolver);
		super.addArgumentResolvers(argumentResolvers);
	}
}
