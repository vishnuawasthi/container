package com.valuelabs.nephele.manager.resource;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class CloudUserRolePermissionsResource {

	private Long roleId;
	private String roleName;
	private List <CloudManagerAppPermissionResource> permissions;
}
