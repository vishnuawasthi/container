package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudProductPriceManagementSheetResource extends ResourceSupport {
	   
	    private Long productPriceManagementSheetId;	    
		private Double price;
		private String status;
		private Long priceManagementConfigId;
		private Long cloudProductPlanId;
		private String sheetName;
		private CloudProductPlanDetails planDetails;
		private Double vendorPrice;
		
	
}
