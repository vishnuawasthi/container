package com.valuelabs.nephele.marketplace.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.RelatedCloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.resource.RelatedCloudProductResource;
import com.valuelabs.nephele.marketplace.controller.RelatedCloudProductQueryController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RelatedCloudProductAssembler extends ResourceAssemblerSupport<RelatedCloudProductDetails, RelatedCloudProductResource>{
	
	public RelatedCloudProductAssembler() {
		super(RelatedCloudProductQueryController.class, RelatedCloudProductResource.class);
	}
	
	@Override
	public RelatedCloudProductResource toResource(RelatedCloudProductDetails details) {
		log.debug("toResource() : START");
		RelatedCloudProductResource resource= instantiateResource(details);
	
		resource= RelatedCloudProductResource.builder()
												.relatedCloudproductId(details.getId())
												.productId(details.getCloudProductId())
												//.productId(details.getId())
												//.cloudproductId(details.getCloudProductId())
												.relatedCloudproducts(details.getRelatedCloudProducts())
												.cloudProductName(details.getCloudProductName())
												.cloudproductDes(details.getCloudproductDes())
												.relatedCloudproductId(details.getRelatedCloudProductId())
												.relatedProductName(details.getRelatedProductName())
												.relatedProductDes(details.getRelatedProductDes())
												.serviceId(details.getServiceId())
												.serviceName(details.getServiceName())
												.status(details.getStatus())
												.cloudProductDetails(details.getCloudProductDetails())
											    .build();
		
		resource.add(linkTo(methodOn(RelatedCloudProductQueryController.class).readRelatedCloudProduct(details.getId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}
	
	public RelatedCloudProductDetails fromResource(RelatedCloudProductResource resource){
		log.debug("fromResource() - START");
		RelatedCloudProductDetails relatedCloudProductDetails=RelatedCloudProductDetails.builder()
																	.id(resource.getRelatedCloudproductId())
																	.cloudProductId(resource.getProductId())
																	.relatedCloudProducts(resource.getRelatedCloudproducts())
																	.build();
		log.debug("fromResource() - END");
		return relatedCloudProductDetails;
		
	}
	
}

