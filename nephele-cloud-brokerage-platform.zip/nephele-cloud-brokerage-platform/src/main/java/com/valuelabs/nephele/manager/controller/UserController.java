package com.valuelabs.nephele.manager.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.MessagingException;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorUserDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudUserRoleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudUserRoleEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserRoleQueryService;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceSuccessResource;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.manager.assembler.CloudDistributorUserAssembler;
import com.valuelabs.nephele.manager.assembler.CloudManagerAppPermissionAssembler;
import com.valuelabs.nephele.manager.resource.CloudDistributorUserResource;
import com.valuelabs.nephele.manager.resource.CloudUserLoginResource;
import com.valuelabs.nephele.manager.resource.CloudUserRolePermissionsResource;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by snagaboina on 25/8/15.
 */
@Slf4j
@RestController
public class UserController {

  @Autowired
  CloudUserService service;
  @Value("${userLogin.UNAUTHORIZED}")
  private String unauthorizedUser;
  @Autowired
  private CloudDistributorUserAssembler assembler;
  @Autowired
  private CloudUserRoleQueryService cloudUserRoleQueryService ;
  @Autowired
  private CloudManagerAppPermissionAssembler permissionsAssembler;
  
  @Autowired
  private NepheleUtils nepheleUtils;

  @RequestMapping(value = "/login", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<?> login(@Valid @RequestBody CloudUserLoginResource resource, BindingResult result, HttpServletRequest request
      , HttpServletResponse response) throws MessagingException, IOException {
    log.info("UserTransmitted# :" + resource.getEmail());
    List<String> errorMessageList = new ArrayList<String>();
    if(result.hasErrors()) {
		List<FieldError> errors = result.getFieldErrors();
		for (FieldError fieldError : errors) {
			errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
		}
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
		return new ResponseEntity<CloudWebserviceErrorResource>(errorResource, HttpStatus.BAD_REQUEST);
	}
    CloudDistributorUserDetails distributorUserDetails = service.getUserByUserName(resource.getEmail());
    if(null == distributorUserDetails){
    	errorMessageList.add(unauthorizedUser);
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
    	return new ResponseEntity<CloudWebserviceErrorResource>(errorResource, HttpStatus.UNAUTHORIZED);
    }
    
    if (null != distributorUserDetails && null != distributorUserDetails.getPassword()
        && resource.getPassword().equals(nepheleUtils.decrypt(distributorUserDetails.getPassword()))) {
    	
    	ReadCloudUserRoleEvent permissionsRequest = new ReadCloudUserRoleEvent().setRoleId(distributorUserDetails.getUserRoleId());
    	EntityReadEvent<CloudUserRoleDetails> event = cloudUserRoleQueryService.readRolePermissions(permissionsRequest);
    	if (!event.isFound()) {
    		errorMessageList.add(unauthorizedUser);
    		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
    		return new ResponseEntity<CloudWebserviceErrorResource>(errorResource, HttpStatus.UNAUTHORIZED);
    	}
    	
    	CloudUserRoleDetails details = event.getEntity();
    	CloudUserRolePermissionsResource userPermissionsResource = permissionsAssembler.buildCloudUserRolePermissionsResource(details); 
    	
    	CloudDistributorUserResource responseResource = assembler.toResource(distributorUserDetails);
    	responseResource.setPermissions(userPermissionsResource.getPermissions());
    	return new ResponseEntity<CloudDistributorUserResource>(responseResource, HttpStatus.OK);
    } else{
    	errorMessageList.add(unauthorizedUser);
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
    	return new ResponseEntity<CloudWebserviceErrorResource>(errorResource, HttpStatus.UNAUTHORIZED);
    }
      
  }

  @RequestMapping(value = "/globalLogout", method = RequestMethod.GET)
  public ResponseEntity logout(HttpServletRequest request) throws MessagingException, IOException {
    String apiKey = request.getHeader(NepheleConstants.API_KEY);
    // User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    service.updateUserLogoutDetail(apiKey);
    return new ResponseEntity(HttpStatus.OK);
  }

  @RequestMapping(value = "/forgetPassword", method = RequestMethod.POST)
  public ResponseEntity forgetPassword(@RequestBody CloudDistributorUserResource resource) throws MessagingException, IOException {
    log.info("UserTransmittedEmail# :" + resource.getEmail());
    service.generateResetPasswordLink(resource.getEmail());
    return new ResponseEntity(HttpStatus.OK);
  }


  @RequestMapping(value = "/resetPassword", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<CloudDistributorUserResource> resetPasswordView(@RequestParam(value = "_key") String resetPasswordToken) {
    CloudDistributorUserDetails details = service.getUserByPasswordResetToken(resetPasswordToken);
    if (null != details && null != details.getResetPasswordToken() && null != details.getResetPasswordExpireTime()
        && details.getResetPasswordExpireTime().after(new Date()))
      return new ResponseEntity<CloudDistributorUserResource>(assembler.toResource(details), HttpStatus.OK);
    else
      return new ResponseEntity<CloudDistributorUserResource>(HttpStatus.NO_CONTENT);
  }

  @RequestMapping(value = "/resetPassword", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<CloudDistributorUserResource> resetPassword(@RequestBody CloudDistributorUserResource resource) {
    log.info("Reset Password Start # " + resource.getEmail() + "  UserPassword# " + resource.getConfirmPassword());
    CloudDistributorUserDetails details = assembler.fromResource(resource);
    if (service.updateUserPasswordDetail(details))
      return new ResponseEntity<CloudDistributorUserResource>(HttpStatus.OK);
    else
      return new ResponseEntity<CloudDistributorUserResource>(HttpStatus.NO_CONTENT);
  }

  @RequestMapping(value = "/changePassword", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<?> changePassword(@Valid @RequestBody  CloudDistributorUserResource resource,BindingResult result) {
    log.info("change Password Start #  New Password : "
    		+ "  " + resource.getNewPassword() + "  Confirm Password # " + resource.getConfirmPassword());
    if(resource.getDistributorId()==null) {
    	result.addError(new FieldError("resource", "distributorId",  resource.getDistributorId(), false, null, null, "Missing required field"));
    }
    
    if (StringUtils.isEmpty(resource.getNewPassword()) || StringUtils.isEmpty(resource.getConfirmPassword()) || StringUtils.isEmpty(resource.getOldPassword())) {
    	result.addError(new FieldError("resource", "",  null, false, null, null, "New password or Confirm  password or Old password should not be empty."));
    }
    
    if (StringUtils.isEmpty(resource.getNewPassword()) || StringUtils.isEmpty(resource.getConfirmPassword())) {
    	result.addError(new FieldError("resource", "",  null, false, null, null, "New password or confirm  password should not be empty."));
    }
    
    if (!StringUtils.isEmpty(resource.getNewPassword()) && !StringUtils.isEmpty(resource.getConfirmPassword())) {
    	if (! resource.getNewPassword().equals( resource.getConfirmPassword())) {
    		result.addError(new FieldError("resource", "",  null, false, null, null, "New password and confirm  password did not match"));
    	}
    }
    
    List<String> messageList = new ArrayList<String>();
    /*if(result.hasErrors()) {
		List<FieldError> errors = result.getFieldErrors();
		for (FieldError fieldError : errors) {
			errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
		}
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
		return new ResponseEntity<CloudWebserviceErrorResource>(errorResource, HttpStatus.BAD_REQUEST);
	}*/
    CloudDistributorUserDetails details = assembler.fromResource(resource);
    details.setUpdateFlag(false);
    details = service.changePassword(details);
	if(resource.getUpdateFlag()){
		messageList.add("Success");
		CloudWebserviceSuccessResource errorResource = CloudWebserviceSuccessResource.builder().successMessages(messageList).build();
		return new ResponseEntity<CloudDistributorUserResource>(HttpStatus.OK);
	}
	else{
		messageList.add("Invalid Password");
    	CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(messageList).build();
    	return new ResponseEntity<CloudWebserviceErrorResource>(errorResource,HttpStatus.BAD_REQUEST);
	}
    	
    }
}
