package com.valuelabs.nephele.marketplace.controller;

import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_CUSTOMER_KEY;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_RESELLER_KEY;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudOrderEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudOrdersEvent;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudOrderQueryService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.marketplace.assembler.CloudOrderAssembler;
import com.valuelabs.nephele.marketplace.resource.CloudOrderResource;

@Slf4j
@RestController
@RequestMapping("/")
public class CloudOrderQueryController {

	@Autowired
	private CloudOrderAssembler assembler;

	@Autowired
	private CloudOrderQueryService service;

	/**
	 * This method will get a single record from DB by passing id.
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "marketplace/orders/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudOrderResource> readCloudOrder(
			@PathVariable Long id) {
		log.info("readCloudOrder() START");
		EntityReadEvent<CloudOrderDetails> event = null;
		if (id != null) {
			ReadCloudOrderEvent request = new ReadCloudOrderEvent().setOrderId(id);
			event = service.readServiceOrder(request);
		}
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudOrderDetails entity = event.getEntity();
		log.info("readCloudOrder() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	/**
	 * This method will get total existing records from DB and also custom records by passing the required parameters using pagination.
	 * 
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "marketplace/orders",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudOrderResource>> readOrdersByStatusOrderIdAndDateRange(
					@RequestParam(required = false) String status, 
					@RequestParam(required = false) Long orderId,
					@RequestParam(required = false) String orderCode,
					@RequestParam(value = X_CUSTOMER_KEY, required = false) String externalCustomerCode,
					@RequestHeader(value = X_RESELLER_KEY , required = false) String externalResellerCode,
					@RequestParam(required = false) Date dateRangeStart,
					@RequestParam(required = false) Date dateRangeEnd,
		            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
		            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
					@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
					PagedResourcesAssembler<CloudOrderDetails> pagedAssembler) {
		
		log.info("readOrdersByStatusOrderIdAndDateRange() START");
		if(!StringUtils.isEmpty(dateRangeStart)) {
			List<String> errorMessageList = new ArrayList<String>();
			if (StringUtils.isEmpty(dateRangeEnd)) {
					errorMessageList.add("End Date should not be empty ");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}

			if (dateRangeStart.compareTo(dateRangeEnd) > 0) {
					errorMessageList.add("Start Date should not be greater than End Date");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}
		}
		ReadCloudOrdersEvent request = new ReadCloudOrdersEvent().setStatus(status)
																 .setCloudOrderId(orderId)
																 .setOrderCode(orderCode)
																 .setExternalCustomerCode(externalCustomerCode)
																 .setDateRangeStart(dateRangeStart)
																 .setDateRangeEnd(dateRangeEnd)
																 .setExternalResellerCode(externalResellerCode);
  		request.setSortColumnName(sortColumnName);
  		request.setSortDirection(sortDirection);
  		request.setPageable(pageable);
		PageReadEvent<CloudOrderDetails> event = service.readServiceOrdersByStatusAndDateRange(request);
		Page<CloudOrderDetails> page = event.getPage();
		PagedResources<CloudOrderResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readOrdersByStatusOrderIdAndDateRange() END");
		
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/orders/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudOrderResource> readOrder(
			@PathVariable Long id) {
		log.info("readService() START");

		ReadCloudOrderEvent request = new ReadCloudOrderEvent().setOrderId(id);

		EntityReadEvent<CloudOrderDetails> event = service
				.readServiceOrder(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudOrderDetails entity = event.getEntity();
		log.info("readService() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/orders", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudOrderResource>> readServices(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@RequestParam(value=QueryParameterConstants.STATUS,required=false) String status,
			@RequestParam(value=QueryParameterConstants.ORDER_ID,required=false)Long orderId,
			@RequestParam(value=QueryParameterConstants.ORDER_CODE,required=false)String orderCode,
			@RequestParam(value=QueryParameterConstants.SERVICE_TYPE,required=false)String serviceType,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudOrderDetails> pagedAssembler) {
		log.info("readServices() START");
		ReadCloudOrdersEvent request = new ReadCloudOrdersEvent();
		
		// Building search Criteria
		request.setPageable(pageable);
		request.setStatus(status);
		request.setCloudOrderId(orderId);
		request.setOrderCode(orderCode);
		request.setServiceType(serviceType);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);

		PageReadEvent<CloudOrderDetails> event = service.readServiceOrdersByStatusAndDateRange(request);

		Page<CloudOrderDetails> page = event.getPage();
		PagedResources<CloudOrderResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readServices() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
