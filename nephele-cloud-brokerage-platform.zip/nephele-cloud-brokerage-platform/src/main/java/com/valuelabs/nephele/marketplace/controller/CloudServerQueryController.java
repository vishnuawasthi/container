package com.valuelabs.nephele.marketplace.controller;

import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_CUSTOMER_KEY;
import static com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants.X_RESELLER_KEY;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.CLOUD_SERVICE_PROVIDER_ID;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.EXTERNAL_RESELLER_CODE;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SERVER_DESCRIPTION;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SERVICE_CATEGORY_ID;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SERVICE_ID;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServerEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServersEvent;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudProductPlanQueryService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServerQueryService;
import com.valuelabs.nephele.marketplace.assembler.CloudServerAssembler;
import com.valuelabs.nephele.marketplace.resource.CloudServerDetailsResource;
import com.valuelabs.nephele.marketplace.resource.CloudServerResource;
import com.valuelabs.nephele.marketplace.resource.Summary;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/marketplace/servers")
public class CloudServerQueryController {

	@Autowired
	private CloudServerAssembler assembler;

	@Autowired
	private CloudServerQueryService service;
	
	@Autowired
	CloudProductPlanQueryService productPlanQueryService;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServerDetailsResource> readCloudServer(@PathVariable Long id) {
		log.info("readCloudServer() - start");

		ReadServerEvent request = new ReadServerEvent().setServerId(id);

		EntityReadEvent<CloudServerDetails> event = service.readServer(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudServerDetails entity = event.getEntity();
		log.info("readCloudServer() - end");
		return new ResponseEntity<CloudServerDetailsResource>(assembler.toResource_details(entity), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServerResource>> readCloudServers(
			@RequestParam(value=CLOUD_SERVICE_PROVIDER_ID,required=false) Long providerId,
			@RequestParam(value=SERVICE_CATEGORY_ID  ,required=false)Long categoryId,
			@RequestParam(value = EXTERNAL_RESELLER_CODE, required=false) String externalResellerCode,
			@RequestParam(value = SERVICE_ID, required=false) Long serviceId,
			@RequestParam(value = SERVER_DESCRIPTION, required=false) String serverDescription,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		    @PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readCloudServers() - start");
		ReadServersEvent request = new ReadServersEvent().setPageable(pageable);
		
		// Search Criteria
		request.setCategoryId(categoryId);
		request.setProviderId(providerId);
		request.setExternalResellerCode(externalResellerCode);
		request.setServiceId(serviceId);
		request.setDescription(serverDescription);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudServerDetails> event = service.readServers(request);
		Page<CloudServerDetails> page = event.getPage();
		PagedResources<CloudServerResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudServers() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

	/**
	 * 
	 * @param customerId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	/*@RequestMapping(value = "/summaryByCustomerId/{customerId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Summary> readServerSummaryByCustomer(@PathVariable Long customerId ,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readCustumerSummary() -start");
		ReadServersEvent request = new ReadServersEvent().setCustomerId(customerId);
		Map<String, Long> event = service.readServerSummaryByCustomer(request);
		Summary summary=Summary.builder().summary(event).build();
		log.info("readCustumerSummary() -end");
		return new ResponseEntity<>(summary, HttpStatus.OK);
	}*/

	/**
	 * This method returns details of Cloud server based on order id
	 * @param orderId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
    //value = "/readServerByOrderId", 
	@RequestMapping(value = "/serversByOrderId/{orderId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServerResource>> readServerByOrderId(
			@PathVariable Long orderId,
	        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
	        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerByOrderId() -start");
		ReadServersEvent request = new ReadServersEvent().setOrderId(orderId);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		request.setPageable(pageable);
		PageReadEvent<CloudServerDetails> event = service.readServerByOrderId(request);
		Page<CloudServerDetails> page = event.getPage();
		PagedResources<CloudServerResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServerByOrderId() -end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param customerId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/serversByCustomerId/{customerId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServerResource>> readServerByCustomerId(
			@PathVariable Long customerId,
		    @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
	        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerByCustomerId() -start");
		ReadServersEvent request = new ReadServersEvent().setCustomerId(customerId);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		request.setPageable(pageable);
		PageReadEvent<CloudServerDetails> event = service.readServerByCustomerId(request);
		Page<CloudServerDetails> page = event.getPage();
		PagedResources<CloudServerResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServerByCustomerId() -end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * This method will get the results from DB by passing required parameters using pagination. 
	 * @param status
	 * @param orderId
	 * @param dateRangeStart
	 * @param dateRangeEnd
	 * @param name
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	//@RequestParam(value=QueryParameterConstants.CLOUD_SERVICE_PROVIDER_ID,required=false) Long providerId,
	//@RequestParam(value=QueryParameterConstants.SERVICE_CATEGORY_ID  ,required=false)Long categoryId,
	
	@RequestMapping(value = "/reseller", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServerResource>> readServerByStatusNameAndDateRange(
			@RequestHeader(value = X_RESELLER_KEY, required=true) String resellerCode,
			@RequestParam(value=CLOUD_SERVICE_PROVIDER_ID,required=false) Long providerId,
			@RequestParam(value=SERVICE_CATEGORY_ID  ,required=false)Long categoryId,
			@RequestParam(value = SERVICE_ID, required=false) Long serviceId,
			@RequestParam(required = false) String status, 
			@RequestParam(required = false) Long orderId,
			@RequestParam(required = false) String orderCode,
			@RequestParam(required = false) Date dateRangeStart,
			@RequestParam(required = false) Date dateRangeEnd, 
			@RequestParam(required = false) String name,
			@RequestParam(required =  false) String serverDescription,
			@RequestParam(value = X_CUSTOMER_KEY, required=false) String externalCustomerCode,
		    @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
	        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, 
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerByStatusNameAndDateRange() -START");
		
		if(!StringUtils.isEmpty(dateRangeStart)) {
			List<String> errorMessageList = new ArrayList<String>();
			if (StringUtils.isEmpty(dateRangeEnd)) {
					errorMessageList.add("End Date should not be empty ");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}

			if (dateRangeStart.compareTo(dateRangeEnd) > 0) {
					errorMessageList.add("Start Date should not be greater than End Date");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}
		}
		
		ReadServersEvent request = new ReadServersEvent().setStatus(status).setOrderId(orderId).setOrderCode(orderCode).setName(name);
		request.setResellerCode(resellerCode);
		request.setExternalCustomerCode(externalCustomerCode);
		request.setDateRangeStart(dateRangeStart);
		request.setDateRangeEnd(dateRangeEnd);
		request.setPageable(pageable);
		request.setProviderId(providerId);
		request.setCategoryId(categoryId);
		request.setServiceId(serviceId);
		request.setDescription(serverDescription);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudServerDetails> event = service.readServerByStatusAndDateRange(request);
		Page<CloudServerDetails> page = event.getPage();
		PagedResources<CloudServerResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServerByStatusNameAndDateRange() -END");
		
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * This method will get the results from DB by passing required parameters using pagination.
	 * @param status
	 * @param orderId
	 * @param dateRangeStart
	 * @param dateRangeEnd
	 * @param name
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/customer", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServerResource>> readServerByStatusAndDateRange
	(       @RequestParam(required = false) String status,
			@RequestParam(required = false) Long orderId,
			@RequestParam(required = false) String orderCode,
			@RequestParam(required = false) Date dateRangeStart,
			@RequestParam(required = false) Date dateRangeEnd, 
			@RequestParam(required = false) String name,
			@RequestParam(required =  false) String serverDescription,
			@RequestParam(value = SERVICE_ID, required=false) Long serviceId,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
		    @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, 
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerByStatusAndDateRange() -START");
		
		if(!StringUtils.isEmpty(dateRangeStart)) {
			List<String> errorMessageList = new ArrayList<String>();
			if (StringUtils.isEmpty(dateRangeEnd)) {
					errorMessageList.add("End Date should not be empty ");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}

			if (dateRangeStart.compareTo(dateRangeEnd) > 0) {
					errorMessageList.add("Start Date should not be greater than End Date");
					CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
					return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
			}
		}
		ReadServersEvent request = new ReadServersEvent().setStatus(status).setOrderId(orderId).setOrderCode(orderCode).setName(name)
				.setDateRangeStart(dateRangeStart).setDateRangeEnd(dateRangeEnd).setServiceId(serviceId).setDescription(serverDescription);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		request.setPageable(pageable);
		PageReadEvent<CloudServerDetails> event = service.readServerByStatusAndDateRange(request);
		Page<CloudServerDetails> page = event.getPage();
		PagedResources<CloudServerResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServerByStatusAndDateRange() -END");
		
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * This method return summary based on the customerCompanyCode, It is
	 * accepted as the form of request header
	 * 
	 * @param customerCode
	 *            , Name of the request parameter
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/summary/customer", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Summary> readServerSummaryByCustomer(
			@RequestHeader(value = X_CUSTOMER_KEY, required = true) String externalCustomerCode,
			@RequestParam(value = SERVICE_ID, required=true) Long serviceId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerSummaryByCustomerCode() -start");
		ReadServersEvent request = new ReadServersEvent();
		request.setExternalCustomerCode(externalCustomerCode);
		request.setServiceId(serviceId);
		
		Map<String, Long> event = service.readServerSummaryByCustomerCode(request);
		Summary summary = Summary.builder().summary(event).build();
		log.info("readServerSummaryByCustomerCode() -end");
		return new ResponseEntity<>(summary, HttpStatus.OK);
	}

	/**
	 * This method return summary based on the resellerCode, It is accepted as
	 * the form of request header
	 * 
	 * @param resellerCode
	 *            ,Name of the request parameter
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/summary/reseller", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String,Long>> readServerSummaryByReseller(
			@RequestHeader(value = X_RESELLER_KEY, required = true) String resellerCode,
			@RequestParam(value = X_CUSTOMER_KEY, required=false) String externalCustomerCode,
			@RequestParam(value = SERVICE_ID, required=true) Long serviceId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServerSummaryByResellerCode() -start");
		ReadServersEvent request = new ReadServersEvent();
		// Search Criteria
		request.setResellerCode(resellerCode);
		request.setExternalCustomerCode(externalCustomerCode);
		request.setServiceId(serviceId);
		
		Map<String, Long> event = service.readServerSummaryByResellerCode(request);
		//Summary summary = Summary.builder().summary(event).build();
		log.info("readServerSummaryByResellerCode() -end");
		return new ResponseEntity<>(event, HttpStatus.OK);
	}
	
	/**
	 * This method  returns servers status and vendor status  searched by servers id.
	 * @param serversId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/status", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CloudServerResource>> readServerStatusAndVendorStatus(
			@RequestParam(value="serversId") List<Long> serversId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServerDetails> pagedAssembler) {
		log.info("readServersAndVendorStatus() -start");
		ReadServersEvent request = new ReadServersEvent().setServersId(serversId);
		List<CloudServerDetails> detailsList = null;
		if(!CollectionUtils.isEmpty(serversId) ) {
		  detailsList = service.readServersAndVendorStatus(request);
		}
		log.info("readServersAndVendorStatus() -end");
		return new ResponseEntity<>(assembler.toResourceList(detailsList), HttpStatus.OK);
	}

}
