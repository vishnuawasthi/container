package com.valuelabs.nephele.manager.validation;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;

public interface CloudRackspaceConfigurationValidationService {
	Boolean isValidToPublishFlavor(CloudRackspaceConfigurationDetails details) throws ResourceNotFoundException,IllegalArgumentException;
}
