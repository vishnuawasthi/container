package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.JobTypes;
import com.valuelabs.nephele.admin.data.api.NepheleCurrency;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRateEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRatesEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCurrencyConversionRateQueryService;
import com.valuelabs.nephele.manager.assembler.CloudCurrencyConversionRateAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudCurrencyConversionRateResource;
import com.valuelabs.nephele.manager.resource.CurrencyListResources;
import com.valuelabs.nephele.manager.resource.JobTypeResources;

import static  com.valuelabs.nephele.manager.constants.QueryParameterConstants.*;


@Slf4j
@RestController
@RequestMapping("/manager/currencyConversionRate")
public class CloudCurrencyConversionRateQueryController {
  
  @Autowired
  private CloudCurrencyConversionRateAssembler assembler;
  
  @Autowired
  private CloudCurrencyConversionRateQueryService service;
  
  
  @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudCurrencyConversionRateResource> readCloudCurrencyConversionRate(@PathVariable Long id) {
		log.info("readCloudCurrencyConversionRate() - start");
		ReadCloudCurrencyConversionRateEvent request=new ReadCloudCurrencyConversionRateEvent().setId(id);
		EntityReadEvent<CloudCurrencyConversionRateDetails> event = service.readCloudCurrencyConversionRate(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudCurrencyConversionRateDetails entity = event.getEntity();
		log.info("readCloudCurrencyConversionRate() - end");
		return new ResponseEntity<CloudCurrencyConversionRateResource>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudCurrencyConversionRateResource>> readCloudCurrencyConversionRates(
			@RequestParam(value=QueryParameterConstants.STATUS,required=false) String status,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudCurrencyConversionRateDetails> pagedAssembler) {
		log.info("readCloudCurrencyConversionRates() - start");
		ReadCloudCurrencyConversionRatesEvent request=new ReadCloudCurrencyConversionRatesEvent().setPageable(pageable);
		request.setStatus(status);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudCurrencyConversionRateDetails> event=service.readCloudCurrencyConversionRates(request);

		Page<CloudCurrencyConversionRateDetails> page=event.getPage();
		PagedResources<CloudCurrencyConversionRateResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudCurrencyConversionRates() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

	@RequestMapping(value = "/currencyList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CurrencyListResources> readCurrencyList() {
		log.info("readCurrencyList() START");
		
		CurrencyListResources response= CurrencyListResources.builder().currencyList((EnumUtils.getEnumList(NepheleCurrency.class))).build();
		log.info("readCurrencyList() END");
		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
  
  
}
