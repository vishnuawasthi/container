package com.valuelabs.nephele.marketplace.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.RackspaceServerConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateRackspaceServerConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.RackspaceServerConfigurationCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.service.RackspaceServerConfigurationCommandService;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.RackspaceServerConfigurationAssembler;
import com.valuelabs.nephele.marketplace.resource.RackspaceServerConfigurationResource;

@Slf4j
@RestController
@Transactional
@RequestMapping(value = "/marketplace/rackspaceServerConfiguration")
public class RackspaceServerConfigurationCommandController {

	@Autowired
	private RackspaceServerConfigurationAssembler assember;

	@Autowired
	private RackspaceServerConfigurationCommandService service;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RackspaceServerConfigurationResource> createRackspaceServerConfiguration(
		@Valid	@RequestBody RackspaceServerConfigurationResource resource,BindingResult result)  throws IllegalArgumentException{
		log.info("createRackspaceServerConfiguration - START");
		if(result.hasErrors()) {
			return new ResponseEntity<RackspaceServerConfigurationResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		RackspaceServerConfigurationDetails details = assember.fromResource(resource);
		CreateRackspaceServerConfigurationEvent request = new CreateRackspaceServerConfigurationEvent()
				.setRackspaceServerConfigurationDetails(details);
		if (null != details) {
			RackspaceServerConfigurationCreatedEvent event = service.createRackspaceServerConfiguration(request);
		}
		log.info("createRackspaceServerConfiguration - END");
		return new ResponseEntity<RackspaceServerConfigurationResource>(HttpStatus.CREATED);
	}
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<RackspaceServerConfigurationResource> upateRackspaceServerConfiguration(
		@Valid	@RequestBody RackspaceServerConfigurationResource resource,BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("upateRackspaceServerConfiguration - START");
		if (resource.getRackspaceServerConfigurationId() == null) {
			result.addError(new FieldError("resource", "rackspaceServerConfigurationId", resource.getRackspaceServerConfigurationId(), false, null, null,
					null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<RackspaceServerConfigurationResource>(resource, HttpStatus.BAD_REQUEST);
		}
		RackspaceServerConfigurationDetails details = assember.fromResource(resource);
		CreateRackspaceServerConfigurationEvent request = new CreateRackspaceServerConfigurationEvent()
				.setRackspaceServerConfigurationDetails(details);
		if (null != details) {
			RackspaceServerConfigurationCreatedEvent event = service.upateRackspaceServerConfiguration(request);
		}
		log.info("upateRackspaceServerConfiguration - END");
		return new ResponseEntity<RackspaceServerConfigurationResource>(HttpStatus.OK);
	}
	
	
	
	
}
