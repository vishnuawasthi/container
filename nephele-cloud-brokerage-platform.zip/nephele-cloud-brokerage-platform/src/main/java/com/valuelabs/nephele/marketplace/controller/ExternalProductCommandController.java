package com.valuelabs.nephele.marketplace.controller;

import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.CREATE_EXTERNAL_PRODUCT_DATA_ROUTING_KEY;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.UPDATE_EXTERNAL_PRODUCT_ROUTING_KEY;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.EXCHANGE_NAME;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.service.ExternalProductsQueryService;
import com.valuelabs.nephele.marketplace.resource.ExternalProductResource;
import com.valuelabs.nephele.marketplace.resource.ExternalProductResources;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/manager/externalProduct")
public class ExternalProductCommandController {
	
	@Autowired
	RabbitTemplate rabbitTemplate;
	
	@Autowired
	ExternalProductsQueryService externalProductsQueryService;
	
	
	@RequestMapping(value="/sync",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<ExternalProductResources> syncExternalProducts(@Valid @RequestBody ExternalProductResources resources,BindingResult result) throws IllegalArgumentException {
		log.info("syncExternalProducts()  - start");
		List<ExternalProductDetails> details = fromResource(resources);
		List<ExternalProductDetails> listToSave = new ArrayList<ExternalProductDetails>(); 
		List<ExternalProductDetails> listToUpdate = new ArrayList<ExternalProductDetails>();
		ReadExternalProductEvent request = new ReadExternalProductEvent();
		EntityReadEvent<ExternalProductDetails> response = null;
		CreateExternalProductEvent createRequest = new CreateExternalProductEvent();
		CreateExternalProductEvent updateRequest = new CreateExternalProductEvent();
		if (!CollectionUtils.isEmpty(details)) {
			for (int index = 0; index < details.size(); index++) {
				ExternalProductDetails productDetails = details.get(index);
				request.setExternalId(productDetails.getExternalId());
				response = externalProductsQueryService.readExternalProductByExternalId(request);
				
				if (!response.isFound()) {
					listToSave.add(productDetails);
				}else{
					productDetails.setExternalProductId(response.getEntity().getExternalProductId());
					listToUpdate.add(productDetails);
				}
				
			}
		}
		if(!CollectionUtils.isEmpty(listToSave)) {
			createRequest.setExternalProducts(listToSave);
			createRequest.setToSaveFlag(true);
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, CREATE_EXTERNAL_PRODUCT_DATA_ROUTING_KEY, createRequest);
		}
		
		if(!CollectionUtils.isEmpty(listToUpdate)) {
			updateRequest.setExternalProducts(listToUpdate);
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, UPDATE_EXTERNAL_PRODUCT_ROUTING_KEY, updateRequest);
		}
		
		log.info("syncExternalProducts()  - end");
		return new ResponseEntity<ExternalProductResources>(HttpStatus.CREATED);
	}
	
	public List<ExternalProductDetails> fromResource(ExternalProductResources resources){
		
		List<ExternalProductResource> externalProducts = resources.getExternalProducts();
		List<ExternalProductDetails> externalProductsDetails = new ArrayList<>();
		for(ExternalProductResource resource:externalProducts){
			ExternalProductDetails productDetails = ExternalProductDetails.builder().externalProductId(resource.getExternalProductId())
					                                                                .brandName(resource.getBrandName())
																					.description(resource.getShortDescription())
																					.externalId(resource.getExternalID())
																					.categoryName(resource.getCategoryName())
																					.productName(resource.getName())
																					.categoryName(resource.getCategoryName())
																					.status(resource.getStatus())
																					.type(resource.getType())
																					.build();
			externalProductsDetails.add(productDetails);	
		}
		return externalProductsDetails;
		
		
	}
	
}
