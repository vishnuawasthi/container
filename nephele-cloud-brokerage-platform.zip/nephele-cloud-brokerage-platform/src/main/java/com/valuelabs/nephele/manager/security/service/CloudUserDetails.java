package com.valuelabs.nephele.manager.security.service;

import java.util.ArrayList;
import java.util.Collection;

import lombok.extern.slf4j.Slf4j;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.valuelabs.nephele.admin.data.entity.CloudDistributorUser;
import com.valuelabs.nephele.admin.data.entity.CloudUserRole;

@Slf4j
public class CloudUserDetails extends CloudDistributorUser implements UserDetails {

  private static final long serialVersionUID = 1L;

  public CloudUserDetails(CloudDistributorUser cloudDistributorUser) {
    log.debug("CloudUserDetails() - start");
    this.setId(cloudDistributorUser.getId());
    //this.setDistributorName(cloudDistributorUser.getDistributorName());
    this.setEmail(cloudDistributorUser.getEmail());
    this.setPassword(cloudDistributorUser.getPassword());
    this.setUserRole(cloudDistributorUser.getUserRole());
    log.debug("CloudUserDetails() - end");
  }

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    log.debug("getAuthorities() - start");
    Collection<GrantedAuthority> authorities = new ArrayList<>();
    CloudUserRole role = this.getUserRole();
    SimpleGrantedAuthority authority = new SimpleGrantedAuthority(role.getRoleName().toUpperCase());
    authorities.add(authority);
    log.debug("getAuthorities() - end");
    return authorities;
  }

  @Override
  public String getUsername() {
    return this.getEmail();
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return true;
  }

}
