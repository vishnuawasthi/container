package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerUserDetails;
import com.valuelabs.nephele.manager.controller.CloudResellerUserQueryController;
import com.valuelabs.nephele.manager.resource.CloudResellerUserResource;

@Slf4j
@Service
public class CloudResellerUserAssembler
		extends
		ResourceAssemblerSupport<CloudResellerUserDetails, CloudResellerUserResource> {

	

	public CloudResellerUserAssembler() {
		super(CloudResellerUserQueryController.class, CloudResellerUserResource.class);
	}

	@Override
	public CloudResellerUserResource toResource(
			CloudResellerUserDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + entity);
		CloudResellerUserResource resource = instantiateResource(entity);

		resource = CloudResellerUserResource.builder()
				.resellerUserId(entity.getResellerUserId())
				.resellerUserName(entity.getResellerUserName())
				.resellerCompanyId(entity.getResellerCompanyId())
				.build();
		resource.add(linkTo(
				methodOn(CloudResellerUserQueryController.class)
						.readCloudResellerUser(entity.getResellerUserId()))
				.withSelfRel());
				
		log.debug("toResource() : resource : " + resource);
		log.debug("toResource() : resource Links: " + resource.getLinks());
		log.debug("toResource() : END");
		return resource;

	}

	public CloudResellerUserDetails fromResouce(
			CloudResellerUserResource resource) {
		log.debug("fromResource: START:{} ",resource);
		CloudResellerUserDetails details = CloudResellerUserDetails
				.builder()
				.resellerUserId(resource.getResellerUserId())
				.resellerUserName(resource.getResellerUserName())
				.resellerCompanyId(resource.getResellerCompanyId())
				.build();
		log.debug("fromResouce: END");
		return details;
	}
}
