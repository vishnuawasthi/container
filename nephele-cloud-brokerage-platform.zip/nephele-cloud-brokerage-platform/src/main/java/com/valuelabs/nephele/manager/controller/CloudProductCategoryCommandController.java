/*package com.valuelabs.nephele.manager.controller;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductCategoryDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudProductCategoryEvent;
import com.valuelabs.nephele.manager.assembler.CloudProductCategoryAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudProductCategoryResource;
import com.valuelabs.nephele.manager.service.CloudProductCategoryCommandService;

@Slf4j
@RestController
@RequestMapping("/manager/productCategory")
public class CloudProductCategoryCommandController {

	@Autowired
	private CloudProductCategoryAssembler assembler;

	@Autowired
	private CloudProductCategoryCommandService commandService;

	*//**
	 * This method will accept http request object to create new records in the
	 * DB.
	 * 
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 *//*
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductCategoryResource> createProductCategory(
			@Valid @RequestBody CloudProductCategoryResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createProductCategory() : START");
		if (result.hasErrors()) {
			return new ResponseEntity<CloudProductCategoryResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudProductCategoryDetails slabDiscountDetails = assembler
				.fromResource(resource);
		CreateCloudProductCategoryEvent request = new CreateCloudProductCategoryEvent()
				.setCloudProductCategoryDetails(slabDiscountDetails);
		if (request != null) {
			commandService.createProductCategoryService(request);
		}
		log.info("createProductCategory() : END");
		return new ResponseEntity<CloudProductCategoryResource>(
				HttpStatus.CREATED);
	}

	*//**
	 * This method updates the existing record in the DB by accepting id.
	 * 
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 * @throws ResourceNotFoundException
	 *//*
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductCategoryResource> updateProductCategoryById(
			@Valid @RequestBody CloudProductCategoryResource resource,
			BindingResult result) throws IllegalArgumentException,
			ResourceNotFoundException {
		log.info("updateProductCategoryById() : START");
		if (resource.getProductCategoryId() == null) {
			result.addError(new FieldError("resource",
					"cloudProductCategoryId", resource
							.getProductCategoryId(), false, null, null,
					null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudProductCategoryResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudProductCategoryDetails discountDetails = assembler
				.fromResource(resource);
		CreateCloudProductCategoryEvent request = new CreateCloudProductCategoryEvent()
				.setCloudProductCategoryDetails(discountDetails);
		if (request != null) {
			commandService.updateProductCategoryByIdService(request);
		}
		log.info("updateProductCategoryById() : END");
		return new ResponseEntity<CloudProductCategoryResource>(HttpStatus.OK);
	}

}
*/