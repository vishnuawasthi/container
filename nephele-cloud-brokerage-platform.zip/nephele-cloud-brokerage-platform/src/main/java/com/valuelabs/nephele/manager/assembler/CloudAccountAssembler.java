package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionDetails;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import com.valuelabs.nephele.manager.controller.CloudAccountQueryController;
import com.valuelabs.nephele.manager.resource.CloudAccountResource;
import com.valuelabs.nephele.manager.resource.CloudServiceResource;
import com.valuelabs.nephele.manager.resource.CloudSubscriptionResource;

@Slf4j
@Service
public class CloudAccountAssembler extends ResourceAssemblerSupport<CloudAccountDetails, CloudAccountResource> {

	@Autowired
	CloudSubscriptionAssembler subscriptionAssembler;
	
	List<CloudSubscriptionResource> subscriptionResourceList = null;
	
  public CloudAccountAssembler() {
	super(CloudAccountQueryController.class, CloudAccountResource.class);
  }
  @Override
  public CloudAccountResource toResource(CloudAccountDetails entity) {
	log.debug("toResource() - start");
	subscriptionResourceList = new ArrayList<CloudSubscriptionResource>();
	CloudAccountResource resource = instantiateResource(entity);
	resource = CloudAccountResource.builder()
                            		.accountId(entity.getId())
                            		.vendorAccountId(entity.getVendorAccountId())
                            		.vendorStatus(entity.getVendorStatus())
                            		.nepheleStatus(entity.getNepheleStatus())
                            		.username(entity.getUsername())
                            		.password(entity.getPassword())
                            		.superPassword(entity.getSuperPassword())
                            		.superUsername(entity.getSuperUsername())
                            		.superAPIKey(entity.getSuperAPIKey())
                            		.customerCompanyId(entity.getCloudCustomerCompanyId())
                            		.customerCompanyName(entity.getCloudCustomerCompanyName())
                            		.orderId(entity.getOrderId())
                            		.orderCode(entity.getOrderCode())
                            		.trialAccount(entity.getIsTrialAccount())
                            		.monthlyLicenseCount(entity.getMonthlyLicenseCount())
                            		.yearlyLicenseCount(entity.getYearlyLicenseCount())
                            		.isTrial(entity.getIsTrial())
                            		.provisionDate(entity.getProvisionDate())
                            		.build();
	
	CloudServiceResource  serviceResource = CloudServiceResource.builder()
                                                      		    .serviceId(entity.getCloudServiceId())
                                                      		    .name(entity.getCloudServiceName())
                                                      		    .isLive( entity.getIsLive())
                                                      		    .isPublished(entity.getIsPublished())
                                                      		    .description(entity.getDescription())
                                                      		    .integrationCode(entity.getIntegrationCode())
                                                      		    .serviceCode(entity.getServiceCode())
                                                      		    .vendorCode(entity.getVendorCode())
                                                      		    .billingCycle(entity.getBillingCycle())
                                                      		    .billingDay(entity.getBillingDay())
                                                      		    .planPrefix(entity.getPlanPrefix())
                                                      		    .subscriptionNamePrefix(entity.getSubscriptionNamePrefix())
                                                      		    .vendorCurrency(entity.getVendorCurrency())
                                                      		    .build();
	
	List<CloudSubscriptionDetails> subscriptionDetailsList = entity.getSubscriptionDetails();
	for (CloudSubscriptionDetails details : NepheleValidationUtils.nullSafe(subscriptionDetailsList)) {
		CloudSubscriptionResource subscriptionresource = subscriptionAssembler.toResource(details);
		subscriptionResourceList.add(subscriptionresource);
	}
	
	resource.setServiceDetails(serviceResource);
	resource.setSubscriptionDetails(subscriptionResourceList);
	resource.add(linkTo(methodOn(CloudAccountQueryController.class).readCloudAccount(entity.getId())).withSelfRel());
	log.debug("toResource() - end");
	return resource;
  }
  
  
  public CloudAccountDetails fromResource(CloudAccountResource resource ) {
	log.debug("fromResource() - start");
	CloudAccountDetails details = CloudAccountDetails.builder()
                                            		.id(resource.getAccountId())
                                            		.vendorAccountId(resource.getVendorAccountId())
                                            		.vendorStatus(resource.getVendorStatus())
                                            		.nepheleStatus(resource.getNepheleStatus())
                                            		.username(resource.getUsername())
                                            		.password(resource.getPassword())
                                            		.superPassword(resource.getSuperPassword())
                                            		.superUsername(resource.getSuperUsername())
                                            		.superAPIKey(resource.getSuperAPIKey())
                                            		.cloudCustomerCompanyId(resource.getCustomerCompanyId())
                                            		.cloudCustomerCompanyName(resource.getCustomerCompanyName())
                                            		.cloudServiceId(resource.getServiceId())
                                            		.cloudServiceName(resource.getServiceName())
                                            		.orderId(resource.getOrderId())
                                            		.isTrial(resource.getIsTrial())
                                            		.provisionDate(resource.getProvisionDate())
                                            		.build();
	log.debug("fromResource() - end");
	return details;
  }

}
