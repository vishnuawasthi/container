package com.valuelabs.nephele.manager.constants;


public enum FlavorClasses {

	STANDARD1,
	GENERAL1,
	IO1,
	PERFORMANCE1;
	
}
