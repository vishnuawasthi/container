package com.valuelabs.nephele.marketplace.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.FLAG_PLAN_CATEGORIES;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.FLAG_PLAN_LOCATION;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.FLAG_PLAN_OS;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.HAS_RELATED_PRODUCTS;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.IS_FEATURED;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.LOCATION_ID;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.PRODUCT_ID;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.PRODUCT_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SERVER_ID;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SERVICE_ID;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.STATUS;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.BundleStatus;
import com.valuelabs.nephele.admin.data.api.FlavourTypes;
import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAdditionalPriceDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductAdditionalChargeDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.Properties;
import com.valuelabs.nephele.admin.rest.lib.event.EntitiesReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundleEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundlesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAdditionalPricesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlanEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlansEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductsEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadOperatingSystemEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRackspaceConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServerEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudLocationQueryService;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudRackspaceConfigurationQueryService;
import com.valuelabs.nephele.admin.rest.lib.marketplace.service.CloudProductPlanQueryService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResources;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudProductResource;
import com.valuelabs.nephele.admin.rest.lib.service.BundleQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudAdditionalPriceQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudOperatingSystemQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudProductQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServerQueryService;
import com.valuelabs.nephele.manager.assembler.CloudOperatingSystemAssembler;
import com.valuelabs.nephele.manager.assembler.CloudProductPlanAssembler;
import com.valuelabs.nephele.manager.assembler.CloudRackspaceConfigurationAssembler;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;
import com.valuelabs.nephele.manager.resource.CloudLocationResources;
import com.valuelabs.nephele.manager.resource.CloudProductPlanResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResources;
import com.valuelabs.nephele.manager.resource.PlansResource;
import com.valuelabs.nephele.manager.resource.ProductPlanResource;
import com.valuelabs.nephele.manager.util.MemoryUnitConverterUtil;
import com.valuelabs.nephele.marketplace.assembler.BundleAssembler;
import com.valuelabs.nephele.marketplace.assembler.CloudProductAssembler;
import com.valuelabs.nephele.marketplace.resource.BundleResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/")
public class CloudProductQueryController {

	@Autowired
	CloudProductAssembler assembler;
	@Autowired 
	CloudProductPlanAssembler cloudProductPlanAssembler;
	@Autowired
  CloudProductQueryService service;
  @Autowired
  CloudServerQueryService cloudServerQueryService;
  @Autowired
  CloudLocationQueryService cloudLocationQueryService;
  @Autowired
  CloudProductPlanQueryService productPlanQueryService;
  @Autowired
  CloudOperatingSystemQueryService cloudOperatingSystemQueryService;
  @Autowired
  CloudOperatingSystemAssembler cloudOperatingSystemAssembler;
  @Autowired
  private CloudRackspaceConfigurationAssembler configAssembler;
  @Autowired
  private CloudRackspaceConfigurationQueryService cloudRackspaceConfigurationQueryService;
  @Autowired
	private CloudAdditionalPriceQueryService additionalPriceService;
	
	
	@Autowired
	private CloudProductPlanAssembler planAssembler;

	@Autowired
	private CloudProductPlanQueryService planService;
	
	@Autowired
	private BundleQueryService bundleQueryService;
	
	@Autowired
	private BundleAssembler bundleAssembler;
	
	@Autowired
	private CloudProductQueryService cloudProductQueryService;
	
	@Autowired
	private CloudProductAssembler cloudProductAssembler;
	
	@Autowired
	private CloudProductPlanAssembler productPlanAssembler;

	@RequestMapping(value = "marketplace/products/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductResource> readCloudProduct(@PathVariable Long id){
		log.info("readCloudProduct() START");
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(id);

		EntityReadEvent<CloudProductDetails> event = service.readPublishedCloudProducts(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudProductDetails entity=event.getEntity();
		log.info("readCloudProduct() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	/*@RequestMapping(value = "/products/{id}/plans", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductPlanResource> readCloudProductPlans(@PathVariable Integer id){
		log.info("readCloudProduct() START");
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(id);
		List<CloudRackspaceConfigurationDetails> configDetailsList = null;
		List<CloudProductAdditionalChargeDetails> additionalChargeList = new ArrayList<CloudProductAdditionalChargeDetails>();
		FlavorClassResource flavorClassResource = null;

		EntityReadEvent<CloudProductDetails> event = service.readCloudProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		//Product details build
		CloudProductDetails entity=event.getEntity();
		CloudProductResource productDetailsResource = assembler.toResource(entity);
		
		// Configuration/flavor details build
		ReadOperatingSystemEvent configRequest = new ReadOperatingSystemEvent().setOperatingSystemId(entity.getOperatingSystemId());
		EntitiesReadEvent<CloudRackspaceConfigurationDetails> configDetails = null;
		try {
			configDetails = cloudRackspaceConfigurationQueryService.readRackspaceConfigurationByOsId(configRequest);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(null != configDetails){
			configDetailsList = configDetails.getEntities();
			flavorClassResource = configAssembler.toResources_forConfiguration(configDetailsList);
		}
		
		//Locations build
		ReadCloudLocationsEvent locationRequest = new ReadCloudLocationsEvent();
		locationRequest.setName("SYD");
		locationRequest.setStatus("PUBLISHED");
		EntitiesReadEvent<CloudLocationDetails> locationsByStatus = cloudLocationQueryService.findByNameNStatus(locationRequest);
		List<CloudLocationResource> locationResource = configAssembler.toResources_forLocation(locationsByStatus.getEntities());
		
		//Additonal charges build
		CloudProductAdditionalChargeDetails  addtChargeDetails = CloudProductAdditionalChargeDetails.builder().id(1).name("Bandwith Out Per GB").price("0.2").build();
		additionalChargeList.add(addtChargeDetails);
		
		PlansResource plansResource = PlansResource.builder().locations(locationResource).flavors(flavorClassResource).build();
		
		log.info("readCloudProduct() END");
		return new ResponseEntity<>(assembler.toResources_forProductPlans(productDetailsResource, plansResource, additionalChargeList), HttpStatus.OK);
	}*/
	
	/*@RequestMapping(value = "/products/{productId}/plans", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductPlanResource> readCloudProductPlansByProduct(@PathVariable Integer productId) throws Exception{
		log.info("readCloudProduct() START");
		
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(productId);
		List<CloudProductAdditionalChargeDetails> additionalChargeList = new ArrayList<CloudProductAdditionalChargeDetails>();

		EntityReadEvent<CloudProductDetails> event = service.readCloudProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		//Building Product resource details
		CloudProductDetails entity=event.getEntity();
		CloudProductResource productDetailsResource = assembler.toResource(entity);
		
		//Building plans resource details
		ReadCloudProductPlanEvent readPlanEvent = new ReadCloudProductPlanEvent().setProductId(productId);
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readPublishedProductPlansByProductId(readPlanEvent);
		List<PlansResource> planResourceList = buildProductPlans(productPlanDetailsReadEvent);
		
		//Building Additional charges resource details
		CloudProductAdditionalChargeDetails  addtChargeDetails = CloudProductAdditionalChargeDetails.builder().id(1).name("Bandwith Out Per GB").price("0.2").build();
		additionalChargeList.add(addtChargeDetails);
		
		log.info("readCloudProduct() END");
		return new ResponseEntity<>(assembler.toResources_forProductPlans(productDetailsResource, planResourceList, additionalChargeList), HttpStatus.OK);
	}*/
	
	/*@RequestMapping(value = "/products/{productId}/plans/locations/{locationId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductPlanResource> readCloudProductPlansByProductAndLocation(@PathVariable Integer productId, @PathVariable Integer locationId) throws Exception{
		log.info("readCloudProduct() START");
		
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(productId);
		List<CloudProductAdditionalChargeDetails> additionalChargeList = new ArrayList<CloudProductAdditionalChargeDetails>();

		EntityReadEvent<CloudProductDetails> event = service.readCloudProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		//Building Product resource details
		CloudProductDetails entity=event.getEntity();
		CloudProductResource productDetailsResource = assembler.toResource(entity);
		
		//Building plans resource details
		ReadCloudProductPlanEvent readPlanEvent = new ReadCloudProductPlanEvent().setProductId(productId).setLocationId(locationId);
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readProductPlansByProductIdAndLocationId(readPlanEvent);
		List<PlansResource> planResourceList = buildProductPlans(productPlanDetailsReadEvent);
		
		//Building Additional charges resource details
		CloudProductAdditionalChargeDetails  addtChargeDetails = CloudProductAdditionalChargeDetails.builder().id(1).name("Bandwith Out Per GB").price("0.2").build();
		additionalChargeList.add(addtChargeDetails);
		
		log.info("readCloudProduct() END");
		return new ResponseEntity<>(assembler.toResources_forProductPlans(productDetailsResource, planResourceList, additionalChargeList), HttpStatus.OK);
	}*/
	
	/*@RequestMapping(value = "/products/{productId}/plans/locations/{locationId}/category/{flavorCategory}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductPlanResource> readCloudProductPlansByProdcutNLocNCategory(@PathVariable Integer productId, 
			@PathVariable Integer locationId, @PathVariable String flavorCategory) throws Exception{
		log.info("readCloudProduct() START");
		
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(productId);
		List<CloudProductAdditionalChargeDetails> additionalChargeList = new ArrayList<CloudProductAdditionalChargeDetails>();

		EntityReadEvent<CloudProductDetails> event = service.readCloudProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		//Building Product resource details
		CloudProductDetails entity=event.getEntity();
		CloudProductResource productDetailsResource = assembler.toResource(entity);
		
		//Building plans resource details
		ReadCloudProductPlanEvent readPlanEvent = new ReadCloudProductPlanEvent().setProductId(productId).setLocationId(locationId).setFlavorCategory(flavorCategory);
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readProductPlansByProductIdAndLocationIdAndFlvCategory(readPlanEvent);
		List<PlansResource> planResourceList = buildProductPlans(productPlanDetailsReadEvent);
		
		//Building Additional charges resource details
		CloudProductAdditionalChargeDetails  addtChargeDetails = CloudProductAdditionalChargeDetails.builder().id(1).name("Bandwith Out Per GB").price("0.2").build();
		additionalChargeList.add(addtChargeDetails);
		
		log.info("readCloudProduct() END");
		return new ResponseEntity<>(assembler.toResources_forProductPlans(productDetailsResource, planResourceList, additionalChargeList), HttpStatus.OK);
	}*/
	

	/**
	 * This method return all the productPlan as requested by  query parameters
	 * @param productId
	 * @param serviceId
	 * @param locationId
	 * @param flavorCategory
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "marketplace/products/{productId}/plans", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductPlanResource> readProductsByLocationAndCategory(
		@PathVariable(value = PRODUCT_ID)Long productId, 
		@RequestParam(value = SERVICE_ID,required=false) Long serviceId, 
		@RequestParam(value = LOCATION_ID, required = false) Long locationId, 
		@RequestParam(value = "flavorCategory",required = false) String flavorCategory,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection
		
		) throws Exception{
		log.info("readProductsByLocationAndCategory() - start");
		List<CloudProductAdditionalChargeDetails> additionalChargeList = new ArrayList<CloudProductAdditionalChargeDetails>();
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(productId);
		EntityReadEvent<CloudProductDetails> event = service.readPublishedCloudProducts(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		//Building Product resource details
		CloudProductDetails entity=event.getEntity();
		CloudProductResource productDetailsResource = assembler.toResource(entity);
		
		//Building plans resource details
		ReadCloudProductPlansEvent readPlanEvent = new ReadCloudProductPlansEvent();
		readPlanEvent.setProductId(productId);
		readPlanEvent.setLocationId(locationId);
		readPlanEvent.setFlavorCategory(flavorCategory);
		readPlanEvent.setServiceId(serviceId);
		readPlanEvent.setSortColumnName(sortColumnName);
		readPlanEvent.setSortDirection(sortDirection);
		
		
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readProductPlansByProductIdAndLocationIdAndFlvCategory(readPlanEvent);
		
		
		List<PlansResource> planResourceList = buildProductPlans(productPlanDetailsReadEvent,null);
		
		ReadCloudAdditionalPricesEvent additionalPriceRequst = 		new ReadCloudAdditionalPricesEvent();
		
		// Criteria for Additional price
		
		additionalPriceRequst.setServiceId(productDetailsResource.getServiceId());
		additionalPriceRequst.setStatus("PUBLISHED");
		PageReadEvent<CloudAdditionalPriceDetails> additionalPriceEvent = additionalPriceService.readAdditionalForProducts(additionalPriceRequst);
		
		Page<CloudAdditionalPriceDetails> page = additionalPriceEvent.getPage();
		List <CloudAdditionalPriceDetails> priceList = page.getContent();
		
		if(!CollectionUtils.isEmpty(priceList)) {
			CloudProductAdditionalChargeDetails additionalChargeDetails =  CloudProductAdditionalChargeDetails.builder().build();
																			CloudAdditionalPriceDetails cloudAdditionalPriceDetails= priceList.get(0);
																			additionalChargeDetails.setId(cloudAdditionalPriceDetails.getAdditionalPriceId());
																			additionalChargeDetails.setName(cloudAdditionalPriceDetails.getName());
																			additionalChargeDetails.setPrice(cloudAdditionalPriceDetails.getPrice().toString());
																			additionalChargeList.add(additionalChargeDetails);
		}
		
		log.info("readProductsByLocationAndCategory() -end");
		return new ResponseEntity<>(assembler.toResources_forProductPlans(productDetailsResource, planResourceList, additionalChargeList), HttpStatus.OK);
	}
	
	/**
	 * This method return all the productPlan as requested by  query parameters
	 * @param productId
	 * @param serviceId
	 * @param locationId
	 * @param flavorCategory
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "marketplace/servers/{serverId}/resizePlans", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<PlansResource>> readProductResizePlans(
		@PathVariable(value = SERVER_ID)Long serverId,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection) throws Exception{
		log.info("readProductResizePlans() - start");
		ReadServerEvent request = new ReadServerEvent().setServerId(serverId);

		EntityReadEvent<CloudServerDetails> event = cloudServerQueryService.readServer(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		List<PlansResource> planResourceList = new ArrayList<PlansResource>();
		
		CloudServerDetails entity = event.getEntity();
		
		ReadCloudProductEvent readCloudProductEvent = new ReadCloudProductEvent().setCloudProductId(entity.getProductId());
		EntityReadEvent<CloudProductDetails> cloudProductEntityReadEvent = cloudProductQueryService.readCloudProduct(readCloudProductEvent);
		
		CloudProductDetails cloudProductDetails = cloudProductEntityReadEvent.getEntity();
		
		CloudProductResource cloudProductResource  = cloudProductAssembler.toResource(cloudProductDetails);
	
		if(cloudProductResource !=null) {
		  cloudProductResource.setStartingPlan(null);
		}
		
		
		if(entity.getFlavorCategory().equals(FlavourTypes.io1.name())){
			return new ResponseEntity<>(planResourceList, HttpStatus.OK);
		}
		//Building plans resource details
		ReadCloudProductPlansEvent readPlanEvent = new ReadCloudProductPlansEvent();
		readPlanEvent.setProductId(entity.getProductId());
		readPlanEvent.setLocationId(entity.getLocationId());
		readPlanEvent.setFlavorCategory(entity.getFlavorCategory());
		readPlanEvent.setServiceId(entity.getCloudServiceId());
		readPlanEvent.setRam(entity.getPlanRam());
		
		readPlanEvent.setSortColumnName(sortColumnName);
		readPlanEvent.setSortDirection(sortDirection);
		
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readProductPlansByProductIdAndLocationIdAndFlvCategory(readPlanEvent);
		planResourceList = buildProductPlans(productPlanDetailsReadEvent,cloudProductResource);
		
		log.info("readProductResizePlans() -end");
		return new ResponseEntity<>(planResourceList, HttpStatus.OK);
	}

	/**
	 * This method return all  filtered  os details 
	 * @param productId
	 * @param serviceId , Service id  , its a filter  query parameter
	 * @param locationId , Location id, It is an filter query parameter
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "marketplace/products/{productId}/plansOS", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudOperatingSystemResources> planOS(
		@PathVariable(value = PRODUCT_ID)Long productId, 
		@RequestParam(value = SERVICE_ID,required=false) Long serviceId,
		@RequestParam(value = LOCATION_ID, required = false) Long locationId,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection) throws Exception{
		log.info("planOS() - start");
		//List<CloudProductAdditionalChargeDetails> additionalChargeList = new ArrayList<CloudProductAdditionalChargeDetails>();
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(productId);
		EntityReadEvent<CloudProductDetails> event = service.readPublishedCloudProducts(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		//Building search criteria
		ReadCloudProductPlansEvent readPlanEvent = new ReadCloudProductPlansEvent();
		readPlanEvent.setProductId(productId);
		readPlanEvent.setLocationId(locationId);
		readPlanEvent.setServiceId(serviceId);
		readPlanEvent.setSortColumnName(sortColumnName);
		readPlanEvent.setSortDirection(sortDirection);
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readProductPlansByProductIdAndLocationIdAndFlvCategory(readPlanEvent);

		List<PlansResource> planResourceList = buildProductOnDemand(productPlanDetailsReadEvent,"plansOS");
		
		CloudOperatingSystemResources cloudOperatingSystemResources =  CloudOperatingSystemResources.builder().build();
 		List <CloudOperatingSystemResource> resourceList = new ArrayList<CloudOperatingSystemResource>();
 		
 		if (!CollectionUtils.isEmpty(planResourceList)) {
 		  					for (PlansResource resource : planResourceList) {
 		  					resourceList.add(resource.getOs());
 		        }
	      }
 		cloudOperatingSystemResources.setPlanOperatingSystems(resourceList);
		log.info("planOS() -end");
		return new ResponseEntity<>(cloudOperatingSystemResources, HttpStatus.OK);
	}
	
	/**
	 * This method return all  filtered  os details 
	 * @param productId
	 * @param serviceId , Service id  , its a filter  query parameter
	 * @param locationId , Location id, It is an filter query parameter
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "manager/productPlan/plansOS", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudOperatingSystemResources> managerPlanOS(
		    @RequestParam(value = SERVICE_ID, required=false) Long serviceId,
			@RequestParam(value=STATUS, required = false) String status,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
	        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection	) throws Exception{
		log.info("managerPlanOS() - start");

		ReadCloudProductPlansEvent request = new ReadCloudProductPlansEvent();
		
		// Building Search Criteria
		request.setServiceId(serviceId);
		request.setStatus(status); 
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		 
		EntitiesReadEvent<CloudProductPlanDetails> planDetailsReadEvent = productPlanQueryService.readProductPlansServiceForFilter(request);

		List<PlansResource> planResourceList = buildProductOnDemand(planDetailsReadEvent,"plansOS");
		
		CloudOperatingSystemResources cloudOperatingSystemResources =  CloudOperatingSystemResources.builder().build();
 		List <CloudOperatingSystemResource> resourceList = new ArrayList<CloudOperatingSystemResource>();
 		
 		if (!CollectionUtils.isEmpty(planResourceList)) {
 		  					for (PlansResource resource : planResourceList) {
 		  					resourceList.add(resource.getOs());
 		        }
	    }
 		cloudOperatingSystemResources.setPlanOperatingSystems(resourceList);
 		
		log.info("managerPlanOS() -end");
		return new ResponseEntity<>(cloudOperatingSystemResources, HttpStatus.OK);
	}
	
	/**
	 * This method return all the location associated to product plan
	 * @param productId 
	 * @param serviceId , Service Id is an filter query parameter
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "marketplace/products/{productId}/planLocations", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudLocationResources> planLocation(
			@PathVariable(value = PRODUCT_ID)Long productId, 
			@RequestParam(value = SERVICE_ID,required=false) Long serviceId) throws Exception{
		log.info("planLocation() - start");
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(productId);
		EntityReadEvent<CloudProductDetails> event = service.readPublishedCloudProducts(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		//Building search criteria
		ReadCloudProductPlansEvent readPlanEvent = new ReadCloudProductPlansEvent();
		readPlanEvent.setProductId(productId);
		readPlanEvent.setServiceId(serviceId);
		CloudLocationResources cloudLocationResources = CloudLocationResources.builder().build();
		List<CloudLocationResource> locationResoruceList = new ArrayList<CloudLocationResource>();
		
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readProductPlansByProductIdAndLocationIdAndFlvCategory(readPlanEvent);
		List<PlansResource> planResourceList =  buildProductOnDemand(productPlanDetailsReadEvent,"planLocations");;
		
		if(!CollectionUtils.isEmpty(planResourceList)) {
		  for( PlansResource resource  : planResourceList) {
			locationResoruceList.add(resource.getLocation());
		  }
		}
		cloudLocationResources.setPlanLocations(locationResoruceList);
		
		log.info("planLocation() -end");
		return new ResponseEntity<>(cloudLocationResources, HttpStatus.OK);
	}
	
	/**
	 * This method return all the location associated to product plan
	 * @param productId 
	 * @param serviceId , Service Id is an filter query parameter
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "manager/productPlan/planLocations", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudLocationResources> managerPlanLocation(
		@RequestParam(value = SERVICE_ID, required=false) Long serviceId,
		@RequestParam(value=STATUS,required=false)String status,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection) throws Exception{
		log.info("managerPlanLocation() - start");
		List<CloudLocationResource> locationResoruceList = new ArrayList<CloudLocationResource>();
		ReadCloudProductPlansEvent request = new ReadCloudProductPlansEvent();
		
		// Building Search Criteria
		request.setServiceId(serviceId);
		request.setStatus(status); 
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		 
		EntitiesReadEvent<CloudProductPlanDetails> planDetailsReadEvent = productPlanQueryService.readProductPlansServiceForFilter(request);
		List<PlansResource> planResourceList = buildProductOnDemand(planDetailsReadEvent,"planLocations");
		
		if(!CollectionUtils.isEmpty(planResourceList)) {
			  for( PlansResource resource  : planResourceList) {
				locationResoruceList.add(resource.getLocation());
			  }
		}
		
		CloudLocationResources cloudLocationResources = CloudLocationResources.builder().planLocations(locationResoruceList).build();
		
		log.info("managerPlanLocation() -end");
		return new ResponseEntity<>(cloudLocationResources, HttpStatus.OK);
	}
	
	/**
	 * This method return all the categories associated to a plan
	 * @param productId
	 * @param serviceId ,Service id is an filter query parameter
	 * @return
	 * @throws Exception
	 */
	/**
	 * @param productId
	 * @param serviceId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "marketplace/products/{productId}/planCategories", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudRackspaceConfigurationResources> planCategories(
		@PathVariable(value = PRODUCT_ID)Long productId, 
		@RequestParam(value = SERVICE_ID,required=false) Long serviceId,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection

		) throws Exception{
		log.info("planCategories() - start");
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(productId);
		EntityReadEvent<CloudProductDetails> event = service.readPublishedCloudProducts(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		//Building search criteria
		ReadCloudProductPlansEvent readPlanEvent = new ReadCloudProductPlansEvent();
		readPlanEvent.setProductId(productId);
		readPlanEvent.setServiceId(serviceId);
		
		readPlanEvent.setSortColumnName(sortColumnName);
		readPlanEvent.setSortDirection(sortDirection);
		
		EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent = productPlanQueryService.readProductPlansByProductIdAndLocationIdAndFlvCategory(readPlanEvent);
		List<PlansResource> planResourceList =  buildProductOnDemand(productPlanDetailsReadEvent,"plansCategories");
		
		List <CloudRackspaceConfigurationResource> categoriesList = new ArrayList<CloudRackspaceConfigurationResource>();
		CloudRackspaceConfigurationResources cloudRackspaceConfigurationResources = CloudRackspaceConfigurationResources.builder().build();
		
		if(!CollectionUtils.isEmpty(planResourceList)) {
		  for( PlansResource resource :planResourceList) {
			categoriesList.add(resource.getFlavor());
		  }
		}
		 cloudRackspaceConfigurationResources.setPlanCategories(categoriesList);
		log.info("planCategories() -end");
		return new ResponseEntity<>(cloudRackspaceConfigurationResources, HttpStatus.OK);
	}
	
	/**
	 * This method return all the categories associated to a plan
	 * @param productId
	 * @param serviceId ,Service id is an filter query parameter
	 * @return
	 * @throws Exception
	 */
	/**
	 * @param productId
	 * @param serviceId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "manager/productPlan/planCategories", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudRackspaceConfigurationResources> managerPlanCategories(
		    @RequestParam(value = SERVICE_ID, required=false) Long serviceId,
			@RequestParam(value=STATUS,required=false)String status,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection
		) throws Exception{
		log.info("managerPlanCategories() - start");

		ReadCloudProductPlansEvent request = new ReadCloudProductPlansEvent();
		
		// Building Search Criteria
		request.setServiceId(serviceId);
		request.setStatus(status); 
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		 
		EntitiesReadEvent<CloudProductPlanDetails> planDetailsReadEvent = productPlanQueryService.readProductPlansServiceForFilter(request);
		List<PlansResource> planResourceList = buildProductOnDemand(planDetailsReadEvent,"plansCategories");
		
		List <CloudRackspaceConfigurationResource> categoriesList = new ArrayList<CloudRackspaceConfigurationResource>();
		CloudRackspaceConfigurationResources cloudRackspaceConfigurationResources = CloudRackspaceConfigurationResources.builder().build();
		
		if(!CollectionUtils.isEmpty(planResourceList)) {
		  for( PlansResource resource :planResourceList) {
			categoriesList.add(resource.getFlavor());
		  }
		}
		 cloudRackspaceConfigurationResources.setPlanCategories(categoriesList);
		log.info("managerPlanCategories() -end");
		return new ResponseEntity<>(cloudRackspaceConfigurationResources, HttpStatus.OK);
	}
	
	
  /**
   * This  is an convenience method for building the resource object as per requirement  
   * @param productPlanDetailsReadEvent
   * @param callflag, An flag which indicates  resource type which is being built
   * @return
   */
  private List<PlansResource> buildProductOnDemand(
	  EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent, String callflag) {
	log.info("buildProductOnDemand() - start");
	
	List<PlansResource> planResourceList = new ArrayList<PlansResource>();

	if (null != productPlanDetailsReadEvent && !CollectionUtils.isEmpty(productPlanDetailsReadEvent.getEntities())) {
	  List<CloudProductPlanDetails> productPlanDetailsList = productPlanDetailsReadEvent.getEntities();
	  for (CloudProductPlanDetails record : productPlanDetailsList) {
		PlansResource plansResource = PlansResource.builder().build();
		
		if (FLAG_PLAN_OS.equals(callflag)) {
			CloudOperatingSystemResource osResource = CloudOperatingSystemResource.builder().operatingSystemId(record.getOperatingSystemId())
																							.name(record.getOperatingSystemName())
																							.build();
		    plansResource.setOs(osResource);
		}
		
		if (FLAG_PLAN_LOCATION.equals(callflag)) {
		    CloudLocationResource locationResource = CloudLocationResource.builder()
			                                       .locationId(record.getLocationId())
			                                       .name(record.getLocationName()).build();
		   plansResource.setLocation(locationResource);
		}

		if (FLAG_PLAN_CATEGORIES.equals(callflag)) {
		  
		    ReadRackspaceConfigurationEvent configReadEvent = new ReadRackspaceConfigurationEvent().setRackspaceConfigurationId(record.getFlavorId());
			EntityReadEvent<CloudRackspaceConfigurationDetails> configDetailsEvent = cloudRackspaceConfigurationQueryService.readRackspaceConfiguration(configReadEvent);
			CloudRackspaceConfigurationDetails  configDetails = configDetailsEvent.getEntity();
		  
		  
		   CloudRackspaceConfigurationResource configResource = CloudRackspaceConfigurationResource.builder()
                                                          			    .flavorClass(record.getFlavorCategory())
                                                          			    .build();
		     plansResource.setFlavor(configResource);
		}
		
		if(!planResourceList.contains(plansResource)) {
		    planResourceList.add(plansResource);
		}
	  }
	}
	log.info("buildProductOnDemand() -end");
	return planResourceList;
  }
	
	
	@RequestMapping(value="marketplace/products", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductResource>> readCloudProducts(
			@RequestParam(value = SERVICE_ID,required=false) Long serviceId,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductDetails> pagedAssembler) {
		log.info("readCloudProducts() START");
		ReadCloudProductsEvent request = new ReadCloudProductsEvent().setCloudServiceId(serviceId).setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudProductDetails> event=service.readCloudActiveProducts(request);
		Page<CloudProductDetails> page=event.getPage();
		PagedResources<CloudProductResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudProducts() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	// Newly added
	@RequestMapping(value="manager/publishedProducts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductResource>> readPublishedProducts(
			@RequestParam(value = SERVICE_ID,required=false) Long serviceId,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductDetails> pagedAssembler) {
		
		log.info("readCloudProducts() START");
		ReadCloudProductsEvent request = new ReadCloudProductsEvent().setCloudServiceId(serviceId).setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudProductDetails> event=service.readCloudActiveProducts(request);
		Page<CloudProductDetails> page=event.getPage();
		PagedResources<CloudProductResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudProducts() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="manager/products", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductResource>> readCloudProductsForManager(
      @PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
      @RequestParam(value = SERVICE_ID, required = false) Long serviceId,
      @RequestParam(value = PRODUCT_NAME,required=false) String productName,
      @RequestParam(value = STATUS,required=false) String status,
      @RequestParam(value = IS_FEATURED,required=false) Boolean isFeatured,
      @RequestParam(value = HAS_RELATED_PRODUCTS,required=false) Boolean hasRelatedProducts,
	  @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
      @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
      PagedResourcesAssembler<CloudProductDetails> pagedAssembler) {
		log.info("readCloudProductsForManager() START");
    ReadCloudProductsEvent request = new ReadCloudProductsEvent().setPageable(pageable).setCloudServiceId(serviceId);
    request.setProductName(productName);
    request.setStatus(status);
    request.setIsFeatured(isFeatured);
    request.setHasRelatedProducts(hasRelatedProducts);
	request.setSortColumnName(sortColumnName);
	request.setSortDirection(sortDirection);
    PageReadEvent<CloudProductDetails> event=service.readCloudProducts(request);

		Page<CloudProductDetails> page=event.getPage();
		PagedResources<CloudProductResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudProductsForManager() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "manager/products/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductResource> readCloudProductForManager(@PathVariable Long id){
		log.info("readCloudProductForManager()  -start");
		ReadCloudProductEvent request=new ReadCloudProductEvent().setCloudProductId(id);

		EntityReadEvent<CloudProductDetails> event = service.readCloudProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudProductDetails entity=event.getEntity();
		log.info("readCloudProductForManager()  - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/products/searchByProductName", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductResource> readCloudProductByProductNameForManager(
			@RequestParam(value = SERVICE_ID,required=false) Long serviceId,
			@RequestParam(value = "productName",required=true) String productName,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection){
		log.info("readCloudProductForManager()  -start");
		ReadCloudProductEvent request=new ReadCloudProductEvent();
		request.setCloudServiceId(serviceId);
		request.setProductName(productName);
	//	request.setSortColumnName(sortColumnName);
	//	request.setSortDirection(sortDirection);
		EntityReadEvent<CloudProductDetails> event = null;
        try{
		   event = service.readCloudProductByProductName(request);
			if(!event.isFound()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
        }catch(ResourceNotFoundException ex){
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudProductDetails entity=event.getEntity();
		log.info("readCloudProductForManager()  - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	/**
	 * This method returns details of products specified in request.
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "marketplace/products/searchByIds/{ids}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductResource>> readByIds(
		    @PathVariable String[]  ids,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			PagedResourcesAssembler<CloudProductDetails> pagedAssembler) {
		log.info("readByIds( ) - start");
		List<Long> productIds = new ArrayList<Long>() ;
		for(String temp :ids) {
			productIds.add(new Long(temp.replaceAll("\\D+","")));
		}
		ReadCloudProductsEvent request = new ReadCloudProductsEvent().setPageable(pageable);
		request.setProductIds(productIds);
		request.setSortColumnName(sortColumnName);
	    request.setSortDirection(sortDirection);
		PageReadEvent<CloudProductDetails> event = service.readreadByIds(request);
		Page<CloudProductDetails> page = event.getPage();
		PagedResources<CloudProductResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readByIds( ) - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="marketplace/services/{serviceId}/products",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductResource>> readProductByServiceId(
		@PathVariable Long serviceId,
        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
		PagedResourcesAssembler<CloudProductDetails> pagedAssembler) {
		log.info("readProductByServiceId() -start");
		ReadCloudProductsEvent request = new ReadCloudProductsEvent().setPageable(pageable);
		request.setCloudServiceId(serviceId);
		request.setSortColumnName(sortColumnName);
	    request.setSortDirection(sortDirection);
		PageReadEvent<CloudProductDetails> event = service.readProductByServiceId(request);
		Page<CloudProductDetails> page = event.getPage();
		PagedResources<CloudProductResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readProductByServiceId() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	// newly added 
	@RequestMapping(value="marketplace/products/readPublished",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductResource>> readPublished(
        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
		PagedResourcesAssembler<CloudProductDetails> pagedAssembler) {
		log.info("readPublished() -start");
		ReadCloudProductsEvent request = new ReadCloudProductsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
	    request.setSortDirection(sortDirection);
		PageReadEvent<CloudProductDetails> event = service.readPublishedProducts(request);
		Page<CloudProductDetails> page = event.getPage();
		PagedResources<CloudProductResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readPublished() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * @param planResourceList
	 * @param productPlanDetailsReadEvent
	 */
	private List<PlansResource> buildProductPlans(EntitiesReadEvent<CloudProductPlanDetails> productPlanDetailsReadEvent ,CloudProductResource cloudProductResource) {
		log.info("buildProductPlans() - Start");
		List<PlansResource> planResourceList = new ArrayList<PlansResource>();
		int  isProductAdded =0;
		if(null != productPlanDetailsReadEvent && !CollectionUtils.isEmpty(productPlanDetailsReadEvent.getEntities())){
			List<CloudProductPlanDetails> productPlanDetailsList = productPlanDetailsReadEvent.getEntities();
			for (CloudProductPlanDetails record : productPlanDetailsList) {
				
				//Reading OS details and building resource
				ReadOperatingSystemEvent readOsEvent = new ReadOperatingSystemEvent().setOperatingSystemId(record.getOperatingSystemId());
				EntityReadEvent<CloudOperatingSystemDetails> osEntity = cloudOperatingSystemQueryService.readOperatingSystem(readOsEvent);
				CloudOperatingSystemDetails osDetails = osEntity.getEntity();
				CloudOperatingSystemResource osResource = CloudOperatingSystemResource.builder().operatingSystemId(osDetails.getOperatingSystemId())
																								.name(osDetails.getName())
																								.build();
				
				// Location resource build
				CloudLocationResource locationResource = CloudLocationResource.builder().locationId(record.getLocationId())
																						.name(record.getLocationName())
																						.build();
				
				// Flavor resource build
				ReadRackspaceConfigurationEvent configReadEvent = new ReadRackspaceConfigurationEvent().setRackspaceConfigurationId(record.getFlavorId());
				EntityReadEvent<CloudRackspaceConfigurationDetails> configDetailsEvent = cloudRackspaceConfigurationQueryService.readRackspaceConfiguration(configReadEvent);
				CloudRackspaceConfigurationDetails  configDetails = configDetailsEvent.getEntity();
				
				Properties properties = Properties.builder().ram(MemoryUnitConverterUtil.convertMegaBytesIntoGigaBytes(configDetails.getRam()))
															.cpu(configDetails.getCpu())
															.disk(configDetails.getDisk())
															.build();
				CloudRackspaceConfigurationResource configResource = CloudRackspaceConfigurationResource.builder().configurationId(configDetails.getConfigurationId())
																												  .name(configDetails.getName())
																												  .flavorClass(configDetails.getFlavorClass())
																												  .properties(properties)
																												  .build();
				
				PlansResource plansResource = PlansResource.builder().build();
				
				if(isProductAdded == 0 && cloudProductResource!=null ) {
				  plansResource.setProductDetails(cloudProductResource);
				  isProductAdded++;
				}
				
                                                      				plansResource.setPlanId(record.getProductPlanId());
                                                      				plansResource.setPlanCode(record.getPlanCode());
                                                      				plansResource.setPrice(String.valueOf(record.getPrice()));
                                                      				plansResource.setOs(osResource);
                                                      				plansResource.setLocation(locationResource);
                                                      				plansResource.setFlavor(configResource);
                                                      				plansResource.setPlanName(record.getPlanName());
                                                      				plansResource.setVendorPlanCode(record.getVendorPlanCode());
                                                      				plansResource.setStatus(record.getStatus());
                                                      				plansResource.setTrialPlan(record.getIsTrialPlan());
                                                      				plansResource.setPricingModel(record.getPricingModel());
                                                      				plansResource.setVendorPrice(record.getVendorPrice());
                                                      				plansResource.setSortKey(record.getSortKey());
                                                      				
                                                      				
                                                  					// .cloudProductResource(cloudProductResource)
                                                  					// .planId(record.getProductPlanId())
																	 //.planCode(record.getPlanCode())
																	// .price(String.valueOf(record.getPrice()))
																	// .os(osResource)
																	// .location(locationResource)
																	// .flavor(configResource)
																	// .build();
				
				planResourceList.add(plansResource);
			}
		}
		
		return planResourceList;
	}

	/**
	 * Plans status by id
	 * @param ids
	 * @return
	 */
	@RequestMapping(value="/marketplace/productPlan/planStatus",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<ProductPlanResource>> readPlanStatusByIds(
		@RequestParam("ids") List<Long> planIds) {
		log.info("readPlanStatusByIds() - start");
		ReadCloudProductPlansEvent request = new ReadCloudProductPlansEvent();
		if(CollectionUtils.isEmpty(planIds)) {
		  log.info("ids not  found to retrieve the plans");
		  return null;
		}
		request.setPlanIds(planIds);
		//request.setSortColumnName(sortColumnName);
		//request.setSortDirection(sortDirection);
		EntitiesReadEvent<CloudProductPlanDetails> event =	planService.readPlansStatusById(request);
		List<CloudProductPlanDetails > detailsList = event.getEntities();
		
		if(CollectionUtils.isEmpty(detailsList)) {
		 return  new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		log.info("readPlanStatusByIds()  -end");
		return new ResponseEntity<>(planAssembler.fromDetailsListToResourcesList(detailsList) ,HttpStatus.OK);
	}
	
	 @RequestMapping(value = "/marketplace/productPlan/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<ProductPlanResource> readProductPlan(@PathVariable Long id) {
		log.info("readProductPlan() - start");
		ReadCloudProductPlanEvent request = new ReadCloudProductPlanEvent().setProductPlanId(id);
		EntityReadEvent<CloudProductPlanDetails> event = productPlanQueryService.readProductPlanService(request);

		if (!event.isFound()) {
		  return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudProductPlanDetails entity = event.getEntity();
		log.info("readProductPlan() - end");
		return new ResponseEntity<>(productPlanAssembler.toResource(entity), HttpStatus.OK);
	  }
  
  
	
	
}
