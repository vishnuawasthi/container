package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerUserDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudResellerUserEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudResellerUsersEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerUserQueryService;
import com.valuelabs.nephele.manager.assembler.CloudResellerUserAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudResellerUserResource;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/manager/resellerUser")
@Transactional
public class CloudResellerUserQueryController {

	@Autowired
	private CloudResellerUserAssembler assembler;
	
	@Autowired
	CloudResellerUserQueryService service;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudResellerUserResource> readCloudResellerUser(@PathVariable Long id) {
		log.info("readCloudResellerUser() START");

		ReadCloudResellerUserEvent request=new ReadCloudResellerUserEvent().setResellerUserId(id);
		
		EntityReadEvent<CloudResellerUserDetails> event = service.readCloudResellerUser(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudResellerUserDetails entity = event.getEntity();
		log.info("readCloudResellerUser() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudResellerUserResource>> readResellerUsers(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudResellerUserDetails> pagedAssembler) {
		log.info("readResellerUsers() START");
		ReadCloudResellerUsersEvent request=new ReadCloudResellerUsersEvent().setPageable(pageable);
    	 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudResellerUserDetails> event=service.readCloudResellerUsers(request);
		Page<CloudResellerUserDetails> page=event.getPage();
		PagedResources<CloudResellerUserResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readResellerUsers() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
