package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(value=Include.NON_DEFAULT)
public class PremiumGroupDiscountSheetResource extends ResourceSupport {
	
	private Long discountRuleId;
	private String startRange;
	private String endRange;
	private String discount;
	private Long premiumGroupId;
	private String premiumGroupName;
	private String discountPlanType;
	private Long premiumGroupDiscountConfigId;
	private Long serviceId;
	private String serviceName;
	private String message;
	private String status;
}
