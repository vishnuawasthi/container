package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudJobSchedularDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudJobSchedularEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudJobSchedularCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudJobSchedularResources;
import com.valuelabs.nephele.manager.assembler.CloudJobSchedularAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/jobSchedular")
@Transactional
public class CloudJobSchedularCommandController {

	@Autowired
	CloudJobSchedularAssembler assembler;

	@Autowired
	CloudJobSchedularCommandService service;

	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudJobSchedularResources> createCloudJobSchedular(
			@Valid @RequestBody CloudJobSchedularResources resource, BindingResult result)
					throws IllegalArgumentException {
		log.info("createCloudJobSchedular() : START");

		if (StringUtils.isEmpty(resource.getMinutes())) {
			result.addError(new FieldError("resource", "getMinutes", resource.getMinutes(), true, null, null, null));
		}
		if (StringUtils.isEmpty(resource.getHours())) {
			result.addError(new FieldError("resource", "getHours", resource.getJobtype(), true, null, null, null));
		}
		if (resource.getJobtype() == null) {
			result.addError(new FieldError("resource", "getJobtype", resource.getJobtype(), true, null, null, null));
		}
		if (resource.getStatus() == null) {
			result.addError(new FieldError("resource", "getStatus", resource.getStatus(), true, null, null, null));
		}
		if (resource.getCloudserviceId() == null) {
			result.addError(new FieldError("resource", "getCloudserviceId", resource.getCloudserviceId(), true, null,
					null, null));
		}

		if (result.hasErrors()) {
			return new ResponseEntity<CloudJobSchedularResources>(resource, HttpStatus.BAD_REQUEST);
		}

		CloudJobSchedularDetails details = assembler.fromResouce(resource);

		CreateCloudJobSchedularEvent request = new CreateCloudJobSchedularEvent().setCloudJobSchedularDetails(details);

		if (request != null) {
			service.createJobSchedular(request);
		}
		log.info("createCloudJobSchedular() : END");
		return new ResponseEntity<CloudJobSchedularResources>(HttpStatus.CREATED);
	}

	// update entity
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudJobSchedularResources> updateCloudJobSchedular(
			@Valid @RequestBody CloudJobSchedularResources resource, BindingResult result)
					throws ResourceNotFoundException, IllegalArgumentException {
		log.info("updateCloudJobSchedular() : START");
		if (resource.getJobId() == null) {
			result.addError(new FieldError("resource", "JobId", resource.getJobId(), true, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudJobSchedularResources>(resource, HttpStatus.BAD_REQUEST);
		}
		// to update the entity
		CloudJobSchedularDetails details = assembler.fromResouce(resource);
		CreateCloudJobSchedularEvent request = new CreateCloudJobSchedularEvent().setCloudJobSchedularDetails(details);

		if (request != null) {
			service.updateJobSchedular(request);
		}
		log.info("updateCloudJobSchedular() : END");
		return new ResponseEntity<CloudJobSchedularResources>(HttpStatus.OK);
	}

	@RequestMapping(value = "{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudJobSchedularResources> deleteScheduledJob(@PathVariable Long id) {
		log.info("deleteScheduledJob() : START");

		if (id == 0 || id == null) {
			return new ResponseEntity<CloudJobSchedularResources>(new CloudJobSchedularResources(),
					HttpStatus.BAD_REQUEST);
		}
		service.deleteScheduledjobById(id);

		log.info("deleteScheduledJob() : START");
		return new ResponseEntity<CloudJobSchedularResources>(HttpStatus.OK);
	}

}
