package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudProductEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudProductResource;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.BundleCloudProductCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudProductCommandService;
import com.valuelabs.nephele.marketplace.assembler.CloudProductAssembler;
import com.valuelabs.nephele.marketplace.resource.BundleResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class BundleCloudProductCommandController {
	
	@Autowired
	private BundleCloudProductCommandService service;
	
	@Autowired
	private CloudProductCommandService cloudProductCommandService;
	
	@Autowired
	private CloudProductAssembler cloudProductAssembler;
	
	@RequestMapping(value="/manager/bundleCloudProduct/{id}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<BundleResource> deleteBundleCloudProduct(@PathVariable Long id){
		log.info("deleteBundleCloudProduct() : START");

		if(id != null){
			service.deleteBundleCloudProduct(id);
		}		
		
		log.info("deleteBundleCloudProduct() : START");
		return new ResponseEntity<BundleResource>(HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/manager/bundleCloudProduct",method = RequestMethod.PUT , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductResource> updateCloudProductLabel(@RequestBody CloudProductResource  resource,BindingResult result){
		log.info("updateCloudProductLabel() : start");
		if (resource.getProductId() == null) {
			result.addError(new FieldError("resource",
					"productId", resource.getProductId(), false, null, null,"productId should not be empty"));
		}
		if (result.hasErrors()) {
			List <String> errorMessageList  = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " "+ fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}	
		CreateCloudProductEvent request = new CreateCloudProductEvent();
		request.setCloudProductDetails(cloudProductAssembler.fromResource(resource));
		if(request!=null){
			cloudProductCommandService.updateProductLabel(request);
		}
		
		log.info("updateCloudProductLabel() : end");
		return new ResponseEntity<CloudProductResource>(HttpStatus.OK);
	}
	
	

}
