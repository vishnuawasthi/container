package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.valuelabs.nephele.admin.rest.lib.domain.Properties;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
//@Setter
//@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudRackspaceConfigurationResource extends ResourceSupport {

	private Long configurationId;
	private String cspResource;
	private String flavourId;
	private String name;
	private Integer size;
	private Long configurationTypeId;
	private Long serviceId;
	private Long cpu;
	private Long ram;
	private Long disk;
	private String flavorClass;
	private String price;
	private Properties properties;
	private String status;
	private Long cloudServiceId;
	
}
