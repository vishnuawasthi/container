package com.valuelabs.nephele.manager.resource;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
@JsonInclude(Include.NON_NULL)
public class CloudRackspaceConfigurationResources {
	private List<CloudRackspaceConfigurationResource> resources;
	private List<CloudRackspaceConfigurationResource> planCategories;
}
