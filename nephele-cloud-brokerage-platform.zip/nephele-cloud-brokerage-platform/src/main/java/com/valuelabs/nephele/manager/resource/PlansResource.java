package com.valuelabs.nephele.manager.resource;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudProductResource;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
//@Setter
//@Getter
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class PlansResource extends ResourceSupport {
  	private CloudProductResource productDetails;
	private List<CloudLocationResource> locations;
	private FlavorClassResource flavors;
	
	private Long planId;
	private String price;
	private String planCode;
	private String planName;
	private String vendorPlanCode;
	private String pricingModel;
	private boolean trialPlan;
	private String status;
	private Double vendorPrice;
	private Long sortKey;
	private CloudOperatingSystemResource os;
	private CloudLocationResource location;
	private CloudRackspaceConfigurationResource flavor;
}
