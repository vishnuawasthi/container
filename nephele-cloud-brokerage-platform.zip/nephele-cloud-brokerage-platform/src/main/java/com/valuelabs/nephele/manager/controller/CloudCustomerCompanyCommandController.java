package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.CREATE_CUSTOMER_DATA_ROUTING_KEY;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.DELETE_CUSTOMER_DATA_ROUTING_KEY;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.EXCHANGE_NAME;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.UPDATE_CUSTOMER_DATA_ROUTING_KEY;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanyRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.DeleteCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.UpdateCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCustomerCompanyCommandService;
import com.valuelabs.nephele.manager.assembler.CloudCustomerCompanyAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudCustomerCompanyResource;
import com.valuelabs.nephele.manager.resource.CloudCustomerCompanyResources;

@Slf4j
@RestController
@RequestMapping("/manager/customerCompany")
public class CloudCustomerCompanyCommandController {

	@Autowired
	CloudCustomerCompanyAssembler assembler;

	@Autowired
	CloudCustomerCompanyCommandService service;
	
	/*@Autowired
	CloudCustomerCompanyDAO customerCompanyDAO;*/
	
	@Autowired
	CloudCustomerCompanyRepository customerCompanyRepository;
	
	@Autowired
	RabbitTemplate rabbitTemplate;
	

	/*@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudCustomerCompanyResource> createCustomerCompany(@Valid @RequestBody CloudCustomerCompanyResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createCloudCustomerCompany() : START");
		CloudCustomerCompanyCreatedEvent response=null;
		if (result.hasErrors()) {
			return new ResponseEntity<CloudCustomerCompanyResource>(resource, HttpStatus.BAD_REQUEST);
		}
		CloudCustomerCompanyDetails details = assembler.fromResouce(resource);
		CreateCloudCustomerCompanyEvent request = new CreateCloudCustomerCompanyEvent().setCustomerCompanyDetails(details);

		if (request != null) {
			response=service.createCloudCustomerCompany(request);
		}
		CloudCustomerCompanyResource responseResource=CloudCustomerCompanyResource.builder().customerCompanyId(response.getCustomerCompanyDetails().getCustomerCompanyId()).build();
		log.info("createCloudCustomerCompany() : END");
		return new ResponseEntity<CloudCustomerCompanyResource>(responseResource,HttpStatus.CREATED);
	}*/
	// update entity
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudCustomerCompanyResource> updateCustomerCompanies(@RequestBody CloudCustomerCompanyResources resources,
			BindingResult result) throws ResourceNotFoundException, IllegalArgumentException {
		log.info("updateCustomerCompanies() : START");
		List<CloudCustomerCompanyDetails> detailsList  =assembler.fromResouce(resources.getCustomers());
		
		UpdateCloudCustomerCompanyEvent request = new UpdateCloudCustomerCompanyEvent().setCustomerCompanyDetailsList(detailsList);
		
		if (request != null) {
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, UPDATE_CUSTOMER_DATA_ROUTING_KEY, request);
		}
		log.info("updateCustomerCompanies() : END");
		return new ResponseEntity<CloudCustomerCompanyResource>(HttpStatus.OK);
	}

	/**
	 * This method accepts List of customer companies and create them.
	 * @param resources
	 * @return
	 * @throws ResourceNotFoundException
	 * @throws IllegalArgumentException
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudCustomerCompanyResources> createCustomerCompanies(@RequestBody CloudCustomerCompanyResources resources)
			throws ResourceNotFoundException, IllegalArgumentException {
		log.info("createcustomerCompanies() - start");
		List<CloudCustomerCompanyDetails> detailsList  =assembler.fromResouce(resources.getCustomers());
		
		CreateCloudCustomerCompanyEvent request = new CreateCloudCustomerCompanyEvent().setCustomerCompanyDetailsList(detailsList);
		
		if (null != request) {
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, CREATE_CUSTOMER_DATA_ROUTING_KEY,	request);
		}
		
		log.info("createcustomerCompanies() - end");
		return new ResponseEntity<CloudCustomerCompanyResources>(HttpStatus.CREATED) ;
	}
	
	/**
	 * This method accepts List of customer companies and create them.
	 * @param resources
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/sync",method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudCustomerCompanyResources> syncCustomerCompanies(@RequestBody CloudCustomerCompanyResources resources)
			throws Exception {
		log.info("syncCustomerCompanies() - start");
		List<CloudCustomerCompanyDetails> detailsList  =assembler.fromResouce(resources.getCustomers());
		List<CloudCustomerCompanyDetails> creationList=new ArrayList<>();
		List<CloudCustomerCompanyDetails> updationList=new ArrayList<>();
		List<CloudCustomerCompanyDetails> deletionList=new ArrayList<>();
		
		for(CloudCustomerCompanyDetails customerCompany:detailsList ){
			if(customerCompany.getIsActive()){
			CloudCustomerCompany entity=null;
			try {
				 entity = customerCompanyRepository.findByExternalCustomerCode(customerCompany.getExternalCustomerCompanyCode());
			} catch (NoResultException e) {
				log.error("Exception while getting customer company  details in syncCustomerCompanies() ");
			}
			if(null != entity){
				updationList.add(customerCompany);
			}else if(null == entity){
				creationList.add(customerCompany);
			}
			}else{
				deletionList.add(customerCompany);
			}
		}
		CreateCloudCustomerCompanyEvent createRequest = new CreateCloudCustomerCompanyEvent().setCustomerCompanyDetailsList(creationList);
		UpdateCloudCustomerCompanyEvent updateRequest = new UpdateCloudCustomerCompanyEvent().setCustomerCompanyDetailsList(updationList);
		DeleteCustomerCompanyEvent deleteRequest=new DeleteCustomerCompanyEvent().setCustomerCompanyDetailsList(deletionList);
		if(null != creationList && creationList.size()>0){
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, CREATE_CUSTOMER_DATA_ROUTING_KEY, createRequest);
		}
		
		if(null != updationList && updationList.size()>0){
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, UPDATE_CUSTOMER_DATA_ROUTING_KEY, updateRequest);
		}
		
		if(null != deletionList && deletionList.size()>0){
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, DELETE_CUSTOMER_DATA_ROUTING_KEY, deleteRequest);
		}
		
		log.info("syncCustomerCompanies() - end");
		return new ResponseEntity<CloudCustomerCompanyResources>(HttpStatus.CREATED) ;
	}
	
	
	@RequestMapping(value="/{externalCompanyCode}" , method=RequestMethod.DELETE , produces=MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudCustomerCompanyResource> deleteCustomerCompany(@PathVariable String externalCompanyCode){
		log.info("deleteCustomerCompany() - start");
		
		if(externalCompanyCode == null){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
		DeleteCustomerCompanyEvent request = new DeleteCustomerCompanyEvent().setExternalCustomerCompanyCode(externalCompanyCode);
		
		//service.deleteCustomerCompany(request);
		if(null != request)
		{
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, DELETE_CUSTOMER_DATA_ROUTING_KEY, request);
		}
		
		log.info("deleteCustomerCompany() - end");
		return new ResponseEntity<CloudCustomerCompanyResource>(HttpStatus.OK) ;
		
	}
	
	

}
