package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.SMTPConfigurationDetails;
import com.valuelabs.nephele.manager.controller.SMTPConfigurationQueryController;
import com.valuelabs.nephele.manager.resource.SMTPConfigurationResource;

@Service
@Slf4j
public class SMTPConfigurationResourceAssembler
    extends
      ResourceAssemblerSupport<SMTPConfigurationDetails, SMTPConfigurationResource> {

  public SMTPConfigurationResourceAssembler() {
	super(SMTPConfigurationQueryController.class, SMTPConfigurationResource.class);
  }

  @Override
  public SMTPConfigurationResource toResource(SMTPConfigurationDetails entity) {
	log.debug("toResource() - start");
	SMTPConfigurationResource resource = SMTPConfigurationResource.builder()
                                                            		.smptConfigurationId(entity.getId())
                                                            		.protocol(entity.getProtocol())
                                                            		.host(entity.getHost())
                                                            		.port(entity.getPort())
                                                            		.smtpAuth(entity.getSmtpAuth())
                                                            		.smtpStarttlsEnable(entity.getSmtpStarttlsEnable())
                                                            		.username(entity.getUsername())
                                                            		.password(entity.getPassword())
                                                            		.from(entity.getFrom())
                                                            		.build();
	resource.add(linkTo(methodOn(SMTPConfigurationQueryController.class).readSMTPConfiguration(entity.getId())).withSelfRel());
	log.debug("toResource() - end");
	return resource;
  }
  
  public SMTPConfigurationDetails fromResource(SMTPConfigurationResource resource) {
	log.debug("fromResource() - start");
	SMTPConfigurationDetails details = SMTPConfigurationDetails.builder()
																	.id(resource.getSmptConfigurationId())
                                                            		.protocol(resource.getProtocol())
                                                            		.host(resource.getHost())
                                                            		.port(resource.getPort())
                                                            		.smtpAuth(resource.getSmtpAuth())
                                                            		.smtpStarttlsEnable(resource.getSmtpStarttlsEnable())
                                                            		.username(resource.getUsername())
                                                            		.password(resource.getPassword())
                                                            		.from(resource.getFrom())
                                                            		.build();
	log.debug("fromResource() - end");
	return details;
  }


}
