package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;
import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountConfigDetails;
import com.valuelabs.nephele.manager.controller.CloudProductPriceMgmtConfigQueryController;
import com.valuelabs.nephele.manager.controller.PremiumGroupDiscountConfigQueryController;
import com.valuelabs.nephele.manager.resource.PremiumGroupDiscountConfigResource;

@Slf4j
@Service
public class PremiumGroupDiscountAssembler extends ResourceAssemblerSupport<PremiumGroupDiscountConfigDetails, PremiumGroupDiscountConfigResource>{

	
	
		
		public PremiumGroupDiscountAssembler() {
			super(CloudProductPriceMgmtConfigQueryController.class, PremiumGroupDiscountConfigResource.class);
		}
		
		@Override
		public PremiumGroupDiscountConfigResource toResource(PremiumGroupDiscountConfigDetails details) {
			log.debug("toResource() : START");
			PremiumGroupDiscountConfigResource resource = instantiateResource(details);
			resource = PremiumGroupDiscountConfigResource.builder().discountSheetName(details.getDiscountSheetName())
																	.premiumGroupDiscountConfigId(details.getPremiumGroupDiscountConfigId())
																	.activeFrom(details.getActiveFrom() != null ? details.getActiveFrom() : null)
																	.activeTo(details.getActiveTo() != null ? details.getActiveTo() : null)
																	.serviceId(details.getServiceId())
																	.status(details.getStatus())
																	.discountPlanType(details.getDiscountPlanType())
																	.build();		
			resource.add(linkTo(
					methodOn(PremiumGroupDiscountConfigQueryController.class)
							.readPremiumGroupDiscountConfig(
									details.getPremiumGroupDiscountConfigId())).withSelfRel());
			log.debug("toResource() : END");
			return resource;
		}
		
		public PremiumGroupDiscountConfigDetails fromResource(PremiumGroupDiscountConfigResource resource) {
			log.debug("fromResource() START:{}",resource);
			PremiumGroupDiscountConfigDetails details = PremiumGroupDiscountConfigDetails.builder().discountSheetName(resource.getDiscountSheetName())
																										.premiumGroupDiscountConfigId(resource.getPremiumGroupDiscountConfigId())
																										.activeFrom(resource.getActiveFrom() != null ? resource.getActiveFrom() : null)
																										.activeTo(resource.getActiveTo() != null ? resource.getActiveTo() : null)
																										.serviceId(resource.getServiceId())
																										.status(resource.getStatus())
																										.discountPlanType(resource.getDiscountPlanType())																									
																										.build();
			log.debug("fromResource() - END");
			return details;
		}
	
	}