/*package com.valuelabs.nephele.marketplace.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderLineDetails;
import com.valuelabs.nephele.marketplace.controller.CloudOrderLineQueryController;
import com.valuelabs.nephele.marketplace.resource.CloudOrderLineResource;

@Slf4j
@Service
public class CloudOrderLineAssembler extends
		ResourceAssemblerSupport<CloudOrderLineDetails, CloudOrderLineResource> {

	public CloudOrderLineAssembler() {
		super(CloudOrderLineQueryController.class, CloudOrderLineResource.class);
	}

	@Override
	public CloudOrderLineResource toResource(CloudOrderLineDetails details) {
		log.debug("toResource() : START");
		CloudOrderLineResource resource = instantiateResource(details);
		resource = CloudOrderLineResource.builder().cloudOrderLineId(details.getId())
				.cloudOrderId(details.getCloudOrderId())
				.cloudProductId(details.getCloudProductId())
				.configuration(details.getConfiguration())
				.quantity(details.getQuantity()).status(details.getStatus())
				.build();
		resource.add(linkTo(
				methodOn(CloudOrderLineQueryController.class)
						.readCloudOrderLine(details.getId())).withSelfRel());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudOrderLineDetails fromResource(CloudOrderLineResource resource) {
		log.debug("fromResource() START:{}", resource);
		CloudOrderLineDetails details = CloudOrderLineDetails.builder()
				.id(resource.getCloudOrderLineId())
				.cloudOrderId(resource.getCloudOrderId())
				.cloudProductId(resource.getCloudProductId())
				.configuration(resource.getConfiguration())
				.quantity(resource.getQuantity()).status(resource.getStatus())
				.build();
		log.debug("fromResource() - END");
		return details;
	}

}
*/