package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceMgmtConfigDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadProductPriceMgmtConfigEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadProductPriceMgmtConfigsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudProductPriceMgmtConfigQueryService;
import com.valuelabs.nephele.manager.assembler.CloudProductPriceMgmtAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudProductPriceMgmtConfigResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/priceManagementConfig")
@Transactional
public class CloudProductPriceMgmtConfigQueryController {

	@Autowired
	private CloudProductPriceMgmtAssembler assembler;

	@Autowired
	private CloudProductPriceMgmtConfigQueryService service;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudProductPriceMgmtConfigResource> readProductPriceMgmtConfig(@PathVariable Long id) {
		log.info("readCloudRackspaceComputePrice() START");

		ReadProductPriceMgmtConfigEvent request=new ReadProductPriceMgmtConfigEvent().setId(id);		

		EntityReadEvent<CloudProductPriceMgmtConfigDetails> event = service.readProductPriceMgmtConfigService(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudProductPriceMgmtConfigDetails entity = event.getEntity();
		log.info("readCloudRackspaceComputePrice() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudProductPriceMgmtConfigResource>> readProductPriceMgmtConfigs(
			@RequestParam(value = "sheetName",required = false) String sheetName,
			@RequestParam(value = "status", required =false) String status,
			@RequestParam(value = "serviceId", required=false) Long serviceId,
			@RequestParam(value = "activeFrom", required=false) String activeFrom,@RequestParam(value = "activeTo", required=false) String activeTo,
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudProductPriceMgmtConfigDetails> pagedAssembler) {
		log.info("readProductPriceMgmtConfigs() START");
		ReadProductPriceMgmtConfigsEvent request=new ReadProductPriceMgmtConfigsEvent().setPageable(pageable);
		request.setSheetName(sheetName);
		request.setStatus(status);
		request.setActiveFrom(activeFrom);
		request.setActiveTo(activeTo);
		request.setServiceId(serviceId);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudProductPriceMgmtConfigDetails> event=service.readProductPriceMgmtConfigServices(request);

		Page<CloudProductPriceMgmtConfigDetails> page=event.getPage();
		PagedResources<CloudProductPriceMgmtConfigResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readProductPriceMgmtConfigs() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
