package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionEditionDetails;
import com.valuelabs.nephele.manager.controller.CloudSubscriptionEditionQueryController;
import com.valuelabs.nephele.manager.resource.CloudSubscriptionEditionResource;


@Slf4j
@Service
public class CloudSubscriptionEditionAssembler extends ResourceAssemblerSupport<CloudSubscriptionEditionDetails, CloudSubscriptionEditionResource> {
	
	public CloudSubscriptionEditionAssembler() {
		super(CloudSubscriptionEditionQueryController.class, CloudSubscriptionEditionResource.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CloudSubscriptionEditionResource toResource(
			CloudSubscriptionEditionDetails entity) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: "+entity);
		CloudSubscriptionEditionResource resource=instantiateResource(entity);
		resource=CloudSubscriptionEditionResource.builder().subscriptionEditionId(entity.getSubscriptionEditionId()).editionId(entity.getEditionId())
				.seatCount(entity.getSeatCount()).subscribedAt(entity.getSubscribedAt()).subscriptionId(entity.getSubscriptionId()).build();
		resource.add(linkTo(methodOn(CloudSubscriptionEditionQueryController.class).readSubscriptionEdition(entity.getSubscriptionEditionId())).withSelfRel());
		log.debug("toResource() : resource : "+resource);
		log.debug("toResource() : resource Links: "+resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudSubscriptionEditionDetails fromResource(CloudSubscriptionEditionResource resource){
		log.debug("fromResource: START:{} ",resource);
		CloudSubscriptionEditionDetails details=CloudSubscriptionEditionDetails.builder().subscriptionEditionId(resource.getSubscriptionEditionId())
				.editionId(resource.getEditionId()).seatCount(resource.getSeatCount()).subscribedAt(resource.getSubscribedAt())
				.subscriptionId(resource.getSubscriptionId()).build();
		log.debug("fromResouce: END");
		return details;
	}
	
}
