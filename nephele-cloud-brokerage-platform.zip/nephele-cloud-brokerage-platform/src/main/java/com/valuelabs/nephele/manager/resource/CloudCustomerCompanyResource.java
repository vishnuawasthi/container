package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudCustomerCompanyResource extends ResourceSupport {

	private Long customerCompanyId;
	private String customerCompanyName;
	private Long cloudResellerCompanyId;
	private String firstName;
	private String lastName;
	private String email;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String country;
	private String zipcode;
	private String externalCustomerCompanyCode;
	private String externalResellerCompanyCode;
	private Boolean isActive;
	private String businessContactname;
	private String businessContactEmail;
	private String abnNumber;
	private String acnNumber;
	private String phoneNumber;
	private String countryCodeUN;
    private String countryCodeISO;
    private String websiteUrl;

}
