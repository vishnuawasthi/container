package com.valuelabs.nephele.manager.controller;

import com.valuelabs.nephele.admin.data.api.NepheleCurrency;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudCurrencyConversionRateEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRateEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCurrencyConversionRateCommandService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudCurrencyConversionRateQueryService;
import com.valuelabs.nephele.manager.assembler.CloudCurrencyConversionRateAssembler;
import com.valuelabs.nephele.manager.resource.CloudCurrencyConversionRateResource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;


@Slf4j
@RestController
@RequestMapping("/manager/currencyConversionRate")
public class CloudCurrencyConversionRateCommandController {
  
  @Autowired
	CloudCurrencyConversionRateCommandService service;
	@Autowired
	CloudCurrencyConversionRateQueryService queryService;
	@Autowired
	private CloudCurrencyConversionRateAssembler assembler;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<CloudCurrencyConversionRateResource> createCloudCurrencyConversionRate(
	 @Valid @RequestBody CloudCurrencyConversionRateResource resource,
	 BindingResult result) throws IllegalArgumentException {
	log.info("createCloudCurrencyConversionRate()  - start");
	//Double conversionrate=resource.getConversionRateId().doubleValue()
	if(resource.getConversionRate()!=null&&resource.getConversionRate()<0.00) {
		  result.addError(new FieldError("resource", "getConversionRate", resource.getConversionRate(), false, null, null, null));
		}
		if (result.hasErrors()) {
		  List<String> errorMessageList = new ArrayList<String>();
		  List<FieldError> errors = result.getFieldErrors();
		  for (FieldError fieldError : errors) {
			  errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
			
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
			    .errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		  }
		}
		ReadCloudCurrencyConversionRateEvent checkRequest = new ReadCloudCurrencyConversionRateEvent().setSourceCurrency(NepheleCurrency.valueOf(resource.getSourceCurrency())).setTargetCurrency(NepheleCurrency.valueOf(resource.getTargetCurrency()));
		if(queryService.readUniqueCloudCurrencyConversionRate(checkRequest).getEntity() != null){
			resource.setErrorMessage("Currency conversion rate already exists for the given combination");
			return new ResponseEntity<CloudCurrencyConversionRateResource>(resource, HttpStatus.BAD_REQUEST);
		}
	
	CloudCurrencyConversionRateDetails details = assembler.fromResource(resource);
	CreateCloudCurrencyConversionRateEvent request = new CreateCloudCurrencyConversionRateEvent().setDetails(details);
	if (request != null) {
	  service.createCloudCurrencyConversionRate(request);
	}
	log.info("createCloudCurrencyConversionRate()  - end");
	return new ResponseEntity<CloudCurrencyConversionRateResource>(HttpStatus.CREATED);
  }
  
  
  @RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<CloudCurrencyConversionRateResource> updateCloudCurrencyConversionRate(
	 @Valid @RequestBody CloudCurrencyConversionRateResource resource,
	 BindingResult result) throws IllegalArgumentException {
	log.info("updateCloudCurrencyConversionRate()  - start");
	
	if(StringUtils.isEmpty(resource.getConversionRateId())) {
	  result.addError(new FieldError("resource", "conversionRateId", resource.getConversionRateId(), false, null, null, null));
	}
	if (result.hasErrors()) {
	  List<String> errorMessageList = new ArrayList<String>();
	  List<FieldError> errors = result.getFieldErrors();
	  if (result.hasErrors()) {
		for (FieldError fieldError : errors) {
		  errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
		}
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
		    .errorMessages(errorMessageList).build();
		return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
	  }
	}
	CloudCurrencyConversionRateDetails details = assembler.fromResource(resource);
	CreateCloudCurrencyConversionRateEvent request = new CreateCloudCurrencyConversionRateEvent().setDetails(details);
	if (request != null) {
	  service.updateCloudCurrencyConversionRate(request);
	  
	}
	log.info("updateCloudCurrencyConversionRate()  - end");
	return new ResponseEntity<CloudCurrencyConversionRateResource>(HttpStatus.OK);
  }
  
  @RequestMapping(method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
  public HttpEntity<CloudCurrencyConversionRateResource> deleteCloudCurrencyConversionRate(
	 @Valid @RequestBody CloudCurrencyConversionRateResource resource,
	 BindingResult result) throws IllegalArgumentException {
	log.info("deleteCloudCurrencyConversionRate()  - start");
	
	if(StringUtils.isEmpty(resource.getConversionRateId())) {
	  result.addError(new FieldError("resource", "conversionRateId", resource.getConversionRateId(), false, null, null, null));
	}
	if (result.hasErrors()) {
	  List<String> errorMessageList = new ArrayList<String>();
	  List<FieldError> errors = result.getFieldErrors();
	  if (result.hasErrors()) {
		for (FieldError fieldError : errors) {
		  errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
		}
		CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
		    .errorMessages(errorMessageList).build();
		return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
	  }
	}
	CloudCurrencyConversionRateDetails details = assembler.fromResource(resource);
	CreateCloudCurrencyConversionRateEvent request = new CreateCloudCurrencyConversionRateEvent().setDetails(details);
	if (request != null) {
	  service.deleteCloudCurrencyConversionRate(request);
	}
	log.info("deleteCloudCurrencyConversionRate()  - end");
	return new ResponseEntity<CloudCurrencyConversionRateResource>(HttpStatus.OK);
  }
  
  
  
  
}
