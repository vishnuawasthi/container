package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceIndustryVerticalDetail;
import com.valuelabs.nephele.manager.controller.CloudServiceIndustryVerticalQueryController;
import com.valuelabs.nephele.manager.resource.CloudServiceIndustryVerticalResource;

@Slf4j
@Service
public class CloudServiceIndustryVerticalAssembler
		extends ResourceAssemblerSupport<CloudServiceIndustryVerticalDetail, CloudServiceIndustryVerticalResource> {
	public CloudServiceIndustryVerticalAssembler() {
		super(CloudServiceIndustryVerticalQueryController.class, CloudServiceIndustryVerticalResource.class);
	}

	@Override
	public CloudServiceIndustryVerticalResource toResource(CloudServiceIndustryVerticalDetail details) {
		log.debug("toResource() : START");
		log.debug("toResource() : Service: " + details);
		CloudServiceIndustryVerticalResource resource = instantiateResource(details);
		resource = CloudServiceIndustryVerticalResource.builder().verticalsId(details.getVerticalsId())
				.name(details.getName()).description(details.getDescription()).build();

		resource.add(linkTo(methodOn(CloudServiceIndustryVerticalQueryController.class)
				.readServiceIndustryVertical(details.getVerticalsId())).withSelfRel());

		log.debug("toResource() : resource : " + resource);
		log.debug("toResource() : resource Links: " + resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudServiceIndustryVerticalDetail fromResource(CloudServiceIndustryVerticalResource resource) {
		log.debug("fromResource: START:{} ", resource);
		CloudServiceIndustryVerticalDetail details = CloudServiceIndustryVerticalDetail.builder()
				.verticalsId(resource.getVerticalsId()).name(resource.getName()).description(resource.getDescription())
				.build();
		log.debug("fromResouce: END");
		return details;

	}

}
