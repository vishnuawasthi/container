package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudDistributorCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudDistributorCompanysEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudDistributorCompanyQueryService;
import com.valuelabs.nephele.manager.assembler.CloudDistributorCompanyAssembler;
import com.valuelabs.nephele.manager.resource.CloudDistributorCompanyResource;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping(value = "/manager/cloudDistributorCompany")
@Transactional
public class CloudDistributorCompanyQueryController {

	@Autowired
	private CloudDistributorCompanyQueryService service;

	@Autowired
	private CloudDistributorCompanyAssembler assembler;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudDistributorCompanyResource> readCloudDistributorCompany(
			@PathVariable("id") Long id) {
		log.info("readCloudDistributorCompany() - start");
		ReadCloudDistributorCompanyEvent request = new ReadCloudDistributorCompanyEvent()
				.setId(id);

		EntityReadEvent<CloudDistributorCompanyDetails> event = service
				.readCloudDistributorCompany(request);
		if (!event.isFound()) {
			return new ResponseEntity<CloudDistributorCompanyResource>(
					HttpStatus.NO_CONTENT);
		}
		log.info("readCloudDistributorCompany() - end");
		return new ResponseEntity<CloudDistributorCompanyResource>(
				assembler.toResource(event.getEntity()), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudDistributorCompanyResource>> readCloudDistributorCompanys(
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudDistributorCompanyDetails> pagedAssembler) {
		log.info("readCloudDistributorCompanys() - start ");
		ReadCloudDistributorCompanysEvent request = new ReadCloudDistributorCompanysEvent()
				.setPageable(pageable);

		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudDistributorCompanyDetails> event = service
				.readCloudDistributorCompanys(request);

		Page<CloudDistributorCompanyDetails> page = event.getPage();
		PagedResources<CloudDistributorCompanyResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readCloudDistributorCompanys() - start ");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

}
