package com.valuelabs.nephele.manager.exception;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.mapping.PropertyReferenceException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.valuelabs.nephele.admin.rest.lib.exception.EmptyFileException;

@ControllerAdvice
public class ExceptionHandlerAdvice {

	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR )
	@ExceptionHandler(value = NullPointerException.class)
	public HttpEntity<ExceptionResponseEntity> nullPointerExceptionHandler(NullPointerException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("NullPointerException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ResponseStatus(value=HttpStatus.BAD_REQUEST )
	@ExceptionHandler(value = TypeMismatchException.class)
	public HttpEntity<ExceptionResponseEntity> typeMismatchExceptionHandler(TypeMismatchException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("TypeMismatchException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	@ExceptionHandler(value = ResourceNotFoundException.class)
	public HttpEntity<ExceptionResponseEntity> resourcePathNotFoundHandler(ResourceNotFoundException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("ResourceNotFoundException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.NOT_FOUND);
	}
	
	@ResponseStatus(value=HttpStatus.METHOD_NOT_ALLOWED)
	@ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
	public HttpEntity<ExceptionResponseEntity> httpRequestMethodNotSupportedExceptionHandler(HttpRequestMethodNotSupportedException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("HttpRequestMethodNotSupportedException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.METHOD_NOT_ALLOWED);
	}

	@ResponseStatus(value=HttpStatus.NOT_ACCEPTABLE)
	@ExceptionHandler(value = HttpMediaTypeNotSupportedException.class)
	public HttpEntity<ExceptionResponseEntity> httpMediaTypeNotSupportedExceptionHandler(HttpMediaTypeNotSupportedException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("HttpMediaTypeNotSupportedException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.NOT_ACCEPTABLE);
	}
	
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = IllegalArgumentException.class)
	public HttpEntity<ExceptionResponseEntity> illegalArgumentExceptionHandler(IllegalArgumentException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("IllegalArgumentException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = HttpMessageNotReadableException.class)
	public HttpEntity<ExceptionResponseEntity> httpMessageNotReadableException(HttpMessageNotReadableException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("HttpMessageNotReadableException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(value = DataIntegrityViolationException.class)
	public HttpEntity<ExceptionResponseEntity> dataIntegrityViolationException(DataIntegrityViolationException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("DataIntegrityViolationException")
				.uri(request.getRequestURL().toString()).build();
		
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = EmptyFileException.class)
	public HttpEntity<ExceptionResponseEntity> emptyFileException(EmptyFileException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("EmptyFileException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = ConstraintViolationException.class)
	public HttpEntity<ExceptionResponseEntity> constraintViolationException(ConstraintViolationException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()).exceptionType("ConstraintViolationException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.BAD_REQUEST);
	}
	
	//PropertyReferenceException
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = PropertyReferenceException.class)
	public HttpEntity<ExceptionResponseEntity> propertyReferenceException(PropertyReferenceException exception, HttpServletRequest request) {
		ExceptionResponseEntity exceptionEntity = ExceptionResponseEntity.builder().message(exception.getMessage()+" Reason : There might be the difference between the field name i.e  sortColumnName,  which you are sending to sort and which actually exist into entity.").exceptionType("PropertyReferenceException")
				.uri(request.getRequestURL().toString()).build();
		return new ResponseEntity<ExceptionResponseEntity>(exceptionEntity,HttpStatus.BAD_REQUEST);
	}
}
