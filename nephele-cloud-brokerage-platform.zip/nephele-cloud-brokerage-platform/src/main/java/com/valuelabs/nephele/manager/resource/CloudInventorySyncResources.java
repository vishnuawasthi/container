package com.valuelabs.nephele.manager.resource;

import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
//@Setter
//@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudInventorySyncResources {
	
	private final String message="Inventory Synchronisation Initialised.";

}
