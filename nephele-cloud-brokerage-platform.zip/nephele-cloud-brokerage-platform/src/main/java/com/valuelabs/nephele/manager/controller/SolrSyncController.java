package com.valuelabs.nephele.manager.controller;

import java.util.List;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.B2BSolarProductSyncEvent;
import com.valuelabs.nephele.admin.rest.lib.service.BundleQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudProductQueryService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/manager")
@Slf4j
public class SolrSyncController {

	public static final String EXCHANGE_NAME = "nephele.cloud.b2b.sync.exchange";

	public static final String SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY = "nephele.cloud.b2b.solar.search.product.syncKey";

	@Autowired
	BundleQueryService bundleService;

	@Autowired
	RabbitTemplate rabbitTemplate;

	@Autowired
	private CloudProductQueryService productQueryService;

	@RequestMapping(value = "/syncProductsAndBundles", method = RequestMethod.POST)
	public HttpEntity<String> syncProductsAndBundles() {
		log.info("syncProductsAndBundles -- start");
		try {
			List<BundleDetails> bundleList = bundleService.readPublishedBundles();
			List<CloudProductDetails> publishedProducts = productQueryService.readProductsByStatus("PUBLISHED");
			
			if (!CollectionUtils.isEmpty(publishedProducts)) {
				B2BSolarProductSyncEvent syncProductsEvent = new B2BSolarProductSyncEvent()
						.setRebuildProductListDetails(publishedProducts);
				log.info("Solr bundle request:{}" + syncProductsEvent);
				rabbitTemplate.convertAndSend(EXCHANGE_NAME, SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY,
						syncProductsEvent);
			}
			if (!CollectionUtils.isEmpty(bundleList)) {
				B2BSolarProductSyncEvent syncBundleEvent = new B2BSolarProductSyncEvent()
						.setBundleListDetails(bundleList);
				log.info("Solr bundle request:{}" + syncBundleEvent);
				rabbitTemplate.convertAndSend(EXCHANGE_NAME, SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY,
						syncBundleEvent);
			}
			
		} catch (Exception e) {
			log.error("Exception in syncSolrProductBundles" + e.getMessage());
		}
		log.info("syncProductsAndBundles -- end");
		return new ResponseEntity<>(HttpStatus.OK);
	}

	/*@RequestMapping(value = "/syncProducts", method = RequestMethod.POST)
	public HttpEntity<String> syncSolrProducts() {
		log.debug("syncSolrProducts --Start");
		try {
			List<CloudProductDetails> publishedProducts = productQueryService.readProductsByStatus("PUBLISHED");

			if (!CollectionUtils.isEmpty(publishedProducts)) {
				B2BSolarProductSyncEvent productListSyncEvent = new B2BSolarProductSyncEvent()
						.setProductListDetails(publishedProducts);
				rabbitTemplate.convertAndSend(EXCHANGE_NAME, SOLAR_SEARCH_PRODUCT_SYNC_ROUTING_KEY,
						productListSyncEvent);
			}

		} catch (Exception e) {
			log.error("Exception in syncSolrProducts " + e.getMessage());
		}
		log.debug("syncSolrProducts --End");
		return new ResponseEntity<>(HttpStatus.OK);
	}*/
}
