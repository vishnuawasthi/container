package com.valuelabs.nephele.marketplace.resource;


import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;




@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudServerResource extends ResourceSupport {

	private Long serverId;
	private String name;
	private String description;
	private String status;
	private String brandCode;
	private String brandName;
	private String vendorStatus;
	private Long orderId;
	private Long customerId;
	private String customerName;
	private String publicIPV4Address;
	private String publicIPV6Address;
	private String privateIPV4Address;
	private String privateIPV6Address;
	private String username;
	private String password;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date creationDate;
	
	private String integrationCode;
	private String categoryName;
	//private Integer productId;
	//private String uri;
	//private String privateAddress;
	//private String serverGroup;
	//private String username;
	//private String publicAddress;
	//private String password;
	//private String cspServerId;
	//private Integer locationId;
    //private Integer cloudServiceId;
    //private Integer cloudOrderLineId;
	
}
