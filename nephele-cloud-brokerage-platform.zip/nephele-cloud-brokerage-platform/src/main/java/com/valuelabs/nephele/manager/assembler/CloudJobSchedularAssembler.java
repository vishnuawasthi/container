package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudJobSchedularDetails;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudJobSchedularResources;
import com.valuelabs.nephele.manager.controller.CloudJobSchedularQueryController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CloudJobSchedularAssembler
		extends ResourceAssemblerSupport<CloudJobSchedularDetails, CloudJobSchedularResources> {

	public CloudJobSchedularAssembler() {
		super(CloudJobSchedularDetails.class, CloudJobSchedularResources.class);
	}

	@Override
	public CloudJobSchedularResources toResource(CloudJobSchedularDetails details) {
		log.debug("toResource() : START");
		CloudJobSchedularResources resource = instantiateResource(details);

		resource = CloudJobSchedularResources.builder().jobId(details.getJobId()).minutes(details.getMinutes())
				.hours(details.getHours()).scheduledDate(details.getScheduledDate()).jobtype(details.getJobtype())
				.cloudserviceId(details.getCloudserviceId())
				.status(details.getStatus()).build();
		resource.add(linkTo(methodOn(CloudJobSchedularQueryController.class).readScheduledJob(details.getJobId()))
				.withSelfRel());
		log.debug("toResource() : END");
		return resource;

	}

	public CloudJobSchedularDetails fromResouce(CloudJobSchedularResources resource) {
		log.debug("fromResource: START:{} ", resource);
		CloudJobSchedularDetails details = CloudJobSchedularDetails.builder().jobId(resource.getJobId())
				.minutes(resource.getMinutes()).hours(resource.getHours()).scheduledDate(resource.getScheduledDate())
				.jobtype(resource.getJobtype()).cloudserviceId(resource.getCloudserviceId())
				.status(resource.getStatus()).build();
		log.debug("fromResouce() : END");
		return details;
	}

}
