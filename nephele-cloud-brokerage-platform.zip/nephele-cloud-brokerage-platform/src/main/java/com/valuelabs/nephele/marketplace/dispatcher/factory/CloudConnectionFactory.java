package com.valuelabs.nephele.marketplace.dispatcher.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.valuelabs.nephele.cloud.connection.factory.CloudTypes;
import com.valuelabs.nephele.cloud.service.dispatcher.NomadeskServiceDispatcherImpl;
import com.valuelabs.nephele.cloud.service.dispatcher.RackspaceServiceDispatcherImpl;
import com.valuelabs.nephele.cloud.service.dispatcher.ServiceDispatcher;
import com.valuelabs.nephele.cloud.service.dispatcher.SoftlayerServiceDispatcherImpl;

@Component("cloudConnectionFactory")
public class CloudConnectionFactory {

	
	@Autowired
	@Qualifier("RackspaceServiceDispatcher")
	private RackspaceServiceDispatcherImpl rackspaceServiceDispatcherImpl;
	
	@Autowired
	@Qualifier("NomadeskServiceDispatcher")
	private NomadeskServiceDispatcherImpl nomadeskServiceDispatcherImpl;
	
	@Autowired
	@Qualifier("SoftlayerServiceDispatcher")
	private SoftlayerServiceDispatcherImpl softlayerServiceDispatcherImpl;

	public ServiceDispatcher getInstance(CloudTypes cloudType) {
		
		if(cloudType.equals(CloudTypes.rackspace)){
			return rackspaceServiceDispatcherImpl;
		}else if(cloudType.equals(CloudTypes.nomadesk)){
			return nomadeskServiceDispatcherImpl;
		}else if (cloudType.equals(CloudTypes.softlayer)){
			return  softlayerServiceDispatcherImpl;
		}
		/* else if(cloudType.equals(CloudTypes.AZURE)){
			type = (Class<V>) AzureCloudConnection.class;
		} */
		else{
			return null;
		}
	}

}
