package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode
@Setter
@Getter
@Builder
@Accessors(chain=true)
public class CloudOrderLineResource extends ResourceSupport {
	private Long cloudOrderLineId;
	private String quantity;
	private String configuration;
	private Long cloudOrderId;
	private Long cloudProductId;
	
	private String status;

}
