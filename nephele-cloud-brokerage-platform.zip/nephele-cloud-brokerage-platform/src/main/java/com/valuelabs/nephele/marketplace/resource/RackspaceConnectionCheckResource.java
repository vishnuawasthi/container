package com.valuelabs.nephele.marketplace.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
public class RackspaceConnectionCheckResource {

	private Integer serviceId;
	private String username;
	private String password;
	private String apiKey;
	private Boolean isConnected;
}
