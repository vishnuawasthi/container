package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.CREATE_RESELLER_DATA_ROUTING_KEY;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.DELETE_RESELLER_DATA_ROUTING_KEY;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.EXCHANGE_NAME;
import static com.valuelabs.nephele.manager.configuration.B2BServiceIntegrationMQConfig.UPDATE_RESELLER_DATA_ROUTING_KEY;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;
import javax.validation.Valid;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;
import com.valuelabs.nephele.admin.data.repository.CloudResellerCompanyRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudResellerCompanyCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudResellerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.DeleteResellerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.UpdateCloudResellerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerCompanyCommandService;
import com.valuelabs.nephele.alerts.notifier.service.MailService;
import com.valuelabs.nephele.alerts.notifier.service.VelocityService;
import com.valuelabs.nephele.manager.assembler.CloudResellerCompanyAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudResellerCompanyResource;
import com.valuelabs.nephele.manager.resource.CloudResellerCompanyResources;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/manager/resellerCompany")
public class CloudResellerComapanyCommandController {

	@Autowired
	private CloudResellerCompanyCommandService service;

	@Autowired
	private CloudResellerCompanyAssembler assember;
	
	@Autowired
	RabbitTemplate rabbitTemplate;
	
	/*@Autowired
	CloudResellerCompanyDAO resellerCompanyDAO;*/
	
	@Autowired
	CloudResellerCompanyRepository resellerCompanyRepository;
	
	@Autowired
	private VelocityService velocityService;
	
	@Autowired
	private MailService mailService;


	/*@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerCompanyResource> createCloudResellerCompany(@Valid @RequestBody CloudResellerCompanyResource resource,BindingResult result) throws IllegalArgumentException{
		log.info(" createCloudResellerCompany()  - start");
		CloudResellerCompanyCreatedEvent response = null;
		if(result.hasErrors()) {
			return new ResponseEntity<CloudResellerCompanyResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudResellerCompanyDetails details = assember.fromResource(resource);
		CreateCloudResellerCompanyEvent request = new CreateCloudResellerCompanyEvent().setResellerCompanyDetails(details);
		if (request != null) {
			response = service.createResellerCompany(request);
		}
		log.info(" createCloudResellerCompany()  - end");
		CloudResellerCompanyResource responseResource=CloudResellerCompanyResource.builder().resellerCompanyId(response.getResellerCompanyDetails().getResellerCompanyId()).build();
		return new ResponseEntity<CloudResellerCompanyResource>(responseResource , HttpStatus.CREATED);
	}*/
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerCompanyResource> updateCloudResellerCompanies(@RequestBody CloudResellerCompanyResources resources,BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info(" updateCloudResellerCompanies()  - start");
		List<CloudResellerCompanyDetails> details = assember.fromResource(resources);
		UpdateCloudResellerCompanyEvent request = new UpdateCloudResellerCompanyEvent().setResellerCompanyDetailsList(details);
		if (request != null) {
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, UPDATE_RESELLER_DATA_ROUTING_KEY ,	request);
		}
		log.info(" updateCloudResellerCompanies()  - end");
		return new ResponseEntity<CloudResellerCompanyResource>(HttpStatus.OK);
	}
	
	
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerCompanyResource> createCloudResellerCompanies( @RequestBody CloudResellerCompanyResources resources,BindingResult result) throws IllegalArgumentException {
		log.info(" createCloudResellerCompanies()  - start");
		List<CloudResellerCompanyDetails> details = assember.fromResource(resources);
		CreateCloudResellerCompanyEvent request = new CreateCloudResellerCompanyEvent().setResellerCompanyDetailsList(details);
		
		if (null != request) {
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, CREATE_RESELLER_DATA_ROUTING_KEY ,	request);
		}
		
		log.info(" createCloudResellerCompanies()  - end");
		return new ResponseEntity<CloudResellerCompanyResource>(HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/sync",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerCompanyResource> syncResellerCompanies(@Valid @RequestBody CloudResellerCompanyResources resources,BindingResult result) throws IllegalArgumentException {
		log.info("syncResellerCompanies()  - start");
		List<CloudResellerCompanyDetails> details = assember.fromResource(resources);
		List<CloudResellerCompanyDetails> listToSave = new ArrayList<CloudResellerCompanyDetails>(); 
		List<CloudResellerCompanyDetails> listToUpdate = new ArrayList<CloudResellerCompanyDetails>();
		List<CloudResellerCompanyDetails> listToDelete = new ArrayList<CloudResellerCompanyDetails>();
		CreateCloudResellerCompanyEvent createRequest = new CreateCloudResellerCompanyEvent();
		UpdateCloudResellerCompanyEvent updateRequest = new UpdateCloudResellerCompanyEvent();
		DeleteResellerCompanyEvent deleteRequest=new DeleteResellerCompanyEvent();
		CloudResellerCompany entity= null;
		if (!CollectionUtils.isEmpty(details)) {
			for (int index = 0; index < details.size(); index++) {
				if (details.get(index).getIsActive()) {
					CloudResellerCompanyDetails company = details
							.get(index);
					try {
						entity = resellerCompanyRepository
								.findByExternalResellerCode(company
										.getExternalResellerCompanyCode());
					} catch (NoResultException e) {
						log.error("Exception while getting reseller company in syncResellerCompanies() ");
					}

					if (null != entity) {
						listToUpdate.add(company);
					}else if(null == entity){
						listToSave.add(company);
					}
				} else {
					listToDelete.add(details.get(index));
				}
			}
		}
		if(!CollectionUtils.isEmpty(listToSave)) {
			createRequest.setResellerCompanyDetailsList(listToSave);
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, CREATE_RESELLER_DATA_ROUTING_KEY, createRequest);
		}
		
		if(!CollectionUtils.isEmpty(listToUpdate)) {
			updateRequest.setResellerCompanyDetailsList(listToUpdate);
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, UPDATE_RESELLER_DATA_ROUTING_KEY, updateRequest);
		}
		
		if(!CollectionUtils.isEmpty(listToDelete)) {
			deleteRequest.setResellerCompanyList(listToDelete);
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, DELETE_RESELLER_DATA_ROUTING_KEY, deleteRequest);
		}
		
		log.info("syncResellerCompanies()  - end");
		return new ResponseEntity<CloudResellerCompanyResource>(HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/{externalResellerCompanyCode}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerCompanyResource> deleteResellerCompany(@PathVariable String externalResellerCompanyCode){
		log.info("deleteResellerCompany()  - end");
		
		if(null == externalResellerCompanyCode)
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		
		DeleteResellerCompanyEvent request = new DeleteResellerCompanyEvent().setExternalResellerCompanyCode(externalResellerCompanyCode);
		if(null != request)
		{
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, DELETE_RESELLER_DATA_ROUTING_KEY, request);
		}
		
		log.info("deleteResellerCompany()  - end");
		return new ResponseEntity<CloudResellerCompanyResource>(HttpStatus.OK) ;
	}

	/**
	 * This method updates Premium group associated with reseller company
	 * @param resource
	 * @param result
	 * @return
	 * @throws ResourceNotFoundException
	 * @throws IllegalArgumentException
	 */
	@RequestMapping(value = "/updatePremiumGroup", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerCompanyResource> updatePremiumGroup(
			@RequestBody CloudResellerCompanyResource resource,
			BindingResult result) throws ResourceNotFoundException,
			IllegalArgumentException {
		log.info("updatePremiumGroup()  - start");
		if(StringUtils.isEmpty(resource.getResellerCompanyId()) || StringUtils.isEmpty(resource.getResellerPremiumGroupId()) ) {
			log.info("Bad request received, Required ids are missing...");
			return new ResponseEntity<CloudResellerCompanyResource> (HttpStatus.BAD_REQUEST);
		}
		CloudResellerCompanyDetails details = assember.fromResource(resource);
		CreateCloudResellerCompanyEvent request = new CreateCloudResellerCompanyEvent().setResellerCompanyDetails(details);
				
		if (request != null) {
		  CloudResellerCompanyCreatedEvent  response =    	service.updatePremiumGroup(request);
		  details = response.getResellerCompanyDetails();
			// Sending mail
						try{
							Map<String, Object> map = new HashMap<>();
							String mailSubject = "PremiumGroup update";
							map.put("resellerName", details.getResellerCompanyName());
							String mailBody = velocityService.buildTemplate(map, "resellerPremiumGroupUpdateEmailTemplate.vm");
							List<String> toList = new ArrayList<String>();
							toList.add(details.getEmail());
							mailService.sendEmail(toList, null, null, mailSubject, mailBody);
						}catch(Exception e){
							log.info("Error in sending mail...:" + e.getMessage());
							e.printStackTrace();
						}
		}
		log.info("updatePremiumGroup()  - end");
		return new ResponseEntity<CloudResellerCompanyResource>(HttpStatus.OK);
	}
	
}
