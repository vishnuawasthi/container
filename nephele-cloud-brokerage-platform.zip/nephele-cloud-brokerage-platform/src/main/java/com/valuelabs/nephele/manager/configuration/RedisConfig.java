/*package com.valuelabs.nephele.manager.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import redis.clients.jedis.JedisPoolConfig;

@Configuration
@EnableAutoConfiguration
public class RedisConfig {

	@Value("${redis.host.name}")
	private String host;

	@Value("${redis.host.port}")
	private int port;
	
	@Value("${redis.noofconsumers.value}")
	private int noofconsumers;

	@Bean
	public RedisConnectionFactory jedisConnectionFactory() {

		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxTotal(noofconsumers);
		poolConfig.setTestOnBorrow(true);
		poolConfig.setTestOnReturn(true);

		JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(
				poolConfig);
		jedisConnectionFactory.setUsePool(true);
		jedisConnectionFactory.setHostName(host);
		jedisConnectionFactory.setPort(port);

		return jedisConnectionFactory;
	}

	@Bean
	public <K, V> RedisTemplate<K, V> redisTemplate() {
		RedisTemplate<K, V> redisTemplate = new RedisTemplate<K, V>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
//		redisTemplate.setKeySerializer(new StringRedisSerializer());
//		redisTemplate.setHashValueSerializer(new GenericToStringSerializer<Object>( Object.class));
//		redisTemplate.setValueSerializer(new GenericToStringSerializer<Object>(Object.class));
		return redisTemplate;
	}

}
*/