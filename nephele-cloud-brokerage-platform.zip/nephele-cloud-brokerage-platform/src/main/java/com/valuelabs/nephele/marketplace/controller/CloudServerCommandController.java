package com.valuelabs.nephele.marketplace.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServerEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServerCommandService;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.marketplace.assembler.CloudServerAssembler;
import com.valuelabs.nephele.marketplace.resource.CloudServerResource;


@Slf4j
@RestController
@RequestMapping(value = "/marketplace/servers")
@Transactional
public class CloudServerCommandController {

	@Autowired
	private CloudServerAssembler assembler;

	@Autowired
	CloudServerCommandService service;


	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServerResource> createCloudServer(@Valid @RequestBody CloudServerResource resource, BindingResult result) throws IllegalArgumentException {
		log.info("createCloudServer() : START");
		if(result.hasErrors()){
			return new ResponseEntity<CloudServerResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudServerDetails serverDetails = assembler.fromResource(resource);
		CreateServerEvent request = new CreateServerEvent().setServerDetails(serverDetails);

		if (request != null) {
			service.createCloudServer(request);
		} 

		log.info("createCloudServer() : END");
		return new ResponseEntity<>(HttpStatus.CREATED);

	}


	/*@RequestMapping(value="{id}",method = RequestMethod.DELETE , produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServerResource> deleteCloudServerModel(@PathVariable Integer id){
		log.info("deleteCloudServerModel() : START");

		if(id != null){
		boolean recordDeleted =	commandService.deleteCloudServer(id);
			if(recordDeleted){
				return new ResponseEntity<CloudServerResource>(HttpStatus.ACCEPTED);
			}else{
				return new ResponseEntity<CloudServerResource>(HttpStatus.NOT_FOUND);
			}

		}else{
			return new ResponseEntity<CloudServerResource>(HttpStatus.BAD_REQUEST);
		}

	}*/


	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServerResource> updateCloudServer(@Valid @RequestBody CloudServerResource resource,BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info("updateCloudServer() : START");
		if(resource.getServerId() == null){
			result.addError(new FieldError("resource", "serverID", resource.getServerId(), true, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudServerResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudServerDetails serverDetails = assembler.fromResource(resource);
		CreateServerEvent requestEvent = new CreateServerEvent().setServerDetails(serverDetails);

		if (requestEvent != null) {
			service.updateCloudServerDetails(requestEvent);
		} 

		log.info("updateCloudServer() : END");
		return new ResponseEntity<>(HttpStatus.OK);

	}

}
