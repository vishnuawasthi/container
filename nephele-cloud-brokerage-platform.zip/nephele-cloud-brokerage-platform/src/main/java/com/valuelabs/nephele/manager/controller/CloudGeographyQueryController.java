package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.GEOGRAPHY_CODE;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudGeographyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudGeographiesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudGeographyEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudGeographyQueryService;
import com.valuelabs.nephele.manager.assembler.CloudGeographyAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudGeographyResource;
@Slf4j
@RestController
@RequestMapping("/manager/cloudGeography")
@Transactional
public class CloudGeographyQueryController {

	@Autowired
	private CloudGeographyAssembler assembler;
	
	@Autowired
	private CloudGeographyQueryService service;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudGeographyResource> readCloudGeography(@PathVariable Long id) {
		log.info("readCloudGeography() - start");
		ReadCloudGeographyEvent request = new ReadCloudGeographyEvent().setId(id);
		EntityReadEvent<CloudGeographyDetails> event = service.readCloudGeography(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudGeographyDetails entity = event.getEntity();
		log.info("readCloudGeography() - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudGeographyResource>> readCloudGeographies(
			@RequestParam(value=GEOGRAPHY_CODE,required=false) String geographyCode,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudGeographyDetails> pagedAssembler) {
		log.info("readCloudGeographies()  - start");
		ReadCloudGeographiesEvent request = new ReadCloudGeographiesEvent().setPageable(pageable);
		request.setGeographyCode(geographyCode);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudGeographyDetails> event = service.readCloudGeographies(request);
		Page<CloudGeographyDetails> page = event.getPage();
		PagedResources<CloudGeographyResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudGeographies()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/byLocationCode", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudGeographyResource> readGeographyByLocationCode(
			@RequestParam(QueryParameterConstants.LOCATION_CODE) String locationCode) {
		log.info("readGeographyByLocationCode() - start");
		ReadCloudGeographyEvent request = new ReadCloudGeographyEvent().setLocationCode(locationCode);
		request.setLocationCode(locationCode);
		EntityReadEvent<CloudGeographyDetails> event = service.readCloudGeographyByLocationCode(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudGeographyDetails entity = event.getEntity();
		log.info("readGeographyByLocationCode() - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	
}
