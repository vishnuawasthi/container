package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceManagementSheetDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudProductPriceManagementSheetEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudProductPriceManagementSheetCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.CloudProductPriceManagementSheetAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudProductPriceManagementSheetResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Transactional
@RequestMapping(value = "/manager/priceManagementSheet")
public class CloudProductPriceManagementSheetCommandController {

	@Autowired
	private CloudProductPriceManagementSheetAssembler assembler;

	@Autowired
	private CloudProductPriceManagementSheetCommandService service;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductPriceManagementSheetResource> createProductPriceManagementSheet(
			@Valid @RequestBody CloudProductPriceManagementSheetResource resource, BindingResult result)
					throws IllegalArgumentException {
		log.info("createProductPriceManagementSheet()  - start");
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		CloudProductPriceManagementSheetDetails details = assembler.fromResource(resource);
		CreateCloudProductPriceManagementSheetEvent request = new CreateCloudProductPriceManagementSheetEvent()
				.setDetails(details);
		if (request != null) {
			service.createProductPriceManagementSheet(request);
		}
		log.info("createCloudDistributorCompany()  - end");
		return new ResponseEntity<CloudProductPriceManagementSheetResource>(HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudProductPriceManagementSheetResource> updateCloudProductPriceManagementSheet(
			@Valid @RequestBody CloudProductPriceManagementSheetResource resource, BindingResult result)
					throws IllegalArgumentException, ResourceNotFoundException {
		log.info(" updateCloudProductPriceManagementSheet()  - start");
		if (resource.getProductPriceManagementSheetId() == null) {
			result.addError(new FieldError("resource", "id should not be null", resource.getProductPriceManagementSheetId(), false, null, null, null));
		}
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		CloudProductPriceManagementSheetDetails details = assembler.fromResource(resource);
		CreateCloudProductPriceManagementSheetEvent request = new CreateCloudProductPriceManagementSheetEvent()
				.setDetails(details);
		if (request != null) {
			service.updateProductPriceManagementSheet(request);
		}
		log.info("updateCloudDistributorCompany()  - end");
		return new ResponseEntity<CloudProductPriceManagementSheetResource>(HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/exportCSV", produces = "text/csv")
	public void exportProdcutPriceMgmtSheetInCsvFormat(@RequestParam(value="serviceId") String serviceId,@RequestParam(value = "sheetName") String sheetName, HttpServletResponse response) {
		log.info(" exportComputePriceDataInCsvFormatGet()  - start");

		Long serId = serviceId != null ? Long.valueOf(serviceId) : 0;
        String status = service.exportProductPriceMgmtSheetDataInCsvFormat(serId, response , sheetName);
        
        log.info("exportComputePriceDataInCsvFormat() : END");
		//return new ResponseEntity<CloudRackspaceComputePriceResource>(CloudRackspaceComputePriceResource.builder().status(status).build(), HttpStatus.OK);
	}
	
	@RequestMapping(value="/importCSV", method=RequestMethod.POST)
    public @ResponseBody HttpEntity<String> importProdcutPriceMgmtSheetFromFile(@RequestParam(value="file") MultipartFile file ){
        log.info(" importProdcutPriceMgmtSheetFromFile() - Start");
        String status = "";
        if (!file.isEmpty()) {
        	status = service.loadProductPriceMgmtSheetCsvData(file);
        } else {
        	status = "You failed to upload " + file.getName() + " because the file is empty.";
        	return new ResponseEntity<String>(status,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<String>(status,HttpStatus.OK);
    }
}
