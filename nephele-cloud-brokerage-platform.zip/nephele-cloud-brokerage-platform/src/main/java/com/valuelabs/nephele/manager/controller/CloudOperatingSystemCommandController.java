package com.valuelabs.nephele.manager.controller;
import static com.valuelabs.nephele.manager.configuration.ServiceLifeCycleMQConfig.EXCHANGE_NAME;
import static com.valuelabs.nephele.manager.configuration.ServiceLifeCycleMQConfig.MARKETPLACE_PRODUCT_SYNC_BY_OS_ROUTING_KEY;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.MarketPlaceProductServiceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudOperatingSystemEvent;
import com.valuelabs.nephele.admin.rest.lib.event.MarketPlaceProductServiceEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudOperatingSystemCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResources;
import com.valuelabs.nephele.manager.assembler.CloudOperatingSystemAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/manager/operatingSystem")
@Transactional
public class CloudOperatingSystemCommandController {

	@Autowired
	private CloudOperatingSystemCommandService service;

	@Autowired
	private CloudOperatingSystemAssembler assembler;
		
	
	@Autowired
	RabbitTemplate rabbitTemplate;
	
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudOperatingSystemResource> updateCloudOperatingSystem(@Valid @RequestBody CloudOperatingSystemResource resource, BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info(" updateCloudOperatingSystem()  - start");
		
		if(resource.getOperatingSystemId() ==null) {
			result.addError(new FieldError("resource", "operatingSystemId", resource.getOperatingSystemId(),false, null, null, null));
		}
		if(result.hasErrors()) {
			return new ResponseEntity<CloudOperatingSystemResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudOperatingSystemDetails details = assembler.fromResource(resource);
		
		CreateCloudOperatingSystemEvent request = new CreateCloudOperatingSystemEvent().setCloudOperatingSystemDetails(details);
		
		if (request != null) {
			
			service.updateCloudOperatingSystem(request);
			
			MarketPlaceProductServiceDetails productsByServiceDetails = MarketPlaceProductServiceDetails.builder().operatingSystemId(resource.getOperatingSystemId())
																												  .status(resource.getStatus())
																												  .build();
			MarketPlaceProductServiceEvent serviceRequest = new MarketPlaceProductServiceEvent().setManageProductsByServiceDetails(productsByServiceDetails);
			rabbitTemplate.convertAndSend(EXCHANGE_NAME, MARKETPLACE_PRODUCT_SYNC_BY_OS_ROUTING_KEY,	serviceRequest);
		}
		
		log.info(" updateCloudOperatingSystem()  - end");
		return new ResponseEntity<CloudOperatingSystemResource>(HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param resources
	 * @return
	 */
	@RequestMapping(value = "/updateStatusById", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity <CloudOperatingSystemResources> updateStatusById(@RequestBody CloudOperatingSystemResources resources) {
		log.info("updateStatusById - start");
		int errorCounter = 0;
		List<CloudOperatingSystemDetails> detailsList = new ArrayList<CloudOperatingSystemDetails>();
		for (CloudOperatingSystemResource resource : resources.getResources()) {
			if(resource.getOperatingSystemId()==null) {
				errorCounter++;
			}
			CloudOperatingSystemDetails details = CloudOperatingSystemDetails.builder().operatingSystemId(resource.getOperatingSystemId())
					.status(resource.getStatus()).build();
			detailsList.add(details);
		}
		if(errorCounter!=0) {
			return new ResponseEntity<CloudOperatingSystemResources>(resources, HttpStatus.BAD_REQUEST);
		}
		CreateCloudOperatingSystemEvent request = new CreateCloudOperatingSystemEvent().setCloudOperatingSystemDetailsList(detailsList);
		service.updateStatusById(request);
		log.info("updateStatusById - end");
		return new ResponseEntity<CloudOperatingSystemResources>(HttpStatus.OK);
	}
	
}
