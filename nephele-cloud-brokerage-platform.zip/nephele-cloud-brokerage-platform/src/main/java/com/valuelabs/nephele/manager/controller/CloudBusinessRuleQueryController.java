package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.BUSINESS_RULE_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudBusinessRuleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudBusinessRuleEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudBusinessRulesEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudBusinessRuleQueryService;
import com.valuelabs.nephele.manager.assembler.CloudBusinessRuleAssembler;
import com.valuelabs.nephele.manager.resource.CloudBusinessRuleResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Transactional
@RequestMapping("/manager/cloudBusinessRule")
public class CloudBusinessRuleQueryController {

	@Autowired
	private CloudBusinessRuleAssembler assembler;

	@Autowired
	private CloudBusinessRuleQueryService service;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudBusinessRuleResource> readCloudBusinessRule(@PathVariable Long id) {
		log.info("readCloudBusinessRule () - start");
		ReadCloudBusinessRuleEvent request = new ReadCloudBusinessRuleEvent().setRuleId(id);
		EntityReadEvent<CloudBusinessRuleDetails> event = service.readCloudBusinessRule(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudBusinessRuleDetails entity = event.getEntity();
		log.info("readCloudBusinessRule () - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudBusinessRuleResource>> readCloudBusinessRules(
			@RequestParam(value=BUSINESS_RULE_NAME,required=false) String ruleName,
            @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,

			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudBusinessRuleDetails> pagedAssembler) {
		log.info("readCloudBusinessRules()  - start");
		ReadCloudBusinessRulesEvent request = new ReadCloudBusinessRulesEvent().setPageable(pageable);
		// Search criteria
		request.setRuleName(ruleName);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<CloudBusinessRuleDetails> event = service.readCloudBusinessRules(request);
		Page<CloudBusinessRuleDetails> page = event.getPage();
		PagedResources<CloudBusinessRuleResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudBusinessRules()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
