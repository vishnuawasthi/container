package com.valuelabs.nephele.manager.controller;

import java.util.Map;

import javax.persistence.NoResultException;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.NepheleTimeZone;
import com.valuelabs.nephele.admin.data.api.ServiceType;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceCredentialDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceEnableDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceCredentialEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServicesEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.exception.ValidationException;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServiceCredentialQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.CloudServiceQueryService;
import com.valuelabs.nephele.manager.assembler.CloudServiceResourceAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudServiceEnableResource;
import com.valuelabs.nephele.manager.resource.CloudServiceResource;

@Slf4j
@RestController
@RequestMapping(value = "/")
public class CloudServiceQueryController {

	@Autowired
	private CloudServiceResourceAssembler assembler;

	@Autowired
	private CloudServiceQueryService service;
	
	@Autowired
	private CloudServiceCredentialQueryService credentialService;

	@RequestMapping(value = "manager/services/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceResource> readService(
			@PathVariable Long id) {
		log.info("readService() START");

		ReadServiceEvent request = new ReadServiceEvent().setId(id);

		EntityReadEvent<CloudServiceDetails> event = service
				.readService(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudServiceDetails entity = event.getEntity();
		log.info("readService() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(value = "manager/services", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServiceResource>> readServices(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@RequestParam(value=QueryParameterConstants.BRAND_NAME,required=false) String brandName,
			@RequestParam(value=QueryParameterConstants.SERVICE_NAME,required=false)String serviceName,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServiceDetails> pagedAssembler) {
		log.info("readServices() START");
		ReadServicesEvent request = new ReadServicesEvent();
		
		// Building search Criteria
		request.setPageable(pageable);
		request.setBrandName(brandName);
		request.setServiceName(serviceName);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);

		PageReadEvent<CloudServiceDetails> event = service.readServices(request);

		Page<CloudServiceDetails> page = event.getPage();
		PagedResources<CloudServiceResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readServices() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="manager/services/active",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServiceResource>> readActiveServices(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServiceDetails> pagedAssembler) {
		log.info("readActiveServices() START");
		ReadServicesEvent request = new ReadServicesEvent().setPageable(pageable);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudServiceDetails> event = service.readActiveServices(request);
		Page<CloudServiceDetails> page = event.getPage();
		PagedResources<CloudServiceResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readActiveServices() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="marketplace/services",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServiceResource>> readActiveServicesForMarketPlace(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value=Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServiceDetails> pagedAssembler) {
		log.info("readActiveServices() START");
		ReadServicesEvent request = new ReadServicesEvent().setPageable(pageable);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudServiceDetails> event = service.readActiveServices(request);
		Page<CloudServiceDetails> page = event.getPage();
		PagedResources<CloudServiceResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readActiveServices() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "marketplace/services/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceResource> readServiceDetails(
			@PathVariable Long id) {
		log.info("readService() START");

		ReadServiceEvent request = new ReadServiceEvent().setId(id);

		EntityReadEvent<CloudServiceDetails> event = service
				.readService(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudServiceDetails entity = event.getEntity();
		log.info("readService() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	/*
	 * API Request Param : serviceId 
     * Authentication  : select username, apikey from cloud_service_credential where serviced={};
     * Pricing:  select count(*) from cloud_product_price_management_config where status=’ACTIVE’ and serviced={};
     * DiscountPlan: select count(*) from cloud_premium_group_discount_config where status=’ACTIVE’ and serviced={};
     * BillingCycle : select billing_day from cloud_service where serviced={}; 
    */
	
	@RequestMapping(value="manager/services/serviceEnable",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceEnableResource> getServiceEnableResults(@RequestParam(value="serviceId",required=true) Long id)  throws   ResourceNotFoundException{
		CloudServiceEnableResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		log.info("Controller - getServiceEnableResults() START");
		ReadServiceEvent request = new ReadServiceEvent().setId(id);
		try{
		EntityReadEvent<CloudServiceEnableDetails> event = service.getServiceEnableResults(request);		
		CloudServiceEnableDetails details = event.getEntity();		
		log.info("Checking service credentials");
		// used to check record is available in CloudServiceCredential table with the serviceid.
		// if exists checking the serverconnection is valid or not
		ReadServiceCredentialEvent credentialRequest = new ReadServiceCredentialEvent().setCloudServiceId(id);
		EntityReadEvent<CloudServiceCredentialDetails> credentialDetails = null;
		try{
				credentialDetails = credentialService.getServiceCredentialsByServiceId(credentialRequest);	
		}catch(NoResultException re){
			log.error("credentialDetails Resource not found for serviceid : "+id);
		}
		if(null != credentialDetails ) {
			details.setAuthentication(true);
		}else{
			 details.setAuthentication(false);
		}
		   
		log.info("Checking service credentials - End");
		responseResource = CloudServiceEnableResource.builder()
														.authentication(details.isAuthentication())
														.pricing(details.isPricing())
														.billingCycle(details.isBillingCycle())
														.discountPlan(details.isDiscountPlan())
														.integarionCode(details.getIntegrationCode())
														.serviceName(details.getServiceName())
														.isServicePublished(details.isServicePublished())
														.isServiceLive(details.isServiceLive())
														.serviceId(id)
														.build();
		}catch(NepheleException | ValidationException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			//responseResource = CloudServiceEnableResource.builder().message(message).build();
		}
		/*catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
			//responseResource = CloudServiceEnableResource.builder().message(message).build();
			return new ResponseEntity<>(statusCode);
		}*/
		log.info("Controller - getServiceEnableResults() End");
		return new ResponseEntity<>(responseResource, statusCode);
	}
	
	@RequestMapping(value = "manager/services/activeCount", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Long>> readActiveServicesCount() {
		log.info("readActiveServicesCount() -START");
		ReadServicesEvent request = new ReadServicesEvent();
		Map<String, Long> event = service.readActiveServicesCount(request);
		log.info("readActiveServicesCount() -END");
		return new ResponseEntity<>(event, HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/services/timeZones", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceResource> getTimeZone(){
		
		CloudServiceResource response = new  CloudServiceResource().setNepheleTimeZones(EnumUtils.getEnumList(NepheleTimeZone.class));
		
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "manager/services/serviceType", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceResource> getServiceType(){
		
		CloudServiceResource response = new  CloudServiceResource().setServiceTypes(EnumUtils.getEnumList(ServiceType.class));
		
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}

}
