package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
public class CloudProductPriceMgmtSheetExportResource extends ResourceSupport {
	
	private Integer PLAN_ID;
	
	private Integer PRICE_CONFIG_ID;
	
	private String SHEET_NAME;
	
	private String PLAN_NAME;
	
	private String SERVICE;
	
	private String PRODUCT_NAME;
	
	private String LOCATION;
	
	private Double PRICE;

	
	
	/*public CloudProductPriceMgmtSheetExportResource(Integer pLAN_ID,
			Integer pRICE_CONFIG_ID, String sHEET_NAME, String pLAN_NAME,
			String sERVICE, String pRODUCT_NAME, String lOCATION) {
		super();
		PLAN_ID = pLAN_ID;
		PRICE_CONFIG_ID = pRICE_CONFIG_ID;
		SHEET_NAME = sHEET_NAME;
		PLAN_NAME = pLAN_NAME;
		SERVICE = sERVICE;
		PRODUCT_NAME = pRODUCT_NAME;
		LOCATION = lOCATION;
	}*/
}
