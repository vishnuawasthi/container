package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceUsageDataDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudRackspaceUsageDataEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudRackspaceUsageDataCommandService;
import com.valuelabs.nephele.manager.assembler.CloudRackspaceUsageDataAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudRackspaceUsageDataResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Transactional
@RequestMapping(value = "/cloudRackspaceUsageData")
public class CloudRackspaceUsageDataCommandController {

	@Autowired
	private CloudRackspaceUsageDataAssembler assembler;

	@Autowired
	private CloudRackspaceUsageDataCommandService service;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudRackspaceUsageDataResource> createCloudRackspaceUsageData(@Valid @RequestBody CloudRackspaceUsageDataResource resource ,BindingResult result) throws IllegalArgumentException {
		log.info("createCloudRackspaceUsageData()  - start");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudRackspaceUsageDataResource>(resource,HttpStatus.BAD_REQUEST); 
		}
		CloudRackspaceUsageDataDetails details = assembler.fromResource(resource);
		CreateCloudRackspaceUsageDataEvent request = new CreateCloudRackspaceUsageDataEvent().setCloudRackspaceUsageDataDetails(details);
		if (request != null) {
			service.createCloudRackspaceUsageData(request);
		}
		log.info("createCloudRackspaceUsageData()  - end");
		return new ResponseEntity<CloudRackspaceUsageDataResource>(HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudRackspaceUsageDataResource> updateCloudRackspaceUsageData(@Valid @RequestBody CloudRackspaceUsageDataResource resource,BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateCloudRackspaceUsageData()  - start");
		if (resource.getCloudRackspaceUsageDataId() == null) {
			result.addError(new FieldError("resource", "CloudRackspaceUsageDataId", resource.getCloudRackspaceUsageDataId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudRackspaceUsageDataResource>(resource, HttpStatus.BAD_REQUEST);
		}
		CloudRackspaceUsageDataDetails details = assembler.fromResource(resource);
		CreateCloudRackspaceUsageDataEvent request = new CreateCloudRackspaceUsageDataEvent().setCloudRackspaceUsageDataDetails(details);
		if (request != null) {
			service.updateCloudRackspaceUsageData(request);
		}
		log.info("updateCloudRackspaceUsageData()  - end");
		return new ResponseEntity<CloudRackspaceUsageDataResource>(HttpStatus.OK);
	}

}
