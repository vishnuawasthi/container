package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudDistributorCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudDistributorCompanyCommandService;
import com.valuelabs.nephele.manager.assembler.CloudDistributorCompanyAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudDistributorCompanyResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="/manager/cloudDistributorCompany")
@Transactional
public class CloudDistributorCompanyCommandController {
	
	@Autowired
	private CloudDistributorCompanyAssembler assembler;

	@Autowired
	private CloudDistributorCompanyCommandService service;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudDistributorCompanyResource> createCloudDistributorCompany(@Valid @RequestBody CloudDistributorCompanyResource resource,BindingResult result) throws IllegalArgumentException{
		log.info("createCloudDistributorCompany()  - start");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudDistributorCompanyResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudDistributorCompanyDetails details = assembler.fromResource(resource);
		CreateCloudDistributorCompanyEvent request = new CreateCloudDistributorCompanyEvent().setCloudDistributorCompanyDetails(details);
		if (request != null) {
			service.createCloudDistributorCompany(request);
		}
		log.info("createCloudDistributorCompany()  - end");
		return new ResponseEntity<CloudDistributorCompanyResource>(HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudDistributorCompanyResource> updateCloudDistributorCompany(@Valid @RequestBody CloudDistributorCompanyResource resource,BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info(" updateCloudDistributorCompany()  - start");
		if (resource.getDistributorCompanyId() == null) {
			result.addError(new FieldError("resource", "distributorCompanyId", resource.getDistributorCompanyId(), false, null, null, null));
		}
		if (result.hasErrors()) {
			return new ResponseEntity<CloudDistributorCompanyResource>(resource, HttpStatus.BAD_REQUEST);
		}
		CloudDistributorCompanyDetails details = assembler.fromResource(resource);
		CreateCloudDistributorCompanyEvent request = new CreateCloudDistributorCompanyEvent().setCloudDistributorCompanyDetails(details);
		if (request != null) {
			service.updateCloudDistributorCompany(request);
		}
		log.info("updateCloudDistributorCompany()  - end");
		return new ResponseEntity<CloudDistributorCompanyResource>(HttpStatus.OK);
	}
}
