package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.api.BundleStatus;
import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundleEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundlesEvent;
import com.valuelabs.nephele.admin.rest.lib.service.BundleQueryService;
import com.valuelabs.nephele.marketplace.assembler.BundleAssembler;
import com.valuelabs.nephele.marketplace.resource.BundleResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/")
public class BundleQueryController {
	
	@Autowired
	private BundleQueryService bundleQueryService;
	
	@Autowired
	private BundleAssembler bundleAssembler;
	
	@RequestMapping(value="manager/bundles", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<BundleResource>> readBundlesForManager(
		@RequestParam(value="name",required=false)String name,
		@RequestParam(value="status",required=false)String status,
        @RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
		PagedResourcesAssembler<BundleDetails> pagedAssembler) {
		log.info("readBundlesForManager() START");
		ReadBundlesEvent request=new ReadBundlesEvent().setPageable(pageable);
		request.setName(name);
		request.setStatus(status);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<BundleDetails> event=bundleQueryService.readBundles(request);

		Page<BundleDetails> page=event.getPage();
		PagedResources<BundleResource> pagedResources = pagedAssembler.toResource(page, bundleAssembler);
		log.info("readBundlesForManager() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/manager/bundles/{bundleId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BundleResource> readCloudBundleByIdForManager(@PathVariable Long bundleId){
		log.info("readCloudBundleByIdForManager() - start");
		EntityReadEvent<BundleDetails> event=null;
		if (bundleId != null) {
		ReadBundleEvent request=new ReadBundleEvent().setId(bundleId);
		event = bundleQueryService.readBundle(request);
		}
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		BundleDetails entity=event.getEntity();
		log.info("readCloudBundleByIdForManager() - end");
		return new ResponseEntity<>(bundleAssembler.toResource(entity), HttpStatus.OK);
	}
	
		@RequestMapping(value="/marketplace/bundles",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<PagedResources<BundleResource>> readCloudBundle(
				@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
		        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
				@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
				PagedResourcesAssembler<BundleDetails> pagedAssembler) {
			log.info("readCloudBundle()  - start");
			ReadBundlesEvent request = new ReadBundlesEvent().setPageable(pageable).setStatus(BundleStatus.PUBLISHED.name());
			request.setSortColumnName(sortColumnName);
		    request.setSortDirection(sortDirection);
			PageReadEvent<BundleDetails> event = bundleQueryService.readBundles(request);
			Page<BundleDetails> page = event.getPage();
			PagedResources<BundleResource> pagedResources = pagedAssembler.toResource(page, bundleAssembler);
			log.info("readCloudBundle()  - end");
			return new ResponseEntity<>(pagedResources, HttpStatus.OK);
		}
		
		@RequestMapping(value = "/marketplace/bundles/{bundleId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<BundleResource> readCloudBundleById(@PathVariable Long bundleId){
			log.info("readCloudBundleById() - start");
			ReadBundleEvent request=new ReadBundleEvent().setId(bundleId);
			EntityReadEvent<BundleDetails> event = bundleQueryService.readBundle(request);
			if(!event.isFound()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			BundleDetails entity=event.getEntity();
			log.info("readCloudBundleById() - end");
			return new ResponseEntity<>(bundleAssembler.toResource(entity), HttpStatus.OK);
		}
		
		@RequestMapping(value="/marketplace/bundlesByIds",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<PagedResources<BundleResource>> readCloudBundleByIds(
				@RequestParam(value="ids",required=true) List<Long> bundleIds,
				@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
				PagedResourcesAssembler<BundleDetails> pagedAssembler) {
			log.info("readCloudBundleByIds()  - start");
			ReadBundlesEvent request = new ReadBundlesEvent().setPageable(pageable);
			request.setBundleIds(bundleIds);
			PageReadEvent<BundleDetails> event  = bundleQueryService.readBundlesByIds(request);
			Page<BundleDetails> page = event.getPage();
			PagedResources<BundleResource> pagedResources = pagedAssembler.toResource(page, bundleAssembler);
			log.info("readCloudBundleByIds()  - end");
			return new ResponseEntity<>(pagedResources, HttpStatus.OK);
		}
	
}
