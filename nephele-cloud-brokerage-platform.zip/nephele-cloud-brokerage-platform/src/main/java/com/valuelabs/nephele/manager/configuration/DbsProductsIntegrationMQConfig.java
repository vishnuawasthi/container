package com.valuelabs.nephele.manager.configuration;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
public class DbsProductsIntegrationMQConfig {
	
	@Autowired
	AmqpAdmin rabbitAdmin;
	
	public static final String EXCHANGE_NAME = "nephele.cloud.dbs.sync.exchange";

	public static final String CREATE_DBS_PRODUCTS_DATA_QUEUE_NAME  = "nephele.cloud.create.dbs.products.integration.data.sync.queue";
	public static final String CREATE_DBS_PRODUCTS_DATA_ROUTING_KEY = "nephele.cloud.create.dbs.products.integration.data.syncKey";
	
	
	@Bean(name = "createDbsProductsIntegrationDataQueue")
	public Queue getCreateDbsProductsIntegrationDataQueue() {
		return new Queue(CREATE_DBS_PRODUCTS_DATA_QUEUE_NAME, true);
	}	
	
	@Bean(name = "createDbsProductsIntegrationDataBinding")
	Binding getCreateDbsProductsIntegrationDataBinding(Queue createDbsProductsIntegrationDataQueue, DirectExchange dbsDirectExchange) {
		return BindingBuilder.bind(createDbsProductsIntegrationDataQueue).to(dbsDirectExchange).with(CREATE_DBS_PRODUCTS_DATA_ROUTING_KEY);
	}
	
	@Bean(name = "dbsDirectExchange")
	public DirectExchange getDBSDirectExchange() {
		return new DirectExchange(EXCHANGE_NAME, true, false);
	}

	@PostConstruct
	public void initializeB2BServiceMessageQueue() {
		
		log.debug("initializeDBSProductIntegrationServiceMessageQueue");
		DirectExchange dbsDirectExchange     = getDBSDirectExchange();		
		Queue createProductsIntDataQueue     = getCreateDbsProductsIntegrationDataQueue();
		Binding createProductsIntDataBinding = getCreateDbsProductsIntegrationDataBinding(createProductsIntDataQueue, dbsDirectExchange);
		
		rabbitAdmin.declareExchange(dbsDirectExchange);		
		rabbitAdmin.declareQueue(createProductsIntDataQueue);
		rabbitAdmin.declareBinding(createProductsIntDataBinding);	
	}
	
}
