package com.valuelabs.nephele.manager.configuration;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class InventorySyncMQConfig {

	@Autowired
	AmqpAdmin rabbitAdmin;

	public static final String EXCHANGE_NAME = "nephele.cloud.inventory.sync.exchange";

	public static final String CREATE_INVENTORY_SYNC_QUEUE_NAME = "nephele.cloud.inventory.sync.queue";
	public static final String CREATE_INVENTORY_SYNC_ROUTING_KEY = "nephele.cloud.inventory.sync.syncKey";

	@Bean(name = "createInventorySyncQueue")
	public Queue getCreateInventorySyncQueue() {
		return new Queue(CREATE_INVENTORY_SYNC_QUEUE_NAME, true);
	}

	@Bean(name = "inventorySyncDirectExchange")
	public DirectExchange getInventorySyncDirectExchange() {
		return new DirectExchange(EXCHANGE_NAME, true, false);
	}

	@Bean(name = "createInventorySyncBinding")
	Binding getCreateInventorySyncBinding(Queue createInventorySyncQueue, DirectExchange inventorySyncDirectExchange) {
		return BindingBuilder.bind(createInventorySyncQueue).to(inventorySyncDirectExchange)
				.with(CREATE_INVENTORY_SYNC_ROUTING_KEY);
	}

	@PostConstruct
	public void initializeInventorySyncMessageQueue() {
		log.debug("initializeInventorySyncMessageQueue");

		DirectExchange inventorySyncDirectExchange = getInventorySyncDirectExchange();

		Queue createInventorySyncQueue = getCreateInventorySyncQueue();
		Binding createInventorySyncBinding = getCreateInventorySyncBinding(createInventorySyncQueue,
				inventorySyncDirectExchange);

		rabbitAdmin.declareExchange(inventorySyncDirectExchange);

		rabbitAdmin.declareQueue(createInventorySyncQueue);
		rabbitAdmin.declareBinding(createInventorySyncBinding);

	}

}
