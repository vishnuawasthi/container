package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
public class CloudResellerSlabDiscountResource extends ResourceSupport{
	
	 private Integer cloudResellerSlabDiscountId;
	 private Double startRange;
	 private Double endRange;
	 private Double discountPercentage;
	 private Integer cloudResellerVolumeDiscountId;
	 //private CloudResellerVolumeDiscountResource resellerVolumeDiscount;
	 private Integer resellerVolumeDiscountId;
	 private Integer distributionPriceGroupId;
	 private String distributionPriceGroupName;
	 private Integer serviceId;
	 private String serviceName;

}
