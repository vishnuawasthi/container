package com.valuelabs.nephele.manager.controller;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.data.repository.CloudBillingCycleRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceUsageDataDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudRackspaceUsageDataEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudRackspaceUsageDatasEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudRackspaceUsageDataQueryService;
import com.valuelabs.nephele.manager.assembler.CloudRackspaceUsageDataAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudRackspaceUsageDataResource;

import lombok.extern.slf4j.Slf4j;



@Slf4j
@RestController
@RequestMapping("manager/cloudRackspaceUsageData")
public class CloudRackspaceUsageDataQueryController {
	
	@Autowired
	private CloudRackspaceUsageDataAssembler assembler;
	
	@Autowired
	private CloudRackspaceUsageDataQueryService service;
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	@Autowired
	private CloudServiceRepository serviceRepository;
	
	@Autowired
	private CloudBillingCycleRepository billingCycleRepository;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudRackspaceUsageDataResource> readCloudRackspaceUsageData(@PathVariable Long id) {
		log.info("readCloudRackspaceUsageData() - start");
		ReadCloudRackspaceUsageDataEvent request=new ReadCloudRackspaceUsageDataEvent().setId(id);
		EntityReadEvent<CloudRackspaceUsageDataDetails> event = service.readCloudRackspaceUsageData(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		CloudRackspaceUsageDataDetails details = event.getEntity();
		log.info("readCloudRackspaceUsageData() - end");
		return new ResponseEntity<>(assembler.toResource(details), HttpStatus.OK);
	}
	
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudRackspaceUsageDataResource>> readCloudRackspaceUsageDatas(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudRackspaceUsageDataDetails> pagedAssembler) {
		log.info("readCloudRackspaceUsageData's() - start");
		ReadCloudRackspaceUsageDatasEvent request =new ReadCloudRackspaceUsageDatasEvent().setPageable(pageable);
		request.setSortDirection(sortDirection);
		request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudRackspaceUsageDataDetails> event=service.readCloudRackspaceUsageDatas(request);
		Page<CloudRackspaceUsageDataDetails> page=event.getPage();
		PagedResources<CloudRackspaceUsageDataResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudRackspaceUsageData's() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/*@RequestMapping(value = "/exportData", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudRackspaceUsageDataResource> loadUsageData() throws InterruptedException  {
		log.info("loadUsageData()  - start");
		 Thread.sleep(2000);
		 CloudService service = serviceRepository.findByIntegrationCode(CloudTypes.rackspace.name());
			if(null == service)
				throw new ResourceNotFoundException("CloudService", "rackspace");
		Integer billingDay = service.getBillingDay();
		Date billingStartDate = DateFormatterUtility.getPreviousMonthDateFromDay(billingDay);
	    Date billingEndDate = DateFormatterUtility.getDateFromDay(billingDay-1);
		CloudBillingCycle billingCycle =null;
		billingCycle = CloudBillingCycle.builder().cloudService(service).nepheleMeteringStatus(JobStatus.NOT_YET_INITIATED)
									    .vendorMeteringStatus(JobStatus.COMPLETED)
									    .invoiceStatus(JobStatus.NOT_YET_INITIATED)
									    .billingPeriodStartDate(billingStartDate)
									    .billingPeriodEndDate(billingEndDate)
									    .build();
		 billingCycleRepository.save(billingCycle);
		 JobDetails jobDetails = JobDetails.builder().jobId(billingCycle.getId()).jobName(JobName.VENDOR_METERING).jobStatus(JobStatus.COMPLETED).build();
         rabbitTemplate.convertAndSend(EXCHANGE_NAME, METERING_DATA_ROUTING_KEY, jobDetails);
		log.info("loadUsageData()  - end");
		return new ResponseEntity<CloudRackspaceUsageDataResource>(HttpStatus.OK);
	}*/

}
