package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceIndustryVerticalDetail;
import com.valuelabs.nephele.admin.rest.lib.event.CloudServiceIndustryVerticalCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateServiceIndustryVerticalEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceIndustryVerticalCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.CloudServiceIndustryVerticalAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudServiceIndustryVerticalResource;

@Slf4j
@RestController
@Transactional
@RequestMapping("/manager/serviceIndustryVertical")
public class CloudServiceIndustryVerticalCommandController {

	@Autowired
	private CloudServiceIndustryVerticalAssembler assembler;

	@Autowired
	private CloudServiceIndustryVerticalCommandService commandService;

	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceIndustryVerticalResource> createServiceIndustryVertical(
			@Valid @RequestBody CloudServiceIndustryVerticalResource resource, BindingResult result)
					throws IllegalArgumentException {
		log.info("createServiceIndustryVertical() : START");

		if (result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
					.errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}

		CloudServiceIndustryVerticalDetail details = assembler.fromResource(resource);
		CreateServiceIndustryVerticalEvent request = new CreateServiceIndustryVerticalEvent()
				.setServiceIndustryVerticalDetail(details);

		if (request != null) {
			CloudServiceIndustryVerticalCreatedEvent event=commandService.createServiceIndustryVertical(request);
			details=event.getDetails();
		}

		log.info("createServiceIndustryVertical() : END");
		return new ResponseEntity<CloudServiceIndustryVerticalResource>(assembler.toResource(details),HttpStatus.CREATED);
	}

	/**
	 * This method will update existing single record in DB by accepting http
	 * request object
	 * 
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 * @throws ResourceNotFoundException
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudServiceIndustryVerticalResource> updateServiceIndustryVertical(
			@Valid @RequestBody CloudServiceIndustryVerticalResource resource, BindingResult result)
					throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateServiceIndustryVertical() : START");

		if (resource.getVerticalsId() == null) {
			result.addError(new FieldError("resource", "roleId", resource.getVerticalsId(), false, null, null, null));
		}

		if (result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " + fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder()
					.errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}

		CloudServiceIndustryVerticalDetail details = assembler.fromResource(resource);
		CreateServiceIndustryVerticalEvent request = new CreateServiceIndustryVerticalEvent()
				.setServiceIndustryVerticalDetail(details);

		if (request != null) {
			commandService.updateServiceIndustryVertical(request);
		}

		log.info("updateServiceIndustryVertical() : END");
		return new ResponseEntity<CloudServiceIndustryVerticalResource>(HttpStatus.OK);
	}
}
