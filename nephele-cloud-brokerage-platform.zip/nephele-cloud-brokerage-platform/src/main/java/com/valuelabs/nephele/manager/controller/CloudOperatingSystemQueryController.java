package com.valuelabs.nephele.manager.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;

import java.util.Map;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadOperatingSystemEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadOperatingSystemsEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.admin.rest.lib.service.CloudOperatingSystemQueryService;
import com.valuelabs.nephele.manager.assembler.CloudOperatingSystemAssembler;
import com.valuelabs.nephele.marketplace.resource.Summary;

@Slf4j
@RestController
@RequestMapping("/manager/operatingSystem")
@Transactional
public class CloudOperatingSystemQueryController {
	@Autowired
	private CloudOperatingSystemAssembler assembler;
	
	@Autowired
	private CloudOperatingSystemQueryService service;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudOperatingSystemResource> readOperatingSystem(@PathVariable Long id) {
		log.info("readOperatingSystem() START");

		ReadOperatingSystemEvent request=new ReadOperatingSystemEvent().setOperatingSystemId(id);
		
		EntityReadEvent<CloudOperatingSystemDetails> event = service.readOperatingSystem(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudOperatingSystemDetails entity = event.getEntity();
		log.info("readOperatingSystem() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudOperatingSystemResource>> readOperatingSystems(
        	@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudOperatingSystemDetails> pagedAssembler) {
		log.info("readCloudOperatingSystems() START");
		ReadOperatingSystemsEvent request=new ReadOperatingSystemsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudOperatingSystemDetails> event=service.readOperatingSystems(request);

		Page<CloudOperatingSystemDetails> page=event.getPage();
		PagedResources<CloudOperatingSystemResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readCloudOperatingSystems() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	/**
	 * This method read all the operating system details matched by status.
	 * @param status
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value="/readByServiceAndStatus/{serviceId}/{status}",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudOperatingSystemResource>> readOperatingSystemsByStatus( 
			@PathVariable String status,@PathVariable Long serviceId,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudOperatingSystemDetails> pagedAssembler) {
		log.info("readOperatingSystemsByStatus() -start");
		ReadOperatingSystemsEvent request=new ReadOperatingSystemsEvent().setPageable(pageable);
		request.setStatus(status);
		request.setServiceId(serviceId);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudOperatingSystemDetails> event=service.readByStatus(request);
		Page<CloudOperatingSystemDetails> page=event.getPage();
		PagedResources<CloudOperatingSystemResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readOperatingSystemsByStatus() -end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="/readByServiceId/{serviceId}",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudOperatingSystemResource>> readOperatingSystemByServiceId(
		@PathVariable Long serviceId,@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
    	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		PagedResourcesAssembler<CloudOperatingSystemDetails> pagedAssembler){
		log.info("readOperatingSystemByServiceId() -start");
		ReadOperatingSystemsEvent request=new ReadOperatingSystemsEvent().setPageable(pageable);
		request.setServiceId(serviceId);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<CloudOperatingSystemDetails> event=service.readByServiceId(request);
		Page<CloudOperatingSystemDetails> page=event.getPage();
		PagedResources<CloudOperatingSystemResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readOperatingSystemByServiceId() -end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
		
	}
	/**
	 * @param serviceId
	 * @param pageable
	 * @param pagedAssembler
	 * @return
	 */
	@RequestMapping(value = "/summaryByServiceId/{serviceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Summary> readOperatingSystemSummaryByServiceId(@PathVariable Long serviceId,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable, PagedResourcesAssembler<CloudOperatingSystemDetails> pagedAssembler) {
		log.info("readOperatingSystemSummaryByServiceId() - start");
		ReadOperatingSystemsEvent request = new ReadOperatingSystemsEvent().setServiceId(serviceId);
		Map<String, Long> event = service.readSummaryByServiceId(request);
		Summary summary = Summary.builder().summary(event).build();
		log.info("readOperatingSystemSummaryByServiceId()   -end");
		return new ResponseEntity<>(summary, HttpStatus.OK);
	}
	
	
}
