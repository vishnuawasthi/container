package com.valuelabs.nephele.manager.resource;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.valuelabs.nephele.admin.data.api.NepheleTimeZone;
import com.valuelabs.nephele.admin.data.api.ServiceType;


@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudServiceResource extends ResourceSupport {

	private Long serviceId;
	private String name;
	private Boolean isPublished;
	private String description;	
	private Long serviceProviderId;
	private String brandName;
	private String serviceCode;
	private Integer billingDay;
	private String billingCycle;
	private String planPrefix;	
	private String subscriptionNamePrefix;
	@JsonFormat(pattern = "MM/dd/YYYY")
	private Date updatedAt;
	private Boolean isLive;
	private String message;
	private String integrationCode;
	private String vendorCode;
	private String vendorCurrency;
	private String timeZone;
	private List<NepheleTimeZone> nepheleTimeZones;
	private Long serviceCategoryId;
	private String serviceCategoryName;
	private Long serviceIndustryVerticalId;
	private String serviceIndustryVerticalName;
	private String serviceType;
	private List<ServiceType> serviceTypes;
	
	
}
