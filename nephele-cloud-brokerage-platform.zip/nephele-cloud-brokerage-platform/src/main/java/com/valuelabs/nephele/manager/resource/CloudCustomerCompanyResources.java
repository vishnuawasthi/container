package com.valuelabs.nephele.manager.resource;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
public class CloudCustomerCompanyResources {
	private List<CloudCustomerCompanyResource> customers;
}
