package com.valuelabs.nephele.manager.resource;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudLicenseResource extends ResourceSupport{

	private Long licenseId;
	private Long subscriptionId;
	private String licenseVendorId;
	private String status;
	private Boolean isActive;
	private Long planId;	
	private Date licenseProvisionDate;
	//private Date licenseNextRenewalDate;
	//private Date licenseLastRenewalDate;
	//private Date autoRenewalOffDate;
	//private boolean licenseAutoRenewal;
	
}
