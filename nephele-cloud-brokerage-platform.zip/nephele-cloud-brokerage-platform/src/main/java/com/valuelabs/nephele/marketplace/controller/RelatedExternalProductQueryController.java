package com.valuelabs.nephele.marketplace.controller;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.RelatedExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRelatedExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRelatedExternalProductsEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.RelatedExternalProductResource;
import com.valuelabs.nephele.admin.rest.lib.service.RelatedExternalProductQueryService;
import static  com.valuelabs.nephele.manager.constants.QueryParameterConstants.*;
import com.valuelabs.nephele.marketplace.assembler.RelatedExternalProductAssembler;

@Slf4j
@RestController
@RequestMapping("/")
public class RelatedExternalProductQueryController {

	
	
	@Autowired
	private RelatedExternalProductQueryService relatedExternalProductService;
	
	@Autowired
	RelatedExternalProductAssembler relatedExternalProductsAssembler;
	
	
	
	@RequestMapping(value = "marketplace/relatedexternalproducts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RelatedExternalProductResource> readRelatedExternalProduct(@PathVariable Long id){
		log.info("readRelatedExternalProduct() START");
		ReadRelatedExternalProductEvent request=new ReadRelatedExternalProductEvent().setRelatedExtProductId(id);
		EntityReadEvent<RelatedExternalProductDetails> event = relatedExternalProductService.readRelatedExternalProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		RelatedExternalProductDetails entity= event.getEntity();
		log.info("readRelatedExternalProduct() END");
		return new ResponseEntity<>(relatedExternalProductsAssembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(value="marketplace/relatedexternalproducts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedExternalProductResource>> readRelatedExternalProducts(
        	@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedExternalProductDetails> pagedAssembler) {
		log.info("readRelatedExternalProducts() -start");
		ReadRelatedExternalProductsEvent request = new ReadRelatedExternalProductsEvent().setPageable(pageable);
		
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<RelatedExternalProductDetails> event = relatedExternalProductService.readRelatedExternalProducts(request);
		Page<RelatedExternalProductDetails> page = event.getPage();
		PagedResources<RelatedExternalProductResource> pagedResources = pagedAssembler.toResource(page, relatedExternalProductsAssembler);
		log.info("readRelatedExternalProducts() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="marketplace/relatedexternalproductsByExtId/{ids}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedExternalProductResource>> readRelatedCloudProductsByExtId(
			@PathVariable String[]  ids,
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedExternalProductDetails> pagedAssembler) {
		log.info("readRelatedexternalproductsByExtId() -start");
		List<String> extProductIds = new ArrayList<String>() ;
		if(ids !=null){
			for(String extId : ids){
				extProductIds.add(extId);
			}
		}
		log.info(extProductIds+"......");
		ReadRelatedExternalProductsEvent request = new ReadRelatedExternalProductsEvent().setExternalProductIds(extProductIds).setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<RelatedExternalProductDetails> event = relatedExternalProductService.readCloudProductsByExtIds(request);
		Page<RelatedExternalProductDetails> page = event.getPage();
		PagedResources<RelatedExternalProductResource> pagedResources = pagedAssembler.toResource(page, relatedExternalProductsAssembler);
		log.info("readRelatedexternalproductsByExtId() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value="manager/relatedexternalproductsByCloudProductId/{ids}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedExternalProductResource>> readRelatedexternalproductsByCloudProductIdForManager(
			@PathVariable String[]  ids, 
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        	@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedExternalProductDetails> pagedAssembler) {
		log.info("readRelatedexternalproductsByExtIdForManager() -start");
		List<Long> cloudProductIds = new ArrayList<Long>() ;
		for(String temp :ids) {
			cloudProductIds.add(new Long(temp.replaceAll("\\D+","")));
		}
		
		ReadRelatedExternalProductsEvent request = new ReadRelatedExternalProductsEvent().setCloudProductIds(cloudProductIds).setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<RelatedExternalProductDetails> event = relatedExternalProductService.readRelatedexternalproductsByCloudProductIds(request);
		Page<RelatedExternalProductDetails> page = event.getPage();
		PagedResources<RelatedExternalProductResource> pagedResources = pagedAssembler.toResource(page, relatedExternalProductsAssembler);
		log.info("readRelatedexternalproductsByExtIdForManager() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/relatedexternalproducts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RelatedExternalProductResource> readRelatedExternalProductForManager(@PathVariable Long id){
		log.info("readRelatedExternalProduct() START");
		ReadRelatedExternalProductEvent request=new ReadRelatedExternalProductEvent().setRelatedExtProductId(id);
		
		EntityReadEvent<RelatedExternalProductDetails> event = relatedExternalProductService.readRelatedExternalProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		RelatedExternalProductDetails entity= event.getEntity();
		log.info("readRelatedExternalProduct() END");
		return new ResponseEntity<>(relatedExternalProductsAssembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(value="manager/relatedexternalproducts",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedExternalProductResource>> readRelatedExternalProductsForManager(
			@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
			@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedExternalProductDetails> pagedAssembler) {
		log.info("readRelatedExternalProducts() -start");
		ReadRelatedExternalProductsEvent request = new ReadRelatedExternalProductsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<RelatedExternalProductDetails> event = relatedExternalProductService.readRelatedExternalProducts(request);
		Page<RelatedExternalProductDetails> page = event.getPage();
		PagedResources<RelatedExternalProductResource> pagedResources = pagedAssembler.toResource(page, relatedExternalProductsAssembler);
		log.info("readRelatedExternalProducts() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
}
