package com.valuelabs.nephele.manager.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudResellerPremiumGroupEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudResellerPremiumGroupsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerPremiumGroupQueryService;
import com.valuelabs.nephele.manager.assembler.CloudResellerPremiumGroupAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.CloudResellerPremiumGroupResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/cloudResellerPremiumGroup")
public class CloudResellerPremiumGroupQueryController {

  @Autowired
  CloudResellerPremiumGroupAssembler assembler;

  @Autowired
  CloudResellerPremiumGroupQueryService service;

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<CloudResellerPremiumGroupResource> readPremiumGroup(@PathVariable Long id) {

    log.info("readPremiumGroup() :  START");
    ReadCloudResellerPremiumGroupEvent request=new ReadCloudResellerPremiumGroupEvent().setId(id);

    EntityReadEvent<CloudResellerPremiumGroupDetails> event = service.readResellerPremiumGroup(request);
    if(!event.isFound()) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    CloudResellerPremiumGroupDetails entity=event.getEntity();
    log.info("readPremiumGroup() :  END");
    return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
  }

  /*@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<PagedResources<CloudResellerPremiumGroupResource>> readPremiumGroups(
      @PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
      PagedResourcesAssembler<CloudResellerPremiumGroupDetails> pagedAssembler) {

    log.info("readPremiumGroups() :  START");
    ReadCloudResellerPremiumGroupsEvent request = new ReadCloudResellerPremiumGroupsEvent().setPageable(pageable);

    PageReadEvent<CloudResellerPremiumGroupDetails> event = service.readResellerPremiumGroups(request);

    Page<CloudResellerPremiumGroupDetails> page = event.getPage();
    PagedResources<CloudResellerPremiumGroupResource> pagedResources = pagedAssembler.toResource(page, assembler);
    log.info("readPremiumGroups() :  END");
    return new ResponseEntity<>(pagedResources, HttpStatus.OK);
  }*/
  

  @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<PagedResources<CloudResellerPremiumGroupResource>> readPremiumGroupByNameORStatus(
		  @RequestParam(value = "groupName", required=false) String groupName, 
		  @RequestParam(value = "status", required=false) String status,
		  @RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
		  @RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
		  @PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
	      PagedResourcesAssembler<CloudResellerPremiumGroupDetails> pagedAssembler) {
    log.info("readPremiumGroupByNameORStatus() :  START");
    ReadCloudResellerPremiumGroupsEvent request = new ReadCloudResellerPremiumGroupsEvent().setPageable(pageable);
    request.setName(groupName);
    request.setStatus(status);
    request.setSortDirection(sortDirection);
    request.setSortColumnName(sortColumnName);

    PageReadEvent<CloudResellerPremiumGroupDetails> event = service.readResellerPremiumGroupByNameorStatus(request);
    if(!event.isFound()) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    Page<CloudResellerPremiumGroupDetails> page = event.getPage();
    PagedResources<CloudResellerPremiumGroupResource> pagedResources = pagedAssembler.toResource(page, assembler);
    log.info("readPremiumGroupByNameORStatus() :  END");
    return new ResponseEntity<>(pagedResources, HttpStatus.OK);
  }
 
  

}
