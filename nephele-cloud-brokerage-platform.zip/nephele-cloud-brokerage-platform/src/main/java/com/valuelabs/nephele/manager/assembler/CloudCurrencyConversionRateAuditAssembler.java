package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateAuditDetails;
import com.valuelabs.nephele.manager.controller.CloudCurrencyConversionRateAuditQueryController;
import com.valuelabs.nephele.manager.controller.CloudCurrencyConversionRateQueryController;
import com.valuelabs.nephele.manager.resource.CloudCurrencyConversionRateAuditResource;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CloudCurrencyConversionRateAuditAssembler extends
		ResourceAssemblerSupport<CloudCurrencyConversionRateAuditDetails, CloudCurrencyConversionRateAuditResource> {

	public CloudCurrencyConversionRateAuditAssembler() {
		super(CloudCurrencyConversionRateQueryController.class, CloudCurrencyConversionRateAuditResource.class);
	}

	@Override
	public CloudCurrencyConversionRateAuditResource toResource(CloudCurrencyConversionRateAuditDetails details) {
		log.debug("toResource() -start");
		CloudCurrencyConversionRateAuditResource resource = CloudCurrencyConversionRateAuditResource.builder()
				.auditId(details.getAuditId()).createdOn(details.getCreatedOn())
				.conversionRate(details.getConversionRate()).ConversionRateId(details.getCurrencyConversionRateId())
				.sourceCurrency(details.getSourceCurrency()).targetCurrency(details.getTargetCurrency())
				.build();

		resource.add(linkTo(methodOn(CloudCurrencyConversionRateAuditQueryController.class)
				.readCloudCurrencyConversionRateAudit(details.getAuditId())).withSelfRel());
		log.debug("toResource() -end");
		return resource;
	}

	public CloudCurrencyConversionRateAuditDetails fromResource(CloudCurrencyConversionRateAuditResource resource) {
		log.debug("fromResource() -start");
		CloudCurrencyConversionRateAuditDetails details = CloudCurrencyConversionRateAuditDetails.builder()
				.auditId(resource.getAuditId()).createdOn(resource.getCreatedOn())
				.conversionRate(resource.getConversionRate()).currencyConversionRateId(resource.getConversionRateId())
				.sourceCurrency(resource.getSourceCurrency()).targetCurrency(resource.getTargetCurrency())
				.build();
		log.debug("fromResource() -end");
		return details;
	}

}
