package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountSheetDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreatePremiumGroupDiscountSheetEvent;
import com.valuelabs.nephele.admin.rest.lib.event.DeletePremiumGroupDiscountSheetEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ValidationException;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.admin.rest.lib.service.PremiumGroupDiscountSheetCommandService;
import com.valuelabs.nephele.manager.assembler.PremiumGroupDiscountSheetAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.PremiumGroupDiscountSheetResource;
import com.valuelabs.nephele.manager.resource.PremiumGroupDiscountSheetsListResource;

@Slf4j
@RestController
@RequestMapping(value = "/manager/discounts")

public class PremiumGroupDiscountSheetCommandController {

	@Autowired
	private PremiumGroupDiscountSheetCommandService service;

	@Autowired
	private PremiumGroupDiscountSheetAssembler assembler;

	/*@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountSheetResource> createPremiumGroupDiscountSheet(@Valid @RequestBody PremiumGroupDiscountSheetResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("createPremiumGroupDiscountSheet()  - start");
		PremiumGroupDiscountSheetResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}		
		try{
			PremiumGroupDiscountSheetDetails details = assembler.fromResource(resource);			
			if(resource.getDiscount() != null) {
			    if(details.getDiscount() < 0 || details.getDiscount() > 100){
			    	throw new NepheleException("Discount% should accept from 0 to 100 % only");			    	
			    }
			}			
			if(details.getStartRange() >= details.getEndRange() && (details.getStartRange() > 0 && details.getEndRange() > 0 ))
			{
			   throw new NepheleException("Discount End Range should be greater than the Start range.");						
			}
			if(details.getStartRange() < 0 || details.getEndRange() < 0)
				throw new NepheleException("Discount Start/End Range should not negative value");		
				
				
			CreatePremiumGroupDiscountSheetEvent request = new CreatePremiumGroupDiscountSheetEvent().setDiscountSheetDetails(details);
			if (request != null) {
				service.createPremiumGroupDiscountSheet(request);
				message = "Discount sheet created successfully";
			}
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = PremiumGroupDiscountSheetResource.builder().message(message).build();
		log.info("createPremiumGroupDiscountSheet()  - end");
		return new ResponseEntity<PremiumGroupDiscountSheetResource>(responseResource, statusCode);
	}
	*/
	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountSheetResource> createPremiumGroupDiscountSheets(@Valid @RequestBody PremiumGroupDiscountSheetsListResource resourceList,
			BindingResult result) throws IllegalArgumentException {
		log.info("createPremiumGroupDiscountSheets()....  - start");
		PremiumGroupDiscountSheetResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}		
		try{
			
			List<PremiumGroupDiscountSheetDetails> detailsList = assembler.fromResource(resourceList.getRules());
			CreatePremiumGroupDiscountSheetEvent request = new CreatePremiumGroupDiscountSheetEvent().setDiscountSheetDetailsList(detailsList);
			if (request != null) {
				service.createPremiumGroupDiscountSheets(request);
				message = "Discount sheets created successfully";
			}			
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = PremiumGroupDiscountSheetResource.builder().message(message).build();
		log.info("createPremiumGroupDiscountSheets()  - end");
		return new ResponseEntity<PremiumGroupDiscountSheetResource>(responseResource, statusCode);
	}
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountSheetResource> updatePremiumGroupDiscountSheets(@Valid @RequestBody PremiumGroupDiscountSheetsListResource resourceList,
			BindingResult result) throws IllegalArgumentException {
		log.info("updatePremiumGroupDiscountSheets()....  - start");
		PremiumGroupDiscountSheetResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}		
		try{
			
			List<PremiumGroupDiscountSheetDetails> detailsList = assembler.fromResource(resourceList.getRules());
			CreatePremiumGroupDiscountSheetEvent request = new CreatePremiumGroupDiscountSheetEvent().setDiscountSheetDetailsList(detailsList);
			if (request != null) {
				if(detailsList.size() > 0){
					DeletePremiumGroupDiscountSheetEvent deleteRequest = new DeletePremiumGroupDiscountSheetEvent()
																	.setConfigId(detailsList.get(0).getPremiumGroupDiscountConfigId())
																	.setPremiumGroupId(detailsList.get(0).getPremiumGroupId());
					service.deletePremiumGroupDiscountSheets(deleteRequest);
				}
				
				service.createPremiumGroupDiscountSheets(request);
				//service.updatePremiumGroupDiscountSheets(request);
				message = "Discount sheets updated successfully";
			}			
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = PremiumGroupDiscountSheetResource.builder().message(message).build();
		log.info("updatePremiumGroupDiscountSheets()  - end");
		return new ResponseEntity<PremiumGroupDiscountSheetResource>(responseResource, statusCode);
	}

	/*@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountSheetResource> updatePremiumGroupDiscountSheet(@Valid @RequestBody PremiumGroupDiscountSheetResource resource,
			BindingResult result) throws IllegalArgumentException {
		log.info("updatePremiumGroupDiscountSheet()  - start");
		PremiumGroupDiscountSheetResource responseResource = null;
		String message = null;
		HttpStatus statusCode = HttpStatus.OK;
		if(result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		try{
			PremiumGroupDiscountSheetDetails details = assembler.fromResource(resource);		
			if(resource.getDiscount() != null){
			    if(details.getDiscount() < 0 || details.getDiscount() > 100){
			    	throw new NepheleException("Discount% should accept from 0 to 100 % only.");				    	
			    }
			}
			if(details.getStartRange() >= details.getEndRange() && (details.getStartRange() > 0 && details.getEndRange() > 0 ))
			{
				throw new NepheleException("Discount End Range should be greater than the Start range.");			
			}
			if(details.getStartRange() < 0 || details.getEndRange() < 0)
				throw new NepheleException("Discount Start/End Range should not negative value.");				
			
			CreatePremiumGroupDiscountSheetEvent request = new CreatePremiumGroupDiscountSheetEvent().setDiscountSheetDetails(details);
			if (request != null) {
				service.updatePremiumGroupDiscountSheet(request);
				message = "Discount sheet updated successfully.";
			}
		}catch(NepheleException | ValidationException | ResourceNotFoundException e ){
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(400);			
		}catch (Exception e) {
			message = e.getMessage();
			statusCode = HttpStatus.valueOf(500);			
		}
		responseResource = PremiumGroupDiscountSheetResource.builder().message(message).build();
		log.info("updatePremiumGroupDiscountSheet()  - end");
		return new ResponseEntity<PremiumGroupDiscountSheetResource>(responseResource, statusCode);
	}
	*/
	
	
	@RequestMapping(value = "/{groupDiscountSheetId}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<PremiumGroupDiscountSheetResource> deletePremiumGroupDiscountSheet(@PathVariable Long groupDiscountSheetId) throws IllegalArgumentException {
		log.info("deletePremiumGroupDiscountSheet()  - start");
		DeletePremiumGroupDiscountSheetEvent request = new DeletePremiumGroupDiscountSheetEvent().setDiscountSheetId(groupDiscountSheetId);
		if (request != null) {
			service.deletePremiumGroupDiscountSheet(request);
		}
		log.info("deletePremiumGroupDiscountSheet()  - end");
		return new ResponseEntity<PremiumGroupDiscountSheetResource>(HttpStatus.OK);
	}
	
	
	

}
