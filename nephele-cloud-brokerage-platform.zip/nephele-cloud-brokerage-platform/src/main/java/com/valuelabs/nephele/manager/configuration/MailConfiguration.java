package com.valuelabs.nephele.manager.configuration;

import com.valuelabs.nephele.admin.rest.lib.domain.SMTPConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadSMTPConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.service.SMTPConfigurationQueryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

/**
 * Created by Srikanth Nagaboina, Valuelabs on 6/8/15.
 */
@Slf4j
@Configuration
public class MailConfiguration {

  @Autowired
  private SMTPConfigurationQueryService sMTPConfigurationQueryService;

  //@Value("${mail.protocol}")
  private String protocol;

  //@Value("${mail.host}")
  private String host;

  //@Value("${mail.port}")
  private int port;

  //@Value("${mail.smtp.auth}")
  private boolean auth;

  //@Value("${mail.smtp.starttls.enable}")
  private boolean starttls;

  //@Value("${mail.username}")
  private String username;

  //@Value("${mail.password}")
  private String password;

  @Bean
  @Primary
  public JavaMailSender javaMailSender() {

    ReadSMTPConfigurationEvent request = new ReadSMTPConfigurationEvent().setId(1L);
    EntityReadEvent<SMTPConfigurationDetails> event = sMTPConfigurationQueryService.readSMTPConfiguration(request);
    SMTPConfigurationDetails details = null;
    if (event.isFound()) {

      details = event.getEntity();
      protocol = details.getProtocol();
      host = details.getHost();
      port = details.getPort();
      auth = details.getSmtpAuth();
      starttls = details.getSmtpStarttlsEnable();
      username = details.getUsername();
      password = details.getPassword();
      log.info("***** Protocol: " + details.getProtocol() + " Host: " + details.getHost() + " Port: " + details.getPort()
          + " SmptAuth: " + details.getSmtpAuth() + " SmtpStarttlsEnable:  " + details.getSmtpStarttlsEnable()
          + " UserName: " + details.getUsername() + " Password: " + details.getPassword());
    }

    JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
    Properties mailProperties = new Properties();
    mailProperties.put("mail.smtp.auth", auth);
    mailProperties.put("mail.smtp.starttls.enable", starttls);
    mailSender.setJavaMailProperties(mailProperties);
    mailSender.setHost(host);
    mailSender.setPort(port);
    mailSender.setProtocol(protocol);
    mailSender.setUsername(username);
    mailSender.setPassword(password);
    return mailSender;
  }
}

