package com.valuelabs.nephele.manager.controller;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.ServiceCategoryDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceCategoriesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceCategoryEvent;
import com.valuelabs.nephele.admin.rest.lib.service.CloudSoftlayerDiskConfigurationQueryService;
import com.valuelabs.nephele.admin.rest.lib.service.ServiceCategoryQueryService;
import com.valuelabs.nephele.manager.assembler.ServiceCategoryAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;
import com.valuelabs.nephele.manager.resource.ServiceCategoryResource;

@Slf4j
@RestController
@RequestMapping(value="/")
public class ServiceCategoryQueryController {
  
  @Autowired
  private ServiceCategoryQueryService service;
  
  @Autowired
  private ServiceCategoryAssembler assembler;
  
  
  @Autowired
  CloudSoftlayerDiskConfigurationQueryService cloudSoftlayerDiskConfigurationQueryService;
  
  
	@RequestMapping(value = "manager/serviceCategory/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ServiceCategoryResource> readServiceCategory(
			@PathVariable Long id) {
		log.info("readServiceCategory () - start");
		ReadServiceCategoryEvent request = new ReadServiceCategoryEvent()
				.setId(id);
		EntityReadEvent<ServiceCategoryDetails> event = service
				.readServiceCategory(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		ServiceCategoryDetails entity = event.getEntity();
		log.info("readServiceCategory () - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(value = "manager/serviceCategory", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<ServiceCategoryResource>> readServiceCategories(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<ServiceCategoryDetails> pagedAssembler) {
		log.info("readServiceCategories()  - start");
		ReadServiceCategoriesEvent request = new ReadServiceCategoriesEvent()
				.setPageable(pageable);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<ServiceCategoryDetails> event = service
				.readServiceCategories(request);
		Page<ServiceCategoryDetails> page = event.getPage();
		PagedResources<ServiceCategoryResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readServiceCategories()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "marketplace/serviceCategory/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ServiceCategoryResource> readMarketplaceServiceCategory(
			@PathVariable Long id) {
		log.info("readServiceCategory () - start");
		ReadServiceCategoryEvent request = new ReadServiceCategoryEvent()
				.setId(id);
		EntityReadEvent<ServiceCategoryDetails> event = service
				.readServiceCategory(request);

		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		ServiceCategoryDetails entity = event.getEntity();
		log.info("readServiceCategory () - end");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}

	@RequestMapping(value = "marketplace/serviceCategory", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<ServiceCategoryResource>> readMarketplaceServiceCategories(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<ServiceCategoryDetails> pagedAssembler) {
		log.info("readServiceCategories()  - start");
		ReadServiceCategoriesEvent request = new ReadServiceCategoriesEvent()
				.setPageable(pageable);
		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<ServiceCategoryDetails> event = service
				.readServiceCategories(request);
		Page<ServiceCategoryDetails> page = event.getPage();
		PagedResources<ServiceCategoryResource> pagedResources = pagedAssembler
				.toResource(page, assembler);
		log.info("readServiceCategories()  - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
  
}
