/*package com.valuelabs.nephele.manager.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import lombok.extern.slf4j.Slf4j;

import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductCategoryDetails;
import com.valuelabs.nephele.manager.controller.CloudProductCategoryQueryController;
import com.valuelabs.nephele.manager.resource.CloudProductCategoryResource;

@Slf4j
@Service
public class CloudProductCategoryAssembler
		extends
		ResourceAssemblerSupport<CloudProductCategoryDetails, CloudProductCategoryResource> {

	public CloudProductCategoryAssembler() {
		super(CloudProductCategoryQueryController.class,
				CloudProductCategoryResource.class);
	}

	@Override
	public CloudProductCategoryResource toResource(
			CloudProductCategoryDetails details) {
		log.debug("toResource() : START");
		log.debug("toResource() : Details: " + details);
		CloudProductCategoryResource resource = instantiateResource(details);
		resource = CloudProductCategoryResource.builder()
				.productCategoryId(details.getProductCategoryId())
				.categoryName(details.getCategoryName())
				.description(details.getDescription()).build();
		resource.add(linkTo(
				methodOn(CloudProductCategoryQueryController.class)
						.readProductCategoryById(
								details.getProductCategoryId()))
				.withSelfRel());
		log.debug("toResource() : resource : " + resource);
		log.debug("toResource() : resource Links: " + resource.getLinks());
		log.debug("toResource() : END");
		return resource;
	}

	public CloudProductCategoryDetails fromResource(
			CloudProductCategoryResource resource) {
		log.debug("fromResource() START:{}", resource);
		CloudProductCategoryDetails details = CloudProductCategoryDetails
				.builder()
				.productCategoryId(resource.getProductCategoryId())
				.categoryName(resource.getCategoryName())
				.description(resource.getDescription()).build();
		log.debug("fromResource() - END");
		return details;
	}

}
*/