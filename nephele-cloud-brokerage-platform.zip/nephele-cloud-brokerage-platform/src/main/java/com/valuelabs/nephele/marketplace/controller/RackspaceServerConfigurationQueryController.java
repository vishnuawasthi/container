package com.valuelabs.nephele.marketplace.controller;

import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_COLUMN_NAME;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.SORT_DIRECTION;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.RackspaceServerConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRackspaceServerConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRackspaceServerConfigurationsEvent;
import com.valuelabs.nephele.admin.rest.lib.service.RackspaceServerConfigurationQueryService;
import com.valuelabs.nephele.marketplace.assembler.RackspaceServerConfigurationAssembler;
import com.valuelabs.nephele.marketplace.resource.RackspaceServerConfigurationResource;

@Slf4j
@RestController
@RequestMapping("/marketplace/rackspaceServerConfiguration")
public class RackspaceServerConfigurationQueryController {

	@Autowired
	private RackspaceServerConfigurationAssembler assembler;

	@Autowired
	private RackspaceServerConfigurationQueryService service;

	@RequestMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public HttpEntity<RackspaceServerConfigurationResource> readRackspaceServerConfiguration(@PathVariable("id") Long id) {
		log.info("readRackspaceServerConfiguration()  - START");
		ReadRackspaceServerConfigurationEvent request = new ReadRackspaceServerConfigurationEvent().setId(id);
		EntityReadEvent<RackspaceServerConfigurationDetails> event = service.readRackspaceServerConfiguration(request);
		if (!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		RackspaceServerConfigurationDetails details = event.getEntity();
		log.info("readRackspaceServerConfiguration()  - END");
		return new ResponseEntity<RackspaceServerConfigurationResource>(assembler.toResource(details), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RackspaceServerConfigurationResource>> readRackspaceServerConfigurations(
		@RequestParam(value = SORT_COLUMN_NAME, required = false) String sortColumnName,
        @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
		@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
		PagedResourcesAssembler<RackspaceServerConfigurationDetails> pagedAssembler) {
		log.info("readRackspaceServerConfigurations() - START");
		ReadRackspaceServerConfigurationsEvent request = new ReadRackspaceServerConfigurationsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<RackspaceServerConfigurationDetails> event = service.readRackspaceServerConfigurations(request);
		Page<RackspaceServerConfigurationDetails> page = event.getPage();
		PagedResources<RackspaceServerConfigurationResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readRackspaceServerConfigurations() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}

}
