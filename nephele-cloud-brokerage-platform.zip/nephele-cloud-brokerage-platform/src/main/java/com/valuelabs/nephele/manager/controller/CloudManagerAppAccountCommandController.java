package com.valuelabs.nephele.manager.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudManagerAppAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudManagerAppAccountCommandService;
import com.valuelabs.nephele.manager.assembler.CloudManagerAppAccountAssembler;
import com.valuelabs.nephele.manager.resource.CloudManagerAppAccountResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value="/manager/cloudManagerAppAccount")
public class CloudManagerAppAccountCommandController {

	@Autowired
	private CloudManagerAppAccountAssembler assembler;
	
	@Autowired
	private CloudManagerAppAccountCommandService service;
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudManagerAppAccountResource> createCloudManagerAppAccount(@Valid @RequestBody CloudManagerAppAccountResource resource, BindingResult result) throws IllegalArgumentException{
		log.info("createCloudManagerAppAccount() : START");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudManagerAppAccountResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudManagerAppAccountDetails cloudManagerAppAccountDetails=assembler.fromResource(resource);
		CreateCloudManagerAppAccountEvent request=new CreateCloudManagerAppAccountEvent().setCloudManagerAppAccountDetails(cloudManagerAppAccountDetails);
		if (request != null) {
			service.createCloudManagerAppAccount(request);
			log.info("createCloudManagerAppAccount() : END");
		}
		return new ResponseEntity<CloudManagerAppAccountResource>(HttpStatus.CREATED);
	}
	
	
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudManagerAppAccountResource> updateCloudManagerAppAccount(@Valid @RequestBody CloudManagerAppAccountResource resource, BindingResult result) throws IllegalArgumentException{
		log.info("updateCloudManagerAppAccount() : START");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudManagerAppAccountResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudManagerAppAccountDetails cloudManagerAppAccountDetails=assembler.fromResource(resource);
		CreateCloudManagerAppAccountEvent request=new CreateCloudManagerAppAccountEvent().setCloudManagerAppAccountDetails(cloudManagerAppAccountDetails);
		if (request != null) {
			service.updateCloudManagerAppAccount(request);
		}
		log.info("updateCloudManagerAppAccount() : END");
		return new ResponseEntity<CloudManagerAppAccountResource>(HttpStatus.OK);
	}
}
