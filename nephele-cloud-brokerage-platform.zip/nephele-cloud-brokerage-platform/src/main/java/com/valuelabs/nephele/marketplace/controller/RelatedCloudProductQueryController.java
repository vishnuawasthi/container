package com.valuelabs.nephele.marketplace.controller;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.RelatedCloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRelatedCloudProductEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadRelatedCloudProductsEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.RelatedCloudProductResource;
import com.valuelabs.nephele.admin.rest.lib.service.RelatedCloudProductQueryService;
import static com.valuelabs.nephele.manager.constants.QueryParameterConstants.*;
import com.valuelabs.nephele.marketplace.assembler.RelatedCloudProductAssembler;

@Slf4j
@RestController
@RequestMapping("/")
public class RelatedCloudProductQueryController {

	
	
	@Autowired
	private RelatedCloudProductQueryService relatedCloudProductService;
	
	@Autowired
	RelatedCloudProductAssembler relatedProductsAssembler;
	
	
	
	@RequestMapping(value = "marketplace/relatedCloudProduct/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RelatedCloudProductResource> readRelatedCloudProduct(@PathVariable Long id){
		log.info("readRelatedCloudProduct() START");
		ReadRelatedCloudProductEvent request=new ReadRelatedCloudProductEvent().setId(id);

		EntityReadEvent<RelatedCloudProductDetails> event = relatedCloudProductService.readRelatedCloudProduct(request);
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		RelatedCloudProductDetails entity= event.getEntity();
		log.info("readRelatedCloudProduct() END");
		return new ResponseEntity<>(relatedProductsAssembler.toResource(entity), HttpStatus.OK);
	}	
	
	@RequestMapping(value = "marketplace/relatedCloudProductByRelatedProductId/{ids}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedCloudProductResource>> readRelatedCloudProductByCloudProductId(
			@PathVariable String[]  ids,
            @RequestParam(value =SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedCloudProductDetails> pagedAssembler){
		log.info("readRelatedCloudProductByCloudProductId() START");
		List<Long> cloudProductIds = new ArrayList<Long>() ;
		for(String temp :ids) {
			cloudProductIds.add(new Long(temp.replaceAll("\\D+","")));
		}
		ReadRelatedCloudProductsEvent request = new ReadRelatedCloudProductsEvent().setCloudProductIds(cloudProductIds).setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<RelatedCloudProductDetails> event = relatedCloudProductService.readRelatedCloudProductDetailsByCloudProductId(request);
		Page<RelatedCloudProductDetails> page = event.getPage();
		PagedResources<RelatedCloudProductResource> pagedResources = pagedAssembler.toResource(page, relatedProductsAssembler);
		log.info("readRelatedCloudProducts() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "manager/relatedCloudProductByCloudProductId/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedCloudProductResource>> readRelatedCloudProductByCloudProductIdForManager(
			@PathVariable Long id,
			@RequestParam(value =SORT_COLUMN_NAME, required = false) String sortColumnName,
            @RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedCloudProductDetails> pagedAssembler){
		log.info("readRelatedCloudProductByCloudProductId() START");		
		ReadRelatedCloudProductsEvent request = new ReadRelatedCloudProductsEvent().setCloudProductId(id).setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		
		PageReadEvent<RelatedCloudProductDetails> event = relatedCloudProductService.readRelatedCloudProductByCloudProductId(request);
		Page<RelatedCloudProductDetails> page = event.getPage();
		PagedResources<RelatedCloudProductResource> pagedResources = pagedAssembler.toResource(page, relatedProductsAssembler);
		log.info("readRelatedCloudProductByCloudProductId() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="marketplace/relatedCloudProduct",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedCloudProductResource>> readRelatedCloudProducts(
			@RequestParam(value =SORT_COLUMN_NAME, required = false) String sortColumnName,
			@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedCloudProductDetails> pagedAssembler) {
		log.info("readRelatedCloudProducts() -start");
		ReadRelatedCloudProductsEvent request = new ReadRelatedCloudProductsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<RelatedCloudProductDetails> event = relatedCloudProductService.readRelatedCloudProducts(request);
		Page<RelatedCloudProductDetails> page = event.getPage();
		PagedResources<RelatedCloudProductResource> pagedResources = pagedAssembler.toResource(page, relatedProductsAssembler);
		log.info("readRelatedCloudProducts() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	@RequestMapping(value = "manager/relatedCloudProduct/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RelatedCloudProductResource> readRelatedCloudProductForManager(@PathVariable Long id){
		log.info("readRelatedCloudProduct() START");
		EntityReadEvent<RelatedCloudProductDetails> event=null;
		if(id!=null){
		ReadRelatedCloudProductEvent request=new ReadRelatedCloudProductEvent().setId(id);
		event = relatedCloudProductService.readRelatedCloudProduct(request);
		}
		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		RelatedCloudProductDetails entity= event.getEntity();
		log.info("readRelatedCloudProduct() END");
		return new ResponseEntity<>(relatedProductsAssembler.toResource(entity), HttpStatus.OK);
	}	
	
	@RequestMapping(value="manager/relatedCloudProduct",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<RelatedCloudProductResource>> readRelatedCloudProductsForManager(
			@RequestParam(value =SORT_COLUMN_NAME, required = false) String sortColumnName,
			@RequestParam(value = SORT_DIRECTION, required = false) String sortDirection,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<RelatedCloudProductDetails> pagedAssembler) {
		log.info("readRelatedCloudProducts() -start");
		ReadRelatedCloudProductsEvent request = new ReadRelatedCloudProductsEvent().setPageable(pageable);
		request.setSortColumnName(sortColumnName);
		request.setSortDirection(sortDirection);
		PageReadEvent<RelatedCloudProductDetails> event = relatedCloudProductService.readRelatedCloudProducts(request);
		Page<RelatedCloudProductDetails> page = event.getPage();
		PagedResources<RelatedCloudProductResource> pagedResources = pagedAssembler.toResource(page, relatedProductsAssembler);
		log.info("readRelatedCloudProducts() - end");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
	
	
}
