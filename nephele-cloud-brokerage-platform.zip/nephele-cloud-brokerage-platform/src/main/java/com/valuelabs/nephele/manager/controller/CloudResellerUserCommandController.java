package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerUserDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudResellerUserEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudResellerUserCommandService;
import com.valuelabs.nephele.manager.assembler.CloudResellerUserAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudResellerUserResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/manager/resellerUser")
@Transactional
public class CloudResellerUserCommandController {

	@Autowired
	private CloudResellerUserCommandService service;

	@Autowired
	private CloudResellerUserAssembler assember;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerUserResource> createCloudResellerUser(@Valid @RequestBody CloudResellerUserResource resource,BindingResult result) throws IllegalArgumentException {
		log.info(" createCloudResellerUser()  - start");
		if(result.hasErrors()) {
			return new ResponseEntity<CloudResellerUserResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudResellerUserDetails details = assember.fromResouce(resource);
		CreateCloudResellerUserEvent request = new CreateCloudResellerUserEvent().setResellerUserDetails(details);
		if (request != null) {
			service.createResellerUser(request);
		}
		log.info(" createCloudResellerUser()  - end");
		return new ResponseEntity<CloudResellerUserResource>(HttpStatus.CREATED);
	}
	
	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudResellerUserResource> updateCloudResellerUser(@Valid @RequestBody CloudResellerUserResource resource,BindingResult result) throws ResourceNotFoundException , IllegalArgumentException {
		log.info(" updateCloudResellerUser()  - start");
		if(resource.getResellerUserId() == null){
			result.addError(new FieldError("resource", "supplierId", resource.getResellerUserId(), true, null, null, null));
		}
		if(result.hasErrors()){
			return new ResponseEntity<CloudResellerUserResource>(resource,HttpStatus.BAD_REQUEST);
		}
		CloudResellerUserDetails details = assember.fromResouce(resource);
		
		CreateCloudResellerUserEvent request = new CreateCloudResellerUserEvent().setResellerUserDetails(details);
		if (request != null) {
			service.updateResellerUser(request);
		}
		log.info(" updateCloudResellerUser()  - end");
		return new ResponseEntity<CloudResellerUserResource>(HttpStatus.OK);
	}
	

}
