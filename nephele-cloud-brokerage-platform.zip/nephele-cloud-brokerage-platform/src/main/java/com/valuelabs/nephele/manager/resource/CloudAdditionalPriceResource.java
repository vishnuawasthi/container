package com.valuelabs.nephele.manager.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Setter
@Getter
public class CloudAdditionalPriceResource extends ResourceSupport {

	private Long  additionalPriceId;
	private String   name;
	private String   price;
	private Long  serviceId;
	private String   location;
	private String   description;
	private String status;
	private String serviceName;
	private String planCode;
	private String vendorPrice;
}
