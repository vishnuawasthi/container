package com.valuelabs.nephele.manager.resource;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)

public class CloudResellerCompanyResources {

	private List<CloudResellerCompanyResource> resellers;
	
}
