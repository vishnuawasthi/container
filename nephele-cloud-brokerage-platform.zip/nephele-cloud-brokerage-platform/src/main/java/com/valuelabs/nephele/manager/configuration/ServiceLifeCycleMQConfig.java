package com.valuelabs.nephele.manager.configuration;

import javax.annotation.PostConstruct;

import lombok.extern.slf4j.Slf4j;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
public class ServiceLifeCycleMQConfig {
	
	@Autowired
	AmqpAdmin rabbitAdmin;
	
	public static final String EXCHANGE_NAME = "nephele.cloud.rackspace.exchange";
	
	//Reseller Data Sync
	//public static final String RESELLER_DATA_QUEUE_NAME = "nephele.cloud.b2b.reseller.data.sync.queue";
	//public static final String RESELLER_DATA_ROUTING_KEY = "nephele.cloud.b2b.reseller.data.syncKey";
	

	// Rackspace service queues
	//ServerAction=provision
	public static final String PROVISION_QUEUE_NAME = "nephele.cloud.rackspace.server.provision.queue";
	public static final String PROVISION_ROUTING_KEY = "nephele.cloud.rackspace.server.provisionKey";
	
	//ServerAction=polling
	public static final String POLLING_QUEUE_NAME = "nephele.cloud.rackspace.server.polling.queue";
	public static final String POLLING_ROUTING_KEY = "nephele.cloud.rackspace.server.pollingKey";
	
	//ServerAction=Reboot
	public static final String REBOOT_QUEUE_NAME = "nephele.cloud.rackspace.server.reboot.queue";
	public static final String REBOOT_ROUTING_KEY = "nephele.cloud.rackspace.server.rebootKey";
	
	//ServerAction=TERMINATE
	public static final String TERMINATE_QUEUE_NAME = "nephele.cloud.rackspace.server.terminate.queue";
	public static final String TERMINATE_ROUTING_KEY = "nephele.cloud.rackspace.server.terminateKey";
	
	//ServerAction=Resize
	public static final String RESIZE_QUEUE_NAME = "nephele.cloud.rackspace.server.resize.queue";
	public static final String RESIZE_ROUTING_KEY = "nephele.cloud.rackspace.server.resizeKey";
	
	//Marketplace Products Sync By Service
	public static final String MARKETPLACE_PRODUCT_SYNC_BY_SERVICE_QUEUE_NAME = "nephele.cloud.rackspace.marketplace.product.sync.byservice.queue";
	public static final String MARKETPLACE_PRODUCT_SYNC_BY_SERVICE_ROUTING_KEY = "nephele.cloud.rackspace.marketplace.product.syncKey.byservice";
	
	//Marketplace Products Sync By Service
	public static final String MARKETPLACE_PRODUCT_SYNC_BY_OS_QUEUE_NAME = "nephele.cloud.rackspace.marketplace.product.sync.byos.queue";
	public static final String MARKETPLACE_PRODUCT_SYNC_BY_OS_ROUTING_KEY = "nephele.cloud.rackspace.marketplace.product.syncKey.byos";
	
	
	//Reset server password
	public static final String RESET_SERVER_PASSWORD_QUEUE_NAME = "nephele.cloud.rackspace.server.reset.password.queue";
	public static final String RESET_SERVER_PASSWORD_ROUTING_KEY = "nephele.cloud.rackspace.server.reset.passwordKey";
	
	//Sync server details
    public static final String SYNC_SERVER_QUEUE_NAME = "nephele.cloud.rackspace.server.sync.queue";
	public static final String SYNC_SERVER_ROUTING_KEY = "nephele.cloud.rackspace.server.sync";
	
	// Nomadesk service queues
	//ServerAction=provision
	public static final String ND_PROVISION_QUEUE_NAME = "nephele.cloud.nomadesk.server.provision.queue";
	public static final String ND_PROVISION_ROUTING_KEY = "nephele.cloud.nomadesk.server.provisionKey";
	
	//Assigning licenses
	public static final String ND_LICENSES_QUEUE_NAME = "nephele.cloud.nomadesk.licenses.queue";
	public static final String ND_LICENSES_ROUTING_KEY = "nephele.cloud.nomadesk.licenses.provisionKey";
	
	//Reactivate Account
	public static final String ND_REACTIVATE_QUEUE_NAME = "nephele.cloud.nomadesk.reactivate.account.queue";
	public static final String ND_REACTIVATE_ROUTING_KEY = "nephele.cloud.nomadesk.reactivate.accountKey";
		
	//Nomadeks SUSPEND 
	public static final String ND_SUSPEND_QUEUE_NAME = "nephele.cloud.nomadesk.suspend.queue";
	public static final String ND_SUSPEND_ROUTING_KEY = "nephele.cloud.nomadesk.suspendKey";
	
	//Nomadeks CANCEL 
	public static final String ND_CANCEL_QUEUE_NAME  = "nephele.cloud.nomadesk.cancel.queue";
	public static final String ND_CANCEL_ROUTING_KEY = "nephele.cloud.nomadesk.cancelKey";
	
	//Nomadeks sync licenses 
	public static final String ND_SYNC_LICENSE_QUEUE_NAME  = "nephele.cloud.nomadesk.sync.licence.queue";
	public static final String ND_SYNC_LICENCE_ROUTING_KEY = "nephele.cloud.nomadesk.sync.licenceKey";
	
	// Softlayer service queues
	//ServerAction=provision
	public static final String SOFTLAYER_PROVISION_QUEUE_NAME = "nephele.cloud.softlayer.server.provision.queue";
	public static final String SOFTLAYER_PROVISION_ROUTING_KEY = "nephele.cloud.softlayer.server.provisionKey";
	
	//ServerAction=reboot
	public static final String SOFTLAYER_REBOOT_QUEUE_NAME = "nephele.cloud.softlayer.server.reboot.queue";
	public static final String SOFTLAYER_REBOOT_ROUTING_KEY = "nephele.cloud.softlayer.server.rebootKey";
	
	//ServerAction=terminate
	public static final String SOFTLAYER_TERMINATE_QUEUE_NAME = "nephele.cloud.softlayer.server.terminate.queue";
	public static final String SOFTLAYER_TERMINATE_ROUTING_KEY = "nephele.cloud.softlayer.server.terminateKey";
	
	//Sync server details
    public static final String SOFTLAYER_SYNC_SERVER_QUEUE_NAME = "nephele.cloud.softlayer.server.sync.queue";
	public static final String SOFLAYER_SYNC_SERVER_ROUTING_KEY = "nephele.cloud.softlayer.server.sync";
	
	/*@Bean(name = "resellerDataQueue")
	public Queue getResellerDataQueue() {
		return new Queue(RESELLER_DATA_QUEUE_NAME, true);
	}*/
	
	@Bean(name = "provisionQueue")
	public Queue getProvisionQueue() {
		return new Queue(PROVISION_QUEUE_NAME, true);
	}
	
	@Bean(name = "pollingQueue")
	public Queue getPollingQueue() {
		return new Queue(POLLING_QUEUE_NAME, true);
	}
	
	@Bean(name = "rebootQueue")
	public Queue getRebootQueue() {
		return new Queue(REBOOT_QUEUE_NAME, true);
	}

	@Bean(name = "terminateQueue")
	public Queue getTerminateQueue() {
		return new Queue(TERMINATE_QUEUE_NAME, true);
	}
	
	@Bean(name = "resizeQueue")
	public Queue getResizeQueue() {
		return new Queue(RESIZE_QUEUE_NAME, true);
	}
	
	@Bean(name = "marketplaceProductSyncByServiceQueue")
	public Queue getMarketplaceProductSyncByServiceQueue() {
		return new Queue(MARKETPLACE_PRODUCT_SYNC_BY_SERVICE_QUEUE_NAME, true);
	}
	
	@Bean(name = "marketplaceProductSyncByOsQueue")
	public Queue getMarketplaceProductSyncByOsQueue() {
		return new Queue(MARKETPLACE_PRODUCT_SYNC_BY_OS_QUEUE_NAME, true);
	}
	
	@Bean(name = "resetServerPasswordQueue")
	public Queue getResetServerPasswordQueue() {
		return new Queue(RESET_SERVER_PASSWORD_QUEUE_NAME, true);
	}
	
	@Bean(name = "syncServerQueue")
	public Queue getSyncServerQueue() {
		return new Queue(SYNC_SERVER_QUEUE_NAME, true);
	}

	@Bean(name = "directExchange")
	public DirectExchange getDirectExchange() {
		return new DirectExchange(EXCHANGE_NAME, true, false);
	}
	
	@Bean(name = "provisionBinding")
	Binding getProvisionBinding(Queue provisionQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(provisionQueue).to(directExchange).with(PROVISION_ROUTING_KEY);
	}
	
	@Bean(name = "pollingBinding")
	Binding getPollingBinding(Queue pollingQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(pollingQueue).to(directExchange).with(POLLING_ROUTING_KEY);
	}
	
	@Bean(name = "rebootBinding")
	Binding getRebootBinding(Queue rebootQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(rebootQueue).to(directExchange).with(REBOOT_ROUTING_KEY);
	}
	
	@Bean(name = "terminateBinding")
	Binding getTerminateBinding(Queue terminateQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(terminateQueue).to(directExchange).with(TERMINATE_ROUTING_KEY);
	}
	
	@Bean(name = "resizeBinding")
	Binding getResizeBinding(Queue resizeQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(resizeQueue).to(directExchange).with(RESIZE_ROUTING_KEY);
	}
	
	@Bean(name = "marketplaceProductSyncByServiceBinding")
	Binding getMarketplaceProductSyncByServiceBinding(Queue marketplaceProductSyncByServiceQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(marketplaceProductSyncByServiceQueue).to(directExchange).with(MARKETPLACE_PRODUCT_SYNC_BY_SERVICE_ROUTING_KEY);
	}
	
	@Bean(name = "marketplaceProductSyncByOsBinding")
	Binding getMarketplaceProductSyncByOsBinding(Queue marketplaceProductSyncByOsQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(marketplaceProductSyncByOsQueue).to(directExchange).with(MARKETPLACE_PRODUCT_SYNC_BY_OS_ROUTING_KEY);
	}
	
	@Bean(name = "resetServerPasswordBinding")
	Binding getResetServerPasswordBinding(Queue resetServerPasswordQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(resetServerPasswordQueue).to(directExchange).with(RESET_SERVER_PASSWORD_ROUTING_KEY);
	}
	
	@Bean(name = "syncServerBinding")
	Binding getSyncServerBinding(Queue syncServerQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(syncServerQueue).to(directExchange).with(SYNC_SERVER_ROUTING_KEY);
	}

	/*@Bean(name = "resellerDataBinding")
	Binding getResellerDataBinding(Queue resellerDataQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(resellerDataQueue).to(directExchange).with(RESELLER_DATA_ROUTING_KEY);
	}*/
	

	// Nomadesk queues
	@Bean(name = "nomadeskProvisionQueue")
	public Queue getNomadeskProvisionQueue() {
		return new Queue(ND_PROVISION_QUEUE_NAME, true);
	}
	
	// Nomadesk reactivate queues
	@Bean(name = "nomadeskReactivateQueue")
	public Queue getNomadeskReactivateQueue() {
		return new Queue(ND_REACTIVATE_QUEUE_NAME, true);
	}
	
	@Bean(name = "nomadeskLicensesQueue")
	public Queue getNomadeskLicensesQueue() {
		return new Queue(ND_LICENSES_QUEUE_NAME, true);
	}
	
	@Bean(name = "nomadeskCancelQueue")
	public Queue getNomadeskCancelQueue() {
		return new Queue(ND_CANCEL_QUEUE_NAME, true);
	}
	
	@Bean(name = "nomadeskSuspendQueue")
	public Queue getNomadeskSuspendQueue() {
		return new Queue(ND_SUSPEND_QUEUE_NAME, true);
	}
	
	
	// Softlayer queues
	@Bean(name = "softlayerProvisionQueue")
	public Queue getSoftlayerProvisionQueue() {
		return new Queue(SOFTLAYER_PROVISION_QUEUE_NAME, true);
	}
	
	@Bean(name = "nomadeskProvisionBinding")
	Binding getNomadeskProvisionBinding(Queue nomadeskProvisionQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(nomadeskProvisionQueue).to(directExchange).with(ND_PROVISION_ROUTING_KEY);
	}
	@Bean(name = "nomadeskReactivateBinding")
	Binding getNomadeskReactivateBinding(Queue nomadeskReactivateQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(nomadeskReactivateQueue).to(directExchange).with(ND_REACTIVATE_ROUTING_KEY);
	}
	@Bean(name = "nomadeskCancelBinding")
	Binding getNomadeskCancelBinding(Queue nomadeskCancelQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(nomadeskCancelQueue).to(directExchange).with(ND_CANCEL_ROUTING_KEY);
	}
	@Bean(name = "nomadeskSuspendBinding")
	Binding getNomadeskSuspendBinding(Queue nomadeskSuspendQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(nomadeskSuspendQueue).to(directExchange).with(ND_SUSPEND_ROUTING_KEY);
	}
	@Bean(name = "nomadeskLicensesBinding")
	Binding getNomadeskLicensesdBinding(Queue nomadeskLicensesQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(nomadeskLicensesQueue).to(directExchange).with(ND_LICENSES_ROUTING_KEY);
	}
	
	@Bean(name = "softlayerProvisionBinding")
	Binding getSoftlayerProvisionBinding(Queue softlayerProvisionQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(softlayerProvisionQueue).to(directExchange).with(SOFTLAYER_PROVISION_ROUTING_KEY);
	}
	
	// Softlayer reboot queue
	@Bean(name = "softlayerRebootQueue")
	public Queue getSoftlayerRebootQueue() {
		return new Queue(SOFTLAYER_REBOOT_QUEUE_NAME, true);
	}
	
	@Bean(name = "softlayerRebootBinding")
	Binding getSoftlayerRebootBinding(Queue softlayerRebootQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(softlayerRebootQueue).to(directExchange).with(SOFTLAYER_REBOOT_ROUTING_KEY);
	}

	// Softlayer terminate queue
	@Bean(name = "softlayerTerminateQueue")
	public Queue getSoftlayerTerminateQueue() {
		return new Queue(SOFTLAYER_TERMINATE_QUEUE_NAME, true);
	}
	
	@Bean(name = "softlayerTerminateBinding")
	Binding getSoftlayerTerminateBinding(Queue softlayerTerminateQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(softlayerTerminateQueue).to(directExchange).with(SOFTLAYER_TERMINATE_ROUTING_KEY);
	}
	
	@Bean(name = "softlayerSyncServerQueue")
	public Queue getSoftlayerSyncServerQueue() {
		return new Queue(SOFTLAYER_SYNC_SERVER_QUEUE_NAME, true);
	}
	
	@Bean(name = "softlayerSyncServerBinding")
	Binding getSoftlayerSyncServerBinding(Queue softlayerSyncServerQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(softlayerSyncServerQueue).to(directExchange).with(SOFLAYER_SYNC_SERVER_ROUTING_KEY);
	}
	
	@Bean(name = "nomadeskSyncLicenseQueue")
	public Queue getNomadeskSyncLicenseQueue() {
		return new Queue(ND_SYNC_LICENSE_QUEUE_NAME, true);
	}
	
	@Bean(name = "nomadeskSyncLicenseBinding")
	Binding getNomadeskSyncLicenseBinding(Queue nomadeskSyncLicenseQueue, DirectExchange directExchange) {
		return BindingBuilder.bind(nomadeskSyncLicenseQueue).to(directExchange).with(ND_SYNC_LICENCE_ROUTING_KEY);
	}
	@PostConstruct
	public void initializeMessageQueue() {
		log.debug("initializeMessageQueue");

		DirectExchange directExchange = getDirectExchange();
		
		Queue provisionQueue = getProvisionQueue();
		Binding provisionBinding = getProvisionBinding(provisionQueue, directExchange);
		
		Queue pollingQueue = getPollingQueue();
		Binding pollingBinding = getPollingBinding(pollingQueue, directExchange);
		
		Queue rebootQueue = getRebootQueue();
		Binding rebootBinding = getRebootBinding(rebootQueue, directExchange);
		
		Queue terminateQueue = getTerminateQueue();
		Binding terminateBinding = getTerminateBinding(terminateQueue, directExchange);
		
		Queue resizeQueue = getResizeQueue();
		Binding resizeBinding = getResizeBinding(resizeQueue, directExchange);
		
		Queue marketplaceProductSyncByServiceQueue = getMarketplaceProductSyncByServiceQueue();
		Binding marketplaceProductSyncByServiceBinding = getResizeBinding(marketplaceProductSyncByServiceQueue, directExchange);
		
		Queue marketplaceProductSyncByOsQueue = getMarketplaceProductSyncByOsQueue();
		Binding marketplaceProductSyncByOsBinding = getResizeBinding(marketplaceProductSyncByOsQueue, directExchange);
		
		Queue resetServerPasswordQueue = getResetServerPasswordQueue();
		Binding resetServerPasswordBinding = getResetServerPasswordBinding(resetServerPasswordQueue, directExchange);
		
		Queue syncServerQueue = getSyncServerQueue();
		Binding syncServerBinding = getSyncServerBinding(syncServerQueue, directExchange);
		
	/*	Queue resellerDataQueue = getResellerDataQueue();
		Binding resellerDataBinding = getResellerDataBinding(resellerDataQueue, directExchange);*/

		rabbitAdmin.declareExchange(directExchange);
		
		rabbitAdmin.declareQueue(provisionQueue);
		rabbitAdmin.declareBinding(provisionBinding);
		
		rabbitAdmin.declareQueue(pollingQueue);
		rabbitAdmin.declareBinding(pollingBinding);
		
		rabbitAdmin.declareQueue(rebootQueue);
		rabbitAdmin.declareBinding(rebootBinding);
		
		rabbitAdmin.declareQueue(terminateQueue);
		rabbitAdmin.declareBinding(terminateBinding);
		
		rabbitAdmin.declareQueue(resizeQueue);
		rabbitAdmin.declareBinding(resizeBinding);
		
		rabbitAdmin.declareQueue(marketplaceProductSyncByServiceQueue);
		rabbitAdmin.declareBinding(marketplaceProductSyncByServiceBinding);
		
		rabbitAdmin.declareQueue(marketplaceProductSyncByOsQueue);
		rabbitAdmin.declareBinding(marketplaceProductSyncByOsBinding);
		
		rabbitAdmin.declareQueue(resetServerPasswordQueue);
		rabbitAdmin.declareBinding(resetServerPasswordBinding);
		
		rabbitAdmin.declareQueue(syncServerQueue);
		rabbitAdmin.declareBinding(syncServerBinding);
		
		/*rabbitAdmin.declareQueue(resellerDataQueue);
		rabbitAdmin.declareBinding(resellerDataBinding);*/

		//Nomadesk queue initialization
		Queue nomadeskProvisionQueue = getNomadeskProvisionQueue();
		Binding nomadeskProvisionBinding = getNomadeskProvisionBinding(nomadeskProvisionQueue, directExchange); 
		
		Queue nomadeskReactivateQueue     = getNomadeskReactivateQueue();
		Binding nomadeskReactivateBinding = getNomadeskReactivateBinding(nomadeskReactivateQueue, directExchange); 
		
		Queue nomadeskCancelQueue     = getNomadeskCancelQueue();
		Binding nomadeskCancelBinding = getNomadeskCancelBinding(nomadeskCancelQueue, directExchange); 
		
		Queue nomadeskSuspendQueue     = getNomadeskSuspendQueue();
		Binding nomadeskSuspendBinding = getNomadeskSuspendBinding(nomadeskSuspendQueue, directExchange);
		
		Queue nomadeskLicenseQueue     = getNomadeskLicensesQueue();
		Binding nomadeskLicenseBinding = getNomadeskLicensesdBinding(nomadeskLicenseQueue, directExchange); 
		
		//softlayer queue initialization
		Queue softlayerProvisionQueue = getSoftlayerProvisionQueue();
		Binding softlayerProvisionBinding = getSoftlayerProvisionBinding(softlayerProvisionQueue, directExchange); 
		
		rabbitAdmin.declareQueue(nomadeskProvisionQueue);
		rabbitAdmin.declareBinding(nomadeskProvisionBinding);
		
		rabbitAdmin.declareQueue(nomadeskReactivateQueue);
		rabbitAdmin.declareBinding(nomadeskReactivateBinding);
		
		rabbitAdmin.declareQueue(nomadeskCancelQueue);
		rabbitAdmin.declareBinding(nomadeskCancelBinding);
		
		rabbitAdmin.declareQueue(nomadeskSuspendQueue);
		rabbitAdmin.declareBinding(nomadeskSuspendBinding);
		
		rabbitAdmin.declareQueue(nomadeskLicenseQueue);
		rabbitAdmin.declareBinding(nomadeskLicenseBinding);
		
		rabbitAdmin.declareQueue(softlayerProvisionQueue);
		rabbitAdmin.declareBinding(softlayerProvisionBinding);
		
		//Softlayer reboot queue declaration
		Queue softlayerRebootQueue = getSoftlayerRebootQueue();
		Binding softlayerRebootBinding = getSoftlayerRebootBinding(softlayerRebootQueue, directExchange); 
		
		rabbitAdmin.declareQueue(softlayerRebootQueue);
		rabbitAdmin.declareBinding(softlayerRebootBinding);
		
		//Softlayer termination queue declaration
		Queue softlayerTerminateQueue = getSoftlayerTerminateQueue();
		Binding softlayerTerminateBinding = getSoftlayerTerminateBinding(softlayerTerminateQueue, directExchange); 
		
		rabbitAdmin.declareQueue(softlayerTerminateQueue);
		rabbitAdmin.declareBinding(softlayerTerminateBinding);
		
		//softlayer sync server queue and binding
		Queue softlayerSyncServerQueue = getSoftlayerSyncServerQueue();
		Binding softlayerSyncServerBinding = getSoftlayerSyncServerBinding(softlayerSyncServerQueue, directExchange);
		
		rabbitAdmin.declareQueue(softlayerSyncServerQueue);
		rabbitAdmin.declareBinding(softlayerSyncServerBinding);
		
		//nomadesk sync licenses queue and binding
		Queue nomadeskSyncLicenseQueue = getNomadeskSyncLicenseQueue();
		Binding nomadeskSyncLicenseBinding = getNomadeskSyncLicenseBinding(nomadeskSyncLicenseQueue, directExchange);
				
		rabbitAdmin.declareQueue(nomadeskSyncLicenseQueue);
		rabbitAdmin.declareBinding(nomadeskSyncLicenseBinding);


	}
	
}
