package com.valuelabs.nephele.marketplace.resource;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class BundleResource extends ResourceSupport {
  private Long bundleId;
  private String name;
  private String description;
  private String status;
  private String logoCode;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date created;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date updated;
  private List<Long> cloudproducts;
  private List<Long> externalproducts;
  private List<CloudProductDetails> cloudProductList;
  private List<ExternalProductDetails> externalProductList;
  private Long cloudProductId;
  private Long externalProductId;
}
