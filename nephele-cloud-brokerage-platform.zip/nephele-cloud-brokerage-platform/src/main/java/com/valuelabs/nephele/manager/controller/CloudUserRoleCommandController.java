package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudUserRoleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudUserRoleEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudUserRoleCommandService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudWebserviceErrorResource;
import com.valuelabs.nephele.manager.assembler.CloudUserRoleAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudUserRolePermissionsResource;
import com.valuelabs.nephele.manager.resource.CloudUserRoleResource;

@Slf4j
@RestController
@Transactional
@RequestMapping("/manager/userRole")
public class CloudUserRoleCommandController {
	
	@Autowired
	private CloudUserRoleAssembler assembler;

	@Autowired
	private CloudUserRoleCommandService commandService;
	
	/**
	 * This method will create new record in DB by accepting http request object.
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 *//*
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudUserRoleResource> createUserRole( 
			@Valid @RequestBody CloudUserRoleResource resource,
			BindingResult result)throws IllegalArgumentException {
		log.info("createUserRole() : START");
		
		if (result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		
		CloudUserRoleDetails details = assembler.fromResource(resource);
		CreateCloudUserRoleEvent request = new CreateCloudUserRoleEvent()
				.setCloudUserRoleDetails(details);
		
		if (request != null) {
			commandService.createUserRoleService(request);
		}
		
		log.info("createUserRole() : END");
		return new ResponseEntity<CloudUserRoleResource>(HttpStatus.CREATED);
	}*/
	
	/**
	 * This method will create new record in DB by accepting http request object.
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 */
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudUserRoleResource> createUserRole( 
			@Valid @RequestBody CloudUserRolePermissionsResource resource,
			BindingResult result)throws IllegalArgumentException {
		log.info("createUserRole() : START");
		
		if (result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		
		CloudUserRoleDetails details = assembler.fromResource(resource);
		CreateCloudUserRoleEvent request = new CreateCloudUserRoleEvent()
				.setCloudUserRoleDetails(details);
		
		if (request != null) {
			commandService.createUserRoleService(request);
		}
		
		log.info("createUserRole() : END");
		return new ResponseEntity<CloudUserRoleResource>(HttpStatus.CREATED);
	}
	
	
	/**
	 * This method will update existing single record in DB by accepting http request object
	 * @param resource
	 * @param result
	 * @return
	 * @throws IllegalArgumentException
	 * @throws ResourceNotFoundException
	 */
	@RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudUserRoleResource> updateUserRole( 
			@Valid @RequestBody CloudUserRoleResource resource,
			BindingResult result) throws IllegalArgumentException, ResourceNotFoundException {
		log.info("updateUserRole() : START");
		
		if (resource.getRoleId() == null) {
			result.addError(new FieldError("resource", "roleId", resource.getRoleId(), false, null, null, null));
		}
		
		if (result.hasErrors()) {
			List<String> errorMessageList = new ArrayList<String>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				errorMessageList.add(fieldError.getField() + " " +  fieldError.getDefaultMessage());
			}
			CloudWebserviceErrorResource errorResource = CloudWebserviceErrorResource.builder().errorMessages(errorMessageList).build();
			return new ResponseEntity(errorResource, HttpStatus.BAD_REQUEST);
		}
		
		CloudUserRoleDetails details = assembler.fromResource(resource);
		CreateCloudUserRoleEvent request = new CreateCloudUserRoleEvent()
				.setCloudUserRoleDetails(details);
		
		if (request != null) {
			commandService.updateUserRoleService(request);
		}
		
		log.info("updateUserRole() : END");
		return new ResponseEntity<CloudUserRoleResource>(HttpStatus.OK);
	}
}
