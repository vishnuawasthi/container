package com.valuelabs.nephele.manager.controller;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceCredentialDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceCredentialEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceCredentialsEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudServiceCredentialQueryService;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudServiceCredentialResource;
import com.valuelabs.nephele.manager.assembler.CloudServiceCredentialResourceAssembler;
import com.valuelabs.nephele.manager.constants.QueryParameterConstants;

@Slf4j
@RestController
@RequestMapping("/manager/serviceCredential")
@Transactional
public class CloudServiceCredentialQueryController {

	@Autowired
	CloudServiceCredentialResourceAssembler assembler;
	
	@Autowired
	CloudServiceCredentialQueryService service;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CloudServiceCredentialResource> readServiceCredential(@PathVariable Long id) {
		log.info("readServiceCredential() START");

		ReadServiceCredentialEvent request=new ReadServiceCredentialEvent().setServiceCredentialId(id);
		
		EntityReadEvent<CloudServiceCredentialDetails> event = service.readServiceCredential(request);

		if(!event.isFound()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

		CloudServiceCredentialDetails entity = event.getEntity();
		log.info("readServiceCredential() END");
		return new ResponseEntity<>(assembler.toResource(entity), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PagedResources<CloudServiceCredentialResource>> readServiceCredentials(
			@RequestParam(value=QueryParameterConstants.SORT_DIRECTION ,required=false)String sortDirection,
			@RequestParam(value=QueryParameterConstants.SORT_COLUMN_NAME ,required=false)String sortColumnName,
			@PageableDefault(value = Integer.MAX_VALUE) Pageable pageable,
			PagedResourcesAssembler<CloudServiceCredentialDetails> pagedAssembler,
			@RequestParam(value = "serviceId",required = false) Long serviceId) {
		log.info("readServiceCredentials() START");
		ReadServiceCredentialsEvent request=new ReadServiceCredentialsEvent().setPageable(pageable).setServiceId(serviceId);

		 request.setSortDirection(sortDirection);
		 request.setSortColumnName(sortColumnName);
		PageReadEvent<CloudServiceCredentialDetails> event=service.readServiceCredentials(request);
		Page<CloudServiceCredentialDetails> page=event.getPage();
		PagedResources<CloudServiceCredentialResource> pagedResources = pagedAssembler.toResource(page, assembler);
		log.info("readServiceCredentials() END");
		return new ResponseEntity<>(pagedResources, HttpStatus.OK);
	}
}
