package com.valuelabs.nephele.manager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudRackspaceConfigurationEvent;
import com.valuelabs.nephele.admin.rest.lib.manager.service.CloudRackspaceConfigurationCommandService;
import com.valuelabs.nephele.manager.assembler.CloudRackspaceConfigurationAssembler;
import com.valuelabs.nephele.manager.exception.ResourceNotFoundException;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResources;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/manager/rackspaceConfiguration")
@Transactional
public class CloudRackspaceConfigurationCommandController {

	@Autowired
	private CloudRackspaceConfigurationAssembler assembler;

	@Autowired
	private CloudRackspaceConfigurationCommandService service;

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudRackspaceConfigurationResource> updateCloudRackspaceConfiguration(@Valid @RequestBody CloudRackspaceConfigurationResource resource,BindingResult result) throws ResourceNotFoundException,IllegalArgumentException {
		log.info(" updateCloudRackspaceConfiguration()  - start");
		if(resource.getConfigurationId() ==null) {
			result.addError(new FieldError("resource", "rackspaceConfigurationId", resource.getConfigurationId(),true, null, null, null));
		}
		if(result.hasErrors()) {
			return new ResponseEntity<CloudRackspaceConfigurationResource>(resource,
					HttpStatus.BAD_REQUEST);
		}
		CloudRackspaceConfigurationDetails details = assembler.fromResource(resource);
		CreateCloudRackspaceConfigurationEvent request = new CreateCloudRackspaceConfigurationEvent().setCloudRackspaceConfigurationDetails(details);
		if (request != null) {
			service.updateCloudRackspaceConfiguration(request);
		}
		log.info(" updateCloudRackspaceConfiguration()  - end");
		return new ResponseEntity<CloudRackspaceConfigurationResource>(HttpStatus.OK);
	}

	/**
	 * 
	 * @param resources
	 * @return
	 */
	@RequestMapping(value = "/updateStatusById", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public HttpEntity<CloudRackspaceConfigurationResources> updateStatusById(@RequestBody CloudRackspaceConfigurationResources resources) throws ResourceNotFoundException,IllegalArgumentException{
		log.info("updateStatusById - start");
		int errorCounter = 0;
		List<CloudRackspaceConfigurationDetails> detailsList = new ArrayList<CloudRackspaceConfigurationDetails>();
		for ( CloudRackspaceConfigurationResource resource : resources.getResources()) {
			if(resource.getConfigurationId()==null) {
				errorCounter++;
			}
			CloudRackspaceConfigurationDetails details= CloudRackspaceConfigurationDetails.builder().configurationId(resource.getConfigurationId())
					.status(resource.getStatus()).build();
			detailsList.add(details);
		}
		if(errorCounter!=0) {
			return new ResponseEntity<CloudRackspaceConfigurationResources>(resources, HttpStatus.BAD_REQUEST);
		}
		CreateCloudRackspaceConfigurationEvent request  = new CreateCloudRackspaceConfigurationEvent().setCloudRackspaceConfigurationDetailsList(detailsList);
		service.updateStatusById(request);
		log.info("updateStatusById - end");
		return new ResponseEntity<CloudRackspaceConfigurationResources>(HttpStatus.OK);
	}
	
	
}
