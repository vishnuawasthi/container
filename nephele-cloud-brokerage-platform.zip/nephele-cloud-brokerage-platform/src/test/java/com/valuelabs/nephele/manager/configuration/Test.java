package com.valuelabs.nephele.manager.configuration;

public class Test {

}
