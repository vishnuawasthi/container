/*package com.valuelabs.nephele.manager.assembler;
import static com.valuelabs.nephele.test.helpers.TestFixtures.ID;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServiceDetails;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServiceResource;
import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;
import com.valuelabs.nephele.manager.resource.CloudServiceResource;

@ContextConfiguration(classes=CloudServiceResourceAssembler.class,loader=AnnotationConfigContextLoader.class)
public class CloudServiceAssemblerTest extends AbstractJUnit4SpringContextTests {
	
	@Autowired
	private CloudServiceResourceAssembler assembler;
	
	@Before
	public void setup() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
	}
	
	
	
	@Test
	public void toResourceTest(){
		CloudServiceDetails details=mockCloudServiceDetails();
		CloudServiceResource resource=assembler.toResource(details);
		TestCase.assertEquals(details.getName(), resource.getName());
		TestCase.assertEquals(details.getServiceCode(), resource.getServiceCode());
		TestCase.assertEquals(details.getStatus(), resource.getStatus());
		TestCase.assertEquals(details.getDescription(), resource.getDescription());
		TestCase.assertEquals(details.getServiceProviderId(), resource.getServiceProviderId());
		TestCase.assertEquals(details.getServicePricingModelId(), resource.getServicePricingModelId());
		TestCase.assertEquals(details.getServiceId(), resource.getServiceId());
		TestCase.assertNotNull(resource.getLink(Link.REL_SELF));
		TestCase.assertEquals("http://localhost:8090/manager/serviceProvider/"+ID,"http://localhost:8090/manager/serviceProvider/1");
	}
	
	@Test
	public void fromResourceTest(){
		
		CloudServiceResource resource=mockCloudServiceResource();
		CloudServiceDetails details = assembler.fromResource(resource);
		TestCase.assertEquals(resource.getName(), details.getName());
		TestCase.assertEquals(resource.getServiceCode(), details.getServiceCode());
		TestCase.assertEquals(resource.getStatus(), details.getStatus());
		TestCase.assertEquals(resource.getDescription(), details.getDescription());
		TestCase.assertEquals(resource.getServiceProviderId(), details.getServiceProviderId());
		TestCase.assertEquals(resource.getServicePricingModelId(), details.getServicePricingModelId());
		TestCase.assertEquals(resource.getServiceId(), details.getServiceId());
	}

	
	@Test
	public void toResourceEmptyTest(){
		CloudServiceDetails details= CloudServiceDetails.builder().build();
		TestCase.assertTrue(StringUtils.isEmpty(details.getName()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getServiceCode()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getStatus()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getServiceCode()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getDescription()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getServiceProviderId()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getServicePricingModelId()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getServiceId()));
	}

	
	@Test
	public void fromResourceEmptyTest(){
		CloudServiceResource resource= CloudServiceResource.builder().build();
		TestCase.assertTrue(StringUtils.isEmpty(resource.getName()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getServiceCode()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getStatus()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getServiceCode()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getDescription()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getServiceProviderId()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getServicePricingModelId()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getServiceId()));
	}
	
}
*/