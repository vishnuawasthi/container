/**
 * 
 *//*
package com.valuelabs.nephele.marketplace.assembler;

import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServerActionDetails;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServerActionResource;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerActionDetails;
import com.valuelabs.nephele.marketplace.resource.CloudServerActionResource;

@ContextConfiguration(classes = {CloudServerActionResource.class}, loader = AnnotationConfigContextLoader.class)
public class CloudServerActionResourceAssemblerTest {

	@Autowired
	CloudServerActionAssember assembler;

	CloudServerActionResource resource = null;
	CloudServerActionDetails details = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
	}

	@Before
	public void setUp() throws Exception {
		resource = mockCloudServerActionResource();
		details = mockCloudServerActionDetails();
	}

	@Test
	public void toReource() {
		CloudServerActionResource resourceTemp = assembler.toResource(details);
		assertEquals(details.getId(), resourceTemp.getCloudServerActionId());
		assertEquals(details.getStatus(), resourceTemp.getStatus());
		assertEquals(details.getCloudServerId(), resourceTemp.getCloudServerId());
		assertEquals(details.getAction(), resourceTemp.getAction());
	}
	@Test
	public void FromReource() {
		CloudServerActionDetails detailsTemp = assembler.fromResource(resource);
		assertEquals(resource.getId(), detailsTemp.getId());
		assertEquals(resource.getStatus(), detailsTemp.getStatus());
		assertEquals(resource.getCloudServerId(), detailsTemp.getCloudServerId());
		assertEquals(resource.getAction(), detailsTemp.getAction());
	}

}
*/