/*package com.valuelabs.nephele.manager.assembler;
import static com.valuelabs.nephele.test.helpers.TestFixtures.ID;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServiceProviderDetails;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServiceProviderResource;
import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceProviderDetails;
import com.valuelabs.nephele.manager.resource.CloudServiceProviderResource;

@ContextConfiguration(classes=CloudServiceProviderAssembler.class,loader=AnnotationConfigContextLoader.class)
public class CloudServiceProviderAssemblerTest extends AbstractJUnit4SpringContextTests {
	
	@Autowired
	private CloudServiceProviderAssembler assembler;
	
	@Before
	public void setup() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
	}
	
	
	
	@Test
	public void toResourceTest(){
		CloudServiceProviderDetails details=mockCloudServiceProviderDetails();
		CloudServiceProviderResource resource=assembler.toResource(details);
		TestCase.assertEquals(details.getBrandName(), resource.getBrandName());
		TestCase.assertEquals(details.getBrandCode(), resource.getBrandCode());
		TestCase.assertEquals(details.getDescription(), resource.getDescription());
		TestCase.assertEquals(details.getServiceProviderId(), resource.getServiceProviderId());
		TestCase.assertNotNull(resource.getLink(Link.REL_SELF));
		TestCase.assertEquals("http://localhost:8090/manager/serviceProvider/"+ID,"http://localhost:8090/manager/serviceProvider/1");
	}
	
	@Test
	public void fromResourceTest(){
		
		CloudServiceProviderResource resource=mockCloudServiceProviderResource();
		CloudServiceProviderDetails details = assembler.fromResource(resource);
		TestCase.assertEquals(resource.getBrandName(), details.getBrandName());
		TestCase.assertEquals(resource.getBrandCode(), details.getBrandCode());
		TestCase.assertEquals(resource.getDescription(), details.getDescription());
	}

	
	@Test
	public void toResourceEmptyTest(){
		CloudServiceProviderDetails details= CloudServiceProviderDetails.builder().build();
		TestCase.assertTrue(StringUtils.isEmpty(details.getBrandName()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getBrandCode()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getServiceProviderId()));
	}

	
	@Test
	public void fromResourceEmptyTest(){
		CloudServiceProviderResource resource= CloudServiceProviderResource.builder().build();
		TestCase.assertTrue(StringUtils.isEmpty(resource.getBrandName()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getBrandCode()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getServiceProviderId()));
	}
	
}
*/