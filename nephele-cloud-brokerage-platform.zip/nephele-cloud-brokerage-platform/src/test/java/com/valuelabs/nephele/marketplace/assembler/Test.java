package com.valuelabs.nephele.marketplace.assembler;

public class Test {

}
