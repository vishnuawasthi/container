package com.valuelabs.nephele.manager;

import org.junit.Test;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class ApplicationTest {
	@Test
	public void contextLoads() {
		// Must be able to connect to the database to pass this test
	}
}

