package com.valuelabs.nephele.manager.resource;

public class Test {

}
