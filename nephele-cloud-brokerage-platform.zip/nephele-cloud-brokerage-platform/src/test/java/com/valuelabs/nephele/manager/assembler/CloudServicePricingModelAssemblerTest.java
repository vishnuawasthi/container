/*package com.valuelabs.nephele.manager.assembler;
import static com.valuelabs.nephele.test.helpers.TestFixtures.ID;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServicePricingModelDetails;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudServicePricingModelResource;
import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServicePricingModelDetails;
import com.valuelabs.nephele.manager.resource.CloudServicePricingModelResource;

@ContextConfiguration(classes=CloudServicePricingModelAssembler.class,loader=AnnotationConfigContextLoader.class)
public class CloudServicePricingModelAssemblerTest extends AbstractJUnit4SpringContextTests {
	
	@Autowired
	private CloudServicePricingModelAssembler assembler;
	
	@Before
	public void setup() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
	}
	
	
	
	@Test
	public void toResourceTest(){
		CloudServicePricingModelDetails details=mockCloudServicePricingModelDetails();
		CloudServicePricingModelResource resource=assembler.toResource(details);
		TestCase.assertEquals(details.getName(), resource.getName());
		TestCase.assertEquals(details.getServicePricingModelId(), resource.getServicePricingModelId());
		TestCase.assertNotNull(resource.getLink(Link.REL_SELF));
		TestCase.assertEquals("http://localhost:8090/manager/servicePricingModel/"+ID,"http://localhost:8090/manager/servicePricingModel/1");
	}
	
	@Test
	public void fromResourceTest(){
		
		CloudServicePricingModelResource resource=mockCloudServicePricingModelResource();
		CloudServicePricingModelDetails details = assembler.fromResource(resource);
		TestCase.assertEquals(resource.getName(), details.getName());
		TestCase.assertEquals(resource.getServicePricingModelId(), details.getServicePricingModelId());
	}

	
	@Test
	public void toResourceEmptyTest(){
		CloudServicePricingModelDetails details= CloudServicePricingModelDetails.builder().build();
		TestCase.assertTrue(StringUtils.isEmpty(details.getName()));
		TestCase.assertTrue(StringUtils.isEmpty(details.getServicePricingModelId()));
	}

	
	@Test
	public void fromResourceEmptyTest(){
		CloudServicePricingModelResource resource= CloudServicePricingModelResource.builder().build();
		TestCase.assertTrue(StringUtils.isEmpty(resource.getName()));
		TestCase.assertTrue(StringUtils.isEmpty(resource.getServicePricingModelId()));
	}
	
}
*/