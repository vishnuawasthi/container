/*package com.valuelabs.nephele.manager.assembler;

import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudDistributorCompanyDetails;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudDistributorCompanyResource;
import junit.framework.TestCase;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorCompanyDetails;
import com.valuelabs.nephele.manager.resource.CloudDistributorCompanyResource;

@ContextConfiguration(classes= {CloudDistributorCompanyAssembler.class ,RequestContextListener.class},loader=AnnotationConfigContextLoader.class)
public class CloudDistributorCompanyAssemblerTest    extends AbstractJUnit4SpringContextTests   {

	@Autowired
	CloudDistributorCompanyAssembler assembler;
	CloudDistributorCompanyDetails details = null;
	CloudDistributorCompanyResource resource  =null;
	
	@BeforeClass
	public static void beforeClass() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

	}
	
	@Before
	public void setUp() throws Exception {
		details = mockCloudDistributorCompanyDetails(); 
		resource = mockCloudDistributorCompanyResource();
	}
	
	@Test
	public void testToResource() {
		CloudDistributorCompanyResource resourcetTemp  =  assembler.toResource(details);
		TestCase.assertEquals(details.getDistributorCompanyId(),  resourcetTemp.getDistributorCompanyId());
		TestCase.assertEquals(details.getDistributorCompanyName(), resourcetTemp.getDistributorCompanyName());
		
	}

	@Test
	public void testFromResource() {
		CloudDistributorCompanyDetails detailsTemp =  assembler.fromResource(resource);
		TestCase.assertEquals(resource.getDistributorCompanyId(), detailsTemp.getDistributorCompanyId());
		TestCase.assertEquals(resource.getDistributorCompanyName(),detailsTemp.getDistributorCompanyName());
		
	}

}
*/