/*package com.valuelabs.nephele.test.helpers;

import lombok.Builder;
import lombok.Data;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceComputePriceDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerActionDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServicePricingModelDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceProviderDetails;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudOperatingSystemResource;
import com.valuelabs.nephele.manager.resource.CloudDistributorCompanyResource;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceComputePriceResource;
import com.valuelabs.nephele.manager.resource.CloudRackspaceConfigurationResource;
import com.valuelabs.nephele.manager.resource.CloudServicePricingModelResource;
import com.valuelabs.nephele.manager.resource.CloudServiceProviderResource;
import com.valuelabs.nephele.manager.resource.CloudServiceResource;
import com.valuelabs.nephele.marketplace.resource.CloudServerActionResource;

@Data
@Builder
public class TestFixtures {

	// These are common variables for preparing mock objects
	public static final Long ID = 1L;
	public static final Long DEPENDENT_ID = 1L;
	public static final String NAME = "goodName";
	public static final String DESCRIPTION = "goodDescription";
	public static final Boolean IS_PUBLISHED = true;
	public static final String STATUS = "goodName";
	public static final Integer ANY_INTEGER_VALUE = 2265;
	public static final Long ANY_LONG_VALUE = 2265l;
	public static final String ANY_STRING_VALUE = "goodString";
	public static final String ANY_DOUBLE_VALUE = "0.2";

	public static CloudServiceProviderDetails mockCloudServiceProviderDetails() {
		return CloudServiceProviderDetails.builder().brandName(NAME)
				.description(DESCRIPTION).serviceProviderId(ID).build();
	}

	public static CloudServiceProviderResource mockCloudServiceProviderResource() {
		return CloudServiceProviderResource.builder().brandName(NAME)
				.description(DESCRIPTION).serviceProviderId(ID).build();
	}

	public static CloudServicePricingModelDetails mockCloudServicePricingModelDetails() {
		return CloudServicePricingModelDetails.builder().name(NAME)
				.servicePricingModelId(ID).build();
	}

	public static CloudServicePricingModelResource mockCloudServicePricingModelResource() {
		return CloudServicePricingModelResource.builder().name(NAME)
				.servicePricingModelId(ID).build();
	}

	public static CloudServiceDetails mockCloudServiceDetails() {
		return CloudServiceDetails.builder().serviceId(ID).name(NAME)
				.description(DESCRIPTION).isPublished(IS_PUBLISHED)				
				.serviceProviderId(DEPENDENT_ID).build();
				
	}

	public static CloudServiceResource mockCloudServiceResource() {
		return CloudServiceResource.builder().serviceId(ID).name(NAME)
				.description(DESCRIPTION).isPublished(IS_PUBLISHED)				
				.serviceProviderId(DEPENDENT_ID)
				.build();
	}

	// CloudOperatingSystemDetails
	public static CloudOperatingSystemDetails mockCloudOperatingSystemDetails() {
		return CloudOperatingSystemDetails.builder().operatingSystemId(ID)
				.name(NAME).status(STATUS).serviceId(ID)
				.imageId(ANY_STRING_VALUE).minDisk(ANY_INTEGER_VALUE)
				.minRam(ANY_INTEGER_VALUE).build();
	}

	// CloudOperatingSystemResource
	public static CloudOperatingSystemResource mockCloudOperatingSystemResource() {
		return CloudOperatingSystemResource.builder().operatingSystemId(ID)
				.name(NAME).status(STATUS).serviceId(ID)
				.imageId(ANY_STRING_VALUE).minDisk(ANY_INTEGER_VALUE)
				.minRam(ANY_INTEGER_VALUE).build();
	}

	// CloudLocation
	public static CloudLocationDetails mockCloudLocationDetails() {
		return CloudLocationDetails.builder().cloudLocationId(ID).name(NAME)
				.status(STATUS).cloudServiceId(ID).build();
	}

	public static CloudLocationResource mockCloudLocationResource() {
		return CloudLocationResource.builder().locationId(ID).name(NAME)
				.status(STATUS).serviceId(ID).build();
	}

	// CloudRackspaceComputePrice
	public static CloudRackspaceComputePriceDetails mockCloudRackspaceComputePriceDetails() {
		return CloudRackspaceComputePriceDetails.builder()
				.cloudRackspaceComputePriceId(ID).name(NAME)
				//.floorPrice(ANY_DOUBLE_VALUE)
				.cloudOperatingSystemId(ID)
				.cloudRackspaceConfigurationId(ID)
				//.recommendedRetailPrice(ANY_DOUBLE_VALUE)
				.build();
	}

	public static CloudRackspaceComputePriceResource mockCloudRackspaceComputePriceResource() {
		return CloudRackspaceComputePriceResource.builder()
				.cloudRackspaceComputePriceId(ID).name(NAME)
				//.floorPrice(ANY_DOUBLE_VALUE)
				.cloudOperatingSystemId(ID)
				.cloudRackspaceConfigurationId(ID)
				//.recommendedRetailPrice(ANY_DOUBLE_VALUE)
				.build();
	}

	// CloudRackspaceConfiguration
	public static CloudRackspaceConfigurationDetails mockCloudRackspaceConfigurationDetails() {
		return CloudRackspaceConfigurationDetails.builder()
				.configurationId(ID).name(NAME)
				//.price(ANY_DOUBLE_VALUE)
				.configurationTypeId(ID)
				.flavourId(ANY_STRING_VALUE).size(ANY_INTEGER_VALUE)
				.serviceId(ID).cpu(ANY_LONG_VALUE).ram(ANY_LONG_VALUE)
				.disk(ANY_STRING_VALUE).flavorClass(ANY_STRING_VALUE)
				.status(STATUS).cloudServiceId(ID).build();
	}

	public static CloudRackspaceConfigurationResource mockCloudRackspaceConfigurationResource() {
		return CloudRackspaceConfigurationResource.builder()
				.configurationId(ID).name(NAME)
				.price(ANY_DOUBLE_VALUE).configurationTypeId(ID)
				.flavourId(ANY_STRING_VALUE).size(ANY_INTEGER_VALUE)
				.serviceId(ID).cpu(ANY_LONG_VALUE).ram(ANY_LONG_VALUE)
				.disk(ANY_STRING_VALUE).flavorClass(ANY_STRING_VALUE)
				.status(STATUS).cloudServiceId(ID).build();
	}


	

	public static CloudDistributorCompanyDetails mockCloudDistributorCompanyDetails() {
		return CloudDistributorCompanyDetails.builder().distributorCompanyId(ID).distributorCompanyName(NAME).build();
	}

	public static CloudDistributorCompanyResource mockCloudDistributorCompanyResource() {
		return CloudDistributorCompanyResource.builder().distributorCompanyId(ID).distributorCompanyName(NAME).build();
	}

	
	public static  CloudServerActionDetails  mockCloudServerActionDetails() {
		return CloudServerActionDetails.builder().id(ID). cloudServerId(DEPENDENT_ID).action(ANY_STRING_VALUE).status(STATUS).build();
	}
	
	public static  CloudServerActionResource mockCloudServerActionResource() {
		return CloudServerActionResource.builder().cloudServerId(ID).CloudServerActionId(DEPENDENT_ID).action(ANY_STRING_VALUE).status(STATUS).build();
	}
	
	
}
*/