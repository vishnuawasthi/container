/*package com.valuelabs.nephele.manager.assembler;

import static com.valuelabs.nephele.test.helpers.TestFixtures.ID;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudLocationDetails;
import static com.valuelabs.nephele.test.helpers.TestFixtures.mockCloudLocationResource;
import junit.framework.TestCase;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.manager.resource.CloudLocationResource;



@ContextConfiguration(classes=CloudLocationAssembler.class,loader=AnnotationConfigContextLoader.class)
public class CloudLocationAssemblerTest extends AbstractJUnit4SpringContextTests {

	

	@Autowired
	private CloudLocationAssembler assembler;
	
	@Before
	public void setup() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestAttributes attributes = new ServletRequestAttributes(request);
		RequestContextHolder.setRequestAttributes(attributes);
	}
	
	
	@Test
	public void toResourceTest(){
		
		CloudLocationDetails details=mockCloudLocationDetails();
		CloudLocationResource resource=assembler.toResource(details);
		
		TestCase.assertEquals(details.getName(), resource.getName());
		TestCase.assertEquals(details.getStatus(), resource.getStatus());
		TestCase.assertEquals(details.getCloudServiceId(), resource.getServiceId());
		
		TestCase.assertNotNull(resource.getLink(Link.REL_SELF));
		TestCase.assertEquals("http://localhost/manager/cloudLocation/"+details.getCloudLocationId(), resource.getLink(Link.REL_SELF).getHref());
		
	}
	
	@Test
    public void fromResourceTest(){
		
		CloudLocationResource resource=mockCloudLocationResource();
		
		CloudLocationDetails details=assembler.fromResource(resource);
		TestCase.assertEquals(resource.getName(), details.getName());
		TestCase.assertEquals(resource.getStatus(), details.getStatus());
		TestCase.assertEquals(resource.getServiceId(), details.getCloudServiceId());
	}
	
	@Test
	public void toResourceEmptyTest() {
		CloudLocationDetails details = CloudLocationDetails.builder().cloudLocationId(ID).build();
		CloudLocationResource resource = assembler.toResource(details);
		
		
		TestCase.assertTrue(StringUtils.isBlank(resource.getName()));
		TestCase.assertTrue(StringUtils.isBlank(resource.getStatus()));
		TestCase.assertNull(resource.getServiceId());
	}

	@Test
	public void fromResourceEmptyTest() {
		CloudLocationResource resource = new CloudLocationResource();
		CloudLocationDetails details = assembler.fromResource(resource);

		TestCase.assertTrue(StringUtils.isBlank(details.getName()));
		TestCase.assertTrue(StringUtils.isBlank(details.getStatus()));
		TestCase.assertNull(resource.getServiceId());
	}
	
	
	
}
*/