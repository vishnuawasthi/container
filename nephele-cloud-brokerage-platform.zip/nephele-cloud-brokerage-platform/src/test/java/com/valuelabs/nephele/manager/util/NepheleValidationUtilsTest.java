package com.valuelabs.nephele.manager.util;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class NepheleValidationUtilsTest {
	List list = new ArrayList<>();
	
	@Before
	public void setUp() throws Exception {
		list.add("TEST1");
		list.add("TEST2");
		list.add("TEST3");
		list.add("TEST4");
	}

	@Test
	public void testListWithData() {
		assertNotNull(NepheleValidationUtils.nullSafe(list));
	}
	
	@Test
	public void testListWithOutData() {
		list = null;
		assertNotNull(NepheleValidationUtils.nullSafe(list));
	}

	@After
	public void tearDown() throws Exception {
	}
	
	
}
