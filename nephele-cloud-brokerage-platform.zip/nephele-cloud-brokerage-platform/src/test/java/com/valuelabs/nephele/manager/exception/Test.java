package com.valuelabs.nephele.manager.exception;

public class Test {

}
