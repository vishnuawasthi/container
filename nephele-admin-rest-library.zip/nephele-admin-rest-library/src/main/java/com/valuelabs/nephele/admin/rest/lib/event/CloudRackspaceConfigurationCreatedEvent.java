package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudRackspaceConfigurationCreatedEvent {
	private CloudRackspaceConfigurationDetails cloudRackspaceConfigurationDetails;
	private List<CloudRackspaceConfigurationDetails> cloudRackspaceConfigurationDetailsList;
	
	private boolean invalid;
	private boolean failed;
	public CloudRackspaceConfigurationCreatedEvent() {
		//this.cloudRackspaceConfigurationDetails = cloudRackspaceConfigurationDetails;
	}

	public CloudRackspaceConfigurationCreatedEvent(CloudRackspaceConfigurationDetails cloudRackspaceConfigurationDetails) {
		this.cloudRackspaceConfigurationDetails = cloudRackspaceConfigurationDetails;
	}

	public CloudRackspaceConfigurationCreatedEvent(List<CloudRackspaceConfigurationDetails> cloudRackspaceConfigurationDetailsList) {
		this.cloudRackspaceConfigurationDetailsList = cloudRackspaceConfigurationDetailsList;
	}
	
	public static CloudRackspaceConfigurationCreatedEvent invalid(CloudRackspaceConfigurationDetails cloudRackspaceConfigurationDetails) {
		CloudRackspaceConfigurationCreatedEvent event = new CloudRackspaceConfigurationCreatedEvent(cloudRackspaceConfigurationDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudRackspaceConfigurationCreatedEvent failed(CloudRackspaceConfigurationDetails cloudRackspaceConfigurationDetails) {
		CloudRackspaceConfigurationCreatedEvent event = new CloudRackspaceConfigurationCreatedEvent(cloudRackspaceConfigurationDetails);
		event.setFailed(true);
		return event;
	}
}
