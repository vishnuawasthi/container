package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceUsageDataDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CreateCloudRackspaceUsageDataEvent {
	private CloudRackspaceUsageDataDetails cloudRackspaceUsageDataDetails;
}
