package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLifeCycleConfigDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudLifeCycleConfigCreatedEvent {
	
private CloudLifeCycleConfigDetails cloudLifeCycleConfigDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudLifeCycleConfigCreatedEvent(CloudLifeCycleConfigDetails cloudLifeCycleConfigDetails) {
		this.cloudLifeCycleConfigDetails = cloudLifeCycleConfigDetails;
	}

	public static CloudLifeCycleConfigCreatedEvent invalid(CloudLifeCycleConfigDetails cloudLifeCycleConfigDetails) {
		CloudLifeCycleConfigCreatedEvent event = new CloudLifeCycleConfigCreatedEvent(cloudLifeCycleConfigDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudLifeCycleConfigCreatedEvent failed(CloudLifeCycleConfigDetails cloudLifeCycleConfigDetails) {
		CloudLifeCycleConfigCreatedEvent event = new CloudLifeCycleConfigCreatedEvent(cloudLifeCycleConfigDetails);
		event.setFailed(true);
		return event;
	}

}
