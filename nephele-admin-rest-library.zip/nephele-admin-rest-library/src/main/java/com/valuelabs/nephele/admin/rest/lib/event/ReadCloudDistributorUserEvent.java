package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudDistributorUserEvent  extends ReadEntityEvent<ReadCloudDistributorUserEvent>{
	private Long id;
	private String distributorName;
	private String email;
	private String resetPasswordToken;
}