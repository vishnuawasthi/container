package com.valuelabs.nephele.admin.rest.lib.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudDistributorResource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudBusinessRuleDetails {

	private Long ruleId;
	private String ruleName;
	private String ruleDescription;
	private String ruleValue;
	private CloudDistributorResource resource;
}
