package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountSheetDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class PremiumGroupDiscountSheetCreatedEvent {
	private PremiumGroupDiscountSheetDetails discountSheetDetails;
	private List<PremiumGroupDiscountSheetDetails> discountSheetDetailsList;

	private boolean invalid;
	private boolean failed;

	public PremiumGroupDiscountSheetCreatedEvent(PremiumGroupDiscountSheetDetails discountSheetDetails) {
		this.discountSheetDetails = discountSheetDetails;
	}
	
	public PremiumGroupDiscountSheetCreatedEvent(List<PremiumGroupDiscountSheetDetails> discountSheetDetailsList) {
		this.discountSheetDetailsList = discountSheetDetailsList;
	}

	public static PremiumGroupDiscountSheetCreatedEvent invalid(PremiumGroupDiscountSheetDetails discountSheetDetails) {
		PremiumGroupDiscountSheetCreatedEvent event = new PremiumGroupDiscountSheetCreatedEvent(discountSheetDetails);
		event.setInvalid(true);
		return event;
	}

	public static PremiumGroupDiscountSheetCreatedEvent failed(PremiumGroupDiscountSheetDetails discountSheetDetails) {
		PremiumGroupDiscountSheetCreatedEvent event = new PremiumGroupDiscountSheetCreatedEvent(discountSheetDetails);
		event.setFailed(true);
		return event;
	}

}
