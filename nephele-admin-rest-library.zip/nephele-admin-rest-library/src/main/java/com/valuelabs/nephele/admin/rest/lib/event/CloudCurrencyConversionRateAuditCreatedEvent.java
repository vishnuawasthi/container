package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateAuditDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
public class CloudCurrencyConversionRateAuditCreatedEvent {
  private CloudCurrencyConversionRateAuditDetails cloudCurrencyConversionRateAuditDetails;

  private boolean invalid;
  private boolean failed;

  public CloudCurrencyConversionRateAuditCreatedEvent(CloudCurrencyConversionRateAuditDetails cloudCurrencyConversionRateAuditDetails) {
	this.cloudCurrencyConversionRateAuditDetails = cloudCurrencyConversionRateAuditDetails;
  }

  public static CloudCurrencyConversionRateAuditCreatedEvent invalid(
		  CloudCurrencyConversionRateAuditDetails cloudCurrencyConversionRateAuditDetails) {
	  CloudCurrencyConversionRateAuditCreatedEvent event = new CloudCurrencyConversionRateAuditCreatedEvent(cloudCurrencyConversionRateAuditDetails);
	  event.setInvalid(true);
	  return event;
  }

  public static CloudCurrencyConversionRateAuditCreatedEvent failed(
	  CloudCurrencyConversionRateAuditDetails cloudCurrencyConversionRateAuditDetails) {
	  CloudCurrencyConversionRateAuditCreatedEvent event = new CloudCurrencyConversionRateAuditCreatedEvent(cloudCurrencyConversionRateAuditDetails);
	  event.setFailed(true);
	  return event;
  }
}
