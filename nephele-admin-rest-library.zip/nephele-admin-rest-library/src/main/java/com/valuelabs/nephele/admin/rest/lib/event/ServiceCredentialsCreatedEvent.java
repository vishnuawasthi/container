package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceCredentialDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceCredentialsCreatedEvent {

	private CloudServiceCredentialDetails cloudServiceCredentialDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceCredentialsCreatedEvent(CloudServiceCredentialDetails cloudServiceCredentialDetails) {
		this.cloudServiceCredentialDetails = cloudServiceCredentialDetails;
	}
	
	public static ServiceCredentialsCreatedEvent invalid(CloudServiceCredentialDetails cloudServiceCredentialDetails) {
		ServiceCredentialsCreatedEvent event = new ServiceCredentialsCreatedEvent(cloudServiceCredentialDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceCredentialsCreatedEvent failed(CloudServiceCredentialDetails cloudServiceCredentialDetails) {
		ServiceCredentialsCreatedEvent event = new ServiceCredentialsCreatedEvent(cloudServiceCredentialDetails);
		event.setFailed(true);
		return event;
	}
}
