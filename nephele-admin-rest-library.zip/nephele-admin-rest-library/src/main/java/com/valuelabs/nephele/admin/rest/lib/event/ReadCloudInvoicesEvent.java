package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.springframework.data.domain.Pageable;

import java.util.Date;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudInvoicesEvent extends ReadPageEvent<ReadCloudInvoicesEvent> {

	private Long cloudInvoiceId;
	private Long resellerId;
  private String resellerName;
  private String status;
	private String serviceCode;
	private Long serviceId;
	private Date fromDate;
	private Date toDate;
  private Date fromDueDate;
  private Date toDueDate;
	private Date billingStartDate;
	private Date billingEndDate;
	private Integer numberOfRecords;
	private String sortBy;
	private String invoiceNumber;
	private String resellerCode;
	private Pageable pageable;
	 private Integer year;
}