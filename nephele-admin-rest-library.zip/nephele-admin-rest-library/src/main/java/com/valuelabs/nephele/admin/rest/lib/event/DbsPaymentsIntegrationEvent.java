package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.cloud.dbs.integration.datamodel.DbsInvoicePaymentDetails;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain=true)
public class DbsPaymentsIntegrationEvent {
	
	private List<DbsInvoicePaymentDetails> payments;

	private String messageId;

}
