package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudBusinessRuleDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
public class CloudBusinessRuleCreatedEvent {
	private boolean invalid;
	private boolean failed;
	private CloudBusinessRuleDetails cloudBusinessRuleDetails;

	public CloudBusinessRuleCreatedEvent() {
		this.cloudBusinessRuleDetails = cloudBusinessRuleDetails;
	}

	public CloudBusinessRuleCreatedEvent(CloudBusinessRuleDetails cloudBusinessRuleDetails) {
		this.cloudBusinessRuleDetails = cloudBusinessRuleDetails;
	}

	public static CloudBusinessRuleCreatedEvent invalid(CloudBusinessRuleDetails cloudBusinessRuleDetails) {
		CloudBusinessRuleCreatedEvent event = new CloudBusinessRuleCreatedEvent(cloudBusinessRuleDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudBusinessRuleCreatedEvent failed(CloudBusinessRuleDetails cloudBusinessRuleDetails) {
		CloudBusinessRuleCreatedEvent event = new CloudBusinessRuleCreatedEvent(cloudBusinessRuleDetails);
		event.setFailed(true);
		return event;
	}
}
