package com.valuelabs.nephele.admin.rest.lib.event;

import java.sql.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadServersEvent extends ReadPageEvent<ReadServersEvent>{

	private Long serverId;
	private Long customerId;
	private String status;
	private Long orderId;
	private Date dateRangeStart;
	private Date dateRangeEnd;
	private String name;
	private String resellerCode;
	private String externalCustomerCode;
	private String orderCode;
	private Long providerId;
	private Long categoryId;
	private List<Long> serversId;
	private String externalResellerCode;
	private Long serviceId;
	private String description;
	
}
