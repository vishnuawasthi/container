package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppPermissionDetails;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class CreateCloudManagerAppPermissionEvent {
	private CloudManagerAppPermissionDetails cloudManagerAppPermissionDetails;
	private List<CloudManagerAppPermissionDetails> permissionsDetails;
}
