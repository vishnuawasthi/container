package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.RelatedCloudProductDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class RelatedCloudProductCreatedEvent {
	

   private List<RelatedCloudProductDetails> relatedCloudProductDetailsList;
   private RelatedCloudProductDetails relatedCloudProductDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public RelatedCloudProductCreatedEvent(List<RelatedCloudProductDetails> relatedCloudProductDetails) {
		this.relatedCloudProductDetailsList = relatedCloudProductDetails;
	}
	
	public RelatedCloudProductCreatedEvent(RelatedCloudProductDetails relatedCloudProductDetails) {
		this.relatedCloudProductDetails = relatedCloudProductDetails;
	}
	
	public static RelatedCloudProductCreatedEvent invalid(List<RelatedCloudProductDetails> relatedCloudProductDetails) {
		RelatedCloudProductCreatedEvent event = new RelatedCloudProductCreatedEvent(relatedCloudProductDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static RelatedCloudProductCreatedEvent failed(List<RelatedCloudProductDetails> relatedCloudProductDetails) {
		RelatedCloudProductCreatedEvent event = new RelatedCloudProductCreatedEvent(relatedCloudProductDetails);
		event.setFailed(true);
		return event;
	}

}
