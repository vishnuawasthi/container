/**
 * 
 */
package com.valuelabs.nephele.admin.rest.lib.exception;

/**
 * @author Vishnu Awasthi
 *
 */
public class EmptyFileException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 109629631463135803L;
	
	private String message;
	public EmptyFileException( String message) {
		this.message= message;
	}
	public String getMessage() {
		return message;
	}
	

}
