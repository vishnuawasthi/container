package com.valuelabs.nephele.admin.rest.lib.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
@ToString
@JsonInclude(Include.NON_DEFAULT)
public class SolrBundleResource extends ResourceSupport {
  private Long BundleID;
  private String BundleName;
  private List<Long> HardwareProducts;
  private List<SolrCloudProduct> CloudProducts;
}
