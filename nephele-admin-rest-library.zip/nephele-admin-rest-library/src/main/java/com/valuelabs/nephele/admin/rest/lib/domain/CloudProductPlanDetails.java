package com.valuelabs.nephele.admin.rest.lib.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudProductPlanDetails {
	
	private Long productPlanId;
	private Double price;
	private Double vendorPrice;
	private String planName;
	private String details;
	private String status;
	private Long operatingSystemId;
	private String operatingSystemName;
	private Long flavorId;
	private String configurationName;
	private String flavorCategory;
	private Long productId;
	private String productName;
	private String productDescription;
	private String productType;
	private Long locationId;
	private String locationName;
	private Long serviceId;
	private String serviceName;
	private Long configurationId;
	private String planCode;
	private String vendorCurrency;
	private String vendorPlanCode;
	private Boolean isTrialPlan;
	private String pricingModel;
	private String description;
	private Long sortKey;
	
	
	
}
