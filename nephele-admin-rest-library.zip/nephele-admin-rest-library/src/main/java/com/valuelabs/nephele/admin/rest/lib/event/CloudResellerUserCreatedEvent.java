package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerUserDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CloudResellerUserCreatedEvent {

private CloudResellerUserDetails resellerUserDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudResellerUserCreatedEvent(CloudResellerUserDetails resellerUserDetails) {
		this.resellerUserDetails = resellerUserDetails;
	}
	
	public static CloudResellerUserCreatedEvent invalid(CloudResellerUserDetails resellerUserDetails) {
		CloudResellerUserCreatedEvent event = new CloudResellerUserCreatedEvent(resellerUserDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudResellerUserCreatedEvent failed(CloudResellerUserDetails resellerUserDetails) {
		CloudResellerUserCreatedEvent event = new CloudResellerUserCreatedEvent(resellerUserDetails);
		event.setFailed(true);
		return event;
	}
}
