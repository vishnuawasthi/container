package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.*;
import lombok.experimental.Accessors;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
@Accessors(chain = true)
public class AlertsNotificationEvent {

  private List<String> toList;

  private List<String> ccList;

  private List<String> bccList;

  private String subject;

  private String body;

  private String filePath;

  //private SimpleMailMessage mailMessage;
}
