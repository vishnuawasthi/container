package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.List;

import javax.transaction.Transactional;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.data.entity.CloudOperatingSystem;
import com.valuelabs.nephele.admin.data.entity.CloudProduct;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.repository.CloudOperatingSystemRepository;
import com.valuelabs.nephele.admin.data.repository.CloudProductRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.elasticsearchresource.ElasticSearchProductsResource;
import com.valuelabs.nephele.admin.rest.lib.event.CloudProductCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudProductEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.support.NepheleRestTemplate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class CloudProductCommandServiceImpl implements CloudProductCommandService  {


	/*@Autowired
	private CloudRackspaceComputePriceDAO CloudRackspaceComputePriceDAO;*/
	
	/*@Autowired
	CloudOperatingSystemDAO cloudOperatingSystemDAO;*/
	
	/*@Autowired
	CloudRackspaceComputePriceDAO cloudRackspaceComputePriceDAO;*/
	
	/*@Autowired
	CloudProductDAO cloudProductDAO;
	
	@Autowired
	CloudServiceDAO cloudServiceDAO;*/
	
	@Autowired
	private CloudOperatingSystemRepository operatingSystemRepository;
	
	@Autowired
	private CloudProductRepository productRepository;
	
	@Autowired
	private CloudServiceRepository serviceRepository;
	
	@Autowired
	private NepheleRestTemplate restClient;
	
	@Value("${elasticsearch.uri}")
	private String url;
	
	@Value("${elasticsearch.products}")
	private String productsPath;

	
	

	@Override
	public void loadProducts(String serviceName) {
		log.debug("loadProducts()  START");
		// will read records from cloud OS table whose status = 'PUBLISHED' and along with given serviceName
		CloudService cloudService = serviceRepository.findByName(serviceName);
		
		List<CloudOperatingSystem> cloudOSList = operatingSystemRepository.getByServiceAndStatus(cloudService.getId(), InventoryStatus.PUBLISHED.name());
		
		//Iterate through those records and get price and insert into Cloud_product table
		log.debug("cloudOSList...size..." + cloudOSList.size());
		for(CloudOperatingSystem cloudOperatingSystem : cloudOSList) {
			//List<CloudRackspaceComputePrice> computePrice = cloudRackspaceComputePriceDAO.getComputePriceByOSId(cloudOperatingSystem.getId());
			CloudProduct cloudProduct = CloudProduct.builder().name(cloudOperatingSystem.getName()).
															   description(cloudOperatingSystem.getName()).
															   type(cloudOperatingSystem.getName()).
															   //startingPrice(computePrice.get(0).getFloorPrice()).
															   cloudOperatingSystem(cloudOperatingSystem).
															   cloudService(cloudOperatingSystem.getCloudService()).
															   build();
			productRepository.save(cloudProduct);
			insertProductsDataintoElasticsearch(cloudProduct);
			
		}
		log.debug("loadProducts()  END");
		
	}

	@Override
	public CloudProductCreatedEvent updateCloudProduct(CreateCloudProductEvent request) throws ResourceNotFoundException,IllegalArgumentException{
		
		log.debug("updateCloudProduct -- START");
		CloudProductDetails details=request.getCloudProductDetails();
		CloudProduct entity = productRepository.findOne(details.getCloudProductId());

		if(entity == null){
			throw new ResourceNotFoundException("Resource not found");
		}
		
		if(!StringUtils.isEmpty(details.getName()))
			entity.setName(details.getName());
		if(!StringUtils.isEmpty(details.getDescription()))
			entity.setDescription(details.getDescription());
		if(!StringUtils.isEmpty(details.getType()))
			entity.setType(details.getType());
		//entity.setStartingPrice(details.getStartingPrice());
		if(!StringUtils.isEmpty(details.getStatus()))
			entity.setStatus(details.getStatus());
		//entity.setCloudOperatingSystem(cloudOperatingSystemDAO.findOne(details.getOperatingSystemId()));
		//entity.setCloudService(cloudServiceDAO.findOne(details.getCloudServiceId()));
		if(!StringUtils.isEmpty(details.getIsFeatured()))
			entity.setIsFeatured(details.getIsFeatured());
		if(!StringUtils.isEmpty(details.getHasFreeTrial()))
			entity.setHasFreeTrial(details.getHasFreeTrial());
		if(!StringUtils.isEmpty(details.getHasRelatedProducts()))
			entity.setHasRelatedProducts(details.getHasRelatedProducts());
		
		productRepository.save(entity);
		insertProductsDataintoElasticsearch(entity);
		log.debug("updateCloudProduct -- END");
		return new CloudProductCreatedEvent(details);
	}
	
	public void insertProductsDataintoElasticsearch(CloudProduct record) {		
		
		ObjectMapper mapper = new ObjectMapper();
		String requestBodyString =null;
		try {			
			log.debug("insertProductsDataintoElasticsearch- STARTED");		
			ElasticSearchProductsResource resource = null;
			String produtsUrl = String.format("%s%s", url,productsPath);						
			resource = ElasticSearchProductsResource.builder()
						 .id(record.getId())
						 .name(record.getName())
						 .description(record.getDescription())						
						 .type(record.getType())
						 .operatingSystemId(record.getCloudOperatingSystem().getId())						
						 .cloudServiceId(record.getCloudService().getId())					 
						 .status(record.getStatus())
						 .isFeatured(record.getIsFeatured())
						 .hasFreeTrial(record.getHasFreeTrial())
						 .hasRelatedProducts(record.getHasRelatedProducts())
						 .build();															  
				requestBodyString = mapper.writeValueAsString(resource);
				restClient.post(produtsUrl, requestBodyString);						
			
			
			log.debug("insertProductsDataintoElasticsearch- END");	
		
		} catch (Exception e) {			
			//e.printStackTrace();
			log.error("error while insertProductsDataintoElasticsearch() due to  : "+e.getMessage());
		}
		
	}

}
