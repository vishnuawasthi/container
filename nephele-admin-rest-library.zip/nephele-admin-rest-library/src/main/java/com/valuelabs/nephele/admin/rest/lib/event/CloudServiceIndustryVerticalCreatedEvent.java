package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceIndustryVerticalDetail;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CloudServiceIndustryVerticalCreatedEvent {
	
	private CloudServiceIndustryVerticalDetail details;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudServiceIndustryVerticalCreatedEvent(CloudServiceIndustryVerticalDetail details) {
		this.details = details;
	}
	
	public static CloudServiceIndustryVerticalCreatedEvent invalid(CloudServiceIndustryVerticalDetail details) {
		CloudServiceIndustryVerticalCreatedEvent event = new CloudServiceIndustryVerticalCreatedEvent(details);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudServiceIndustryVerticalCreatedEvent failed(CloudServiceIndustryVerticalDetail details) {
		CloudServiceIndustryVerticalCreatedEvent event = new CloudServiceIndustryVerticalCreatedEvent(details);
		event.setFailed(true);
		return event;
	}

}
