package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceProviderDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceProviderCreatedEvent {
	
	private CloudServiceProviderDetails cloudServiceProviderDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceProviderCreatedEvent(CloudServiceProviderDetails cloudServiceProviderDetails) {
		this.cloudServiceProviderDetails = cloudServiceProviderDetails;
	}
	
	public static ServiceProviderCreatedEvent invalid(CloudServiceProviderDetails cloudServiceProviderDetails) {
		ServiceProviderCreatedEvent event = new ServiceProviderCreatedEvent(cloudServiceProviderDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceProviderCreatedEvent failed(CloudServiceProviderDetails cloudServiceProviderDetails) {
		ServiceProviderCreatedEvent event = new ServiceProviderCreatedEvent(cloudServiceProviderDetails);
		event.setFailed(true);
		return event;
	}
	

}
