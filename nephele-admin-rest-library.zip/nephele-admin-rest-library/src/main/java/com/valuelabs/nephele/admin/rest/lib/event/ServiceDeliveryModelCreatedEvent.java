package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDeliveryModelDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceDeliveryModelCreatedEvent {
	
	private CloudServiceDeliveryModelDetails cloudServiceDeliveryModelDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceDeliveryModelCreatedEvent(CloudServiceDeliveryModelDetails cloudServiceDeliveryModelDetails) {
		this.cloudServiceDeliveryModelDetails = cloudServiceDeliveryModelDetails;
	}
	
	public static ServiceDeliveryModelCreatedEvent invalid(CloudServiceDeliveryModelDetails cloudServiceDeliveryModelDetails) {
		ServiceDeliveryModelCreatedEvent event = new ServiceDeliveryModelCreatedEvent(cloudServiceDeliveryModelDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceDeliveryModelCreatedEvent failed(CloudServiceDeliveryModelDetails cloudServiceDeliveryModelDetails) {
		ServiceDeliveryModelCreatedEvent event = new ServiceDeliveryModelCreatedEvent(cloudServiceDeliveryModelDetails);
		event.setFailed(true);
		return event;
	}
	

}
