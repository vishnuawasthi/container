package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.event.CloudProductCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudProductEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;


public interface CloudProductCommandService {

	void loadProducts(String serviceName);
	CloudProductCreatedEvent updateCloudProduct(CreateCloudProductEvent request) throws ResourceNotFoundException,IllegalArgumentException;
	
}
