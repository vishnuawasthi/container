package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.SMTPConfigurationDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class SMTPConfigurationCreatedEvent {
	private SMTPConfigurationDetails smtpConfigurationDetails;

	private boolean invalid;
	private boolean failed;

	public SMTPConfigurationCreatedEvent(SMTPConfigurationDetails smtpConfigurationDetails) {
		this.smtpConfigurationDetails = smtpConfigurationDetails;
	}

	public static SMTPConfigurationCreatedEvent invalid(SMTPConfigurationDetails smtpConfigurationDetails) {
		SMTPConfigurationCreatedEvent event = new SMTPConfigurationCreatedEvent(smtpConfigurationDetails);
		event.setInvalid(true);
		return event;
	}

	public static SMTPConfigurationCreatedEvent failed(SMTPConfigurationDetails smtpConfigurationDetails) {
		SMTPConfigurationCreatedEvent event = new SMTPConfigurationCreatedEvent(smtpConfigurationDetails);
		event.setFailed(true);
		return event;
	}
}
