package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain=true)
public class CloudProductPriceMgmtConfigDetails {

	private Long  productPriceMgmtConfigId;
	private Long serviceId;
	private String priceSheetName;
	private Date activeFrom;
	private Date activeTo;
	private String status;
	private String comments;
	private Date customDate;
}
