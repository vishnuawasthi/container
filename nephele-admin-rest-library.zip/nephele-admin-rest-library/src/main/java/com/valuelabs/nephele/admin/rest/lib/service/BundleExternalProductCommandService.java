package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.event.BundleExternalProductCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateBundleExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface BundleExternalProductCommandService {
	
  BundleExternalProductCreatedEvent createBundleExternalProduct(CreateBundleExternalProductEvent request) throws IllegalArgumentException;
  void deleteBundleExternalProduct(Long id) throws ResourceNotFoundException, IllegalArgumentException;
}
