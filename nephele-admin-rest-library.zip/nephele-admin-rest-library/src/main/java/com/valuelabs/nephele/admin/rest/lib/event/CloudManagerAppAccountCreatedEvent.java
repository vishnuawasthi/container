package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppAccountDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
//@Data
@Setter
@Getter
@Accessors(chain=true)
public class CloudManagerAppAccountCreatedEvent {
	private CloudManagerAppAccountDetails cloudManagerAppAccountDetails;

	private boolean invalid;
	private boolean failed;

	public CloudManagerAppAccountCreatedEvent(CloudManagerAppAccountDetails cloudManagerAppAccountDetails) {
		this.cloudManagerAppAccountDetails = cloudManagerAppAccountDetails;
	}

	public static CloudManagerAppAccountCreatedEvent invalid(CloudManagerAppAccountDetails cloudManagerAppAccountDetails) {
		CloudManagerAppAccountCreatedEvent event = new CloudManagerAppAccountCreatedEvent(cloudManagerAppAccountDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudManagerAppAccountCreatedEvent failed(CloudManagerAppAccountDetails cloudManagerAppAccountDetails) {
		CloudManagerAppAccountCreatedEvent event = new CloudManagerAppAccountCreatedEvent(cloudManagerAppAccountDetails);
		event.setFailed(true);
		return event;
	}
}
