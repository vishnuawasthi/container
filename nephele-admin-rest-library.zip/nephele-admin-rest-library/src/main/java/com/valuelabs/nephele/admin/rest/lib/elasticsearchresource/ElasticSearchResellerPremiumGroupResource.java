package com.valuelabs.nephele.admin.rest.lib.elasticsearchresource;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@Accessors(chain = true)
@JsonInclude(value=Include.NON_DEFAULT)
//@EqualsAndHashCode(callSuper = false)
public class ElasticSearchResellerPremiumGroupResource {

	@Id   
	private Long id;
	private String name;
	private String description;	
	private String status;
	
}
