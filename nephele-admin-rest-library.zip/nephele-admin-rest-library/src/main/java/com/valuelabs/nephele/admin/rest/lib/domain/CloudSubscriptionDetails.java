package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudSubscriptionDetails {

	private Long subscriptionId;
	private Long customerId;
	private String customerName;
	private Long resellerId;
	private String resellerName;
	private Long orderId;
	private Long productId;
	private Long orderLineId;
	private String vendorSubscriptionId;
	private String subscriptionStatus;
	private Date subscriptionDate;
	private String description;
	private boolean isNewSubArrearInvoiced;
	private Date lastInvoicedDate;
	private Integer licenseCount;
	private Long cloudProductPlanId;
	private String planName;
	private Long accountId;
	private CloudServiceDetails cloudServiceDetails;
	private CloudProductPlanDetails cloudProductPlanDetails;
	private Long serviceId;
	private Date subscriptionLastRenewalDate;
	private Date autoRenewalOffDate;
	private boolean licenseAutoRenewal;
	private String canellation;
}
