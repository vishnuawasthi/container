package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.*;
import lombok.experimental.Accessors;

/**
 * Created by snagaboina on 30/11/15.
 */
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class CloudInvoiceDiscountLineDetail {

  private Long cloudInvoiceDiscountLineId;
  private String brand;
  private String description;
  private String discountPercent;
  private String quantity;
  private String amount;
  private String discountType;
}