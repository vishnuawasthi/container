package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudOperatingSystemDetails {

	private Long operatingSystemId;
	private String cspResource;
	private String imageId;
	private Long minDisk;
	private Long minRam;
	private String name;
	private String status;
	private Long serviceId;
	private List<Long> failedFlavorList;
	private String failureMessage;
}
