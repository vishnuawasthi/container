package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerPremiumGroupCreatedEvent {

	private CloudResellerPremiumGroupDetails CloudResellerPremiumGroupDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudResellerPremiumGroupCreatedEvent(CloudResellerPremiumGroupDetails CloudResellerPremiumGroupDetails) {
		this.CloudResellerPremiumGroupDetails = CloudResellerPremiumGroupDetails;
	}
	
	public static CloudResellerPremiumGroupCreatedEvent invalid(CloudResellerPremiumGroupDetails CloudResellerPremiumGroupDetails) {
		CloudResellerPremiumGroupCreatedEvent event = new CloudResellerPremiumGroupCreatedEvent(CloudResellerPremiumGroupDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudResellerPremiumGroupCreatedEvent failed(CloudResellerPremiumGroupDetails CloudResellerPremiumGroupDetails) {
		CloudResellerPremiumGroupCreatedEvent event = new CloudResellerPremiumGroupCreatedEvent(CloudResellerPremiumGroupDetails);
		event.setFailed(true);
		return event;
	}
}
