package com.valuelabs.nephele.admin.rest.lib.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.hateoas.ResourceSupport;

/**
 * Created by snagaboina on 8/9/15.
 */
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudInvoiceDiscountLineResource extends ResourceSupport {

  private Long cloudInvoiceDiscountLineId;
  private String brand;
  private String description;
  private String discountPercent;
  private String quantity;
  private String amount;
  private String discountType;
}
