package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain=true)
public class AzureServerEndpointDetails {
	private Integer id;
	private Integer cloudServerId;
	private String publicPort;
	private String privatePort;
	private String enabled;
}
