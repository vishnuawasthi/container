package com.valuelabs.nephele.admin.rest.lib.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode(callSuper=false)
@Builder
@Accessors(chain=true)
@JsonInclude(Include.NON_DEFAULT)
public class ProductPlanDetailsResource {
	
	private Long operatingSystemId;
	
	private Long flavorId;

}
