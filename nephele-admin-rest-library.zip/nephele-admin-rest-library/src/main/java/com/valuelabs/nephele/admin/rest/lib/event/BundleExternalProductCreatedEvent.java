package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Data;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleExternalProductDetails;

@Data
@Accessors(chain = true)
public class BundleExternalProductCreatedEvent {
	
private BundleExternalProductDetails bundleExternalProductDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public BundleExternalProductCreatedEvent(BundleExternalProductDetails bundleExternalProductDetails) {
		this.bundleExternalProductDetails = bundleExternalProductDetails;
	}

	public static BundleExternalProductCreatedEvent invalid(BundleExternalProductDetails bundleExternalProductDetails) {
		BundleExternalProductCreatedEvent event = new BundleExternalProductCreatedEvent(bundleExternalProductDetails);
		event.setInvalid(true);
		return event;
	}

	public static BundleExternalProductCreatedEvent failed(BundleExternalProductDetails bundleExternalProductDetails) {
		BundleExternalProductCreatedEvent event = new BundleExternalProductCreatedEvent(bundleExternalProductDetails);
		event.setFailed(true);
		return event;
	}

}
