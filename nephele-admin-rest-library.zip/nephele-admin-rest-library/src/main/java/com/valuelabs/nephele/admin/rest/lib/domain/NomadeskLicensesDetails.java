package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class NomadeskLicensesDetails {

    private String accountName;
    private String token;
    private String email;
    private String planType;
	private Long customerId;
	private Long resellerId;
	private Long orderId;
	private Long productId;
	private Long orderLineId;	
	private String subscriptionStatus;	
	private String description;
	private boolean isNewSubArrearInvoiced;	
	private Integer licenseCount;
	private Long cloudProductPlanId;
	private Long accountId;
}
