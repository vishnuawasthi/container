package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerCompanyDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudResellerCompanyEvent {

	private  CloudResellerCompanyDetails resellerCompanyDetails;
	private List<CloudResellerCompanyDetails> resellerCompanyDetailsList;

}
