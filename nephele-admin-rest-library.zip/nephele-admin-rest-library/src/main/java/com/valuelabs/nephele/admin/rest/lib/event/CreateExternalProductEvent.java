package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.ArrayList;
import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;

@Data
@Accessors(chain=true)
public class CreateExternalProductEvent {
	
	private ExternalProductDetails externalProductDetails;
	private List<ExternalProductDetails> externalProducts ;
	private Boolean toSaveFlag;

}
