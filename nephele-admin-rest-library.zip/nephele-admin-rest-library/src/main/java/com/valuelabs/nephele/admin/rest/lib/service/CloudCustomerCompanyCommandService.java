package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.event.CloudCustomerCompanyCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.DeleteCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.UpdateCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface CloudCustomerCompanyCommandService {

	CloudCustomerCompanyCreatedEvent createCloudCustomerCompany(CreateCloudCustomerCompanyEvent request)throws IllegalArgumentException;
	CloudCustomerCompanyCreatedEvent updateCloudCustomerCompany(CreateCloudCustomerCompanyEvent request) throws ResourceNotFoundException,IllegalArgumentException, Exception;
	CloudCustomerCompanyCreatedEvent createCloudCustomerCompanies(CreateCloudCustomerCompanyEvent request)throws IllegalArgumentException;
	void deleteCustomerCompany(DeleteCustomerCompanyEvent request) throws Exception;
	CloudCustomerCompanyCreatedEvent updateCloudCustomerCompanies(UpdateCloudCustomerCompanyEvent request) throws IllegalArgumentException, Exception;
}
