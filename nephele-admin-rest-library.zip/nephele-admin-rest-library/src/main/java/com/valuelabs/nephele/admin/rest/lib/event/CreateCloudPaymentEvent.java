package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudPaymentDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudPaymentEvent extends ReadPageEvent<CreateCloudPaymentEvent> {
	
	private CloudPaymentDetails cloudPaymentDetails;

}
