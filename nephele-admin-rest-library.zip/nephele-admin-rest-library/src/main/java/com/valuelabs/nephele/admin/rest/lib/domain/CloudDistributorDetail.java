package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.*;
import lombok.experimental.Accessors;

/**
 * Created by snagaboina on 30/11/15.
 */
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class CloudDistributorDetail {

  private String companyName;
  private String addressLine1;
  private String addressLine2;
  private String city;
  private String state;
  private String country;
  private String zipCode;
  private String phone;
  private String fax;
  private String ABN;
  private String ACN;

}
