package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Accessors(chain = true)
public class CloudCurrencyConversionRateDetails {
  private Long id;
  private String status;
  private Double conversionRate;
  private Date activeFrom;
  private Date activeTo;
  private String sourceCurrency;
  private String targetCurrency;
  
}
