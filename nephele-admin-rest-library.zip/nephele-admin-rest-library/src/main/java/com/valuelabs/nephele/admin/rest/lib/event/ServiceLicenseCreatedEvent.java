package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLicenseDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceLicenseCreatedEvent {
	
	private CloudLicenseDetails cloudLicenseDetails;
	
	private List<CloudLicenseDetails> cloudLicenseDetailsList;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceLicenseCreatedEvent(CloudLicenseDetails cloudLicenseDetails) {
		this.cloudLicenseDetails = cloudLicenseDetails;
	}
	
	public ServiceLicenseCreatedEvent(List<CloudLicenseDetails> cloudLicenseDetailsList) {
		this.cloudLicenseDetailsList = cloudLicenseDetailsList;
	}
	
	public static ServiceLicenseCreatedEvent invalid(CloudLicenseDetails cloudLicenseDetails) {
		ServiceLicenseCreatedEvent event = new ServiceLicenseCreatedEvent(cloudLicenseDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceLicenseCreatedEvent failed(CloudLicenseDetails cloudLicenseDetails) {
		ServiceLicenseCreatedEvent event = new ServiceLicenseCreatedEvent(cloudLicenseDetails);
		event.setFailed(true);
		return event;
	}
	

}
