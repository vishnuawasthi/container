package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadRackspaceConfigurationEvent extends ReadEntityEvent<ReadRackspaceConfigurationEvent> {

	private Long rackspaceConfigurationId;
	private Long operatingSystemId;
	/*private String cspResource;
	private String flavourId;
	private String name;
	private Integer size;
	private Integer configurationTypeId;
	private Integer serviceId;
	private Integer cpu;
	private Integer ram;
	private Integer disk;
	private String flavorClass;
	private double price;
	private Properties properties;
	private String status;
	private Integer cloudServiceId;*/
}
