package com.valuelabs.nephele.admin.rest.lib.resource;



import java.io.Serializable;
import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
//@Setter
//@Getter
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class RelatedExternalProductResource extends ResourceSupport implements Serializable{

	private static final long serialVersionUID = 1L;
	// productId means relatedCloudproduct entity id
	private Long relatedExtProductId;
	private String externalId;
	private Long cloudproductId;
	private String cloudProductName;
	private String cloudproductDes;
	private List<Long> externalProducts;
	private Long externalProductId;
	private String externalProductName;
	private String externalProductDes;
	private String status;
	private Long serviceId;
	private String serviceName;
	private CloudProductDetails cloudProductDetails;
	
	
	
}
