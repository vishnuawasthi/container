package com.valuelabs.nephele.admin.rest.lib.exception;

public class NepheleException  extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1017900651879944904L;

	
	public NepheleException(String message){
		
		super(message);
	}
}
