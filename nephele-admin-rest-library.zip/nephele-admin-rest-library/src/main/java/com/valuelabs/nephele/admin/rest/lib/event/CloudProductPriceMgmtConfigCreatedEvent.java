package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceMgmtConfigDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudProductPriceMgmtConfigCreatedEvent {
	

private CloudProductPriceMgmtConfigDetails productPriceMgmtConfigDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudProductPriceMgmtConfigCreatedEvent(CloudProductPriceMgmtConfigDetails productPriceMgmtConfigDetails) {
		this.productPriceMgmtConfigDetails = productPriceMgmtConfigDetails;
	}
	
	public static CloudProductPriceMgmtConfigCreatedEvent invalid(CloudProductPriceMgmtConfigDetails productPriceMgmtConfigDetails) {
		CloudProductPriceMgmtConfigCreatedEvent event = new CloudProductPriceMgmtConfigCreatedEvent(productPriceMgmtConfigDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudProductPriceMgmtConfigCreatedEvent failed(CloudProductPriceMgmtConfigDetails productPriceMgmtConfigDetails) {
		CloudProductPriceMgmtConfigCreatedEvent event = new CloudProductPriceMgmtConfigCreatedEvent(productPriceMgmtConfigDetails);
		event.setFailed(true);
		return event;
	}

}
