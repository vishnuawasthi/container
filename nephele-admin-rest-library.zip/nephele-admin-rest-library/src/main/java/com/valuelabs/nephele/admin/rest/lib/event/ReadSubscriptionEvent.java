package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadSubscriptionEvent extends ReadEntityEvent<ReadSubscriptionEvent> {

	private Long subscriptionId;
	private String customerId;
	private String resellerId;
	private Long orderId;
	private Long productId;
	private Long accountId;
	private String licenseId;
	private Long serviceId;
}
