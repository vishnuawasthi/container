package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.data.entity.CloudService;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudResellerPremiumGroupEvent extends ReadEntityEvent<ReadCloudResellerPremiumGroupEvent>{

	private Long id;
	private String name;
	private String description;
	private String status;
	private CloudService serviceId;
}
