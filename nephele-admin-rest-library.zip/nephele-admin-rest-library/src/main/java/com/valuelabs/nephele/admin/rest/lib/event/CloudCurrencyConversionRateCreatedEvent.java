package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;

@Setter
@Getter
@Accessors(chain = true)
public class CloudCurrencyConversionRateCreatedEvent {
  private CloudCurrencyConversionRateDetails cloudCurrencyConversionRateDetails;

  private boolean invalid;
  private boolean failed;

  public CloudCurrencyConversionRateCreatedEvent(CloudCurrencyConversionRateDetails cloudCurrencyConversionRateDetails) {
	this.cloudCurrencyConversionRateDetails = cloudCurrencyConversionRateDetails;
  }

  public static CloudCurrencyConversionRateCreatedEvent invalid(
	  CloudCurrencyConversionRateDetails cloudCurrencyConversionRateDetails) {
	  CloudCurrencyConversionRateCreatedEvent event = new CloudCurrencyConversionRateCreatedEvent(cloudCurrencyConversionRateDetails);
	  event.setInvalid(true);
	  return event;
  }

  public static CloudCurrencyConversionRateCreatedEvent failed(
	  CloudCurrencyConversionRateDetails cloudCurrencyConversionRateDetails) {
	  CloudCurrencyConversionRateCreatedEvent event = new CloudCurrencyConversionRateCreatedEvent(cloudCurrencyConversionRateDetails);
	  event.setFailed(true);
	  return event;
  }
}
