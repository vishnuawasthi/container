package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.Collections;
import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@EqualsAndHashCode
public class EntitiesReadEvent<T> {
	private final List<T> entities;

	public EntitiesReadEvent(List<T> entities) {
		this.entities = Collections.unmodifiableList(entities);
	}
	
	private EntitiesReadEvent() {
		this(null);
	}

	public static <T> EntitiesReadEvent<T> notFound() {
		return new EntitiesReadEvent<T>();
	}
}