package com.valuelabs.nephele.admin.rest.lib.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class NepheleSyndCategoryResources {

	private String name;
	private String taxonomyUri;
	/*public NepheleSyndCategoryResources() {
		super();
	}
	public NepheleSyndCategoryResources(String name, String taxonomyUri) {
		super();
		this.name = name;
		this.taxonomyUri = taxonomyUri;
	}*/
}
