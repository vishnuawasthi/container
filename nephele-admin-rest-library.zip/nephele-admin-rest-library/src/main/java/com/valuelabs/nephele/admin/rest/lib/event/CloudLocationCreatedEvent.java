package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudLocationCreatedEvent {

	private CloudLocationDetails cloudLocationDetails;
	private List<CloudLocationDetails> cloudLocationDetailsList;

	private boolean invalid;
	private boolean failed;

	public CloudLocationCreatedEvent(CloudLocationDetails cloudLocationDetails) {
		this.cloudLocationDetails = cloudLocationDetails;
	}

	public CloudLocationCreatedEvent(List<CloudLocationDetails> cloudLocationDetailsList) {
		this.cloudLocationDetailsList = cloudLocationDetailsList;
	}
	public static CloudLocationCreatedEvent invalid(CloudLocationDetails cloudLocationDetails) {
		CloudLocationCreatedEvent event = new CloudLocationCreatedEvent(cloudLocationDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudLocationCreatedEvent failed(CloudLocationDetails cloudLocationDetails) {
		CloudLocationCreatedEvent event = new CloudLocationCreatedEvent(cloudLocationDetails);
		event.setFailed(true);
		return event;
	}
}