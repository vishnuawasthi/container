package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.api.SubscriptionStatus;
import com.valuelabs.nephele.admin.data.entity.CloudLicense;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudSubscription;
import com.valuelabs.nephele.admin.data.repository.CloudLicenseRepository;
import com.valuelabs.nephele.admin.data.repository.CloudProductPlanRepository;
import com.valuelabs.nephele.admin.data.repository.CloudSubscriptionRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudLicenseDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CreateLicenseEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ServiceLicenseCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CloudLicenseCommandServiceImpl implements
CloudLicenseCommandService {

	@Autowired
	private CloudSubscriptionRepository cloudSubscriptionRepository;
	
	@Autowired
	private CloudLicenseRepository cloudLicenseRepository;
	
	@Autowired
	CloudProductPlanRepository cloudProductPlanRepository;


	@Override
	public ServiceLicenseCreatedEvent createLicense(CreateLicenseEvent request) throws IllegalArgumentException {
		log.debug("createLicense() START");
		List<CloudLicenseDetails> cloudLicenseDetailsList = request.getCloudLicenseDetailsList();
		List<CloudLicense> licensesList = new ArrayList();
		
		for(CloudLicenseDetails details : cloudLicenseDetailsList )
		{
			CloudSubscription cloudSubscription = cloudSubscriptionRepository.findOne(details.getSubscriptionId());				
			if(cloudSubscription==null){
				 throw new ResourceNotFoundException("CloudSubscription", details.getSubscriptionId());
			}			
			CloudLicense license = CloudLicense.builder()
												.subscription(cloudSubscription)												
												.licenseId(details.getLicenseVendorId())
												.status(SubscriptionStatus.valueOf(details.getStatus()))											
												.licenseProvisionDate(details.getLicenseProvisionDate())										
												.build();
			licensesList.add(license);		
		}
	
		cloudLicenseRepository.save(licensesList);
		log.debug("createLicense() END");
		return new ServiceLicenseCreatedEvent(cloudLicenseDetailsList);
	}

	@Override
	public ServiceLicenseCreatedEvent updateeLicense(CreateLicenseEvent request)
			throws IllegalArgumentException, ResourceNotFoundException {
		log.debug("updateeLicense() START");
		CloudLicense cloudLicense = cloudLicenseRepository
				.findOne(request.getCloudLicenseDetails().getLicenseId());
		if (cloudLicense == null) {
			throw new ResourceNotFoundException("Resource not found for given id");
		}
		CloudLicenseDetails cloudLicenseDetails = request.getCloudLicenseDetails();
		
		cloudLicenseRepository.save(cloudLicense);
		log.debug("updateeLicense() END");
		return new ServiceLicenseCreatedEvent(cloudLicenseDetails);
	}

}
