package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
//@Accessors(chain = false)
public class CloudPaymentDetails {
	
	private Long paymentId;
	private Double total;
	private Double invoiceAmount;
	private Double surcharge;
	private Double surchargeGst;
	private Long invoiceId;
	private Date created;
	private Date updated;
	private String paymentMode;
	private String transactionId;
	private String serviceName;
	private String instrumentType;

}
