package com.valuelabs.nephele.admin.rest.lib.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class CloudFeedEventResources {
	private String dataCenter;
	private String endTime;
	private String environment;
	private String id;
	private String region;
	private String resourceId;
	private String resourceName;
	private String startTime;
	private String tenantId;
	private String type;
	private String version;
	private CloudFeedProductResources product;
	/*
	 * public EventResources() { super(); } public EventResources(String
	 * dataCenter, String endTime, String environment, String id, String region,
	 * String resourceId, String resourceName, String startTime, String
	 * tenantId, String type, String version, ProductResources product) {
	 * super(); this.dataCenter = dataCenter; this.endTime = endTime;
	 * this.environment = environment; this.id = id; this.region = region;
	 * this.resourceId = resourceId; this.resourceName = resourceName;
	 * this.startTime = startTime; this.tenantId = tenantId; this.type = type;
	 * this.version = version; this.product = product; }
	 */

}
