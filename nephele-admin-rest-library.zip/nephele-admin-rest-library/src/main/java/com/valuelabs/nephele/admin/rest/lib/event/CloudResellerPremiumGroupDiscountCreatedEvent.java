package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDiscountDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerPremiumGroupDiscountCreatedEvent {

	private CloudResellerPremiumGroupDiscountDetails cloudResellerPremiumGroupDiscountDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudResellerPremiumGroupDiscountCreatedEvent(CloudResellerPremiumGroupDiscountDetails cloudResellerPremiumGroupDiscountDetails ) {
		this.cloudResellerPremiumGroupDiscountDetails = cloudResellerPremiumGroupDiscountDetails;
	}
	
	public static CloudResellerPremiumGroupDiscountCreatedEvent invalid(CloudResellerPremiumGroupDiscountDetails cloudResellerPremiumGroupDiscountDetails) {
		CloudResellerPremiumGroupDiscountCreatedEvent event = new CloudResellerPremiumGroupDiscountCreatedEvent(cloudResellerPremiumGroupDiscountDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudResellerPremiumGroupDiscountCreatedEvent failed(CloudResellerPremiumGroupDiscountDetails cloudResellerPremiumGroupDiscountDetails) {
		CloudResellerPremiumGroupDiscountCreatedEvent event = new CloudResellerPremiumGroupDiscountCreatedEvent(cloudResellerPremiumGroupDiscountDetails);
		event.setFailed(true);
		return event;
	}
}
