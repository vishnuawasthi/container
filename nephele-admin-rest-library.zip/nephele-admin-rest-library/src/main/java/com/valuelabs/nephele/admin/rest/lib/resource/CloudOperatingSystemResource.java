package com.valuelabs.nephele.admin.rest.lib.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
//@Setter
//@Getter
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties({"cspResource"})
@JsonInclude(Include.NON_DEFAULT)
public class CloudOperatingSystemResource  extends ResourceSupport{

	private Long operatingSystemId;
	private String cspResource;
	private String imageId;
	private Long minDisk;
	private Long minRam;
	private String name;
	private String status;
	private Long serviceId;
	
}
