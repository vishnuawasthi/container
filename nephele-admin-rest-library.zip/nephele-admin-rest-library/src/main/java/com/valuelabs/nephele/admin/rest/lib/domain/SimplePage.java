package com.valuelabs.nephele.admin.rest.lib.domain;


import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public class SimplePage<T> implements Page<T>, Serializable {
	private static final long serialVersionUID = -5215971321688872186L;

	private List<T> content;
	private Pageable pageable;
	private long total;

	public SimplePage(List<T> content, Pageable pageable, long total) {
		this.content = content;
		this.pageable = pageable;
		this.total = total;
	}

	public SimplePage(List<T> content) {
		this(content, null, null == content ? 0 : content.size());
	}

	public SimplePage() {
	}

	public SimplePage<T> setContent(List<T> content) {
		this.content = content;
		return this;
	}

	public SimplePage<T> setPageable(Pageable pageable) {
		this.pageable = pageable;
		return this;
	}

	public SimplePage<T> setTotal(long total) {
		this.total = total;
		return this;
	}

	@Override
	public int getNumber() {
		return null == pageable ? 0 : pageable.getPageNumber();
	}

	@Override
	public int getSize() {
		return null == pageable ? 0 : pageable.getPageSize();
	}

	@Override
	public int getNumberOfElements() {
		return hasContent() ? content.size() : 0;
	}

	@Override
	public List<T> getContent() {
		return content;
	}

	@Override
	public boolean hasContent() {
		return null != content && !content.isEmpty();
	}

	@Override
	public Sort getSort() {
		return null == pageable ? null : pageable.getSort();
	}

	@Override
	public boolean isFirst() {
		return !hasPrevious();
	}

	@Override
	public boolean isLast() {
		return !hasNext();
	}

	@Override
	public boolean hasNext() {
		return getNumber() + 1 < getTotalPages();
	}

	@Override
	public boolean hasPrevious() {
		return getNumber() > 0;
	}

	@Override
	public Pageable nextPageable() {
		return hasNext() ? pageable.next() : null;
	}

	@Override
	public Pageable previousPageable() {
		return hasPrevious() ? pageable.previousOrFirst() : null;
	}

	@Override
	public Iterator<T> iterator() {
		return content.iterator();
	}

	@Override
	public int getTotalPages() {
		return getSize() == 0 ? 1 : (int)((total + getSize() - 1) / getSize());
	}

	@Override
	public long getTotalElements() {
		return total;
	}

	public boolean hasPreviousPage() {
		return hasPrevious();
	}

	public boolean isFirstPage() {
		return isFirst();
	}

	public boolean hasNextPage() {
		return hasNext();
	}

	public boolean isLastPage() {
		return isLast();
	}
}
