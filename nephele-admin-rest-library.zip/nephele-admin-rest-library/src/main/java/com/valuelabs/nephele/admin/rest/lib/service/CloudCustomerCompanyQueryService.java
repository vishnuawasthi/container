package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomersCompanyEvent;

public interface CloudCustomerCompanyQueryService {

	EntityReadEvent<CloudCustomerCompanyDetails> readCustomerCompany(ReadCloudCustomerCompanyEvent request);
	PageReadEvent<CloudCustomerCompanyDetails> readCustomersCompany(ReadCloudCustomersCompanyEvent request);
	CloudCustomerCompany findByCloudCustomerCompanyCode(String customerCompanyCode) throws Exception;
	CloudCustomerCompany findByExternalCompanyCode(String customerCompanyCode);
}
