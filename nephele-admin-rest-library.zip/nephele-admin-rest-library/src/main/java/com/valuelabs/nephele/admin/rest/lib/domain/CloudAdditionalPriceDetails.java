package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain = true)
public class CloudAdditionalPriceDetails {

private Long  additionalPriceId;
private String   name;
private Double   price;
private Long  cloudServiceId;
private String   location;
private String   description;
private String status;
private String serviceName;
private String planCode;
private String serviceType;

	
}
