package com.valuelabs.nephele.admin.rest.lib.event;

import org.springframework.data.domain.Pageable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class ReadPageEvent<T extends ReadPageEvent<T>> {

	private Pageable pageable;

	public T setPageable(Pageable pageable) {
		this.pageable = pageable;

		@SuppressWarnings("unchecked")
		T ret = (T)this;
		return ret;
	}
}
