package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudPaymentDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudPaymentDetailsCreatedEvent {
	
private CloudPaymentDetails cloudPaymentDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudPaymentDetailsCreatedEvent(CloudPaymentDetails cloudPaymentDetails) {
		this.cloudPaymentDetails = cloudPaymentDetails;
	}
	
	public static CloudPaymentDetailsCreatedEvent invalid(CloudPaymentDetails cloudPaymentDetails) {
		CloudPaymentDetailsCreatedEvent event = new CloudPaymentDetailsCreatedEvent(cloudPaymentDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudPaymentDetailsCreatedEvent failed(CloudPaymentDetails cloudPaymentDetails) {
		CloudPaymentDetailsCreatedEvent event = new CloudPaymentDetailsCreatedEvent(cloudPaymentDetails);
		event.setFailed(true);
		return event;
	}

}
