package com.valuelabs.nephele.admin.rest.lib.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@JsonInclude(Include.NON_DEFAULT)
public class CloudProductPriceManagementSheetDetails {
	
    private Long id;
	private Double price;
	//private String status;
	private Long priceManagementConfigId;
	private Long cloudProductPlanId;
	private String sheetName;
	private CloudProductPlanDetails planDetails;
	private Double vendorPrice;
	

}
