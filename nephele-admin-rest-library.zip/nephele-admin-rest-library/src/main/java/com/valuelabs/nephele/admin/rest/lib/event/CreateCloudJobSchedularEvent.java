package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudJobSchedularDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudJobSchedularEvent {
	
	private CloudJobSchedularDetails cloudJobSchedularDetails;

}
