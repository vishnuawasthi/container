package com.valuelabs.nephele.admin.rest.lib.resource;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.hateoas.ResourceSupport;

import java.util.Date;

/**
 * Created by ranjith on 16/9/15.
 */

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
//@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudPaymentResource extends ResourceSupport {
  private Long cloudPaymentId;
  private String invoiceAmount;
  private String surcharge;
  private String total;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date created;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date updated;
  private String paymentMode;
  private String transactionId;
  private String instrumentType;
  private Long invoiceId;
  private String surchargeGst;
  private String serviceName;
}
