package com.valuelabs.nephele.admin.rest.lib.resource;

import org.springframework.hateoas.ResourceSupport;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
public class CloudProductPriceMgmtSheetExportResource extends ResourceSupport {
	
	private Long PLAN_ID;
	
	private Long PRICE_CONFIG_ID;
	
	private String SHEET_NAME;
	
	private String PLAN_NAME;
	
	private String SERVICE;
	
	private String PRODUCT_NAME;
	
	private String LOCATION;
	
	private Double PRICE;
	
	private Long SHEET_ID;
	
	private Double VENDOR_PRICE;

	
	
	/*public CloudProductPriceMgmtSheetExportResource(Integer pLAN_ID,
			Integer pRICE_CONFIG_ID, String sHEET_NAME, String pLAN_NAME,
			String sERVICE, String pRODUCT_NAME, String lOCATION) {
		super();
		PLAN_ID = pLAN_ID;
		PRICE_CONFIG_ID = pRICE_CONFIG_ID;
		SHEET_NAME = sHEET_NAME;
		PLAN_NAME = pLAN_NAME;
		SERVICE = sERVICE;
		PRODUCT_NAME = pRODUCT_NAME;
		LOCATION = lOCATION;
		
	}*/
}
