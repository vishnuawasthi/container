package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain=false)
public class AcquireServerDetails {


	
	private String locationCode;
	
	private Long locationId;
	
	private Long configurationId;

	private String groupName;

	private String operatingSystem;

	private String opeatingSystemVersion;

	private Long ram;

	private Long disk;
	
	private Long cpu;

	private Integer serverCount;

	private String publicAddresses;

	private String loginUser;

	private String password;

	private String serverName;

	private String serverId;
	
	private String imageId;
	
	private String osType;
	
	private String flavorId;
	
	private String cspResource;
	
	private Long cloudCustomerCompanyId;
	
	private String status;
	
	private Long productId;
	
	private Long planId;
	
	private String ndPlanType;
	
	private String customization;
	
	private Integer quantity;
	
	private Long orderId;
	
	private Long serviceId;
	
	private String subscriptionNamePrefix;
	
	private Long resellerCompanyId;
	
	private String externalResellerCompanyCode;
	
	private String resellerEmail;
	
	private String flavorName;
	
	private String planCode;
	
	private String ruleValue;
	
	private String purchaseOrderNumber;
}
