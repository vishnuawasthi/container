package com.valuelabs.nephele.admin.rest.lib.event;





import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;



//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceCreatedEvent {
	
	private CloudServiceDetails serviceDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceCreatedEvent(CloudServiceDetails serviceDetails) {
		this.serviceDetails=serviceDetails;		
	}
	
	public static ServiceCreatedEvent invalid(CloudServiceDetails serviceDetails) {
		ServiceCreatedEvent event = new ServiceCreatedEvent(serviceDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceCreatedEvent failed(CloudServiceDetails serviceDetails) {
		ServiceCreatedEvent event = new ServiceCreatedEvent(serviceDetails);
		event.setFailed(true);
		return event;
	}

}
