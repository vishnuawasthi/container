package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadProductPriceMgmtConfigsEvent  extends ReadPageEvent< ReadProductPriceMgmtConfigsEvent> {
	private Integer id;
	private String sheetName;
	private String status;
	private String activeFrom;
	private String activeTo;
	private Long serviceId;

}
