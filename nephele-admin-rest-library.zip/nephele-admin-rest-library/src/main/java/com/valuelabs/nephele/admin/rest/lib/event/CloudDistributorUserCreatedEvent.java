package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorUserDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudDistributorUserCreatedEvent {
	private CloudDistributorUserDetails cloudDistributorUserDetails;

	private boolean invalid;
	private boolean failed;

	public CloudDistributorUserCreatedEvent(CloudDistributorUserDetails cloudDistributorUserDetails) {
		this.cloudDistributorUserDetails = cloudDistributorUserDetails;
	}

	public static CloudDistributorUserCreatedEvent invalid(CloudDistributorUserDetails cloudDistributorUserDetails) {
		CloudDistributorUserCreatedEvent event = new CloudDistributorUserCreatedEvent(cloudDistributorUserDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudDistributorUserCreatedEvent failed(CloudDistributorUserDetails cloudDistributorUserDetails) {
		CloudDistributorUserCreatedEvent event = new CloudDistributorUserCreatedEvent(cloudDistributorUserDetails);
		event.setFailed(true);
		return event;
	}
}
