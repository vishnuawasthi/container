package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorPriceGroupDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudDistributorPriceGroupCreatedEvent {
	private CloudDistributorPriceGroupDetails cloudDistributorPriceGroupDetails;
	private boolean invalid;
	private boolean failed;
	public CloudDistributorPriceGroupCreatedEvent(CloudDistributorPriceGroupDetails cloudDistributorPriceGroupDetails) {
		this.cloudDistributorPriceGroupDetails = cloudDistributorPriceGroupDetails;
	}

	public static CloudDistributorPriceGroupCreatedEvent invalid(CloudDistributorPriceGroupDetails cloudDistributorPriceGroupDetails) {
		CloudDistributorPriceGroupCreatedEvent event = new CloudDistributorPriceGroupCreatedEvent(cloudDistributorPriceGroupDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudDistributorPriceGroupCreatedEvent failed(CloudDistributorPriceGroupDetails cloudDistributorPriceGroupDetails) {
		CloudDistributorPriceGroupCreatedEvent event = new CloudDistributorPriceGroupCreatedEvent(cloudDistributorPriceGroupDetails);
		event.setFailed(true);
		return event;
	}
}
