package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;

@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class CreateBundleEvent {
  private BundleDetails bundleDetails;
}
