package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.event.CloudOrderCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudOrderEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface CloudOrderCommandService {

	CloudOrderCreatedEvent createServiceCloudOrder(CreateCloudOrderEvent request) throws IllegalArgumentException;
	CloudOrderCreatedEvent updateServiceCloudOrder(CreateCloudOrderEvent request) throws IllegalArgumentException, ResourceNotFoundException;
	String getOrderCodePatternSequenceValue();
}
