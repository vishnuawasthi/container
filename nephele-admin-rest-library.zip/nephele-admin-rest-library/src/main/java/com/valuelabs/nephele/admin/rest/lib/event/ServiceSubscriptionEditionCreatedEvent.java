package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionEditionDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceSubscriptionEditionCreatedEvent {
	
	private CloudSubscriptionEditionDetails cloudSubscriptionEditionDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceSubscriptionEditionCreatedEvent(CloudSubscriptionEditionDetails cloudSubscriptionEditionDetails) {
		this.cloudSubscriptionEditionDetails = cloudSubscriptionEditionDetails;
	}
	
	public static ServiceSubscriptionEditionCreatedEvent invalid(CloudSubscriptionEditionDetails cloudSubscriptionEditionDetails) {
		ServiceSubscriptionEditionCreatedEvent event = new ServiceSubscriptionEditionCreatedEvent(cloudSubscriptionEditionDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceSubscriptionEditionCreatedEvent failed(CloudSubscriptionEditionDetails cloudSubscriptionEditionDetails) {
		ServiceSubscriptionEditionCreatedEvent event = new ServiceSubscriptionEditionCreatedEvent(cloudSubscriptionEditionDetails);
		event.setFailed(true);
		return event;
	}
	

}
