package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadPremiumGroupDiscountSheetsEvent extends ReadPageEvent<ReadPremiumGroupDiscountSheetsEvent> {
	private Long id;
	private String sheetName;
	private Long sheetId;
	private String groupName;
	private Long serviceId;
	private String planType;
	private String externalResellerCode;
	private ChangeManagementConfigStatus status;
	
}
