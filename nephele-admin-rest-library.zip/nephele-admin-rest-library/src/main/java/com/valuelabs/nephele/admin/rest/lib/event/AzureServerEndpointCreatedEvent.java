package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.AzureServerEndpointDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class AzureServerEndpointCreatedEvent {

	private AzureServerEndpointDetails azureServerEndpointDetails;
	private boolean invalid;
	private boolean failed;
	
	public AzureServerEndpointCreatedEvent(){
		
	}

	public AzureServerEndpointCreatedEvent(AzureServerEndpointDetails azureServerEndpointDetails) {
		this.azureServerEndpointDetails = azureServerEndpointDetails;
	}

	public static AzureServerEndpointCreatedEvent invalid(AzureServerEndpointDetails azureServerEndpointDetails) {
		AzureServerEndpointCreatedEvent event = new AzureServerEndpointCreatedEvent(azureServerEndpointDetails);
		event.setInvalid(true);
		return event;
	}

	public static AzureServerEndpointCreatedEvent failed(AzureServerEndpointDetails azureServerEndpointDetails) {
		AzureServerEndpointCreatedEvent event = new AzureServerEndpointCreatedEvent(azureServerEndpointDetails);
		event.setFailed(true);
		return event;
	}
	
	
}
