package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudInvoiceDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudInvoiceDetailsCreatedEvent {
	

private CloudInvoiceDetails cloudInvoiceDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudInvoiceDetailsCreatedEvent(CloudInvoiceDetails cloudInvoiceDetails) {
		this.cloudInvoiceDetails = cloudInvoiceDetails;
	}
	
	public static CloudInvoiceDetailsCreatedEvent invalid(CloudInvoiceDetails cloudInvoiceDetails) {
		CloudInvoiceDetailsCreatedEvent event = new CloudInvoiceDetailsCreatedEvent(cloudInvoiceDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudInvoiceDetailsCreatedEvent failed(CloudInvoiceDetails cloudInvoiceDetails) {
		CloudInvoiceDetailsCreatedEvent event = new CloudInvoiceDetailsCreatedEvent(cloudInvoiceDetails);
		event.setFailed(true);
		return event;
	}

}
