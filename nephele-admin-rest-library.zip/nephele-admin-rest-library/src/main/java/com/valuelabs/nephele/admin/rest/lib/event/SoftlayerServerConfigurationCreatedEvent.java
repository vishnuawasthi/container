package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.SoftlayerServerConfigurationDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class SoftlayerServerConfigurationCreatedEvent {
	private SoftlayerServerConfigurationDetails softlayerServerConfigurationDetails;
	private boolean invalid;
	private boolean failed;

	public SoftlayerServerConfigurationCreatedEvent(SoftlayerServerConfigurationDetails softlayerServerConfigurationDetails) {
		this.softlayerServerConfigurationDetails = softlayerServerConfigurationDetails;
	}

	public static SoftlayerServerConfigurationCreatedEvent invalid(SoftlayerServerConfigurationDetails softlayerServerConfigurationDetails) {
		SoftlayerServerConfigurationCreatedEvent event = new SoftlayerServerConfigurationCreatedEvent(softlayerServerConfigurationDetails);
		event.setInvalid(true);
		return event;
	}

	public static SoftlayerServerConfigurationCreatedEvent failed(SoftlayerServerConfigurationDetails softlayerServerConfigurationDetails) {
		SoftlayerServerConfigurationCreatedEvent event = new SoftlayerServerConfigurationCreatedEvent(softlayerServerConfigurationDetails);
		event.setFailed(true);
		return event;
	}

}
