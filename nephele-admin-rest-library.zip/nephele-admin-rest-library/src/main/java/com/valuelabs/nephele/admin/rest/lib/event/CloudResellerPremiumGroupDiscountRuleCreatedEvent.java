package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDiscountRuleDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerPremiumGroupDiscountRuleCreatedEvent {

	private CloudResellerPremiumGroupDiscountRuleDetails cloudResellerPremiumGroupDiscountRuleDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudResellerPremiumGroupDiscountRuleCreatedEvent(CloudResellerPremiumGroupDiscountRuleDetails cloudResellerPremiumGroupDiscountRuleDetails ) {
		this.cloudResellerPremiumGroupDiscountRuleDetails = cloudResellerPremiumGroupDiscountRuleDetails;
	}
	
	public static CloudResellerPremiumGroupDiscountRuleCreatedEvent invalid(CloudResellerPremiumGroupDiscountRuleDetails cloudResellerPremiumGroupDiscountRuleDetails) {
		CloudResellerPremiumGroupDiscountRuleCreatedEvent event = new CloudResellerPremiumGroupDiscountRuleCreatedEvent(cloudResellerPremiumGroupDiscountRuleDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudResellerPremiumGroupDiscountRuleCreatedEvent failed(CloudResellerPremiumGroupDiscountRuleDetails cloudResellerPremiumGroupDiscountRuleDetails) {
		CloudResellerPremiumGroupDiscountRuleCreatedEvent event = new CloudResellerPremiumGroupDiscountRuleCreatedEvent(cloudResellerPremiumGroupDiscountRuleDetails);
		event.setFailed(true);
		return event;
	}
}
