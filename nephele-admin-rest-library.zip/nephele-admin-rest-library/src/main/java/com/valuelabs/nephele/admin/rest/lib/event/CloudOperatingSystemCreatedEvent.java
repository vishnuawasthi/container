package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudOperatingSystemCreatedEvent {

private CloudOperatingSystemDetails cloudOperatingSystemDetails;
private List<CloudOperatingSystemDetails> cloudOperatingSystemDetailsList;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudOperatingSystemCreatedEvent(CloudOperatingSystemDetails cloudOperatingSystemDetails) {
		this.cloudOperatingSystemDetails = cloudOperatingSystemDetails;
	}
	
	public CloudOperatingSystemCreatedEvent(List<CloudOperatingSystemDetails> cloudOperatingSystemDetailsList) {
		this.cloudOperatingSystemDetailsList = cloudOperatingSystemDetailsList;
	}
	
	public static CloudOperatingSystemCreatedEvent invalid(CloudOperatingSystemDetails cloudOperatingSystemDetails) {
		CloudOperatingSystemCreatedEvent event = new CloudOperatingSystemCreatedEvent(cloudOperatingSystemDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudOperatingSystemCreatedEvent failed(CloudOperatingSystemDetails cloudOperatingSystemDetails) {
		CloudOperatingSystemCreatedEvent event = new CloudOperatingSystemCreatedEvent(cloudOperatingSystemDetails);
		event.setFailed(true);
		return event;
	}
}
