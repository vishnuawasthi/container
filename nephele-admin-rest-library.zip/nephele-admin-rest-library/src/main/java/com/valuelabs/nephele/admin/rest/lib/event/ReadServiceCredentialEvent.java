package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadServiceCredentialEvent extends ReadEntityEvent<ReadServiceCredentialEvent>{

	private Long serviceCredentialId;
	private String apiKey;
	private String description;
	private String username;
	private String password;
	private Long cloudServiceId;
}
