package com.valuelabs.nephele.admin.rest.lib.resource;

import java.util.Date;
import java.util.List;

import com.sun.syndication.feed.impl.ObjectBean;
import com.sun.syndication.feed.synd.SyndContent;
import com.sun.syndication.feed.synd.SyndFeed;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class CloudFeedEntryResources {

	private ObjectBean objBean;
	private String uuid;
	private String link;
	private Date publishedDate;
	private Date updatedDate;
	private String title;
	private SyndContent description;
	private List links;
	private List<NepheleSyndContentResources> contents;
	private SyndFeed source;
	private Object foreignMarkup;
	private Object wireEntry;
	private List<NepheleSyndCategoryResources> categories;
	private String feedUuid;

}
