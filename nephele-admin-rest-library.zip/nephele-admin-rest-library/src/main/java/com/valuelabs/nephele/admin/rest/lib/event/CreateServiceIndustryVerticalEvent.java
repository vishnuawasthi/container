package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceIndustryVerticalDetail;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateServiceIndustryVerticalEvent {

	private CloudServiceIndustryVerticalDetail serviceIndustryVerticalDetail;
}
