package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudProductsEvent extends ReadPageEvent<ReadCloudProductsEvent>{
	
	private Long cloudProductId;
	private List< Long> productIds;
	private Long cloudServiceId;
	private String productName;
	private String status;
	private Boolean isFeatured;
	private Boolean hasRelatedProducts;
	
}
