package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Accessors(chain = true)
//@Data
@Setter
@Getter
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudCustomersCompanyEvent extends ReadPageEvent<ReadCloudCustomersCompanyEvent>{
	
	  private Long customerCompanyId;
}
