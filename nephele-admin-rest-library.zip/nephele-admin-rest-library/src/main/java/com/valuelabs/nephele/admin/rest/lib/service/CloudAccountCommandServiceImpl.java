package com.valuelabs.nephele.admin.rest.lib.service;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.AccountStatus;
import com.valuelabs.nephele.admin.data.entity.CloudAccount;
import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudOrder;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.repository.CloudAccountRepository;
import com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanyRepository;
import com.valuelabs.nephele.admin.data.repository.CloudOrderRepository;
import com.valuelabs.nephele.admin.data.repository.CloudProductPlanRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudAccountCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;


@Service
@Slf4j
@Transactional
public class CloudAccountCommandServiceImpl implements CloudAccountCommandService {

  @Autowired
  private CloudAccountRepository cloudAccountRepository;
  
  @Autowired
  private CloudServiceRepository cloudServiceRepository;
  
  @Autowired
  private CloudOrderRepository cloudOrderRepository;
  
  @Autowired
  private CloudCustomerCompanyRepository cloudCustomerCompanyRepository;
  
  @Autowired
  private CloudProductPlanRepository cloudProductPlanRepository;
  
  @Override
  public CloudAccountCreatedEvent createCloudAccount(CreateCloudAccountEvent request) throws IllegalArgumentException, InterruptedException {
	log.debug("createCloudAccount() - start");
	
	CloudAccountDetails details = request.getAccountDetails();
	
	
	CloudService cloudService = cloudServiceRepository.findOne(details.getCloudServiceId());	
	if(cloudService==null) {
	  throw new ResourceNotFoundException("CloudService", details.getCloudServiceId());
	}	
	CloudOrder cloudOrder = cloudOrderRepository.findOne(details.getOrderId());	
	if(cloudOrder==null) {
		  throw new ResourceNotFoundException("CloudOrder", details.getOrderId());
	}
	CloudCustomerCompany cloudCustomerCompany =cloudCustomerCompanyRepository.findOne(details.getCloudCustomerCompanyId());	
	if(cloudCustomerCompany==null) {
	  throw new ResourceNotFoundException("CloudCustomerCompany", details.getCloudCustomerCompanyId());
	}
	
	CloudProductPlan  cloudProductPlan  = cloudProductPlanRepository.findOne(details.getPlanId());
	if(cloudProductPlan == null) {
		  throw new ResourceNotFoundException("CloudProductPlan", details.getPlanId());
	}
	
	CloudAccount entity = CloudAccount.builder()
            							.vendorAccountId(details.getVendorAccountId())
                                  		.password(details.getPassword())
                                  		.username(details.getUsername())
                                  		.superUsername(details.getSuperUsername())
                                  		.superPassword(details.getSuperPassword())
                                  		.superAPIKey(details.getSuperAPIKey())
                                  		.vendorStatus(AccountStatus.valueOf(details.getVendorStatus()))
                                  		.nepheleStatus(details.getNepheleStatus())
                                  		.cloudService(cloudService)
                                  		.cloudCustomerCompany(cloudCustomerCompany)
                                  		.cloudOrder(cloudOrder)
                                  		.cloudProductPlan(cloudProductPlan)
                                  		.build();
	
	cloudAccountRepository.save(entity);
	details.setId(entity.getId());
	log.debug("createCloudAccount() - end");
	return new CloudAccountCreatedEvent(details) ;
  }

  @Override
  public CloudAccountCreatedEvent updateCloudAccount(CreateCloudAccountEvent request) throws ResourceNotFoundException,
	  IllegalArgumentException {
	log.debug("updateCloudAccount() - start");
	
	CloudAccountDetails details = request.getAccountDetails();
	
	CloudAccount entity = cloudAccountRepository.findOne(details.getId());
	
	if(entity!=null) {
	  
	  if(!StringUtils.isEmpty(details.getPassword()))
	  entity.setPassword(details.getPassword());
	  
	  if(!StringUtils.isEmpty(details.getUsername()))
		entity.setUsername(details.getUsername());
	  
	 if(!StringUtils.isEmpty(details.getVendorStatus())) 
	  entity.setVendorStatus(AccountStatus.valueOf(details.getVendorStatus()));
	 
	 if(!StringUtils.isEmpty(details.getNepheleStatus())) 
		  entity.setNepheleStatus(details.getNepheleStatus());
		
	 if(!StringUtils.isEmpty(details.getSuperUsername()))
		entity.setSuperUsername(details.getSuperUsername());
		  
	 if(!StringUtils.isEmpty(details.getSuperPassword()))
	  	entity.setSuperPassword(details.getSuperPassword());
			
	 if(!StringUtils.isEmpty(details.getSuperAPIKey()))
	 entity.setSuperAPIKey(details.getSuperAPIKey());
	  
	 
	 if(!StringUtils.isEmpty(details.getCloudServiceId())) {
		CloudService cloudService = cloudServiceRepository.findOne(details.getCloudServiceId());
		if (cloudService != null) {
		  entity.setCloudService(cloudService);
		} else {
		  throw new ResourceNotFoundException("CloudService", details.getCloudServiceId());
		}
	 }
	 
	 if(!StringUtils.isEmpty(details.getCloudCustomerCompanyId())) {
		CloudCustomerCompany cloudCustomerCompany =cloudCustomerCompanyRepository.findOne(details.getCloudCustomerCompanyId());
		if (cloudCustomerCompany != null) {
		  entity.setCloudCustomerCompany(cloudCustomerCompany);
		} else {
		  throw new ResourceNotFoundException("CloudCustomerCompany", details.getCloudCustomerCompanyId());
		}
	 }
	 
	 if(!StringUtils.isEmpty(details.getOrderId())) {
		CloudOrder cloudOrder =   cloudOrderRepository.findOne(details.getOrderId());
		if (cloudOrder != null) {
		  entity.setCloudOrder(cloudOrder);
		} else {
		  throw new ResourceNotFoundException("CloudOrder", details.getOrderId());
		}
	 }
	 
	 
	 cloudAccountRepository.save(entity);
	}
	
	log.debug("updateCloudAccount() - end");
	 return new CloudAccountCreatedEvent(details);
  }

}
