package com.valuelabs.nephele.admin.rest.lib.service;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.entity.BundleCloudProduct;
import com.valuelabs.nephele.admin.data.repository.BundleCloudProductRepository;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

@Service
@Slf4j
@Transactional
public class BundleCloudProductCommandServiceImpl implements BundleCloudProductCommandService{
	
	@Autowired
	private BundleCloudProductRepository bundleCloudProductRepository;
	
	
		public void deleteBundleCloudProduct(Long id) throws ResourceNotFoundException, IllegalArgumentException {
			log.debug("deleteBundleCloudProduct()  - START");
			BundleCloudProduct entity = bundleCloudProductRepository.findOne(id);
			if(entity == null){
				throw new ResourceNotFoundException("Resource not found");
			}
			bundleCloudProductRepository.delete(id);
			log.debug("deleteBundleCloudProduct()  - END");
		}

}
