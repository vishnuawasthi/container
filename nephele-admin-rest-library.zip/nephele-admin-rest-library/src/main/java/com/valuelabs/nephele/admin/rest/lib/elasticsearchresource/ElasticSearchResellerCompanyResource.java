package com.valuelabs.nephele.admin.rest.lib.elasticsearchresource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@Accessors(chain = true)
@JsonInclude(value=Include.NON_DEFAULT)
//@EqualsAndHashCode(callSuper = false)

public class ElasticSearchResellerCompanyResource  
{
  
  private Long id;
  private String resellerCompanyName;
  private String firstName;
  private String lastName; 
  private String email;
  private String addressLine1;   
  private String addressLine2;  
  private String creditCardToken;  
  private String city;
  private String state; 
  private String country;  
  private String zipcode;  
  private String resellerCompanyCode; 
  private Boolean isActive;
  
}