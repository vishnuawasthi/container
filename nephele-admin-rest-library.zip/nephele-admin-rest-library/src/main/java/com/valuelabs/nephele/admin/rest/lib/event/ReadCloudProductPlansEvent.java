package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudProductPlansEvent extends ReadPageEvent<ReadCloudProductPlansEvent>{
	
	private Long productPlanId;
	private String status;
	private Long productId ;
	private Long locationId ;
	private String flavorCategory;
	private Long serviceId;
	private Long operatingSystemId;
	private Long ram;
	private String serviceName;
	private String operatingSystemName;
	private String locationName;
	private List<Long> planIds;
	private String planName;
	
	
	
}
