package com.valuelabs.nephele.admin.rest.lib.domain;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudServiceEnableDetails {
	
	private boolean authentication;
	private boolean pricing;
	private boolean discountPlan;
	private boolean billingCycle;
	private String serviceName;
	private String serviceCode;
	private boolean isServicePublished;
	private boolean isServiceLive;
	private String integrationCode;
	private String vendorCode;
}
