package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
@Accessors(chain = true)
public class ServerPasswordResetEvent {

	private String cspServerId;
	private String newPassword;
	private Long serverId;
	private Long locationId;
	private Long serverActionId;
	private Long cloudServiceId;
	private Long resellerCompanyId;
	private String externalResellerCompanyCode;
	private String resellerEmail;
	
}
