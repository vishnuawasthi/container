package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudUserRoleDetails {
	
	private Long 	roleId;
	private String 	roleName;
	private String 	roleDescription;
	private Date 	createdAt;
	private Date 	updatedAt;
	private Integer userCount;
	private List<CloudManagerAppPermissionDetails> permissions;


}
