package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.PremiumGroupDiscountConfigDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class PremiumGroupDiscountConfigCreatedEvent {
	

private PremiumGroupDiscountConfigDetails premiumGroupDiscountConfigDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public PremiumGroupDiscountConfigCreatedEvent(PremiumGroupDiscountConfigDetails premiumGroupDiscountConfigDetails) {
		this.premiumGroupDiscountConfigDetails = premiumGroupDiscountConfigDetails;
	}
	
	public static PremiumGroupDiscountConfigCreatedEvent invalid(PremiumGroupDiscountConfigDetails premiumGroupDiscountConfigDetails) {
		PremiumGroupDiscountConfigCreatedEvent event = new PremiumGroupDiscountConfigCreatedEvent(premiumGroupDiscountConfigDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static PremiumGroupDiscountConfigCreatedEvent failed(PremiumGroupDiscountConfigDetails premiumGroupDiscountConfigDetails) {
		PremiumGroupDiscountConfigCreatedEvent event = new PremiumGroupDiscountConfigCreatedEvent(premiumGroupDiscountConfigDetails);
		event.setFailed(true);
		return event;
	}

}
