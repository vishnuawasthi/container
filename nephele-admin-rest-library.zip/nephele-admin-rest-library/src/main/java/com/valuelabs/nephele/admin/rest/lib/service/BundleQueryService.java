package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundleEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundlesEvent;

public interface BundleQueryService {

  EntityReadEvent<BundleDetails> readBundle(ReadBundleEvent request);
  PageReadEvent<BundleDetails> readBundles(ReadBundlesEvent requst);
  PageReadEvent<BundleDetails> readBundlesByIds(ReadBundlesEvent requst);
  List<BundleDetails> readPublishedBundles();
  
}
