package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.*;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudInvoiceLineDetails {

	private Long cloudInvoiceLineId;
	private String description;
	private Double price = 0.0D;
	private String quantity;
	private String total;
	private Long cloudInvoiceId;
	private String cloudCustomerName;
	private String serviceName;
	private String productPlan;
	private String type;

}
