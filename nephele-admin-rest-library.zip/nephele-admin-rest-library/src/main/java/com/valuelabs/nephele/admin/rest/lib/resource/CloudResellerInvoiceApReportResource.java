package com.valuelabs.nephele.admin.rest.lib.resource;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;


@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudResellerInvoiceApReportResource extends ResourceSupport {

   @JsonSerialize(using = CustomJsonDateSerializer.class)
   private Date fromDate;
   @JsonSerialize(using = CustomJsonDateSerializer.class)
   private Date toDate;
   private String grossTotal;
   private String currency;
   private String sortBy;
   private String cloudServiceId;

}
