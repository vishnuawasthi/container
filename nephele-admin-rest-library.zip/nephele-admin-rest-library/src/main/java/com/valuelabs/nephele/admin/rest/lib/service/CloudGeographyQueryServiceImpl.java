package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.entity.CloudGeography;
import com.valuelabs.nephele.admin.data.entity.CloudLocation;
import com.valuelabs.nephele.admin.data.repository.CloudGeographyRepository;
import com.valuelabs.nephele.admin.data.repository.CloudGeographySpecifications;
import com.valuelabs.nephele.admin.data.repository.CloudLocationRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudGeographyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudGeographiesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudGeographyEvent;

@Service
@Slf4j
public class CloudGeographyQueryServiceImpl implements
		CloudGeographyQueryService {

	@Autowired
	private CloudGeographyRepository cloudGeographyRepository;
	
	@Autowired
	private CloudLocationRepository cloudLocationRepository;
	
	@Override
	public EntityReadEvent<CloudGeographyDetails> readCloudGeography(ReadCloudGeographyEvent request) {
			log.debug("readCloudGeography() - start");
			CloudGeography entity = cloudGeographyRepository.findOne(request.getId());
			CloudGeographyDetails details = null;
			if(entity!=null) {
				details = CloudGeographyDetails.builder()
												.id(entity.getId())
												.geographyCode(entity.getGeographyCode())
												.geographyName(entity.getGeographyName())
												.build();
			}
			log.debug("readCloudGeography() - end");
		return new EntityReadEvent<CloudGeographyDetails> (details);
	}

	@Override
	public PageReadEvent<CloudGeographyDetails> readCloudGeographies(ReadCloudGeographiesEvent request) {
		log.debug("readCloudGeographies() - start");	
		List<CloudGeography> dbContent = new ArrayList<>();
		dbContent = cloudGeographyRepository.findAll(CloudGeographySpecifications.getByGeographyCode(request.getGeographyCode()));
		List<CloudGeographyDetails> content = new ArrayList<>();
		long total = 0;
		for (CloudGeography record : dbContent) {
			if (total >= request.getPageable().getOffset() && total < request.getPageable().getOffset()+ request.getPageable().getPageSize()) {
				CloudGeographyDetails details = CloudGeographyDetails.builder()
																	.id(record.getId())
																	.geographyCode(record.getGeographyCode())
																	.geographyName(record.getGeographyName())
																	.build();
				content.add(details);
			}
			++total;
		}
		Page<CloudGeographyDetails> page = new PageImpl<>(content,request.getPageable(), total);
		log.debug("readCloudGeographies() - end");
		return new PageReadEvent<>(page);
	}

	@Override
	public EntityReadEvent<CloudGeographyDetails> readCloudGeographyByLocationCode(ReadCloudGeographyEvent request) {
		log.debug("readCloudGeographyByLocationCode() - start");
		
		CloudLocation cloudLocation  = cloudLocationRepository.findByLocationCode(request.getLocationCode());
		CloudGeographyDetails details = null;

		if(cloudLocation!=null) {
			CloudGeography entity =cloudLocation.getCloudGeography();
			details = CloudGeographyDetails.builder()
											.id(entity.getId())
											.geographyCode(entity.getGeographyCode())
											.geographyName(entity.getGeographyName())
											.build();
		}
		log.debug("readCloudGeographyByLocationCode() - end");
		return new EntityReadEvent<CloudGeographyDetails> (details);
		
	}
	
	

}
