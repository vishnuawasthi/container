package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerDiscountPlanTypeDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerDiscountPlanTypeCreatedEvent {

	private CloudResellerDiscountPlanTypeDetails cloudResellerDiscountPlanTypeDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudResellerDiscountPlanTypeCreatedEvent(CloudResellerDiscountPlanTypeDetails cloudResellerDiscountPlanTypeDetails) {
		this.cloudResellerDiscountPlanTypeDetails = cloudResellerDiscountPlanTypeDetails;
	}
	
	public static CloudResellerDiscountPlanTypeCreatedEvent invalid(CloudResellerDiscountPlanTypeDetails cloudResellerDiscountPlanTypeDetails) {
		CloudResellerDiscountPlanTypeCreatedEvent event = new CloudResellerDiscountPlanTypeCreatedEvent(cloudResellerDiscountPlanTypeDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudResellerDiscountPlanTypeCreatedEvent failed(CloudResellerDiscountPlanTypeDetails cloudResellerDiscountPlanTypeDetails) {
		CloudResellerDiscountPlanTypeCreatedEvent event = new CloudResellerDiscountPlanTypeCreatedEvent(cloudResellerDiscountPlanTypeDetails);
		event.setFailed(true);
		return event;
	}
}
