package com.valuelabs.nephele.admin.rest.lib.elasticsearchresource;

import java.util.Date;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
public class ElasticSearchResellerInvoiceResource {

  @Id
  private Long id;
  private String cloudInvoiceNumber;
  private String currency;
  private Double grossTotal;
  private Double tax;
  private Double netTotal;
  private Date dueDate;
  private Date closedDate;
  private String invoiceStatus;
  private Long cloudResellerId;
  private String resellerCode;
  private String resellerCompanyName;
  private Date createdDate;
  private Boolean isOverdue;
  private Double totalUsage;
  private Double discountPercentage;
  private Double discountAmount;
  private Date billingStartDate;
  private Date billingEndDate;
  private String csvFilePath;
  private String pdfFilePath;
}
