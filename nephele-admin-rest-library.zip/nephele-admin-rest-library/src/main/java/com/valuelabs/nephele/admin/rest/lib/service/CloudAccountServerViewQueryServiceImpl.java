package com.valuelabs.nephele.admin.rest.lib.service;

import static com.valuelabs.nephele.admin.data.repository.CloudAccountServerViewSpecifications.constructPageSpecification;
import static com.valuelabs.nephele.admin.data.repository.CloudAccountServerViewSpecifications.findAccountServersByFilter;
import static com.valuelabs.nephele.admin.data.repository.CloudAccountServerViewSpecifications.sortByIdAsc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.NepheleServerStatus;
import com.valuelabs.nephele.admin.data.entity.CloudAccountServerView;
import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudProduct;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.entity.CloudServiceProvider;
import com.valuelabs.nephele.admin.data.entity.ServiceCategory;
import com.valuelabs.nephele.admin.data.repository.CloudAccountServerViewRepository;
import com.valuelabs.nephele.admin.data.repository.CloudAccountServerViewSpecifications;
import com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanyRepository;
import com.valuelabs.nephele.admin.data.repository.CloudOrderRepository;
import com.valuelabs.nephele.admin.data.repository.CloudProductPlanRepository;
import com.valuelabs.nephele.admin.data.repository.CloudResellerCompanyRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceProviderRepository;
import com.valuelabs.nephele.admin.data.repository.CloudServiceRepository;
import com.valuelabs.nephele.admin.data.repository.ServiceCategoryRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountServerViewDetails;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadAccountServerViewEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServersEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleUtils;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;

@Slf4j
@Service
public class CloudAccountServerViewQueryServiceImpl implements CloudAccountServerViewQueryService{
	
	@Autowired
	CloudAccountServerViewRepository accountServerViewRepository;
	
	@Autowired
	private CloudCustomerCompanyRepository customerCompanyRepository;
	
	@Autowired
	private CloudServiceRepository cloudServiceRepository;
	
	@Autowired
	private NepheleUtils nepheleUtils;
	
	@Autowired
	private CloudResellerCompanyRepository resellerCompanyRepository;
	
	@Autowired
	private ServiceCategoryRepository serviceCategoryRepository;
	
	@Autowired
	private CloudServiceProviderRepository cloudServiceProviderRepository;
	
	@Autowired
	private CloudOrderRepository cloudOrderRepository;
	
	@Autowired
	private CloudProductPlanRepository cloudProductPlanRepository;
	
	/* 
	 * This method will give List of records from DB by using pagination.
	 * (non-Javadoc)
	 * @see com.valuelabs.nephele.marketplace.service.CloudAccountServerViewQueryService#readAccountServerViewByFilter(com.valuelabs.nephele.admin.rest.lib.event.ReadAccountServerViewEvent)
	 */
	@Override
	public PageReadEvent<CloudAccountServerViewDetails> readAccountServerViewByFilter(ReadAccountServerViewEvent request) {
		
		log.debug("readAccountServerViewByFilter - START");
		Page<CloudAccountServerView> dbContent = null;
		Page<CloudAccountServerViewDetails> page = null;
		List<CloudAccountServerViewDetails> content = new ArrayList<>();
		
		/*if(null != request.getExternalCustomerCode() || null != request.getExternalResellerCode()){
			cloudCustomerCompany = customerCompanyRepository.findByExternalCustomerCode(request.getExternalCustomerCode());
			customerList = customerCompanyRepository.findByExternalResellerCode(request.getExternalResellerCode());
			if(null != cloudCustomerCompany)
				customerId = cloudCustomerCompany.getId();
			
			for (CloudCustomerCompany customerRecord : customerList) {
				customerIdList.add(customerRecord.getId());
			}
			
			dbContent = accountServerViewRepository.findAll(findAccountServersByFilter(customerId, customerIdList), 
				constructPageSpecification(request.getPageable().getPageNumber(), request.getPageable().getPageSize(), sortByIdAsc()));
		}else{
			dbContent = accountServerViewRepository.findAll(constructPageSpecification(request.getPageable().getPageNumber(), request.getPageable().getPageSize(), sortByIdAsc()));
		}*/
		
		//Filter - 1  - Reseller Code filter
		Long cloudResellerCompanyId =null;
		
		if(!StringUtils.isEmpty(request.getExternalResellerCode())) {
		  cloudResellerCompanyId = resellerCompanyRepository.findIdByExternalResellerCode(request.getExternalResellerCode());
		}
		
		List<Long> customerCompanyIds =null;
		
		if(cloudResellerCompanyId!=null) {
		  customerCompanyIds = customerCompanyRepository.findCustomerIdByResellerId(cloudResellerCompanyId);
		}
		
		List<Long> customerCompanyIdList = new ArrayList<>();
		
		if(!CollectionUtils.isEmpty(customerCompanyIds)) {
		  customerCompanyIdList.addAll(customerCompanyIds);
		}
		
		// CustomerExternal code filter
		Long  customerCompanyId = null;
		
		if(!StringUtils.isEmpty(request.getExternalCustomerCode())) {
		  customerCompanyId = customerCompanyRepository.findIdByExternalCustomerCode(request.getExternalCustomerCode());
		  if (customerCompanyId != null) {
				customerCompanyIdList.add(customerCompanyId);
		  } else {
				//customerCompanyIdList.add(0L);
				customerCompanyId =0L;
		  }
		}
		
		// ServiceCategory Filter
		
		Set<CloudService> cloudServices  = null;
		List<Long> serviceIdListFromCategory = new ArrayList<Long>();
		
	  if (!StringUtils.isEmpty(request.getCategoryId())) {
	  
	  ServiceCategory serviceCategory = serviceCategoryRepository.findOne(request.getCategoryId());
	  
	  if (serviceCategory != null) {
			cloudServices = serviceCategory.getCloudServices();
			for (CloudService cloudService : NepheleValidationUtils.nullSafe(cloudServices)) {
			  			serviceIdListFromCategory.add(cloudService.getId());
			}

	  } else {
		serviceIdListFromCategory.add(0L);
	  }
	}
		// Service Provider filter 
	  
		List<Long> serviceIdListFromProvider = new ArrayList<Long>();
		
		if(!StringUtils.isEmpty(request.getProviderId())) {
		  cloudServices = null;
		  CloudServiceProvider serviceProvider =  cloudServiceProviderRepository.findOne(request.getProviderId());
		  
	  if (!StringUtils.isEmpty(serviceProvider)) {
		cloudServices = serviceProvider.getCloudServices();
		for (CloudService cloudService : NepheleValidationUtils.nullSafe(cloudServices)) {
		  serviceIdListFromProvider.add(cloudService.getId());

		}
	  } else {
		serviceIdListFromProvider.add(0L);
	  }
  }
  	
  	Long orderIdFromOrderCode = null;
  	if (!StringUtils.isEmpty(request.getOrderCode())) {
  	  	orderIdFromOrderCode = cloudOrderRepository.findCloudOrderByOrderCode(request.getOrderCode());
  	  
  	}
		
		dbContent = accountServerViewRepository.findAll(findAccountServersByFilter(customerCompanyId, customerCompanyIdList,request.getStatus(),request.getOrderId(),request.getFromDate(),request.getToDate(),request.getDescription(),serviceIdListFromProvider,serviceIdListFromCategory,orderIdFromOrderCode), 
			constructPageSpecification(request.getPageable().getPageNumber(), request.getPageable().getPageSize(), sortByIdAsc()));
			
		if(null != dbContent){
			for (CloudAccountServerView record : NepheleValidationUtils.nullSafe( dbContent.getContent())) {
				
				CloudCustomerCompany viewCustomerCompany = customerCompanyRepository.findOne(record.getCustomerCompanyId());
				
				if(null == viewCustomerCompany)
					throw new ResourceNotFoundException("CloudCustomerCompany", record.getCustomerCompanyId());
				
				CloudService cloudService = cloudServiceRepository.findOne(record.getCloudServiceId());
				
				if(null == cloudService)
					throw new ResourceNotFoundException("CloudService", record.getCloudServiceId());
				
				
				CloudProductPlan cloudProductPlan = cloudProductPlanRepository.findOne(record.getCloudProductPlanId());
				
				
				if( null==cloudProductPlan) {
				  throw new ResourceNotFoundException("CloudProductPlan", record.getCloudProductPlanId());
				}
				
			   	CloudProduct  cloudProduct =cloudProductPlan.getCloudProduct();
			   	
			   	if(null == cloudProduct) {
			   	 throw new ResourceNotFoundException("There is no associate product with the plan id ",cloudProductPlan.getId()); 
			   	}
				
				CloudAccountServerViewDetails details = CloudAccountServerViewDetails.builder().resourceId(record.getResourceId())
																							   .resourceType(record.getResourceType())
																							   .customerId(viewCustomerCompany.getId())
																							   .customerName(viewCustomerCompany.getCustomerCompanyName())
																							   .customerCode(viewCustomerCompany.getCustomerCompanyCode())
																							   .description(record.getDescription())
																							   .integrationCode(cloudService.getIntegrationCode())
																							   .vendorStatus(record.getVendorStatus())
																							   .nepheleStatus(record.getNepheleStatus())
																							   .categoryName(cloudService.getServiceCategory().getName())
																							   .provisionDate(record.getProvisionDate())
																							   .planCode(cloudProductPlan.getPlanCode())
																							   .planId(cloudProductPlan.getId())
																							   .planName(cloudProductPlan.getPlanName())
																							   .productId(cloudProduct.getId())
																							   .productName(cloudProduct.getName())
																							   .build();
				content.add(details);
			}
			page = new PageImpl<>(content, request.getPageable(), dbContent.getTotalElements());
		}else{
			page = new PageImpl<>(content);
		}
		
		log.debug("readAccountServerViewByFilter - END");
		return new PageReadEvent<>(page);
	}
	

  

  @Override
  public Map<String, Long> readServerSummaryByCustomer(ReadServersEvent request) {
	log.debug("readServerSummaryByCustomer() -start");

	Set <CloudService> cloudServices = null;
	
	//Filter - 1  - Customer Code filter
	
	List<Long> customerCompanyIdList = new ArrayList<>();
	Long customerCompanyId  =null;
	
	if(!StringUtils.isEmpty(request.getExternalCustomerCode())) {
	  customerCompanyId = customerCompanyRepository.findIdByExternalCustomerCode(request.getExternalCustomerCode());
	  if (customerCompanyId != null) {
		customerCompanyIdList.add(customerCompanyId);
	  } else {
		customerCompanyIdList.add(0L);
	  }
	}
	
	// Filter - 2 Category Id filter 
	
	List<Long> serviceIdList = new ArrayList<Long>();
	
	if(!StringUtils.isEmpty(request.getCategoryId())) {
	  ServiceCategory serviceCategory  =serviceCategoryRepository.findOne(request.getCategoryId());
    	  
	  	if(serviceCategory!=null) {
    		cloudServices = serviceCategory.getCloudServices();
    	  }
    	  if(CollectionUtils.isEmpty(cloudServices)) {
    		serviceIdList.add(0L);
    	  }
	}
	 for (CloudService cloudService : NepheleValidationUtils.nullSafe(cloudServices)) {
	   serviceIdList.add(cloudService.getId());
	  }
	  
     //  Filter 3  ServiceId Filter	
	/*if(!StringUtils.isEmpty(request.getServiceId())) {
	  serviceIdList.add(request.getServiceId());
	}*/
	
	//CloudAccountServerViewSpecifications

	List <CloudAccountServerView>  cloudAccountServerViewList =	accountServerViewRepository.findAll(CloudAccountServerViewSpecifications.findAccountServersStatusByFilter(customerCompanyIdList, serviceIdList,request.getServiceId(),null,request.getStatus()));
	
   	Map<String, Long> statusMapTemp = buildStatusMapFromList( cloudAccountServerViewList);
	setUnavailableServersStatus(statusMapTemp);
	
	log.debug("readServerSummaryByCustomer() - end");
	return statusMapTemp;
  }

 

  // New 
  @Override
  public Map<String, Long> readServerSummaryByReseller(ReadServersEvent request) {
	log.debug("readServerSummaryByReseller() -start");
	
	Set <CloudService> cloudServices = null;
	
	//Filter - 1  - Reseller Code filter
	Long cloudResellerCompanyId =null;
	if(!StringUtils.isEmpty(request.getExternalResellerCode())) {
	  cloudResellerCompanyId = resellerCompanyRepository.findIdByExternalResellerCode(request.getExternalResellerCode());
	}
	List<Long> customerCompanyIds =null;
	
	if(cloudResellerCompanyId!=null) {
	  customerCompanyIds = customerCompanyRepository.findCustomerIdByResellerId(cloudResellerCompanyId);
	}
	
	List<Long> customerCompanyIdList = new ArrayList<>();
	
	if(!CollectionUtils.isEmpty(customerCompanyIds)) {
	  customerCompanyIdList.addAll(customerCompanyIds);
	}
	
	// Filter - 2  Customer code filter
	Long  cloudCustomerCompanyId =null;
	if(!StringUtils.isEmpty(request.getExternalCustomerCode())) {
	  cloudCustomerCompanyId = 	customerCompanyRepository.findIdByExternalCustomerCode(request.getExternalCustomerCode());
	  if(cloudCustomerCompanyId==null) {
		cloudCustomerCompanyId=0L;
	  }else {
		customerCompanyIdList.add(cloudCustomerCompanyId);
	  }
		
	}
	
	// Filter - 3 Category Id filter 
	
	List<Long> serviceIdList = new ArrayList<Long>();
	
	if(!StringUtils.isEmpty(request.getCategoryId())) {
	  ServiceCategory serviceCategory  =serviceCategoryRepository.findOne(request.getCategoryId());
    	  if(serviceCategory!=null) {
    		cloudServices = serviceCategory.getCloudServices();
    	  }
    	  if(CollectionUtils.isEmpty(cloudServices)) {
    		serviceIdList.add(0L);
    	  }
	}
	 for (CloudService cloudService : NepheleValidationUtils.nullSafe(cloudServices)) {
	   serviceIdList.add(cloudService.getId());
	  }
	  
     //  Filter 4  ServiceId Filter	

	  List <CloudAccountServerView>  cloudAccountServerViewList =	accountServerViewRepository.findAll(CloudAccountServerViewSpecifications.findAccountServersStatusByFilter(customerCompanyIdList, serviceIdList,request.getServiceId(),cloudCustomerCompanyId,request.getStatus()));
	
   	Map<String, Long> statusMapTemp = buildStatusMapFromList( cloudAccountServerViewList);
	setUnavailableServersStatus(statusMapTemp);
	
	log.debug("readServerSummaryByReseller() -end");
	return statusMapTemp;
  }

  
  private Map<String, Long> buildStatusMapFromList(List<CloudAccountServerView> cloudAccountServerViewList) {
	long total = 0;
	Map<String, Long> statusMapTemp = new HashMap<String, Long>();
	for (CloudAccountServerView view : NepheleValidationUtils.nullSafe(cloudAccountServerViewList)) {
	  if (view != null) {
		if (statusMapTemp.containsKey(view.getNepheleStatus())) {
		  
		  statusMapTemp.put(view.getNepheleStatus(), statusMapTemp.get(view.getNepheleStatus()) + 1);
		} else {
		  
		  statusMapTemp.put(view.getNepheleStatus(), 1L);
		}
	  }

	  total++;
	}
	statusMapTemp.put("TOTAL", total);
	return statusMapTemp;
  }
  private void setUnavailableServersStatus(Map<String, Long> resultMap) {
	if (!resultMap.containsKey(NepheleServerStatus.ACTIVE.name())) {
	  resultMap.put(NepheleServerStatus.ACTIVE.name(), 0L);
	}

	if (!resultMap.containsKey(NepheleServerStatus.ERROR.name())) {
	  resultMap.put(NepheleServerStatus.ERROR.name(), 0L);
	}
	if (!resultMap.containsKey(NepheleServerStatus.PENDING.name())) {
	  resultMap.put(NepheleServerStatus.PENDING.name(), 0L);
	}

	if (!resultMap.containsKey(NepheleServerStatus.PENDING_USER_ACTION.name())) {
	  resultMap.put(NepheleServerStatus.PENDING_USER_ACTION.name(), 0L);
	}

	

  }

  
}
