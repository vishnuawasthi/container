package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
public class CloudResellerCompanyDetails {

	private Long resellerCompanyId;
	private String resellerCompanyName;
	private Long distributorCompanyId;
	private String firstName;
	private String lastName;
	private String email;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String country;
	private String zipCode;
	private Long resellerPremiumGroupId;
	private String resellerPremiumGroupName;
	private String externalResellerCompanyCode;
	private Date created;
	private Date updated;
	private Boolean isActive;
	private String creditCardToken; 
	private Boolean accountHoldStatus;
	//private Date creditCardExpiryDate;
	 private Integer creditCardExpiryYear;
    private Integer creditCardExpiryMonth;
    private String abnNumber;
    private String terrCode;
    private String creditCardType;
    private String salesPerson;
    private String countryCodeUN;
    private String countryCodeISO;
	
	 
}
