package com.valuelabs.nephele.admin.rest.lib.resource;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class StartPlanResource extends ResourceSupport {

	private Long planId;
	private String price;
	private String planCode;
	private String pricingModel;
	
}
