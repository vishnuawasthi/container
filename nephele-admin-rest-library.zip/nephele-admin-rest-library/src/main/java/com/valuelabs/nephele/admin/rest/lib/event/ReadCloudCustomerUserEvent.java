package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudCustomerUserEvent extends ReadEntityEvent<ReadCloudCustomerUserEvent>{

	private Long customerId;
	private String customerName;
    private Long cloudCustomerCompanyId;
}
