package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain=true)
public class RackspacePollingServerDetails {

	private String locationCode;
	
	private Long locationId;
	
	private Long configurationId;

	private Long serverId;
	
	private Long serverActionId;
	
	private String cspServerId;
	
	private Long productId;
	
	private String poolingAction;
	
	private Long orderId;
	
	private Long serviceId;
	
	private Boolean isServerDeleted;
	
	private Long resellerCompanyId;
	
	private String externalResellerCompanyCode;
	
	private String resellerEmail;
	
	private Long planId;
	
	private Boolean confirmResize;
	
	private Long cpu;
	
	private Long ram;
	
	private Long disk;
}
