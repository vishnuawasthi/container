package com.valuelabs.nephele.admin.rest.lib.domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;
import lombok.*;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Accessors(chain = true)
public class CloudInvoiceDetails {

  private Long cloudInvoiceId;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date closedDate;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date createdDate;
  private String invoiceNumber;
  private boolean isOverdue;
  private String currency;
	private Date dueDate;
  private Double grossTotal = 0.0D;
  private Boolean closed;
  private Double netTotal = 0.0D;
  private Double total = 0.0D;
  private Double tax = 0.0D;
  private String taxDescription;
  private Double discountAmount = 0.0D;
  private Double discountPercentage = 0.0D;
  private String status;
  private Long cloudResellerId;
  private Date fromDate;
  private Date toDate;
  private CloudCompanyDetails cloudResellerCompanyDetails;
  private CloudCustomerCompanyDetails customerCompanyDetails;
  private Set<CloudInvoiceLineDetails> cloudResellerInvoiceLineDetails;
  private Set<CloudInvoiceDiscountLineDetail> discountLineDetailSet;
  private Integer numberOfRecords;
  private String sortBy;
  private String paymentTerm;
  private String userId;
  private String userName;
  private String companyCode;
  private String firstName;
  private String lastName;
  private String email;
  private String addressLine1;
  private String addressLine2;
  private String city;
  private String state;
  private String country;
  private String distributor;
  private String taxPercentage;
  private CloudDistributorDetail cloudDistributorResource;
  private Set<CloudPaymentDetails> cloudPaymentDetails;
}