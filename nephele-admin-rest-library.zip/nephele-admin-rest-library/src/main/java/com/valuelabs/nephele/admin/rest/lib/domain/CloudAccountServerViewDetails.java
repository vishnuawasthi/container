package com.valuelabs.nephele.admin.rest.lib.domain;




import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Accessors(chain = true)
public class CloudAccountServerViewDetails {
	
	private Long resourceId;
	private Long customerId;
	private String customerName;
	private String description;
	private String integrationCode;
	private String vendorStatus;
	private String nepheleStatus;
	private String categoryName;
	private Date provisionDate;
	private String resourceType;
	
    private String customerCode;
    private Long planId;
    private String planName;
    private String planCode;
    private String productName;
    private Long productId;
	
	
	
	/*private Long serverId;
	private Long productId;
	private String name;
	private String description;
	private String status;
	private String vendorStatus;
	private String uri;
	private String serverGroup;
	private String username;
	private String publicIPv4Address;
	private String publicIPv6Address;
	private String privateIPv4Address;
	private String privateIPv6Address;
	private String password;
	private String cspServerId;
	private Long locationId;
	private String locationName;
	private String flavorCategory;
	private Long serviceId;
	private Long customerId;
	private String customerName;
	private Long planId;
	private Long planRam;
    private Long cloudServiceId;
    private Long cloudOrderId;
    private String cloudServiceName;
    private String brandCode;
	private String brandName;
    private String integrationCode;
    private Date dateRangeStart;
	private Date dateRangeEnd;
	private Date creationDate;
	private String categoryName;
	private String remarks;*/
}



