package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.rest.lib.event.CloudAdditionalPriceCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudAdditionalPriceEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface CloudAdditionalPriceCommandService {
	CloudAdditionalPriceCreatedEvent createCloudAdditionalPrice(CreateCloudAdditionalPriceEvent request)throws IllegalArgumentException;
	CloudAdditionalPriceCreatedEvent updateCloudAdditionalPrice(CreateCloudAdditionalPriceEvent request)throws ResourceNotFoundException,IllegalArgumentException;
	public String getAdditionalPriceCodePatternSequenceValue(CloudService cloudService);
}
