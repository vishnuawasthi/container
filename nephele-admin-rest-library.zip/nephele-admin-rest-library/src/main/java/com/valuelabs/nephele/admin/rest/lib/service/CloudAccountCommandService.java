package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.event.CloudAccountCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface CloudAccountCommandService {

  CloudAccountCreatedEvent createCloudAccount(CreateCloudAccountEvent request)throws IllegalArgumentException, InterruptedException;
  CloudAccountCreatedEvent updateCloudAccount(CreateCloudAccountEvent request)throws ResourceNotFoundException,IllegalArgumentException;
}
