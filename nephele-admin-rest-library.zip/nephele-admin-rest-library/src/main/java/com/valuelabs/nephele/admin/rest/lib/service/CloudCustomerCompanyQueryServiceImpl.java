package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanyRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCustomersCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import static com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanySpecifications.*;

@Slf4j
@Service
public class CloudCustomerCompanyQueryServiceImpl implements CloudCustomerCompanyQueryService {

	/*@Autowired
	private CloudCustomerCompanyDAO customerCompanyDAO;*/
	
	@Autowired
	private CloudCustomerCompanyRepository customerCompanyRepository;
	
	
	@Override
	public EntityReadEvent<CloudCustomerCompanyDetails> readCustomerCompany(ReadCloudCustomerCompanyEvent request) {
		log.debug("readCustomerCompany() START ");
		CloudCustomerCompany record = customerCompanyRepository.findOne(request.getCustomerCompanyId());
		if (null == record) {
			log.debug("Service with ServiceId {} not found.", request.getCustomerCompanyId());
			return EntityReadEvent.<CloudCustomerCompanyDetails> notFound();
		}
		CloudCustomerCompanyDetails customerCompanyDetails = CloudCustomerCompanyDetails.builder().customerCompanyId(record.getId())
				.firstName(record.getFirstName()).lastName(record.getLastName()).email(record.getEmail()).addressLine1(record.getAddressLine1())
				.addressLine2(record.getAddressLine2()).city(record.getCity()).state(record.getState()).zipcode(record.getZipcode())
				.country(record.getCountry()).customerCompanyName(record.getCustomerCompanyName())
				.cloudResellerCompanyId(record.getCloudResellerCompany().getId()).externalCustomerCompanyCode(record.getCustomerCompanyCode())
				.externalResellerCompanyCode(record.getCloudResellerCompany().getResellerCompanyCode()).isActive(record.getIsActive())
				.businessContactname(record.getBusinessContactname())
				.businessContactEmail(record.getBusinessContactEmail())
				.abnNumber(record.getAbnNumber())
				.acnNumber(record.getAcnNumber())
				.phoneNumber(record.getPhoneNumber())
				.countryCodeISO(record.getCountryCodeISO())
				.countryCodeUN(record.getCountryCodeUN())
				.build();
		log.debug("readCustomerCompany() START ");
		return new EntityReadEvent<>(customerCompanyDetails);
	}

	@Override
	public PageReadEvent<CloudCustomerCompanyDetails> readCustomersCompany(ReadCloudCustomersCompanyEvent request) {
		log.debug("readCustomerCompanies() START ");
		List<CloudCustomerCompany> dbContent = new ArrayList<>();
		dbContent = customerCompanyRepository.findAll();
		List<CloudCustomerCompanyDetails> content = new ArrayList<>();
		long total = 0;
		for (CloudCustomerCompany record : NepheleValidationUtils.nullSafe(dbContent)) {
			if (total >= request.getPageable().getOffset() && total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
				CloudCustomerCompanyDetails customerCompanyDetails = CloudCustomerCompanyDetails.builder().customerCompanyId(record.getId())
						.firstName(record.getFirstName()).lastName(record.getLastName()).email(record.getEmail()).addressLine1(record.getAddressLine1())
						.addressLine2(record.getAddressLine2()).city(record.getCity()).state(record.getState()).zipcode(record.getZipcode())
						.country(record.getCountry()).customerCompanyName(record.getCustomerCompanyName())
						.cloudResellerCompanyId(record.getCloudResellerCompany().getId()).externalCustomerCompanyCode(record.getCustomerCompanyCode())
						.externalResellerCompanyCode(record.getCloudResellerCompany().getResellerCompanyCode()).isActive(record.getIsActive())
						.businessContactname(record.getBusinessContactname())
						.businessContactEmail(record.getBusinessContactEmail())
						.abnNumber(record.getAbnNumber())
						.acnNumber(record.getAcnNumber())
						.phoneNumber(record.getPhoneNumber())
						.countryCodeISO(record.getCountryCodeISO())
						.countryCodeUN(record.getCountryCodeUN())
						.build();
				content.add(customerCompanyDetails);
			}
			++total;
		}
		// Long total=(long) dbContent.size();
		Page<CloudCustomerCompanyDetails> page = new PageImpl<>(content, request.getPageable(), total);
		log.debug("readCustomerCompanies() END ");
		return new PageReadEvent<>(page);
	}

	@Override
	public CloudCustomerCompany findByCloudCustomerCompanyCode(
			String customerCompanyCode) throws Exception{
		log.debug("findByCloudCustomerCompanyCode() - start");		
		CloudCustomerCompany entity = customerCompanyRepository.findOne(findCustomerCompany(customerCompanyCode));
		if(entity == null )
			throw new ResourceNotFoundException("customerCompanyRepository resource not found for externalCustomerCompanyCode : " +customerCompanyCode);
		log.debug("findByCloudCustomerCompanyCode() - end");		
		
		return entity;
	}
	
	@Override
	public CloudCustomerCompany findByExternalCompanyCode(String customerCompanyCode){
		log.info("findByExternalCompanyCode() - start");
		CloudCustomerCompany customerCompany = CloudCustomerCompany.builder().build();
		List<Object[]> customerDetails = customerCompanyRepository.findByExternalCompanyCode(customerCompanyCode);
		if(!CollectionUtils.isEmpty(customerDetails)){
			for (Object obj[] : customerDetails) {
				customerCompany.setId((Long) obj[0]);
				customerCompany.setCustomerCompanyName((String) obj[1]);
				customerCompany.setCustomerCompanyCode((String) obj[2]);
		      }
		}
		log.info("findByExternalCompanyCode() - end");
		return customerCompany;
	}
}
