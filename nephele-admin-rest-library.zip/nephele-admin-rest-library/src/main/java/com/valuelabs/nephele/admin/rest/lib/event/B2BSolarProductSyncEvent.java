package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductSyncDetails;

//@Data
@Setter
@Getter
@Accessors(chain = true)
@ToString
//@EqualsAndHashCode(callSuper = false)
public class B2BSolarProductSyncEvent {
	private List<CloudProductDetails> productListDetails;
	private BundleDetails bundleDetails;
	private List<BundleDetails> bundleListDetails;
	private ExternalProductSyncDetails externalProductSyncDetails;
}
