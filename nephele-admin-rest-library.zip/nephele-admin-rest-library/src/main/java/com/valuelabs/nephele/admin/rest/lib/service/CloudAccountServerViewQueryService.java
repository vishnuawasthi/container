package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.Map;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountServerViewDetails;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadAccountServerViewEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServersEvent;

public interface CloudAccountServerViewQueryService {
	
	PageReadEvent<CloudAccountServerViewDetails> readAccountServerViewByFilter(ReadAccountServerViewEvent request);
	
	 //Map<String, Long> readServerSummaryByCustomerIdAndServiceId(ReadServersEvent request);
	 
	 //Map<String, Long> readServerSummaryByResellerAndServiceId(ReadServersEvent request);
	 
	 Map<String, Long> readServerSummaryByCustomer(ReadServersEvent request);
	 
	 Map<String, Long> readServerSummaryByReseller(ReadServersEvent request);
	 

}
