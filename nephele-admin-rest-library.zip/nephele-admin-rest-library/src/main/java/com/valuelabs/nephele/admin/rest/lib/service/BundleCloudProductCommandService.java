package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface BundleCloudProductCommandService {
	void deleteBundleCloudProduct(Long id) throws ResourceNotFoundException, IllegalArgumentException; 
}
