package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.NepheleCurrency;
import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRate;
import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRateAudit;
import com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateAuditRepository;
import com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudCurrencyConversionRateCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudCurrencyConversionRateEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CloudCurrencyConversionRateCommandServiceImpl implements CloudCurrencyConversionRateCommandService {

	@Autowired
	private CloudCurrencyConversionRateRepository rateRepository;

	@Autowired
	private CloudCurrencyConversionRateAuditRepository rateAuditRepository;

	@Override
	public CloudCurrencyConversionRateCreatedEvent createCloudCurrencyConversionRate(
			CreateCloudCurrencyConversionRateEvent request) throws IllegalArgumentException {
		log.debug("createCloudCurrencyConversionRate() -start");
		CloudCurrencyConversionRateDetails details = request.getDetails();
		CloudCurrencyConversionRate entity = CloudCurrencyConversionRate.builder()
				.conversionRate(details.getConversionRate())
				.sourceCurrency(NepheleCurrency.valueOf(details.getSourceCurrency()))
				.targetCurrency(NepheleCurrency.valueOf(details.getTargetCurrency())).build();
		rateRepository.save(entity);

		if (entity.getConversionRate()!=null&&entity.getConversionRate()>0.00) {
			CloudCurrencyConversionRateAudit auditEntity = CloudCurrencyConversionRateAudit.builder()
					.conversionRate(details.getConversionRate()).createdOn(new Date())
					.cloudCurrencyConversionRate(entity).build();
			rateAuditRepository.save(auditEntity);
		}

		log.debug("createCloudCurrencyConversionRate() -end");
		return new CloudCurrencyConversionRateCreatedEvent(details);
	}

	@Override
	public CloudCurrencyConversionRateCreatedEvent updateCloudCurrencyConversionRate(
			CreateCloudCurrencyConversionRateEvent request) throws ResourceNotFoundException, IllegalArgumentException {
		log.debug("updateCloudCurrencyConversionRate() -start");
		CloudCurrencyConversionRateDetails details = request.getDetails();

		CloudCurrencyConversionRate entity = rateRepository.findOne(details.getId());

		if (entity == null) {

			throw new ResourceNotFoundException("CloudCurrencyConversionRate", details.getId());

		} else {

			if (!StringUtils.isEmpty(details.getConversionRate())) {
				entity.setConversionRate(details.getConversionRate());

				CloudCurrencyConversionRateAudit auditEntity = CloudCurrencyConversionRateAudit.builder()
						.conversionRate(details.getConversionRate()).createdOn(new Date())
						.cloudCurrencyConversionRate(entity).build();
				rateRepository.save(entity);
				rateAuditRepository.save(auditEntity);
			}

		}
		log.debug("updateCloudCurrencyConversionRate() -end");
		return new CloudCurrencyConversionRateCreatedEvent(details);
	}

	@Override
	public CloudCurrencyConversionRateCreatedEvent deleteCloudCurrencyConversionRate(
			CreateCloudCurrencyConversionRateEvent request) throws ResourceNotFoundException, IllegalArgumentException {
		log.debug("deleteCloudCurrencyConversionRate() -start");
		CloudCurrencyConversionRateDetails details = request.getDetails();
		rateRepository.delete(details.getId());
		log.debug("deleteCloudCurrencyConversionRate() -end");
		return new CloudCurrencyConversionRateCreatedEvent(details);
	}

}
