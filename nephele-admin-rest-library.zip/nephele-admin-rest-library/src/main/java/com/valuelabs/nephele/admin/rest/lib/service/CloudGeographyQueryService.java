package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudGeographyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudGeographiesEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudGeographyEvent;

public interface CloudGeographyQueryService {
	EntityReadEvent<CloudGeographyDetails> readCloudGeography(
			ReadCloudGeographyEvent request);

	PageReadEvent<CloudGeographyDetails> readCloudGeographies(
			ReadCloudGeographiesEvent requst);
	
	EntityReadEvent<CloudGeographyDetails> readCloudGeographyByLocationCode(ReadCloudGeographyEvent request);
			

}
