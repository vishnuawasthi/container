package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceConfigurationDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CreateCloudRackspaceConfigurationEvent {
	private CloudRackspaceConfigurationDetails cloudRackspaceConfigurationDetails;
	private List<CloudRackspaceConfigurationDetails> cloudRackspaceConfigurationDetailsList;
	
}
