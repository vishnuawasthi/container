package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.cloud.dbs.integration.datamodel.DbsInvoiceDetail;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * Created by snagaboina on 4/12/15.
 */
@Data
@Accessors(chain = true)
public class DbsInvoiceIntegrationEvent {

  private List<DbsInvoiceDetail> invoiceDetailList;

  private String messageId;
}
