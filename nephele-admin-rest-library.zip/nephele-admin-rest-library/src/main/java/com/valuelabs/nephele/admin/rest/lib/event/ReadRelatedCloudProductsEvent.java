package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadRelatedCloudProductsEvent extends ReadPageEvent<ReadRelatedCloudProductsEvent>{
	
	private Long id;
	private List< Long> ids;
	private Long cloudProductId;
	private List<Long> cloudProductIds;
	private Long relatedCloudProductId;
	
}
