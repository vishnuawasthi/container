package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudUserRoleDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CloudUserRoleCreatedEvent {
	
	private CloudUserRoleDetails cloudUserRoleDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudUserRoleCreatedEvent(CloudUserRoleDetails cloudUserRoleDetails) {
		this.cloudUserRoleDetails = cloudUserRoleDetails;
	}
	
	public static CloudUserRoleCreatedEvent invalid(CloudUserRoleDetails cloudUserRoleDetails) {
		CloudUserRoleCreatedEvent event = new CloudUserRoleCreatedEvent(cloudUserRoleDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudUserRoleCreatedEvent failed(CloudUserRoleDetails cloudUserRoleDetails) {
		CloudUserRoleCreatedEvent event = new CloudUserRoleCreatedEvent(cloudUserRoleDetails);
		event.setFailed(true);
		return event;
	}

}
