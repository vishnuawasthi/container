package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.fasterxml.jackson.annotation.JsonInclude;


@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudSoftlayerDiskConfigurationDetails {
  private Long id;
  private Double hourlyRecurringFee;
  private String description;
  private Long capacity;
  private String status;
  private String device;
  private Boolean localDiskFlag;

}
