package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;
import com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanyRepository;
import com.valuelabs.nephele.admin.data.repository.CloudResellerCompanyRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudCustomerCompanyCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.DeleteCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.event.UpdateCloudCustomerCompanyEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.NepheleException;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;

@Slf4j
@Service
@Transactional
public class CloudCustomerCompanyCommandServiceImpl implements CloudCustomerCompanyCommandService {
	
	@Autowired
	private CloudCustomerCompanyRepository customerCompanyRepository;
	
	@Autowired
	private CloudResellerCompanyRepository resellerCompanyRepository;
	
	@Override
	public CloudCustomerCompanyCreatedEvent createCloudCustomerCompany(CreateCloudCustomerCompanyEvent request) throws IllegalArgumentException {
		log.debug("CreateCloudCustomerCompany() START");
		CloudCustomerCompanyDetails details = request.getCustomerCompanyDetails();
		CloudCustomerCompany entity = CloudCustomerCompany.builder()
				.customerCompanyName(details.getCustomerCompanyName())
				.firstName(details.getFirstName())
				.lastName(details.getLastName())
				.email(details.getEmail())
				.addressLine1(details.getAddressLine1())
				.addressLine2(details.getAddressLine2())
				.city(details.getCity())
				.zipcode(details.getZipcode())/*.cloudResellerCompany(cloudResellerCompanyDAO.findOne(details.getCloudResellerCompanyId()))*/
				.state(details.getState())
				.country(details.getCountry())
				.customerCompanyCode(details.getExternalCustomerCompanyCode())
				.isActive(details.getIsActive())
				.businessContactname(details.getBusinessContactname())
				.businessContactEmail(details.getBusinessContactEmail())
				.abnNumber(details.getAbnNumber())
				.acnNumber(details.getAcnNumber())
				.phoneNumber(details.getPhoneNumber())
				.countryCodeISO(details.getCountryCodeISO())
				.countryCodeUN(details.getCountryCodeUN())
				.build();
		customerCompanyRepository.save(entity);
		details.setCustomerCompanyId(entity.getId());
		log.debug("entity.getId()"+entity.getId());
		log.debug("CreateCloudCustomerCompany() END");
		return new CloudCustomerCompanyCreatedEvent(details);
	}

	// To update existence entity
	@Override
	public CloudCustomerCompanyCreatedEvent updateCloudCustomerCompany(CreateCloudCustomerCompanyEvent request) throws Exception {
		log.debug("updateCloudCustomerCompany() START");

		CloudCustomerCompanyDetails details = request.getCustomerCompanyDetails();
		CloudCustomerCompany entity= customerCompanyRepository.findByExternalCustomerCode(details.getExternalCustomerCompanyCode());
		
		if(entity == null )
			throw new ResourceNotFoundException("Resource not found for externalCustomerCompanyCode : " +details.getExternalCustomerCompanyCode());
		
		/*if (CollectionUtils.isEmpty(entityList)) {
			throw new ResourceNotFoundException("CloudCustomerCompany", details.getExternalCustomerCompanyCode());
		}*/
		//CloudCustomerCompany entity=entityList.get(0);
		//entity.setId(details.getCustomerCompanyId());
		if(!StringUtils.isEmpty(details.getCustomerCompanyName()) && !details.getCustomerCompanyName().equals(entity.getCustomerCompanyName())){
		entity.setCustomerCompanyName(details.getCustomerCompanyName());
		}
		if(!StringUtils.isEmpty(details.getFirstName())){
			entity.setFirstName(details.getFirstName());
			}
		if(!StringUtils.isEmpty(details.getLastName())){
			entity.setLastName(details.getLastName());
			}
		if(!StringUtils.isEmpty(details.getEmail())){
			entity.setEmail(details.getEmail());
			}
		if(!StringUtils.isEmpty(details.getAddressLine1())){
			entity.setAddressLine1(details.getAddressLine1());
			}
		if(!StringUtils.isEmpty(details.getAddressLine2())){
			entity.setAddressLine2(details.getAddressLine2());
			}
		if(!StringUtils.isEmpty(details.getCity())){
			entity.setCity(details.getCity());
			}
		if(!StringUtils.isEmpty(details.getState())){
			entity.setState(details.getState());
			}
		if(!StringUtils.isEmpty(details.getCountry())){
			entity.setCountry(details.getCountry());
			}
		if(!StringUtils.isEmpty(details.getZipcode())){
			entity.setZipcode(details.getZipcode());
			}
		if(details.getIsActive()){
			entity.setIsActive(true);
		}
		if(!StringUtils.isEmpty(details.getBusinessContactname())){
			entity.setBusinessContactname(details.getBusinessContactname());
		}
		if(!StringUtils.isEmpty(details.getBusinessContactEmail())){
			entity.setBusinessContactEmail(details.getBusinessContactEmail());
		}
		if(!StringUtils.isEmpty(details.getAbnNumber())){
			entity.setAbnNumber(details.getAbnNumber());
		}
		if(!StringUtils.isEmpty(details.getAcnNumber())){
			entity.setAcnNumber(details.getAcnNumber());
		}
		if(!StringUtils.isEmpty(details.getPhoneNumber())){
			entity.setPhoneNumber(details.getPhoneNumber());
		}
		if(!StringUtils.isEmpty(details.getCountryCodeISO()))
			entity.setCountryCodeISO(details.getCountryCodeISO());
		
		if(!StringUtils.isEmpty(details.getCountryCodeUN()))
			entity.setCountryCodeUN(details.getCountryCodeUN());
		customerCompanyRepository.save(entity);
		log.debug("updateCloudCustomerCompany() END");
		return new CloudCustomerCompanyCreatedEvent(details);
	}

	@Override
	public CloudCustomerCompanyCreatedEvent updateCloudCustomerCompanies(UpdateCloudCustomerCompanyEvent request)
			throws Exception {
		log.debug("updateCloudCustomerCompanies() START");
		List<CloudCustomerCompanyDetails> updateList=request.getCustomerCompanyDetailsList();
		List<CloudCustomerCompany> requestUpdate=new ArrayList<>();
		for(CloudCustomerCompanyDetails details:  NepheleValidationUtils.nullSafe(updateList)){
			CloudCustomerCompany entity= customerCompanyRepository.findByExternalCustomerCode(details.getExternalCustomerCompanyCode());
			
			if(entity == null)
				throw new ResourceNotFoundException("Resource not found for externalCustomerCompanyCode : " +details.getExternalCustomerCompanyCode());
			
			if(!StringUtils.isEmpty(details.getCustomerCompanyName()) && !details.getCustomerCompanyName().equals(entity.getCustomerCompanyName())){
			entity.setCustomerCompanyName(details.getCustomerCompanyName());
			}
			if(!StringUtils.isEmpty(details.getFirstName())){
				entity.setFirstName(details.getFirstName());
				}
			if(!StringUtils.isEmpty(details.getLastName())){
				entity.setLastName(details.getLastName());
				}
			if(!StringUtils.isEmpty(details.getEmail())){
				entity.setEmail(details.getEmail());
				}
			if(!StringUtils.isEmpty(details.getAddressLine1())){
				entity.setAddressLine1(details.getAddressLine1());
				}
			if(!StringUtils.isEmpty(details.getAddressLine2())){
				entity.setAddressLine2(details.getAddressLine2());
				}
			if(!StringUtils.isEmpty(details.getCity())){
				entity.setCity(details.getCity());
				}
			if(!StringUtils.isEmpty(details.getState())){
				entity.setState(details.getState());
				}
			if(!StringUtils.isEmpty(details.getCountry())){
				entity.setCountry(details.getCountry());
				}
			if(!StringUtils.isEmpty(details.getZipcode())){
				entity.setZipcode(details.getZipcode());
				}
			if(details.getIsActive()){
				entity.setIsActive(true);
			}
			
			if(!StringUtils.isEmpty(details.getBusinessContactname())){
				entity.setBusinessContactname(details.getBusinessContactname());
			}
			if(!StringUtils.isEmpty(details.getBusinessContactEmail())){
				entity.setBusinessContactEmail(details.getBusinessContactEmail());
			}
			if(!StringUtils.isEmpty(details.getAbnNumber())){
				entity.setAbnNumber(details.getAbnNumber());
			}
			if(!StringUtils.isEmpty(details.getAcnNumber())){
				entity.setAcnNumber(details.getAcnNumber());
			}
			if(!StringUtils.isEmpty(details.getPhoneNumber())){
				entity.setPhoneNumber(details.getPhoneNumber());
			}
			if(!StringUtils.isEmpty(details.getCountryCodeISO()))
				entity.setCountryCodeISO(details.getCountryCodeISO());
			
			if(!StringUtils.isEmpty(details.getCountryCodeUN()))
				entity.setCountryCodeUN(details.getCountryCodeUN());
			
			requestUpdate.add(entity);
			
		}
		customerCompanyRepository.save(requestUpdate);
		log.debug("updateCloudCustomerCompanies() END");
		
		return null;
	}
	@Override
	public CloudCustomerCompanyCreatedEvent createCloudCustomerCompanies(CreateCloudCustomerCompanyEvent request) throws IllegalArgumentException {
		log.debug("createCloudCustomerCompanies() - start");
		List<CloudCustomerCompanyDetails> detailsList = request.getCustomerCompanyDetailsList();
		List<CloudCustomerCompany> entityList = new ArrayList<CloudCustomerCompany>();
		
		for (CloudCustomerCompanyDetails details : NepheleValidationUtils.nullSafe(detailsList)) {
			CloudResellerCompany cloudResellerCompany=resellerCompanyRepository.findByExternalResellerCode(details.getExternalResellerCompanyCode());
			if(null == cloudResellerCompany){
				throw new ResourceNotFoundException("CloudResellerCompany", details.getExternalResellerCompanyCode());
			}
			CloudCustomerCompany entity = CloudCustomerCompany.builder().customerCompanyName(details.getCustomerCompanyName())
					.firstName(details.getFirstName())
					.lastName(details.getLastName())
					.email(details.getEmail())
					.addressLine1(details.getAddressLine1())
					.addressLine2(details.getAddressLine2())
					.city(details.getCity())
					.zipcode(details.getZipcode())
					.cloudResellerCompany(cloudResellerCompany)
					.state(details.getState()).country(details.getCountry())
					.customerCompanyCode(details.getExternalCustomerCompanyCode())
					.isActive(details.getIsActive())
					.businessContactname(details.getBusinessContactname())
					.businessContactEmail(details.getBusinessContactEmail())
					.abnNumber(details.getAbnNumber())
					.acnNumber(details.getAcnNumber())
					.phoneNumber(details.getPhoneNumber())
					.countryCodeISO(details.getCountryCodeISO())
					.countryCodeUN(details.getCountryCodeUN())
					.build();
			entityList.add(entity);
		}

		customerCompanyRepository.save(entityList);
		log.debug("createCloudCustomerCompanies() - end");
		return null;
	}

	@Override
	public void deleteCustomerCompany(DeleteCustomerCompanyEvent request) throws Exception {

		log.debug("deleteCustomerCompany() - start");

		if (!StringUtils.isEmpty(request.getExternalCustomerCompanyCode())) {
			deleteCustomerCompanyUsingCode(request
					.getExternalCustomerCompanyCode());
		}
		if (!CollectionUtils.isEmpty(request.getCustomerCompanyDetailsList())) {
			for (CloudCustomerCompanyDetails company : request.getCustomerCompanyDetailsList()) {
				deleteCustomerCompanyUsingCode(company.getExternalCustomerCompanyCode());
			}
		}

		log.debug("deleteCustomerCompany() - end");

	}

	public void deleteCustomerCompanyUsingCode(
			String externalCustomerCompanyCode) throws Exception {
		log.debug("deleteCustomerCompanyUsingCode() - start");
		CloudCustomerCompany entity = null;
		try {
			    entity = customerCompanyRepository.findByExternalCustomerCode(externalCustomerCompanyCode);
			if(entity == null)
				throw new ResourceNotFoundException("Resource not found for externalCustomerCompanyCode : " +externalCustomerCompanyCode);
		} catch (NoResultException e) {
			throw new ResourceNotFoundException("CloudCustomerCompany",externalCustomerCompanyCode);
		}
		try {
			if (entity.getIsActive()) {
				entity.setIsActive(false);
			}
		} catch (Exception e) {
			throw new NepheleException("Unable to delete customer company");
		}
		log.debug("deleteCustomerCompanyUsingCode() - end");
	}

}
