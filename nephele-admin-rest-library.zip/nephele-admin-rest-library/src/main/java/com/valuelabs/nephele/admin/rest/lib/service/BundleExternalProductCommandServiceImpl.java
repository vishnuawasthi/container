package com.valuelabs.nephele.admin.rest.lib.service;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.entity.BundleExternalProduct;
import com.valuelabs.nephele.admin.data.repository.BundleExternalProductRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.BundleExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.BundleExternalProductCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateBundleExternalProductEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

@Slf4j
@Service
public class BundleExternalProductCommandServiceImpl implements BundleExternalProductCommandService{
	
	@Autowired
	private BundleExternalProductRepository bundleExternalProductRepository;

	@Override
	public BundleExternalProductCreatedEvent createBundleExternalProduct(CreateBundleExternalProductEvent request)throws IllegalArgumentException {
		log.debug("createBundleExternalProduct() START");
		BundleExternalProductDetails details = request.getBundleExternalProductDetails();
		BundleExternalProduct entity = BundleExternalProduct.builder()
									//.externalProducts(details.getExternalProducts())
									.build();

		
		bundleExternalProductRepository.save(entity);
		log.debug("BundleExternalProduct Id {} :", entity.getId());
		details.setBundleExternalProductId(entity.getId());
		log.debug("createBundleExternalProduct() END");
		return new BundleExternalProductCreatedEvent(details);
	}

	
	@Override	
	public void deleteBundleExternalProduct(Long id) throws ResourceNotFoundException, IllegalArgumentException{
			log.debug("deleteBundleExternalProduct()  - START");
			BundleExternalProduct entity = bundleExternalProductRepository.findOne(id);
			if(entity == null){
				throw new ResourceNotFoundException("Resource not found");
			}
			bundleExternalProductRepository.delete(id);
			log.debug("deleteBundleExternalProduct()  - END");
		}

}
