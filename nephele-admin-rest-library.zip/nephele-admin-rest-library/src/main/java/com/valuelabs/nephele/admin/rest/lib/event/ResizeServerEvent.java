package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
@Accessors(chain = true)
public class ResizeServerEvent {

	private Long serverId;
	private String serverName;
	private String flavourId;
	private Long planId;
	private Long serverActionId;
	private Long serviceId;
	private String cspServerId;
	private Long locationId;
	private Long cloudServiceId;
	private Long resellerCompanyId;
	private String externalResellerCompanyCode;
	private String resellerEmail;
	private Integer ram;
	private Boolean confirmResize;
}
