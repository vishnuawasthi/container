package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudOperatingSystemEvent {
	
	private CloudOperatingSystemDetails CloudOperatingSystemDetails;
	private List<CloudOperatingSystemDetails> cloudOperatingSystemDetailsList;

}
