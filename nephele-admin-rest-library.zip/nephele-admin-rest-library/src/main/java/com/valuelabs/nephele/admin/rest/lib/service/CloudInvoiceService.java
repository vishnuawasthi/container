package com.valuelabs.nephele.admin.rest.lib.service;

import com.google.gson.Gson;
import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.valuelabs.nephele.admin.data.api.*;
import com.valuelabs.nephele.admin.data.common.ReadCloudInvoice;
import com.valuelabs.nephele.admin.data.entity.*;
import com.valuelabs.nephele.admin.data.repository.*;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;
import com.valuelabs.nephele.admin.rest.lib.constants.NepheleConstants;
import com.valuelabs.nephele.admin.rest.lib.domain.*;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudInvoicesEvent;
import com.valuelabs.nephele.admin.rest.lib.resource.CloudDistributorResource;
import com.valuelabs.nephele.admin.rest.lib.util.InvoiceUtility;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.FileOutputStream;
import java.util.*;

import static com.valuelabs.nephele.admin.data.repository.CloudBusinessRuleSpecifications.getBusinessRulesByRuleName;

/**
 * Created by Srikanth Nagaboina, Valuelabs on 21/8/15.
 */
@Component
public interface CloudInvoiceService {

  Double getDiscountPercentage(CloudResellerCompany resellerCompany, Double totalUsage, CloudService cloudService);

  Double getAmountAfterDiscount(CloudResellerCompany resellerCompany, Double grossTotal, Double totalUsage, CloudService cloudService);

  Double getAmountAfterDiscount(Double grossTotal, Double discountPercentage);

  Double calculatePrice(CloudRackspaceUsageData usageData);

  Double calculateVendorCost(CloudRackspaceUsageData usageData);

  Double getTaxAmount(Double grossAmount);

  ResellerDiscountPlanType getDiscountPlanTypeByService(CloudService service);

  String getInvoicePatternSequenceValue(CloudService cloudService);

  CloudResellerCompany findByExternalResellerCode(String externalResellerCode);

  Date getPaymentTermDueDate(CloudService cloudService);

  String createPDFReport(CloudResellerInvoice cloudInvoice, CloudUserType userType, boolean isInvoicePaid, String directoryPath);

  CloudDistributorResource getCloudDistributorResource();

  CloudCompanyDetails getCloudResellerCompanyDetails(CloudResellerCompany record);

  List<YearlyTopServiceDetails> getServiceDetail(List<RevenueServiceDetail> revenueServiceDetails, Pageable pageable, Date date);

  ReadCloudInvoice prepareInvoiceRequestFromEvent(ReadCloudInvoicesEvent request);

  void updateApiKeyExpireTime(CloudDistributorUser cloudDistributorUser);

  CloudCustomerCompanyDetails getCustomerCompanyDetail(CloudCustomerCompany company);

  List<RevenueServiceDetail> toRevenueDetailFromObjects(List<Object[]> objects);

  Set<CloudResellerInvoiceLineDetails> getCloudInvoiceDetails(List<CloudResellerInvoiceLine> cloudInvoiceLines);

  Set<CloudInvoiceDiscountLineDetail> toDiscountDetail(CloudResellerInvoice invoice);

  List<YearlyTopServiceDetails> getCsvServiceDetail(List<RevenueServiceDetail> revenueServiceDetails, Date date);

  Set<CloudPaymentDetails> getCloudPayments(CloudResellerInvoice invoice);

  Page<CloudResellerInvoiceDetails> paginateInvoiceDetails(List<CloudResellerInvoice> list, ReadCloudInvoicesEvent request);

  String getCloudBusinessRuleByRuleName(BusinessRuleNames ruleName);

  CloudPaymentProcessingDetail getPaymentProcessingDetail(CloudResellerInvoice invoice, String pgMerchantId);

  List<CloudResellerInvoiceApReportDetails> getApCsvData(List<CloudResellerInvoiceApReportDetails> details);

  @Slf4j
  @Service
  @Transactional
  static class Impl implements CloudInvoiceService {

    public static final String DEFAULT_PREMIUM_GROUP_NAME = "DEFAULT";

    @Autowired
    private CloudCodeSequenceGenerationPatternDAO patternDAO;

    @Autowired
    private CloudResellerPremiumGroupRepository groupRepository;

    @Autowired
    private CloudBusinessRuleRepository businessRuleRepository;

    @Autowired
    private CloudDistributorUserRepository distributorUserRepository;

    @Autowired
    private CloudResellerCompanyRepository resellerCompanyRepository;

    @Autowired
    private PDFBuilder pdfBuilder;

    @Autowired
    private CloudResellerInvoiceRepository invoiceRepository;

    @Autowired
    private PremiumGroupDiscountConfigRepository premiumGroupDiscountConfigRepository;


    @Override
    public Double getDiscountPercentage(CloudResellerCompany resellerCompany, Double totalUsage, CloudService cloudService) {
      Double discountedPercentage = 0D;
      boolean isDefaultGroupConfigured = false;
      //Checks reseller category and his corresponding discount slab
      if (null != resellerCompany && null != resellerCompany.getPremiumGroup() && null != resellerCompany.getPremiumGroup().getPriceGroupDiscountSheetSet()
          && !resellerCompany.getPremiumGroup().getPriceGroupDiscountSheetSet().isEmpty()) {
        if(resellerCompany.getPremiumGroup().getName().equalsIgnoreCase(DEFAULT_PREMIUM_GROUP_NAME))
          isDefaultGroupConfigured = true;
        discountedPercentage = getDiscountPercent(resellerCompany.getPremiumGroup(), totalUsage, cloudService);
      }
        //If Reseller doesn't configured to the any one of the premium group, then we need to apply default discount rules.
      if (discountedPercentage.equals(0D) && !isDefaultGroupConfigured)
        discountedPercentage = getDiscountPercent(getDefaultPremiumGroup(), totalUsage, cloudService);
      return discountedPercentage;
    }

    /**
     * Amount after applying Discounts
     *
     * @param grossTotal - Invoice Amount
     * @return Amount after applying Discounts
     */
    @Override
    public Double getAmountAfterDiscount(CloudResellerCompany resellerCompany, Double grossTotal, Double totalUsage, CloudService cloudService) {
      Double discountPercentage = getDiscountPercentage(resellerCompany, totalUsage, cloudService);
      return grossTotal - grossTotal * discountPercentage / 100;
    }

    private Double getDiscountPercent(CloudResellerPremiumGroup premiumGroup, Double totalUsage, CloudService cloudService) {
      Double discountedPercentage = 0D;
      if (null != premiumGroup && null != premiumGroup.getPriceGroupDiscountSheetSet()) {
        Set<PremiumGroupDiscountSheet> discountSheetSet = premiumGroup.getPriceGroupDiscountSheetSet();
        for (PremiumGroupDiscountSheet discountSheet : discountSheetSet) {
          if (null != discountSheet && discountedPercentage.equals(0D) && null != discountSheet.getPremiumGroupDiscountConfig()) {
            PremiumGroupDiscountConfig discountConfig = discountSheet.getPremiumGroupDiscountConfig();
            if (null != discountConfig.getPlanType() && null != discountConfig.getPlanType().name() && discountConfig.getCloudService().getId().equals(cloudService.getId())
                && discountConfig.getStatus().equals(ChangeManagementConfigStatus.ACTIVE)) {
              if (discountConfig.getPlanType().name().equalsIgnoreCase(ResellerDiscountPlanType.VOLUME.name())
                  && null != discountConfig.getActiveFrom() && discountConfig.getActiveFrom().before(new Date())
                  && (null == discountConfig.getActiveTo() || (null != discountConfig.getActiveTo() && discountConfig.getActiveTo().after(new Date())))) {
                if (InvoiceUtility.isNotEmpty(discountSheet.getEndRange()) && totalUsage >= discountSheet.getStartRange() && totalUsage <= discountSheet.getEndRange()) {
                  discountedPercentage = discountSheet.getDiscount();
                  break;
                } else if (InvoiceUtility.isNotEmpty(discountSheet.getStartRange()) && !InvoiceUtility.isNotEmpty(discountSheet.getEndRange()) && totalUsage >= discountSheet.getStartRange()) {
                  discountedPercentage = discountSheet.getDiscount();
                  break;
                }// The below case arises only when the service type is subscription
                else if (!InvoiceUtility.isNotEmpty(discountSheet.getStartRange()) && !InvoiceUtility.isNotEmpty(discountSheet.getEndRange())) {
                  discountedPercentage = discountSheet.getDiscount();
                  break;
                }
              } else if (discountConfig.getPlanType().name().equalsIgnoreCase(ResellerDiscountPlanType.FLAT.name()) && discountConfig.getActiveFrom().after(new Date())
                  && discountConfig.getActiveTo().before(new Date())) {
                discountedPercentage = discountSheet.getDiscount();
                break;
              }
            }
          }
        }
      }
      return discountedPercentage;
    }


    @Override
    public Double getAmountAfterDiscount(Double grossTotal, Double discountPercentage) {
      return grossTotal - grossTotal * discountPercentage / 100;
    }


    /**
     * Price can calculate as the Product(No: of Units Consumed * Unit Price)
     *
     * @param usageData - {@link  CloudRackspaceUsageData} Object
     * @return Invoice line amount
     */
    @Override
    public Double calculatePrice(CloudRackspaceUsageData usageData) {
      //return usageData.getUsageQuantity() * usageData.getUnitPrice();
      //As per latest changes no need to calculate price
      //Commented because total amout shoud be calculated and applied round celing in the Rackspace usage data.
      //return Utility.parseAndRoundCeilingDouble(usageData.getUnitPrice()) * Utility.parseAndCeilingDouble(usageData.getUsageQuantity());
      return usageData.getTotalPrice();
    }

    @Override
    public Double calculateVendorCost(CloudRackspaceUsageData usageData) {
      Double returnVal = 0.0D;
      if (null != usageData && null != usageData.getCloudServer() && null != usageData.getCloudServer().getCloudProductPlan()
          && null != usageData.getCloudServer().getCloudProductPlan().getVendorPrice() && null != usageData.getTotalPrice()) {
        returnVal = usageData.getUsageQuantity() * usageData.getCloudServer().getCloudProductPlan().getVendorPrice();
      }
      return returnVal;
    }

    /**
     * Net amount after applying sales tax
     *
     * @param grossAmount - Gross Amount after applying Discount if any
     * @return Net amount after applying sales tax
     */
    @Override
    public Double getTaxAmount(Double grossAmount) {
      Double returnVal = 0d;
      try {
        List<CloudBusinessRule> cloudBusinessRules = businessRuleRepository.findAll(getBusinessRulesByRuleName(BusinessRuleNames.GST.name()));
        if (null != cloudBusinessRules && !cloudBusinessRules.isEmpty()) {
          for (CloudBusinessRule rule : cloudBusinessRules) {
            if (null != rule && null != rule.getRuleName() && BusinessRuleNames.valueOf(rule.getRuleName().name()).equals(BusinessRuleNames.GST)
                && null != rule.getRuleValue() && NumberUtils.isNumber(rule.getRuleValue())) {
              returnVal = (grossAmount * Double.parseDouble(rule.getRuleValue())) / 100;
              break;
            }
          }
        }
      } catch (Exception e) {
        log.error("Exception occurs while calculating tax: ", e.getMessage());
      }
      return returnVal;
    }

    @Override
    public ResellerDiscountPlanType getDiscountPlanTypeByService(CloudService service) {
      ResellerDiscountPlanType returnVal = null;
      if (null != service) {
        List<PremiumGroupDiscountConfig> groupDiscountConfigs = premiumGroupDiscountConfigRepository.findByServiceId(service.getId());
        if (InvoiceUtility.isNotEmpty(groupDiscountConfigs)) {
          for (PremiumGroupDiscountConfig discountConfig : groupDiscountConfigs) {
            if (null != discountConfig.getActiveFrom() && null != discountConfig.getStatus()
                && discountConfig.getActiveFrom().before(new Date()) && discountConfig.getStatus().equals(ChangeManagementConfigStatus.ACTIVE)) {
              returnVal = discountConfig.getPlanType();
            }
          }
        }
      }
      return returnVal;
    }

    @Override
    public String getInvoicePatternSequenceValue(CloudService cloudService) {
      StringBuilder sb = new StringBuilder(200);
      try {
        List<CloudBusinessRule> cloudBusinessRules = businessRuleRepository.findAll(getBusinessRulesByRuleName(BusinessRuleNames.INVOICE_PREFIX.name()));
        if (null != cloudBusinessRules && !cloudBusinessRules.isEmpty()) {
          for (CloudBusinessRule rule : cloudBusinessRules) {
            if (null != rule && null != rule.getRuleName() && BusinessRuleNames.valueOf(rule.getRuleName().name()).equals(BusinessRuleNames.INVOICE_PREFIX)
                && null != rule.getRuleValue()) {
              sb.append(rule.getRuleValue().substring(0, 2));
              break;
            }
          }
        }
        Long patternNumber = patternDAO.getNextInvoicePatternNumber();
        if (!patternNumber.equals(0L))
          sb.append(patternNumber);
        sb.trimToSize();
      } catch (Exception e) {
        log.error("Exception occurs while getting next sequence value ", e.getMessage());
      }
      return sb.toString();
    }

    @Override
    public Date getPaymentTermDueDate(CloudService cloudService) {
      Date returnVal = new Date();
      try {
        List<CloudBusinessRule> cloudBusinessRules = businessRuleRepository.findAll(getBusinessRulesByRuleName(BusinessRuleNames.INVOICE_TERM.name()));
        if (null != cloudBusinessRules && !cloudBusinessRules.isEmpty()) {
          for (CloudBusinessRule rule : cloudBusinessRules) {
            if (null != rule && null != rule.getRuleName() && BusinessRuleNames.valueOf(rule.getRuleName().name()).equals(BusinessRuleNames.INVOICE_TERM)
                && null != rule.getRuleValue() && NumberUtils.isNumber(rule.getRuleValue())) {
              returnVal = InvoiceUtility.getDaysAfterDate(new Date(), Integer.parseInt(rule.getRuleValue()));
              break;
            }
          }
        }
      } catch (Exception e) {
        log.error("Exception occurs while converting the json object to resource: ", e.getMessage());
      }
      return returnVal;
    }

    @Override
    public CloudResellerCompany findByExternalResellerCode(String externalResellerCode) {
      return resellerCompanyRepository.findByExternalResellerCode(externalResellerCode);
    }

    @Override
    public String createPDFReport(CloudResellerInvoice cloudInvoice, CloudUserType userType, boolean isInvoicePaid, String directoryPath) {
      String filePath = null;
      Document document = null;
      try {
        if (null != cloudInvoice && null != cloudInvoice.getCloudInvoiceNumber()) {
          ReadCloudInvoicesEvent request = new ReadCloudInvoicesEvent().setInvoiceNumber(cloudInvoice.getCloudInvoiceNumber());
          ReadCloudInvoice invoiceRequest = prepareInvoiceRequestFromEvent(request);

          document = new Document();
          directoryPath = directoryPath + File.separator + NepheleConstants.PDF;
          if (!new File(directoryPath).exists())
            createDirectory(directoryPath);
          filePath = directoryPath + File.separator;
          if (isInvoicePaid) {
            filePath = filePath + NepheleConstants.PAID;
            if (!new File(filePath).exists())
              createDirectory(filePath);
            filePath = filePath + File.separator + cloudInvoice.getCloudInvoiceNumber() + "_" + NepheleConstants.PAID + NepheleConstants.PDF_FILE_EXTENSION;
          } else
            filePath = filePath + cloudInvoice.getCloudInvoiceNumber() + NepheleConstants.PDF_FILE_EXTENSION;
          PdfWriter.getInstance(document, new FileOutputStream(filePath));
          document.open();
          document.setPageSize(PageSize.A4);
          pdfBuilder.createInvoiceTable(document, invoiceRequest);
          document.close();
        }
      } catch (Exception e) {
        log.error("Exception occurs while creating  / persisting PDF report into file system: ", e);
      }
      return filePath;
    }



    @Override
    public CloudDistributorResource getCloudDistributorResource() {
      CloudDistributorResource resource = null;
      try {
        List<CloudBusinessRule> cloudBusinessRules = businessRuleRepository.findAll(getBusinessRulesByRuleName(BusinessRuleNames.DISTRIBUTOR_NAME.name()));
        if (null != cloudBusinessRules && !cloudBusinessRules.isEmpty()) {
          for (CloudBusinessRule rule : cloudBusinessRules) {
            if (null != rule && null != rule.getRuleName() && BusinessRuleNames.valueOf(rule.getRuleName().name()).equals(BusinessRuleNames.DISTRIBUTOR_NAME)) {
              Gson gson = new Gson();
              resource = gson.fromJson(rule.getRuleValue(), CloudDistributorResource.class);
              break;
            }
          }
        }
      } catch (Exception e) {
        log.error("Exception occurs while converting the json object to resource: ", e.getMessage());
      }
      return resource;
    }

    @Override
    public CloudCustomerCompanyDetails getCustomerCompanyDetail(CloudCustomerCompany company) {
      CloudCustomerCompanyDetails details = null;
      if (null != company) {
        details = CloudCustomerCompanyDetails.builder()
            .customerCompanyId(company.getId())
            .customerCompanyName(company.getCustomerCompanyName())
            .addressLine1(company.getAddressLine1())
            .addressLine2(company.getAddressLine2())
            .firstName(company.getFirstName())
            .lastName(company.getLastName())
            .city(company.getCity())
            .country(company.getCountry())
            .cloudResellerCompanyId(company.getCloudResellerCompany().getId())
            .email(company.getEmail())
            .externalCustomerCompanyCode(company.getCustomerCompanyCode())
            .state(company.getState())
            .zipcode(company.getZipcode())
            .isActive(company.getIsActive())
            .build();
      }
      return details;
    }

    @Override
    public CloudCompanyDetails getCloudResellerCompanyDetails(CloudResellerCompany record) {
      CloudCompanyDetails cloudCompanyDetails = null;
      if (null != record) {
        cloudCompanyDetails = CloudCompanyDetails.builder()
            .companyId(record.getId())
            .companyName(record.getResellerCompanyName())
            .firstName(record.getFirstName())
            .lastName(record.getLastName()).email(record.getEmail())
            .addressLine1(record.getAddressLine1())
            .addressLine2(record.getAddressLine2()).city(record.getCity())
            .country(record.getCountry()).state(record.getState())
            .externalCompanyCode(record.getResellerCompanyCode())
            .abnNumber(record.getAbnNumber())
                .salesPerson(record.getSalesPerson())
                .terriCode(record.getTerrCode())
            .zipCode(record.getZipcode()).build();
      }
      return cloudCompanyDetails;
    }

    @Override
    public List<YearlyTopServiceDetails> getServiceDetail(List<RevenueServiceDetail> revenueServiceDetails, Pageable pageable, Date date) {
      Long total = 0l;
      List<YearlyTopServiceDetails> serviceDetailsList = new ArrayList<>();
      if (null != revenueServiceDetails && !revenueServiceDetails.isEmpty()) {
        for (RevenueServiceDetail detail : revenueServiceDetails) {
          if (total >= pageable.getOffset() && total < pageable.getOffset() + pageable.getPageSize()) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            if (!revenueServiceDetails.isEmpty())
              Collections.sort(revenueServiceDetails, new RevenueServiceComparator());
            YearlyTopServiceDetails serviceDetails = YearlyTopServiceDetails.builder()
                .revenue(detail.getRevenue())
                .integrationCode(detail.getIntegrationCode())
                .serviceName(detail.getServiceName())
                .serviceId(detail.getServiceId())
                .build();
            serviceDetailsList.add(serviceDetails);
          }
        }
      }
      return serviceDetailsList;
    }

    @Override
    public ReadCloudInvoice prepareInvoiceRequestFromEvent(ReadCloudInvoicesEvent request) {
      ReadCloudInvoice invoiceRequest = null;
      if (null != request) {
        invoiceRequest = ReadCloudInvoice.builder()
            .invoiceNumber(request.getInvoiceNumber())
            .fromDate(InvoiceUtility.getMonthStartDate(request.getFromDate()))
            .toDate(InvoiceUtility.getMonthEndDate(request.getToDate()))
            .numberOfRecords(request.getNumberOfRecords())
            .resellerId(request.getResellerId())
            .sortBy(request.getSortBy())
            .status(request.getStatus())
            .resellerCode(request.getResellerCode())
            .build();
      }
      return invoiceRequest;
    }

    private void createDirectory(String destinationPath) {
      log.debug("Creating directing: " + destinationPath);
      boolean directory = new File(destinationPath).mkdirs();
      if (directory)
        log.debug("Created directory !! ");
      else
        log.debug("Unable to create directory..");
    }

    @Override
    public void updateApiKeyExpireTime(CloudDistributorUser cloudDistributorUser) {
      try {
        if (null != cloudDistributorUser) {
          cloudDistributorUser.setApiKeyExpireTime(DateFormatterUtility.getAfterDateInMinutes(30));
          distributorUserRepository.save(cloudDistributorUser);
        }
      } catch (Exception e) {
        log.error("Exception occurs while updating API-KEY expire time: ");
      }
    }

    @Override
    public List<RevenueServiceDetail> toRevenueDetailFromObjects(List<Object[]> objects) {
      List<RevenueServiceDetail> results = new ArrayList<>();
      try {
        if (null != objects && !objects.isEmpty()) {
          for (Object[] obj : objects) {
            RevenueServiceDetail service = new RevenueServiceDetail();
            service.setRevenue(String.valueOf(obj[0]));
            service.setServiceId(((Long) obj[1]));
            service.setServiceName((String) obj[2]);
            service.setIntegrationCode((String) obj[3]);
            results.add(service);
          }
        }
      } catch (Exception e) {
        log.error("exception occur while preparingList");
      }
      return results;
    }

    @Override
    public Set<CloudResellerInvoiceLineDetails> getCloudInvoiceDetails(List<CloudResellerInvoiceLine> cloudInvoiceLines) {
      Set<CloudResellerInvoiceLineDetails> list = new HashSet<>();
      if (null != cloudInvoiceLines && !cloudInvoiceLines.isEmpty()) {
        for (CloudResellerInvoiceLine line : cloudInvoiceLines) {
          CloudResellerInvoiceLineDetails data = CloudResellerInvoiceLineDetails.builder()
              .cloudInvoiceLineId(line.getId())
              .description(line.getDescription())
              .price(line.getUnitPrice())
              .total(String.valueOf(line.getTotal()))
              .cloudInvoiceId(line.getCloudInvoice().getId())
              .quantity(line.getQuantity())
              .serviceName(line.getServiceName())
              .productPlan(line.getProductPlanName())
              .build();
          list.add(data);
        }
      }
      return list;
    }

    @Override
    public Set<CloudInvoiceDiscountLineDetail> toDiscountDetail(CloudResellerInvoice invoice) {
      Set<CloudInvoiceDiscountLineDetail> list = new HashSet<>();
      if (null != invoice && null != invoice.getDiscountLineList() && !invoice.getDiscountLineList().isEmpty()) {
        for (CloudInvoiceDiscountLine line : invoice.getDiscountLineList()) {
          StringBuilder sb = new StringBuilder();
          sb.append(line.getDiscountType().name().toLowerCase()).append(" ")
              .append("DISCOUNT")
              .append(" ( ")
              .append(line.getDiscountPercent())
              .append(" on $")
              .append(InvoiceUtility.formatDouble(invoice.getGrossTotal())).append(" )");
          sb.trimToSize();
          CloudInvoiceDiscountLineDetail data = CloudInvoiceDiscountLineDetail.builder()
              .cloudInvoiceDiscountLineId(line.getId())
              .description(sb.toString())
              .amount(InvoiceUtility.formatDouble(line.getTotal()))
              .quantity(line.getQuantity())
              .discountPercent(line.getDiscountPercent().toString())
              .brand(line.getBrand())
              .discountType(line.getDiscountType().name())
              .build();
          list.add(data);
        }
      }
      return list;
    }

    @Override
    public List<YearlyTopServiceDetails> getCsvServiceDetail(List<RevenueServiceDetail> revenueServiceDetails, Date date) {
      List<YearlyTopServiceDetails> serviceDetailsList = new ArrayList<>();
      if (null != revenueServiceDetails && !revenueServiceDetails.isEmpty()) {
        for (RevenueServiceDetail detail : revenueServiceDetails) {
          Calendar calendar = Calendar.getInstance();
          calendar.setTime(date);
          if (!revenueServiceDetails.isEmpty())
            Collections.sort(revenueServiceDetails, new RevenueServiceComparator());
          YearlyTopServiceDetails serviceDetails = YearlyTopServiceDetails.builder()
              .revenue(detail.getRevenue())
              .integrationCode(detail.getIntegrationCode())
              .serviceName(detail.getServiceName())
              .serviceId(detail.getServiceId())
              .build();
          serviceDetailsList.add(serviceDetails);

        }
      }

      return serviceDetailsList;
    }


    @Override
    public List<CloudResellerInvoiceApReportDetails> getApCsvData(List<CloudResellerInvoiceApReportDetails> details) {
      List<CloudResellerInvoiceApReportDetails> apReportDetails = new ArrayList<>();
      if (null != details && !details.isEmpty()) {
        for (CloudResellerInvoiceApReportDetails apReport : details) {
          CloudResellerInvoiceApReportDetails report = CloudResellerInvoiceApReportDetails.builder()
              .grossTotal(apReport.getGrossTotal())
              .currency(apReport.getCurrency())
              .cloudServiceId(apReport.getCloudServiceId())
              .fromDate(apReport.getFromDate())
              .toDate(apReport.getToDate())
              .build();
          apReportDetails.add(report);
        }
      }
      return apReportDetails;
    }

    @Override
    public Set<CloudPaymentDetails> getCloudPayments(CloudResellerInvoice invoice) {
      Set<CloudPaymentDetails> paymentResource = new HashSet<>();
      if (null != invoice && null != invoice.getCloudPayments()) {
        for (CloudPayment payment : invoice.getCloudPayments()) {
          paymentResource.add(CloudPaymentDetails.builder()
              .invoiceId(payment.getCloudInvoice().getId())
              .paymentMode(payment.getPaymentMode())
              .instrumentType(payment.getInstrumentType())
              .invoiceAmount(payment.getInvoiceAmount())
              .transactionId(payment.getTransactionId())
              .surcharge(payment.getSurcharge())
              .surchargeGst(payment.getSurchargeGst())
              .total(payment.getTotal())
              .created(payment.getCreated())
              .paymentId(payment.getId())
              .serviceName(payment.getServiceName())
              .build());
        }
      }
      return paymentResource;
    }

    private CloudServiceDetails getCloudServiceDetails(CloudResellerInvoice invoice) {
      CloudServiceDetails details = new CloudServiceDetails();
      if (null != invoice.getCloudService()) {
        details = CloudServiceDetails.builder()
            .serviceCode(invoice.getCloudService().getServiceCode())
            .vendorCode(invoice.getCloudService().getVendorCode())
            .name(invoice.getCloudService().getName())
            .build();
      }
      return details;
    }

    @Override
    public Page<CloudResellerInvoiceDetails> paginateInvoiceDetails(List<CloudResellerInvoice> list, ReadCloudInvoicesEvent request) {
      List<CloudResellerInvoiceDetails> content = new ArrayList<>();
      long total = 0;
      if (null != list && !list.isEmpty()) {
        for (CloudResellerInvoice record : list) {
          if (total >= request.getPageable().getOffset() && total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
            CloudResellerInvoiceDetails details = CloudResellerInvoiceDetails
                .builder()
                .cloudInvoiceId(record.getId())
                .cloudResellerId(record.getCloudResellerCompany().getId())
                .status(record.getInvoiceStatus().toString())
                .currency(record.getCurrency())
                .grossTotal(record.getGrossTotal())
                .netTotal(record.getNetTotal())
                .tax(record.getTax())
                .closedDate(record.getClosedDate())
                .dueDate(record.getDueDate())
                .createdDate(record.getCreated())
                .discountAmount(record.getDiscountAmount())
                .total(record.getTotal())
                .discountPercentage(record.getDiscountPercentage())
                .paymentTerm(InvoiceUtility.getPaymentTerm(record.getCreated(), record.getDueDate()))
                .cloudResellerCompanyDetails(getCloudResellerCompanyDetails(record.getCloudResellerCompany()))
                .discountLineDetailSet(toDiscountDetail(record))
                .cloudResellerInvoiceLineDetails(new HashSet<CloudResellerInvoiceLineDetails>())
                .fromDate(record.getFromDate())
                .customerCompanyDetails(getCustomerCompanyDetail(record.getCloudCustomerCompany()))
                .toDate(record.getToDate())
                .distributor(InvoiceUtility.getDistributor(getCloudDistributorResource()))
                .invoiceNumber(record.getCloudInvoiceNumber())
                .cloudDistributorResource(getCloudDistributorResource())
                .cloudPaymentDetails(getCloudPayments(record))
                .isOverdue(InvoiceUtility.getDateWithoutTime(record.getDueDate()).before(InvoiceUtility.getDateWithoutTime(new Date())) && !record.getInvoiceStatus().name().equalsIgnoreCase(InvoiceStatus.PAID.name()))
                .cloudService(getCloudServiceDetails(record))
                .build();
            content.add(details);
          }
          ++total;
        }
      }
      return new PageImpl<>(content, request.getPageable(), total);
    }

    @Override
    public CloudPaymentProcessingDetail getPaymentProcessingDetail(CloudResellerInvoice invoice, String pgMerchantId) {
      CloudPaymentProcessingDetail detail = null;
      String merchantId = getCloudBusinessRuleByRuleName(BusinessRuleNames.PAYMENT_GATEWAY_MERCHANT_ID);
      if (null != merchantId && !merchantId.isEmpty())
        pgMerchantId = merchantId;
      if (null != invoice && null != invoice.getDueDate() && null != invoice.getCloudResellerCompany() &&
          InvoiceUtility.getDateWithoutTime(new Date()).equals(InvoiceUtility.getDateWithoutTime(invoice.getDueDate()))) {
        Double surchargePercentage = null;
        Double invoiceTotal = invoice.getTotal();
        String cardType = invoice.getCloudResellerCompany().getCreditCardType();
        if (null != cardType && !cardType.isEmpty()) {
          for (BusinessRuleNames name : BusinessRuleNames.values()) {
            if (name.aliasName.contains(cardType)) {
              String ruleValue = getCloudBusinessRuleByRuleName(name);
              if (null != ruleValue && NumberUtils.isNumber(ruleValue)) {
                surchargePercentage = Double.parseDouble(ruleValue);
                break;
              }
            }
          }
        }
        Double surchargeAmount = InvoiceUtility.calculateSurcharge(invoiceTotal, surchargePercentage);
        Double totalAmount = invoiceTotal + surchargeAmount;
        Double surchargeGST = 0.0D;
        String GST = getCloudBusinessRuleByRuleName(BusinessRuleNames.GST);
        if (null != GST && !GST.isEmpty() && NumberUtils.isNumber(GST))
          surchargeGST = InvoiceUtility.calculateSurcharge(surchargeAmount, Double.parseDouble(GST));
        totalAmount = totalAmount + surchargeGST;
        StringBuilder sb = new StringBuilder(5);
        if (null != invoice.getCloudResellerCompany().getCreditCardExpiryYear() && null != invoice.getCloudResellerCompany().getCreditCardExpiryMonth())
          sb.append(invoice.getCloudResellerCompany().getCreditCardExpiryYear().toString().substring(2, 4))
              .append(StringUtils.leftPad(invoice.getCloudResellerCompany().getCreditCardExpiryMonth().toString(), 2, '0'));
        sb.trimToSize();
        detail = CloudPaymentProcessingDetail.builder()
            .merchantId(pgMerchantId)
            .amount(totalAmount.toString())
            .cvv(null)
            .invoiceNumber(invoice.getCloudInvoiceNumber())
            .expiryDate(sb.toString())
            .invoiceId(invoice.getId().toString())
            .surcharge(surchargeAmount)
            .surchargeGST(surchargeGST)
            .vpnTokenNumber(invoice.getCloudResellerCompany().getCreditCardToken())
            .build();
      }
      return detail;
    }

    private CloudResellerPremiumGroup getDefaultPremiumGroup() {
      CloudResellerPremiumGroup premiumGroup = null;
      try {
        premiumGroup = groupRepository.findPremiumGroup(DEFAULT_PREMIUM_GROUP_NAME);
      } catch (Exception e) {
        log.error("Exception occurs while fetching default premium discount rules: ", e.getMessage());
      }
      return premiumGroup;
    }

    @Override
    public String getCloudBusinessRuleByRuleName(BusinessRuleNames ruleName) {
      String ruleValue = null;
      try {
        List<CloudBusinessRule> cloudBusinessRules = businessRuleRepository.findAll(getBusinessRulesByRuleName(ruleName.name()));
        if (null != cloudBusinessRules && !cloudBusinessRules.isEmpty()) {
          for (CloudBusinessRule rule : cloudBusinessRules) {
            if (null != rule && null != rule.getRuleName() && BusinessRuleNames.valueOf(rule.getRuleName().name()).equals(ruleName)) {
              ruleValue = rule.getRuleValue();
            }
          }
        }
      } catch (Exception e) {
        log.error("Exception occurs while converting the json object to resource: ", e.getMessage());
      }
      return ruleValue;
    }

  }


  class RevenueServiceComparator implements Comparator<RevenueServiceDetail> {
    @Override
    public int compare(RevenueServiceDetail o1, RevenueServiceDetail o2) {
      int returnVal = 0;
      if (null != o1 && null != o2) {
        returnVal = o1.getRevenue().compareTo(o2.getRevenue());
      }
      return returnVal;
    }
  }
}
