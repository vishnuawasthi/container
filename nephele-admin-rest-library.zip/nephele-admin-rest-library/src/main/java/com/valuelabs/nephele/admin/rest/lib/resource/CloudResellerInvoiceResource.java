package com.valuelabs.nephele.admin.rest.lib.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.hateoas.ResourceSupport;

import java.util.Date;
import java.util.List;
import java.util.Set;


@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudResellerInvoiceResource extends ResourceSupport {

  private String invoiceNumber;
  private String currency;
  private Long cloudInvoiceId;
  private String grossTotal;
  private String tax;
  private String taxPercentage;
  private String taxDescription;
  private String status;
  private Boolean isOverdue;
  private String netTotal;
  private String paymentTerm;
  private String total;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date paymentDate;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date createdDate;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date dueDate;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date billingStartDate;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date billingEndDate;
  private Long cloudResellerId;
  private String discountAmount;
  //private String discountPercentage;
  private CloudCompanyDetails billTo;
  private CloudCustomerCompanyDetails shipTo;
  private CloudDistributorResource billBy;
  private String distributor;
  private List<CloudResellerInvoiceLineResource> invoiceLines;
  private Set<CloudInvoiceDiscountLineResource> discountLineResources;
  private String sortBy;
  private String userId;
  private String userName;
  private String companyCode;
  private String firstName;
  private String lastName;
  private String email;
  private String addressLine1;
  private String addressLine2;
  private String city;
  private String state;
  private String country;

  private List<CloudPaymentResource> cloudPayments;
  private CloudServiceResource cloudService;

}
