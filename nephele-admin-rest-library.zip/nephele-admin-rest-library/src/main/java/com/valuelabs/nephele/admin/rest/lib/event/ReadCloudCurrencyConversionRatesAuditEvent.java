package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
public class ReadCloudCurrencyConversionRatesAuditEvent extends ReadPageEvent<ReadCloudCurrencyConversionRatesAuditEvent> {

	String id;
}
