package com.valuelabs.nephele.admin.rest.lib.elasticsearchresource;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;
@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@Accessors(chain = true)
@JsonInclude(value=Include.NON_DEFAULT)
//@EqualsAndHashCode(callSuper = false)
public class ElasticSearchCloudServiceResource {

	private Long serviceId;
	private String name;
	private Boolean isPublished;
	private String description;	
	private Long serviceProviderId;
	private String serviceProviderName;	
	private String serviceCode;
	private Boolean checkValidation;
	private Integer billingDay;
	private String billingCycle;
	private  Date updatedDate;
	private String planPrefix;	
	private String subscriptionNamePrefix;
	private Boolean isLive;
	private String integrationCode;
	private String vendorCode;
}
