package com.valuelabs.nephele.admin.rest.lib.resource;



import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
//@Setter
//@Getter
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_DEFAULT)
public class CloudProductResource extends ResourceSupport implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long productId;
	private String name;
//	private String planCode;
	private String description;
	private String type;
	private StartPlanResource startingPlan;
    private Long operatingSystemId;
    private String operatingSystemName;
    private Long serviceId;
    private String serviceCode;
    private String integrationCode;
    private String serviceName;
    private String brandCode;
    private String brandName;
    private Long categoryId;
    private String categoryName;
    private String status;
    private Boolean isFeatured;
	private Boolean hasFreeTrial;
	private Boolean hasRelatedProducts;
    
}
