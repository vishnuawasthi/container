package com.valuelabs.nephele.admin.rest.lib.domain;


import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudServiceDetails {
	private Long serviceId;
	private String name;
	private Boolean isPublished;
	private String description;	
	private Long serviceProviderId;
	private String serviceProviderName;	
	private String serviceCode;
	private Boolean checkValidation;
	private Integer billingDay;
	private String billingCycle;
	private  Date updatedDate;
	private String planPrefix;	
	private String subscriptionNamePrefix;
	private Boolean isLive;
	private String integrationCode;
	private String vendorCode;
	private String vendorCurrency;
	private String timeZone;
	private Long serviceCategoryId;
	private Long serviceIndustryVerticalId;
	private String serviceCategoryName;
	private String serviceIndustryVerticalName;
}
