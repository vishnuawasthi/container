package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.RelatedExternalProductDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class RelatedExternalProductCreatedEvent {
	

	private RelatedExternalProductDetails relatedExternalProductDetails;
	private List<RelatedExternalProductDetails> relatedExternalProductDetailsList;
	private List<String> externalIdList;
	
	private boolean invalid;
	private boolean failed;
	
	public RelatedExternalProductCreatedEvent(RelatedExternalProductDetails relatedExternalProductDetails) {
		this.relatedExternalProductDetails = relatedExternalProductDetails;
	}
	
	public RelatedExternalProductCreatedEvent(List<RelatedExternalProductDetails> relatedExternalProductDetailsList) {
		this.relatedExternalProductDetailsList = relatedExternalProductDetailsList;
	}
	
	public static RelatedExternalProductCreatedEvent invalid(RelatedExternalProductDetails relatedExternalProductDetails) {
		RelatedExternalProductCreatedEvent event = new RelatedExternalProductCreatedEvent(relatedExternalProductDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static RelatedExternalProductCreatedEvent failed(RelatedExternalProductDetails relatedExternalProductDetails) {
		RelatedExternalProductCreatedEvent event = new RelatedExternalProductCreatedEvent(relatedExternalProductDetails);
		event.setFailed(true);
		return event;
	}

}
