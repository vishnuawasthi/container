package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain=true)
public class CreateSubscriptionEvent {
	
	private CloudSubscriptionDetails cloudSubscriptionDetails;

}
