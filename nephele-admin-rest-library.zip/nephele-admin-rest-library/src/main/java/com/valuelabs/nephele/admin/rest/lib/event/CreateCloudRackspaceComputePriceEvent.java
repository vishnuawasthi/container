package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceComputePriceDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudRackspaceComputePriceEvent {
	private CloudRackspaceComputePriceDetails cloudRackspaceComputePriceDetails;
}
