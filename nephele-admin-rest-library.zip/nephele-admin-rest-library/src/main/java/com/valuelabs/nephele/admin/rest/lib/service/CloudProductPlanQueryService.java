package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.Map;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntitiesReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlanEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlansEvent;

public interface CloudProductPlanQueryService {
	
	EntityReadEvent<CloudProductPlanDetails> readProductPlanService(ReadCloudProductPlanEvent request);

	EntitiesReadEvent<CloudProductPlanDetails> readPublishedProductPlansByProductId(ReadCloudProductPlanEvent request) throws Exception;
	
	PageReadEvent<CloudProductPlanDetails> readProductPlansService(ReadCloudProductPlansEvent request);

	EntitiesReadEvent<CloudProductPlanDetails> readProductPlansByProductIdAndLocationId(ReadCloudProductPlanEvent request) throws Exception;

	 EntitiesReadEvent<CloudProductPlanDetails>  readProductPlansByProductIdAndLocationIdAndFlvCategory(ReadCloudProductPlansEvent request) throws Exception;
	 Map<String, Long> readSummary(ReadCloudProductPlansEvent request);

	EntitiesReadEvent<CloudProductPlanDetails> readProductPlansServiceForFilter(
			ReadCloudProductPlansEvent request);
	
	EntitiesReadEvent<CloudProductPlanDetails> readPlansStatusById(ReadCloudProductPlansEvent request) ;

}
