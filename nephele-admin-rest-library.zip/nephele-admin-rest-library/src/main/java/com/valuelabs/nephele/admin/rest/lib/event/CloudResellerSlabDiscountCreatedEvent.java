package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerSlabDiscountDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerSlabDiscountCreatedEvent {
	
private CloudResellerSlabDiscountDetails slabDiscountDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudResellerSlabDiscountCreatedEvent(CloudResellerSlabDiscountDetails slabDiscountDetails) {
		this.slabDiscountDetails = slabDiscountDetails;
	}
	
	public static CloudResellerSlabDiscountCreatedEvent invalid(CloudResellerSlabDiscountDetails slabDiscountDetails) {
		CloudResellerSlabDiscountCreatedEvent event = new CloudResellerSlabDiscountCreatedEvent(slabDiscountDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudResellerSlabDiscountCreatedEvent failed(CloudResellerSlabDiscountDetails slabDiscountDetails) {
		CloudResellerSlabDiscountCreatedEvent event = new CloudResellerSlabDiscountCreatedEvent(slabDiscountDetails);
		event.setFailed(true);
		return event;
	}

}
