package com.valuelabs.nephele.admin.rest.lib.resource;

import com.rometools.rome.feed.impl.ObjectBean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class CloudFeedLinksResources {

	private ObjectBean _objBean;

	private String href;
	private String rel;
	private String type;
	private String hreflang;
	private String title;
	private long length;
	/*
	 * public LinksResources() { super(); // TODO Auto-generated constructor
	 * stub } public LinksResources(ObjectBean _objBean, String href, String
	 * rel, String type, String hreflang, String title, long length) { super();
	 * this._objBean = _objBean; this.href = href; this.rel = rel; this.type =
	 * type; this.hreflang = hreflang; this.title = title; this.length = length;
	 * }
	 */

}
