package com.valuelabs.nephele.admin.rest.lib.constants;

/**
 * Created by ranjith on 13/11/15.
 */
public class PdfConstants {

  public static final String YY_MM_DD = "YYYY-MM-dd";


  public static final String SOLD_TO = "Sold To";
  public static final String SHIP_TO = "Ship To";
  public static final String PAID = "PAID";
  public static final String TAX_INVOICE = "Tax Invoice    ";
  public static final String PRODUCT_CHARGES = "Product Charges";
  public static final String PRODUCT_DISCOUNT = "Product Discount";
  public static final String PAYMENT_SUMMARY = "Payment Summary";
  public static final String PAYMENT = "Payment ";

  // INVOICE TABLE
  public static final String INVOICE_DATE = "Invoice Date";
  public static final String BILLING_START_DATE = "Billing Start Date";
  public static final String BILLING_END_DATE = "Billing End Date";
  public static final String CUSTOMER_CODE = "Customer Code";
  public static final String TERR_CODE = "Terr. Code";
  public static final String ABN_NUMBER = "ABN Number";
  public static final String SALES_PERSON = "Sales Person";
  public static final String CURRENCY = "Currency";

  // INVOICE LINE TABLE
  public static final String NUMBER = "No # ";
  public static final String BRAND = "Brand";
  public static final String PLAN_NAME_WITH_DESCRIPTION = "Plan Name And Description";
  public static final String QUANTITY = "QTY";
  public static final String PRICE = "Price";
  public static final String TOTAL = "Total";


  public static final String DESCRIPTION = "Description";
  public static final String AMOUNT = "Amount";

  //PAYMENT SUMMARY
  public static final String PAYMENT_TERM = "    PAYMENT TERM:";
  public static final String DUE_DATE = "              DUE DATE:";
  public static final String PAYMENT_STATUS = "PAYMENT STATUS:";
  public static final String GROSS_AMOUNT = "      GROSS AMOUNT:";
  public static final String DISCOUNT_AMOUNT = "DISCOUNT AMOUNT:";
  public static final String NET_AMOUNT = "           NET AMOUNT:";
  public static final String GST = "                 PLUS GST:";
  public static final String INVOICE_TOTAL = "       INVOICE TOTAL:";


  //PAYMENT TABLE
  public static final String INVOICE_NUMBER = "Invoice No";
  public static final String PAYMENT_NUMBER = "Payment No";
  public static final String PAYMENT_DATE = "Payment Date";
  public static final String PAYMENT_METHOD = "Payment Method";
  public static final String INVOICE_AMOUNT = "Invoice Amount";
  public static final String SURCHARGE = "Surcharge";
  public static final String SURCHARGE_GST = "Surcharge GST";


  public static final String PAID_IMAGE = "invoice-paid.png";


}
