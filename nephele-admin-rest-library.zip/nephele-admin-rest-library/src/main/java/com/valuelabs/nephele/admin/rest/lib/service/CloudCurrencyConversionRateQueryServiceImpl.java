package com.valuelabs.nephele.admin.rest.lib.service;

import static com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateSpecifications.constructPageSpecification;
import static com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateSpecifications.sortByIdAsc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRate;
import com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRateEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRatesEvent;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class CloudCurrencyConversionRateQueryServiceImpl  implements CloudCurrencyConversionRateQueryService{

  @Autowired
  private CloudCurrencyConversionRateRepository  currencyConversionRateRepository;

  @Override
  public EntityReadEvent<CloudCurrencyConversionRateDetails> readCloudCurrencyConversionRate(
      ReadCloudCurrencyConversionRateEvent request) {
	log.debug("readCloudCurrencyConversionRate() - start");
	CloudCurrencyConversionRate entity = currencyConversionRateRepository.findOne(request.getId());
	CloudCurrencyConversionRateDetails details = null;
	if(entity!=null) {
	  details    = CloudCurrencyConversionRateDetails.builder()
                                            		  .id(entity.getId())
                                            		  .conversionRate(entity.getConversionRate())
                                            		  .sourceCurrency(entity.getSourceCurrency().name())
                                            		  .targetCurrency(entity.getTargetCurrency().name())
                                            		  .build();
	}
	log.debug("readCloudCurrencyConversionRate() - end");
	return new EntityReadEvent<CloudCurrencyConversionRateDetails>(details);
  }

  @Override
  public PageReadEvent<CloudCurrencyConversionRateDetails> readCloudCurrencyConversionRates(
      ReadCloudCurrencyConversionRatesEvent request) {
	log.debug("readCloudCurrencyConversionRates() -start");
	Page<CloudCurrencyConversionRate> dbContent = null;
	Page<CloudCurrencyConversionRateDetails> page = null;
	List<CloudCurrencyConversionRateDetails> content = new ArrayList<>();
	dbContent = currencyConversionRateRepository.findAll(constructPageSpecification(request.getPageable().getPageNumber(), request.getPageable().getPageSize(), sortByIdAsc()));
	if(null != dbContent){
		for (CloudCurrencyConversionRate record : NepheleValidationUtils.nullSafe(dbContent)) {
		  		CloudCurrencyConversionRateDetails details    = CloudCurrencyConversionRateDetails.builder()
                                                                                		  .id(record.getId())
                                                                                		  .conversionRate(record.getConversionRate())
                                                                                		  .sourceCurrency(record.getSourceCurrency().name())
                                                                                		  .targetCurrency(record.getTargetCurrency().name())
                                                                                		  .build();
				content.add(details);
		}
		 page = new PageImpl<>(content, request.getPageable(),dbContent.getTotalElements());
	}else{
		page = new PageImpl<>(content);
	}
	log.debug("readCloudCurrencyConversionRates() - end");
	return new PageReadEvent<>(page);
  }
  
  
  
}
