package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
//@EqualsAndHashCode
@Setter
@Getter
@Builder
@Accessors(chain=true)
public class MarketPlaceProductServiceDetails {
	private Long serviceId;
	private Long operatingSystemId;
	private String name;
	private Boolean isPublished;
	private String status;
}
