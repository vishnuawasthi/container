package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudProductPlanEvent extends ReadEntityEvent<ReadCloudProductPlanEvent>{
	
	private Long productPlanId;
	private Long productId;
	private Long locationId;
	private String flavorCategory;

}
