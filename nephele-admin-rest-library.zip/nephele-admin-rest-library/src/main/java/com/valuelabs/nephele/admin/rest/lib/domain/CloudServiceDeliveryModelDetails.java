package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudServiceDeliveryModelDetails {

	private Long serviceDeliveryModelId;
	private String name;
	private String description;
}
