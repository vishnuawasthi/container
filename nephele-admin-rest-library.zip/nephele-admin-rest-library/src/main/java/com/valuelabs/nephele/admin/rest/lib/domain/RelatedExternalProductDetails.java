package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = false)
public class RelatedExternalProductDetails {
	
	private Long relatedExtProductId;
	private String externalId;
	private Long cloudProductId;
	private String cloudProductName;
	private String cloudproductDes;
	private List<Long> externalProducts;	
	private Long externalProductId;
	private String externalProductName;
	private String externalProductDes;
	private String status;
	private Long serviceId;
	private String serviceName;
	private CloudProductDetails cloudProductDetails;
	
	

}
