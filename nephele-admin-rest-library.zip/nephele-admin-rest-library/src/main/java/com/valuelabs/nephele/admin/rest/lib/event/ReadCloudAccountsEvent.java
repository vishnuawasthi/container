package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;


@Accessors(chain = true)
@Setter
@Getter
public class ReadCloudAccountsEvent  extends ReadPageEvent<ReadCloudAccountsEvent>{

  private Long id;
  private String vendorAccountId;
  private String status;
  private Long serviceId;
  
}
