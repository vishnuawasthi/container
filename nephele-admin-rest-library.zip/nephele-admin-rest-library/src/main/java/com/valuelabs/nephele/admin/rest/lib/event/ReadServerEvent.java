package com.valuelabs.nephele.admin.rest.lib.event;



import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;


//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadServerEvent extends ReadEntityEvent<ReadServerEvent>{
	
	private Long serverId;
	private String name;
	private String status;
	private String uri;
	private String privateAddress;
	private String serverGroup;
	private String username;
	private String publicAddress;
	private String password;
	private String cspServerId;
	private Long cloudCustomerCompanyId;
	private Long cloudProductId;
    private Long cloudServiceId;
    private Long cloudOrderId;
    private Long cloudOrderLineId;

}
