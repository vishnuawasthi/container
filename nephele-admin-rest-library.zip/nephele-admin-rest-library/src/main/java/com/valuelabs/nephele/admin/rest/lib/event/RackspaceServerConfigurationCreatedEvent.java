package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.RackspaceServerConfigurationDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class RackspaceServerConfigurationCreatedEvent {
	private RackspaceServerConfigurationDetails rackspaceServerConfigurationDetails;
	private boolean invalid;
	private boolean failed;
	public RackspaceServerConfigurationCreatedEvent(RackspaceServerConfigurationDetails rackspaceServerConfigurationDetails) {
		this.rackspaceServerConfigurationDetails = rackspaceServerConfigurationDetails;
	}

	public static RackspaceServerConfigurationCreatedEvent invalid(RackspaceServerConfigurationDetails rackspaceServerConfigurationDetails) {
		RackspaceServerConfigurationCreatedEvent event = new RackspaceServerConfigurationCreatedEvent(rackspaceServerConfigurationDetails);
		event.setInvalid(true);
		return event;
	}

	public static RackspaceServerConfigurationCreatedEvent failed(RackspaceServerConfigurationDetails rackspaceServerConfigurationDetails) {
		RackspaceServerConfigurationCreatedEvent event = new RackspaceServerConfigurationCreatedEvent(rackspaceServerConfigurationDetails);
		event.setFailed(true);
		return event;
	}

}