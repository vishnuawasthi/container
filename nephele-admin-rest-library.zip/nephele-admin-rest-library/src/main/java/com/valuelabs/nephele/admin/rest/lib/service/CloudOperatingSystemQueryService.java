package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.Map;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntitiesReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadOperatingSystemEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadOperatingSystemsEvent;

public interface CloudOperatingSystemQueryService {
	EntityReadEvent<CloudOperatingSystemDetails> readOperatingSystem(ReadOperatingSystemEvent request);
	PageReadEvent<CloudOperatingSystemDetails> readOperatingSystems(ReadOperatingSystemsEvent request);
	PageReadEvent<CloudOperatingSystemDetails> readByStatus(ReadOperatingSystemsEvent request);
	PageReadEvent<CloudOperatingSystemDetails> readByServiceId(ReadOperatingSystemsEvent request);
	Map<String, Long> readSummaryByServiceId(ReadOperatingSystemsEvent request);
	EntitiesReadEvent<CloudOperatingSystemDetails> readEntitiesByServiceAndStatus(ReadOperatingSystemsEvent request);
}
