package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPriceMgmtConfigDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
public class CreateProductPriceMgmtConfigEvent {

	private CloudProductPriceMgmtConfigDetails productPriceMgmtConfigDetails;
}
