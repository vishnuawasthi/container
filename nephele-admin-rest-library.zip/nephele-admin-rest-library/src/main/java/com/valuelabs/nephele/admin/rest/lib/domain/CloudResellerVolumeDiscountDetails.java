package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain = true)
public class CloudResellerVolumeDiscountDetails {

	private Integer resellerVolumeDiscountId;
	private Integer resellerPremiumGroupId;
	private String resellerPremiumGroupName;
	private Integer serviceId;
	private String serviceName;
}
