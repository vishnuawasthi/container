package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.entity.CloudLocation;
import com.valuelabs.nephele.admin.data.repository.CloudLocationRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntitiesReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudLocationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudLocationsEvent;

@Slf4j
@Service("CloudLocationQueryServiceLib")
public class CloudLocationQueryServiceImpl implements CloudLocationQueryService {

	/*@Autowired
	private CloudLocationDAO cloudLocationDAO;*/
	
	@Autowired
	private CloudLocationRepository locationRepository;
	

	@Override
	public EntityReadEvent<CloudLocationDetails> readCloudLocation(
			ReadCloudLocationEvent request) {
		log.debug("readCloudLocation() - start");
		CloudLocation record = locationRepository.findOne(request
				.getCloudLocationId());
		if (null == record) {
			log.debug("Location with LocationId {} not found.",
					request.getCloudLocationId());
			return EntityReadEvent.<CloudLocationDetails> notFound();
		}
		CloudLocationDetails cloudLocationDetails = CloudLocationDetails
				.builder().cloudLocationId(record.getId())
				.name(record.getName()).status(record.getStatus())
				.cloudServiceId(record.getCloudService().getId()).build();
		log.debug("readCloudLocation() - end");
		return new EntityReadEvent<>(cloudLocationDetails);

	}

	@Override
	public PageReadEvent<CloudLocationDetails> readCloudLocations(
			ReadCloudLocationsEvent request) {
		log.debug("readCloudLocations() START");
		List<CloudLocation> dbContent = new ArrayList<>();
		dbContent = locationRepository.findAll();
		List<CloudLocationDetails> content = new ArrayList<>();
		long total = 0;
		for (CloudLocation record : dbContent) {
			if (total >= request.getPageable().getOffset()
					&& total < request.getPageable().getOffset()
							+ request.getPageable().getPageSize()) {
				CloudLocationDetails details = CloudLocationDetails.builder()
						.cloudLocationId(record.getId()).name(record.getName())
						.status(record.getStatus())
						.cloudServiceId(record.getCloudService().getId()).build();
				content.add(details);
			}
			++total;
		}
		// Long total=(long) dbContent.size();
		Page<CloudLocationDetails> page = new PageImpl<>(content,
				request.getPageable(), total);
		log.debug("readCloudLocations() END");
		return new PageReadEvent<>(page);
	}

	@Override
	public PageReadEvent<CloudLocationDetails> findByStatus(ReadCloudLocationsEvent request) {
		log.debug("findByStatus() -- start");
		List<CloudLocation> dbContent = new ArrayList<>();
		dbContent = locationRepository.findByStatus(request.getStatus());
		List<CloudLocationDetails> content = new ArrayList<>();
		long total = 0;
		for (CloudLocation record : dbContent) {
			if (total >= request.getPageable().getOffset()
					&& total < request.getPageable().getOffset()
							+ request.getPageable().getPageSize()) {
				CloudLocationDetails details = CloudLocationDetails.builder()
						.cloudLocationId(record.getId()).name(record.getName())
						.status(record.getStatus())
						.cloudServiceId(record.getCloudService().getId()).build();
				content.add(details);
			}
			++total;
		}
		// Long total=(long) dbContent.size();
		Page<CloudLocationDetails> page = new PageImpl<>(content,
				request.getPageable(), total);
		log.debug("findByStatus() -- end");
		return new PageReadEvent<>(page);
	}
	
	@Override
	public EntitiesReadEvent<CloudLocationDetails> findByNameNStatus(ReadCloudLocationsEvent request) {
		log.debug("findByNameNStatus() -- start");
		List<CloudLocationDetails> detailsList = new ArrayList<CloudLocationDetails>();
		CloudLocationDetails details = null;
		List<CloudLocation> list = locationRepository.findByNameNStatus(request.getName(), request.getStatus());
		
		if(CollectionUtils.isEmpty(list)){
			for (CloudLocation record : list) {
				//CloudLocation record = list.get(0);
				details = CloudLocationDetails.builder().cloudLocationId(record.getId())
						 .name(record.getName())
						 .status(record.getStatus())
						 .cloudServiceId(record.getCloudService().getId())
						 .build();
				detailsList.add(details);
			}
			
		}
		log.debug("findByNameNStatus() -- end");
		return new EntitiesReadEvent<>(detailsList);
	}
	
	/*@Override
	public Map<String, String> getGeographiesMap() {
		Map<String, String> geographiesMap = new HashMap<String, String>();
		geographiesMap.put(GeographyCode.AUS, GeographyName.AUSTRALIA);
		geographiesMap.put(GeographyCode.APAC, GeographyName.ASIA_PACIFIC);
		geographiesMap.put(GeographyCode.USA,
				GeographyName.UNITED_STATE_OF_AMERICA);
		return geographiesMap;
	}

	@Override
	public Map<String, String> getLocationsMap() {
		Map<String, String> locationsMap = new HashMap<String, String>();
		locationsMap.put(LocationsCode.IAD, LocationsValue.NORTHERN_VERGINIA);
		locationsMap.put(LocationsCode.DFW, LocationsValue.DALLAS);
		locationsMap.put(LocationsCode.ORD, LocationsValue.CHICAGO);
		locationsMap.put(LocationsCode.HKG, LocationsValue.HONG_KONG);
		locationsMap.put(LocationsCode.SYD, LocationsValue.SYDNEY);
		return locationsMap;
	}*/


}
