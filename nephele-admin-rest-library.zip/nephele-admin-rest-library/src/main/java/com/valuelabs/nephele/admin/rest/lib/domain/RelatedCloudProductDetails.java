package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = false)
public class RelatedCloudProductDetails {
	
	private Long id;
	private Long cloudProductId;
	private String cloudProductName;
	private String cloudproductDes;
	private List<Long> relatedCloudProducts;
	private Long relatedCloudProductId;
	private String relatedProductName;
	private String relatedProductDes;
	private String status;
	private Long serviceId;
	private String serviceName;
	private CloudProductDetails cloudProductDetails;
	

}
