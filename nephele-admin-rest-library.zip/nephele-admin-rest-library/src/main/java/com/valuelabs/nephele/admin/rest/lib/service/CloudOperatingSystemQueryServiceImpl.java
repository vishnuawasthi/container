package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.data.entity.CloudOperatingSystem;
import com.valuelabs.nephele.admin.data.repository.CloudOperatingSystemRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudOperatingSystemDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntitiesReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadOperatingSystemEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadOperatingSystemsEvent;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleStatusWrapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CloudOperatingSystemQueryServiceImpl implements
		CloudOperatingSystemQueryService {

	/*@Autowired
	CloudOperatingSystemDAO operatingSystemDAO;*/
	
	@Autowired
	CloudOperatingSystemRepository operatingSystemRepository;

	@Override
	public EntityReadEvent<CloudOperatingSystemDetails> readOperatingSystem(
			ReadOperatingSystemEvent request) {
		log.debug("readOperatingSystem() START ");
		CloudOperatingSystem record = operatingSystemRepository.findOne(request
				.getOperatingSystemId());
		if (null == record) {
			log.debug("Service with ServiceId {} not found.",
					request.getOperatingSystemId());
			return EntityReadEvent.<CloudOperatingSystemDetails> notFound();
		}
		CloudOperatingSystemDetails operatingSystemDetails = CloudOperatingSystemDetails
				.builder().operatingSystemId(record.getId())
				.cspResource(record.getCspResource())
				.imageId(record.getImageId()).name(record.getName())
				.status(record.getStatus()).minDisk(record.getMinDisk())
				.minRam(record.getMinRam())
				.serviceId(record.getCloudService().getId()).build();
		log.debug("readOperatingSystem() END ");
		return new EntityReadEvent<>(operatingSystemDetails);
	}

	@Override
	public PageReadEvent<CloudOperatingSystemDetails> readOperatingSystems(
			ReadOperatingSystemsEvent request) {
		log.debug("readOperatingSystems() START ");
		List<CloudOperatingSystem> dbContent = new ArrayList<>();
		dbContent = operatingSystemRepository.findAll();
		List<CloudOperatingSystemDetails> content = new ArrayList<>();
		long total = 0;
		for (CloudOperatingSystem record : dbContent) {
			if(total >= request.getPageable().getOffset() && total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
				CloudOperatingSystemDetails details = CloudOperatingSystemDetails
						.builder().operatingSystemId(record.getId())
						.name(record.getName())
						.cspResource(record.getCspResource()).imageId(record.getImageId()).minDisk(record.getMinDisk()).minRam(record.getMinRam())
						.status(record.getStatus()).serviceId(record.getCloudService().getId()).build();
				content.add(details);
			}
			++ total;
		}
		//Long total=(long) dbContent.size();
		Page<CloudOperatingSystemDetails> page = new PageImpl<>(content, request.getPageable(),total);
		log.debug("readOperatingSystems() END ");
		return new PageReadEvent<>(page);
	}

	@Override
	public PageReadEvent<CloudOperatingSystemDetails> readByStatus(ReadOperatingSystemsEvent request) {
		log.debug("readByStatus() - START");
		List<CloudOperatingSystem> dbContent = new ArrayList<>();
		dbContent = operatingSystemRepository.getByServiceAndStatus(request.getServiceId(), request.getStatus());
		List<CloudOperatingSystemDetails> content = new ArrayList<>();
		long total = 0;
		for (CloudOperatingSystem record : dbContent) {
			if(total >= request.getPageable().getOffset() && total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
				CloudOperatingSystemDetails details = CloudOperatingSystemDetails
						.builder().operatingSystemId(record.getId())
						.name(record.getName())
						.cspResource(record.getCspResource()).imageId(record.getImageId()).minDisk(record.getMinDisk()).minRam(record.getMinRam())
						.status(record.getStatus()).serviceId(record.getCloudService().getId()).build();
				content.add(details);
			}
			++ total;
		}
		Page<CloudOperatingSystemDetails> page = new PageImpl<>(content, request.getPageable(),total);
		log.debug("readByStatus() - END");
		return new PageReadEvent<>(page);
	}

	@Override
	public PageReadEvent<CloudOperatingSystemDetails> readByServiceId(
			ReadOperatingSystemsEvent request) {
		log.debug("readByServiceId() - START");
		List<CloudOperatingSystem> dbContent = new ArrayList<>();
		dbContent = operatingSystemRepository.getByService(request.getServiceId());
		List<CloudOperatingSystemDetails> content = new ArrayList<>();
		long total = 0;
		for (CloudOperatingSystem record : dbContent) {
			if(total >= request.getPageable().getOffset() && total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
				CloudOperatingSystemDetails details = CloudOperatingSystemDetails
						.builder().operatingSystemId(record.getId())
						.name(record.getName())
						.cspResource(record.getCspResource()).imageId(record.getImageId()).minDisk(record.getMinDisk()).minRam(record.getMinRam())
						.status(record.getStatus()).serviceId(record.getCloudService().getId()).build();
				content.add(details);
			}
			++ total;
		}
		Page<CloudOperatingSystemDetails> page = new PageImpl<>(content, request.getPageable(),total);
		log.debug("readByServiceId() - END");
		return new PageReadEvent<>(page);
		}
	
	@Override
	public EntitiesReadEvent<CloudOperatingSystemDetails> readEntitiesByServiceAndStatus(ReadOperatingSystemsEvent request) {
		log.debug("readEntitiesByServiceAndStatus() - START");
		List<CloudOperatingSystemDetails> content = new ArrayList<>();
		
		List<CloudOperatingSystem> stagedOSList = operatingSystemRepository.getByServiceAndStatus(request.getServiceId(), InventoryStatus.STAGED.name());
		
		for (CloudOperatingSystem record : stagedOSList) {
				CloudOperatingSystemDetails details = CloudOperatingSystemDetails.builder().operatingSystemId(record.getId())
																						   .name(record.getName())
																						   .cspResource(record.getCspResource())
																						   .imageId(record.getImageId())
																						   .minDisk(record.getMinDisk())
																						   .minRam(record.getMinRam())
																						   .status(record.getStatus())
																						   .serviceId(record.getCloudService().getId())
																						   .build();
				content.add(details);
		}
		log.debug("readEntitiesByServiceAndStatus() - END");
		return new EntitiesReadEvent<>(content);
	}

	@Override
	public Map<String, Long> readSummaryByServiceId(ReadOperatingSystemsEvent request) {
		log.debug("readSummaryByServiceId() - start");
		List<Object[]> details= operatingSystemRepository.findOperatingSystemSummaryByServiceId(request.getServiceId());
		Map<String, Long> resultMap = new HashMap<String, Long>(details.size());
			for (Object[] result : details){
				  resultMap.put((String)result[0], (Long)result[1]);
			}
		NepheleStatusWrapper.setUnavailableStatus( resultMap);
		log.debug("readSummaryByServiceId() - end");
		return resultMap;
	}
	
	

}
