package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudConfigurationTypeDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudConfigurationTypeDetailsCreatedEvent {
	private CloudConfigurationTypeDetails cloudConfigurationTypeDetails;

	private boolean invalid;
	private boolean failed;

	public CloudConfigurationTypeDetailsCreatedEvent(CloudConfigurationTypeDetails cloudConfigurationTypeDetails) {
		this.cloudConfigurationTypeDetails = cloudConfigurationTypeDetails;
	}

	public static CloudConfigurationTypeDetailsCreatedEvent invalid(CloudConfigurationTypeDetails cloudConfigurationTypeDetails) {
		CloudConfigurationTypeDetailsCreatedEvent event = new CloudConfigurationTypeDetailsCreatedEvent(cloudConfigurationTypeDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudConfigurationTypeDetailsCreatedEvent failed(CloudConfigurationTypeDetails cloudConfigurationTypeDetails) {
		CloudConfigurationTypeDetailsCreatedEvent event = new CloudConfigurationTypeDetailsCreatedEvent(cloudConfigurationTypeDetails);
		event.setFailed(true);
		return event;
	}

}
