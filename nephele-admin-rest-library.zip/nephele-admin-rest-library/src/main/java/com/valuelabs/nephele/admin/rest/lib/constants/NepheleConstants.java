package com.valuelabs.nephele.admin.rest.lib.constants;

public class NepheleConstants {
	
	public static final String MARKETPLACE = "marketplace";
	public static final String MANAGER = "manager";
	public static final String GLOBAL_LOGOUT = "globalLogout";
	public static final String API_KEY = "api-key";
	public static final String X_RESELLER_KEY = "X-RESELLER-KEY";
	public static final String X_CUSTOMER_KEY = "X-CUSTOMER-KEY";
	public static final String OPTIONS = "OPTIONS";
	public static final String AUTHORIZATION = "authorization";
	public static final String MONTHLY = "MONTHLY";
	public static final String WEEKLY = "WEEKLY";
	public static final String PDF_FILE_EXTENSION = ".pdf";
	public static final String PAID = "PAID";
	public static final String CSV_FILE_EXTENSION = ".csv";
	public static final String CSV = "CSV";
	public static final String PDF = "PDF";
	public static final String 	CLOUD_BANDWIDTH = "Cloud Bandwidth";
	public static final String CLOUD_SERVERS = "Cloud Servers";
	public static final String CLOUD_SERVER_DESCRIPTION = "Compute charge per hour";
	public static final String CLOUD_BANDWIDTH_DESCRIPTION = "Bandwidth charge per gigabyte";
	public static final String CLOUD_BANDWIDTH_PLAN_DESC = "Bandwidth Out";
	public static final String X_MARKETPLACE_SECRET_KEY="X-MARKETPLACE-SECRET-KEY";
}
