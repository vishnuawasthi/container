package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.valuelabs.nephele.admin.rest.lib.resource.StartPlanResource;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = false)
@JsonInclude(Include.NON_NULL)
public class CloudProductDetails {
	
	private Long cloudProductId;
	private String name;
	private String description;
	private String type;
	private String status;
	private StartPlanResource startingPlan;
    private Long operatingSystemId;
    private String operatingSystemName;
    private Long cloudServiceId;
    private String serviceCode;
    private String integrationCode;
    private String serviceName;
    private String brandCode;
    private String brandName;
    private Long categoryId;
    private String categoryName;
	private Boolean isFeatured;
	private Boolean hasFreeTrial;
	private Boolean hasRelatedProducts;

}
