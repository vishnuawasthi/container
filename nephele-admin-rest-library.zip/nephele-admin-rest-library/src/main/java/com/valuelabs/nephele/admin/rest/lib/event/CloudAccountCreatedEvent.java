package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;

@Setter
@Getter
@Accessors(chain = true)
public class CloudAccountCreatedEvent {
  private boolean invalid;
  private boolean failed;
  private CloudAccountDetails accountDetails;

  public CloudAccountCreatedEvent() {
	this.accountDetails = accountDetails;
  }

  public CloudAccountCreatedEvent(CloudAccountDetails accountDetails) {
	this.accountDetails = accountDetails;
  }

  public static CloudAccountCreatedEvent invalid(CloudAccountDetails accountDetails) {
	CloudAccountCreatedEvent event = new CloudAccountCreatedEvent(accountDetails);
	event.setInvalid(true);
	return event;
  }

  public static CloudAccountCreatedEvent failed(CloudAccountDetails accountDetails) {
	CloudAccountCreatedEvent event = new CloudAccountCreatedEvent(accountDetails);
	event.setFailed(true);
	return event;
  }

}
