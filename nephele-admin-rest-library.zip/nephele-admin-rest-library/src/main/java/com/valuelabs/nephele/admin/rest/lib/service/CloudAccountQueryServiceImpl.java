package com.valuelabs.nephele.admin.rest.lib.service;

import static com.valuelabs.nephele.admin.data.repository.CloudServerSpecifications.constructPageSpecification;
import static com.valuelabs.nephele.admin.data.repository.CloudServerSpecifications.sortByIdAsc;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.api.NomadeskVendorPlanCode;
import com.valuelabs.nephele.admin.data.entity.CloudAccount;
import com.valuelabs.nephele.admin.data.entity.CloudSubscription;
import com.valuelabs.nephele.admin.data.repository.CloudAccountRepository;
import com.valuelabs.nephele.admin.data.repository.CloudAccountSpecifications;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudServiceDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAccountsEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudProductPlanEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadServiceEvent;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;


@Service
@Slf4j
public class CloudAccountQueryServiceImpl implements CloudAccountQueryService {

	@Autowired
	private CloudAccountRepository cloudAccountRepository;
  
  	@Autowired
	private CloudServiceQueryService cloudServiceQueryService;
	
	@Autowired
	private CloudProductPlanQueryService CloudProductPlanQueryService;
  
  @Override
  public EntityReadEvent<CloudAccountDetails> readCloudAccount(ReadCloudAccountEvent request) {
	log.debug("readCloudAccount() - start");
	List<CloudSubscriptionDetails> subscriptionDetailsList = new ArrayList<CloudSubscriptionDetails>();
	Long monthlyLicenseCount = 0l;
	Long yearlyLicenseCount = 0l;
	CloudSubscriptionDetails subscriptionDetails = null;
	
	
	CloudAccount entity = cloudAccountRepository.findOne(request.getId());
	
	if (null == entity) {
		log.debug("CloudAccountService with accountId {} not found.",
				request.getId());
		return EntityReadEvent.<CloudAccountDetails> notFound();
	}	
	
	CloudAccountDetails details = null;
	
	Set<CloudSubscription> subscriptionList = entity.getCloudSubscription();
	
	for (CloudSubscription record : NepheleValidationUtils.nullSafe(subscriptionList)) {
		if(NomadeskVendorPlanCode.monthly.name().equalsIgnoreCase(record.getCloudProductPlan().getVendorPlanCode())){
			++monthlyLicenseCount;
		}else if(NomadeskVendorPlanCode.yearly.name().equalsIgnoreCase(record.getCloudProductPlan().getVendorPlanCode())){
			++yearlyLicenseCount;
		}
		
		EntityReadEvent<CloudServiceDetails> serviceResponse = cloudServiceQueryService.readService(new ReadServiceEvent().setId(record.getCloudAccount().getCloudService().getId()));
		EntityReadEvent<CloudProductPlanDetails> planResponse = CloudProductPlanQueryService.readProductPlanService(new ReadCloudProductPlanEvent().setProductPlanId(record.getCloudProductPlan().getId()));
		if(null != serviceResponse && null != planResponse){
			subscriptionDetails = CloudSubscriptionDetails.builder().subscriptionId(record.getId())				
																	.resellerId(record.getCloudResellerCompany() != null ? record.getCloudResellerCompany().getId() : null )	
																	.resellerName(record.getCloudResellerCompany().getResellerCompanyName() != null ? record.getCloudResellerCompany().getResellerCompanyName() : null )
																	.customerId(record.getCloudCustomerCompany() != null ? record.getCloudCustomerCompany().getId() : null )
																	.customerName(record.getCloudCustomerCompany().getCustomerCompanyName() != null ? record.getCloudCustomerCompany().getCustomerCompanyName() : null)
																	.orderId(record.getCloudOrder() != null ? record.getCloudOrder().getId() : null)				
																	.vendorSubscriptionId(record.getVendorSubscrioptionId())
																	.accountId(record.getCloudAccount().getCloudService() != null ? record.getCloudAccount().getId() : null )
																	.cloudServiceDetails(serviceResponse.getEntity())
																	.cloudProductPlanDetails(planResponse.getEntity())
																	.cloudProductPlanId(record.getCloudProductPlan() != null ? record.getCloudProductPlan().getId() : null )
																	.planName(record.getCloudProductPlan().getPlanName() != null ? record.getCloudProductPlan().getPlanName() : null)
																	.description(record.getDescription())
																	.isNewSubArrearInvoiced(record.isNewSubscriptionArrearInvoiced())
																	.lastInvoicedDate(record.getLastInvoicedDate())
																	.licenseCount(record.getLicenseCount())
																	.subscriptionDate(record.getSubscriptionDate())
																	.subscriptionStatus(record.getSubscriptionStatus().toString())
																	.subscriptionLastRenewalDate(record.getSubscriptionLastRenewalDate())
																	.autoRenewalOffDate(record.getAutoRenewalOffDate())
																	.licenseAutoRenewal(record.isLicenseAutoRenewal())
																	.build();
		}
		
		subscriptionDetailsList.add(subscriptionDetails);
	}
	
	if(entity!=null) {
	  details = CloudAccountDetails.builder()
                        		  .id(entity.getId())
                        		  .username(entity.getUsername())
                        		  .password(entity.getPassword())
                        		  .superUsername(entity.getSuperUsername())
                        		  .superPassword(entity.getSuperPassword())
                        		  .superAPIKey(entity.getSuperAPIKey())
                        		  .vendorAccountId(entity.getVendorAccountId())
                        		  .cloudCustomerCompanyId(entity.getCloudCustomerCompany() != null ? entity.getCloudCustomerCompany().getId() : null)
                        		  .cloudCustomerCompanyName(entity.getCloudCustomerCompany() != null ? entity.getCloudCustomerCompany().getCustomerCompanyName() : null)
                        		  .cloudServiceId(entity.getCloudService() !=null ? entity.getCloudService().getId() : null)
                        		  .cloudServiceName(entity.getCloudService() !=null ? entity.getCloudService().getName() : null)
                        		  .isLive(entity.getCloudService() !=null ? entity.getCloudService().getIsLive(): null)
                        		  .isPublished(entity.getCloudService() !=null ? entity.getCloudService().getIsPublished() :null)
                        		  .description(entity.getCloudService() !=null ? entity.getCloudService().getDescription():null)
                        		  .integrationCode(entity.getCloudService() !=null ? entity.getCloudService().getIntegrationCode():null)
                        		  .serviceCode(entity.getCloudService() !=null ? entity.getCloudService().getServiceCode():null)
                        		  .vendorCode(entity.getCloudService() !=null ? entity.getCloudService().getVendorCode():null)
                        		  .billingCycle(entity.getCloudService() !=null ? entity.getCloudService().getBillingCycle():null)
                        		  .billingDay(entity.getCloudService() !=null ? entity.getCloudService().getBillingDay():null)
                        		  .planPrefix(entity.getCloudService() !=null ? entity.getCloudService().getPlanPrefix():null)
                        		  .subscriptionNamePrefix(entity.getCloudService() !=null ? entity.getCloudService().getSubscriptionNamePrefix():null)
                        		  .vendorCurrency(entity.getCloudService() !=null ? entity.getCloudService().getVendorCurrency():null)
                        		  .vendorStatus(entity.getVendorStatus() != null ? entity.getVendorStatus().name() : null )
                        		  .nepheleStatus(entity.getNepheleStatus() != null ? entity.getNepheleStatus() : null )
                        		  .orderId(entity.getCloudOrder() != null ? entity.getCloudOrder().getId() : null )
                        		  .orderCode(entity.getCloudOrder() != null ? entity.getCloudOrder().getOrderCode() : null )
                        		  .isTrialAccount(entity.getCloudProductPlan() != null ? entity.getCloudProductPlan().getIsTrialPlan() : false)
                        		  .subscriptionDetails(subscriptionDetailsList)
                        		  .monthlyLicenseCount(monthlyLicenseCount)
                        		  .yearlyLicenseCount(yearlyLicenseCount)
                        		  .build();
	}
	log.debug("readCloudAccount() - end");
	return new EntityReadEvent<CloudAccountDetails>(details);
  }

  @Override
  public PageReadEvent<CloudAccountDetails> readCloudAccounts(ReadCloudAccountsEvent request) {
	log.debug("readCloudAccounts() - start");
	Page<CloudAccount> dbContent = null;
	Page<CloudAccountDetails> page = null;
	List<CloudAccountDetails> content = new ArrayList<>();
	dbContent = cloudAccountRepository.findAll(CloudAccountSpecifications.findByFilter(request.getServiceId()),constructPageSpecification(request.getPageable().getPageNumber(), request.getPageable().getPageSize(), sortByIdAsc()));
	if(null != dbContent){
	for (CloudAccount record : NepheleValidationUtils.nullSafe(dbContent)) {
	  //if (total >= request.getPageable().getOffset()&& total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
		
		CloudAccountDetails details = CloudAccountDetails.builder()
                                          			  .id(record.getId())
                                             		  .username(record.getUsername())
                                             		  .password(record.getPassword())
                                             		  .superUsername(record.getSuperUsername())
                                             		  .superPassword(record.getSuperPassword())
                                             		  .superAPIKey(record.getSuperAPIKey())
                                             		  .vendorAccountId(record.getVendorAccountId())
                                             		  .cloudCustomerCompanyId(record.getCloudCustomerCompany() != null ? record.getCloudCustomerCompany().getId() : null)
                                             		  .cloudCustomerCompanyName(record.getCloudCustomerCompany() != null ? record.getCloudCustomerCompany().getCustomerCompanyName() : null)
                                             		  .cloudServiceId(record.getCloudService() !=null ? record.getCloudService().getId() : null)
                                             		  .cloudServiceName(record.getCloudService() !=null ? record.getCloudService().getName() : null)
                                             		  .isLive(record.getCloudService() !=null ? record.getCloudService().getIsLive(): null)
                                              		  .isPublished(record.getCloudService() !=null ? record.getCloudService().getIsPublished() :null)
                                              		  .description(record.getCloudService() !=null ? record.getCloudService().getDescription():null)
                                              		  .integrationCode(record.getCloudService() !=null ? record.getCloudService().getIntegrationCode():null)
                                              		  .serviceCode(record.getCloudService() !=null ? record.getCloudService().getServiceCode():null)
                                              		  .vendorCode(record.getCloudService() !=null ? record.getCloudService().getVendorCode():null)
                                              		  .billingCycle(record.getCloudService() !=null ? record.getCloudService().getBillingCycle():null)
                                              		  .billingDay(record.getCloudService() !=null ? record.getCloudService().getBillingDay():null)
                                              		  .planPrefix(record.getCloudService() !=null ? record.getCloudService().getPlanPrefix():null)
                                              		  .subscriptionNamePrefix(record.getCloudService() !=null ? record.getCloudService().getSubscriptionNamePrefix():null)
                                              		  .vendorCurrency(record.getCloudService() !=null ? record.getCloudService().getVendorCurrency():null)
                                             		  .vendorStatus(record.getVendorStatus() != null ? record.getVendorStatus().name() : null )
                                             		  .nepheleStatus(record.getNepheleStatus() != null ? record.getNepheleStatus() : null )
                                             		  .orderId(record.getCloudOrder() != null ? record.getCloudOrder().getId() : null )
                                             		  .orderCode(record.getCloudOrder() != null ? record.getCloudOrder().getOrderCode() : null )
                                             		  .build();
		content.add(details);
	 // }
	  //++total;
	}
	 page = new PageImpl<>(content, request.getPageable(),dbContent.getTotalElements());
	}else {
	  page = new PageImpl<>(content);
	}
	// Long total=(long) dbContent.size();
	log.debug("readCloudAccounts() - end");
	return new PageReadEvent<>(page);
  }

@Override
public CloudAccountDetails getAccountDetailsWithCustomerIdAndServiceId(Long customerId,Long serviceId) {
	log.debug("getAccountDetailsWithCustomerId() - start");
	CloudAccountDetails accountDetails = null;
	CloudAccount record = cloudAccountRepository.getAccountByCustomerIdAndServiceId(customerId, serviceId);
	if(null != record){
		 accountDetails = CloudAccountDetails.builder()
    		  .id(record.getId())
       		  .username(record.getUsername())
       		  .password(record.getPassword())
       		  .superUsername(record.getSuperUsername())
       		  .superPassword(record.getSuperPassword())
       		  .superAPIKey(record.getSuperAPIKey())
       		  .vendorAccountId(record.getVendorAccountId())
       		  .cloudCustomerCompanyId(record.getCloudCustomerCompany() != null ? record.getCloudCustomerCompany().getId() : null)
    		  .cloudCustomerCompanyName(record.getCloudCustomerCompany() != null ? record.getCloudCustomerCompany().getCustomerCompanyName() : null)
    		  .cloudServiceId(record.getCloudService() !=null ? record.getCloudService().getId() : null)
    		  .cloudServiceName(record.getCloudService() !=null ? record.getCloudService().getName() : null)
    		  .vendorStatus(record.getVendorStatus() != null ? record.getVendorStatus().name() : null )
              .nepheleStatus(record.getNepheleStatus() != null ? record.getNepheleStatus() : null )
    		  .orderId(record.getCloudOrder() != null ? record.getCloudOrder().getId() : null )
    		  .orderCode(record.getCloudOrder() != null ? record.getCloudOrder().getOrderCode() : null )
       		  .build();
	}
	log.debug("getAccountDetailsWithCustomerId() - end");
	return accountDetails;
}

}
