package com.valuelabs.nephele.admin.rest.lib.service;

import static com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateSpecifications.constructPageSpecification;
import static com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateSpecifications.sortByIdAsc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRate;
import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRateAudit;
import com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateAuditRepository;
import com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateAuditDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRateAuditEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRatesAuditEvent;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CloudCurrencyConversionRateQueryAuditServiceImpl implements CloudCurrencyConversionRateAuditQueryService {

	@Autowired
	private CloudCurrencyConversionRateAuditRepository currencyConversionRateAuditRepository;

	@Autowired
	private CloudCurrencyConversionRateRepository currencyConversionRateRepository;

	@Override
	public EntityReadEvent<CloudCurrencyConversionRateAuditDetails> readCloudCurrencyConversionRateAudit(
			ReadCloudCurrencyConversionRateAuditEvent request) {
		log.debug("readCloudCurrencyConversionRateAudit() - start");
		CloudCurrencyConversionRateAudit entity = currencyConversionRateAuditRepository.findOne(request.getId());

		if (entity == null) {
			log.debug("CloudCurrencyConversionRateAudit Record not found for give id :" + request.getId());
			return EntityReadEvent.<CloudCurrencyConversionRateAuditDetails> notFound();
		}

		CloudCurrencyConversionRateAuditDetails details = null;

		if (entity != null) {
			details = CloudCurrencyConversionRateAuditDetails.builder().auditId(entity.getId())
					.conversionRate(entity.getConversionRate()).createdOn(entity.getCreatedOn())
					.currencyConversionRateId(entity.getCloudCurrencyConversionRate().getId()).build();
		}
		log.debug("readCloudCurrencyConversionRateAudit() - end");
		return new EntityReadEvent<CloudCurrencyConversionRateAuditDetails>(details);
	}

	@Override
	public PageReadEvent<CloudCurrencyConversionRateAuditDetails> readCloudCurrencyConversionRatesAudit(
			ReadCloudCurrencyConversionRatesAuditEvent request) {
		log.debug("readCloudCurrencyConversionRatesAudit() -start");
		Page<CloudCurrencyConversionRateAudit> dbContent = null;
		Page<CloudCurrencyConversionRateAuditDetails> page = null;
		List<CloudCurrencyConversionRateAuditDetails> content = new ArrayList<>();
		dbContent = currencyConversionRateAuditRepository.findAll(constructPageSpecification(
				request.getPageable().getPageNumber(), request.getPageable().getPageSize(), sortByIdAsc()));
		if (null != dbContent) {
			for (CloudCurrencyConversionRateAudit record : NepheleValidationUtils.nullSafe(dbContent)) {

				CloudCurrencyConversionRate entity = currencyConversionRateRepository
						.findOne(record.getCloudCurrencyConversionRate().getId());
				CloudCurrencyConversionRateDetails entitydetails = null;
				if (entity != null) {

					CloudCurrencyConversionRateAuditDetails details = CloudCurrencyConversionRateAuditDetails.builder()
							.auditId(record.getId()).conversionRate(record.getConversionRate())
							.createdOn(record.getCreatedOn())
							.currencyConversionRateId(record.getCloudCurrencyConversionRate().getId())
							.sourceCurrency(entity.getSourceCurrency().toString())
							.targetCurrency(entity.getTargetCurrency().toString()).build();
					content.add(details);
				}
			}
			page = new PageImpl<>(content, request.getPageable(), dbContent.getTotalElements());
		} else {
			page = new PageImpl<>(content);
		}
		log.debug("readCloudCurrencyConversionRatesAudit() - end");
		return new PageReadEvent<>(page);
	}

}
