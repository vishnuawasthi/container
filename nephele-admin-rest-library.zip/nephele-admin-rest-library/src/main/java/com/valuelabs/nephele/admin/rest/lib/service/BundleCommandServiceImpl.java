package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.HashSet;
import java.util.Set;

import javax.transaction.Transactional;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.BundleStatus;
import com.valuelabs.nephele.admin.data.entity.Bundle;
import com.valuelabs.nephele.admin.data.entity.BundleCloudProduct;
import com.valuelabs.nephele.admin.data.entity.BundleExternalProduct;
import com.valuelabs.nephele.admin.data.entity.CloudProduct;
import com.valuelabs.nephele.admin.data.entity.ExternalProduct;
import com.valuelabs.nephele.admin.data.repository.BundleCloudProductRepository;
import com.valuelabs.nephele.admin.data.repository.BundleExternalProductRepository;
import com.valuelabs.nephele.admin.data.repository.BundleRepository;
import com.valuelabs.nephele.admin.data.repository.CloudProductRepository;
import com.valuelabs.nephele.admin.data.repository.ExternalProductRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.elasticsearchresource.ElasticSearchBundleResource;
import com.valuelabs.nephele.admin.rest.lib.event.BundleCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateBundleEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import com.valuelabs.nephele.admin.rest.support.NepheleRestTemplate;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class BundleCommandServiceImpl implements BundleCommandService {

  @Autowired
  private BundleRepository bundleRepository;
  
  @Autowired
  private CloudProductRepository cloudProductRepository;
  
  @Autowired
  private BundleCloudProductRepository bundleCloudProductRepository;
  
  @Autowired
  private ExternalProductRepository externalProductRepository;
  
  @Autowired
  private BundleExternalProductRepository bundleExternalProductRepository;
  
  @Autowired
  private NepheleRestTemplate restClient;
	
  @Value("${elasticsearch.uri}")
  private String url;
  
  @Value("${elasticsearch.bundle}")
  private String bundlePath;
  
  @Override
  public BundleCreatedEvent createBundle(CreateBundleEvent request) throws IllegalArgumentException {
	log.debug("createBundle() -start");
	BundleDetails details = request.getBundleDetails();
	
	Bundle entity  = null;
          if(details.getId()!=null)
		   {
		      bundleCloudProductRepository.deleteByBundleId(details.getId());
              bundleExternalProductRepository.deleteByBundleId(details.getId());           
              entity = bundleRepository.findOne(details.getId());

              if(entity!=null) {
          	  
          	  if(!StringUtils.isEmpty(details.getName()))
          		entity.setName(details.getName());
          	  
          	  if(!StringUtils.isEmpty(details.getDescription()))
          		entity.setDescription(details.getDescription());
          	  
          	  if(!StringUtils.isEmpty(details.getLogoCode()))
          		entity.setLogoCode(details.getLogoCode());
          	  
          	  if(!StringUtils.isEmpty(details.getStatus()))
          		entity.setStatus(BundleStatus.valueOf(details.getStatus()));
          	  bundleRepository.save(entity);
          	}
              
              
              
		   }else{
				entity = Bundle.builder()
						  .name(details.getName())
						  .description(details.getDescription())
						  .status(BundleStatus.DRAFT)
						  .logoCode(details.getLogoCode())
						  .build();
			          bundleRepository.save(entity);
			          insertBundlesDataIntoElasticserach(entity);
			          entity.getId();
		   }
          
          Set<Long> cloudProductSet =null;
          if(!CollectionUtils.isEmpty(details.getBundleCloudproducts())  &&  details.getBundleCloudproducts().size() > 0) {
        	cloudProductSet = new HashSet<Long>(details.getBundleCloudproducts());
          }
    
        for(Long productId : NepheleValidationUtils.nullSafe(cloudProductSet))
	    {
		CloudProduct cloudProduct = cloudProductRepository.findOne(productId);
		if(cloudProduct == null){
			throw new ResourceNotFoundException("CloudProduct",productId);
		}	
		   BundleCloudProduct bundleCloudProducts = BundleCloudProduct.builder().bundle(entity).cloudProduct(cloudProduct).build();
		   bundleCloudProductRepository.save(bundleCloudProducts);
	    }
        Set<Long> externalProductSet = null ;
        
        if(!CollectionUtils.isEmpty(details.getBundleExternalproducts())  && details.getBundleExternalproducts().size() >0 ) {
          externalProductSet = new HashSet<Long>(details.getBundleExternalproducts());
        }
        
		for(Long externalId : NepheleValidationUtils.nullSafe(externalProductSet))
		{
			ExternalProduct externalProduct = externalProductRepository.findOne(externalId);
			if(externalProduct == null){
				throw new ResourceNotFoundException("ExternalProduct",externalId);
		}
		BundleExternalProduct bundleExternalProducts = BundleExternalProduct.builder().bundle(entity).externalProduct(externalProduct).build();
		    bundleExternalProductRepository.save(bundleExternalProducts);
		}
	log.debug("createBundle()  - END");
	return new BundleCreatedEvent(details.setId(entity.getId()));
  }

  @Override
  public BundleCreatedEvent updateBundle(CreateBundleEvent request) throws ResourceNotFoundException,
	  IllegalArgumentException {
	log.debug("updateBundle() - start");
	BundleDetails details = request.getBundleDetails();
	Bundle entity =  bundleRepository.findOne(details.getId());
	if(entity!=null) {
	  
	  if(!StringUtils.isEmpty(details.getName()))
		entity.setName(details.getName());
	  
	  if(!StringUtils.isEmpty(details.getDescription()))
		entity.setDescription(details.getDescription());
	  
	  if(!StringUtils.isEmpty(details.getLogoCode()))
		entity.setLogoCode(details.getLogoCode());
	  
	  if(!StringUtils.isEmpty(details.getStatus()))
		entity.setStatus(BundleStatus.valueOf(details.getStatus()));

	  bundleRepository.save(entity);
	}
	log.debug("updateBundle() - end");
	return new BundleCreatedEvent(details);
  }

  @Override
	public void deleteBundle(Long id) throws ResourceNotFoundException, IllegalArgumentException {
		log.debug("deleteBundle()  - START");
		Bundle entity = bundleRepository.findOne(id);
		if(entity == null){
			throw new ResourceNotFoundException("Resource not found");
		}
		bundleRepository.delete(id);
		log.debug("deleteBundle()  - END");
	}
  
   public void insertBundlesDataIntoElasticserach(Bundle record ) {		
		ObjectMapper mapper = new ObjectMapper();
		String requestBodyString =null;
		try {			
			log.debug("insertBundlesDataIntoElasticserach- STARTED");		
			ElasticSearchBundleResource resource = null;
			String bundleUrl = String.format("%s%s", url,bundlePath);
			resource = ElasticSearchBundleResource.builder()
							.id(record.getId())
						 	.name(record.getName())
						 	.description(record.getDescription())					 
						 	.status(record.getStatus().toString())
						 	.logoCode(record.getLogoCode())						
						 	.build();															  
			requestBodyString = mapper.writeValueAsString(resource);
			restClient.post(bundleUrl, requestBodyString);		
			log.debug("insertBundlesDataIntoElasticserach- END");	
		} catch (Exception e) {			
			//e.printStackTrace();
			//log.error("error while insertBundlesDataIntoElasticserach() due to  : "+e.getMessage());
		  e.printStackTrace();
		}
		
	}

 
}
