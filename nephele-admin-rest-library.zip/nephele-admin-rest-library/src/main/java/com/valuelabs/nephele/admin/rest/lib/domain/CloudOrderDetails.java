package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudOrderDetails {

	private Long orderId;
	private String orderCode;
	private Long productId;
	private Long planId;
	private Integer quantity;
	private String status;
	private Long customerCompanyId;
	private Long customerId;
	private Long locationId;
	private String purchaseOrderNumber;
	
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dateRangeStart;
	
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date dateRangeEnd;
	private String customerName;
	private String customerCompanyName;
	private Date creationDate;
	private String serviceName;
	private String productName;
	private String externalCustomerCode;
	private Long accountId;
	private String remarks;
}