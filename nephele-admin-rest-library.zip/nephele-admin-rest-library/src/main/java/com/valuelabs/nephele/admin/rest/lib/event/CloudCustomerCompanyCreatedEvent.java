package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerCompanyDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudCustomerCompanyCreatedEvent {

	private CloudCustomerCompanyDetails customerCompanyDetails;

	private boolean invalid;
	private boolean failed;

	public CloudCustomerCompanyCreatedEvent(CloudCustomerCompanyDetails customerCompanyDetails) {
		this.customerCompanyDetails = customerCompanyDetails;
	}

	public static CloudCustomerCompanyCreatedEvent invalid(CloudCustomerCompanyDetails customerCompanyDetails) {
		CloudCustomerCompanyCreatedEvent event = new CloudCustomerCompanyCreatedEvent(customerCompanyDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudCustomerCompanyCreatedEvent failed(CloudCustomerCompanyDetails customerCompanyDetails) {
		CloudCustomerCompanyCreatedEvent event = new CloudCustomerCompanyCreatedEvent(customerCompanyDetails);
		event.setFailed(true);
		return event;
	}
}
