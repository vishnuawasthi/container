package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.List;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import lombok.Getter;
import lombok.Setter;

//@Data
@Setter
@Getter
public class SerializedPageWrapper<T> {
	private int number;
	private int size;
	private int totalPages;
	private int numberOfElements;
	private long totalElements;
	private boolean previousPage;
	private boolean firstPage;
	private boolean nextPage;
	private boolean lastPage;
	private List<T> content;
	private Sort sort;

	public PageImpl<T> toPageImpl() {
		return new PageImpl<T>(getContent(), new PageRequest(getNumber(), getSize(), getSort()), getTotalElements());
	}
}
