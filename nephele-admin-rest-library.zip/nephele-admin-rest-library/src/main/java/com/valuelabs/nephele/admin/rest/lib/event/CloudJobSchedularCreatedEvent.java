package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudJobSchedularDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
public class CloudJobSchedularCreatedEvent {

	private CloudJobSchedularDetails cloudJobSchedularDetails;

	private boolean invalid;
	private boolean failed;

	public CloudJobSchedularCreatedEvent(CloudJobSchedularDetails details) {
		this.cloudJobSchedularDetails = details;
	}

	public static CloudJobSchedularCreatedEvent invalid(CloudJobSchedularDetails details) {
		CloudJobSchedularCreatedEvent event = new CloudJobSchedularCreatedEvent(details);
		event.setInvalid(true);
		return event;
	}

	public static CloudJobSchedularCreatedEvent failed(CloudJobSchedularDetails cloudCustomerUserDetails) {
		CloudJobSchedularCreatedEvent event = new CloudJobSchedularCreatedEvent(cloudCustomerUserDetails);
		event.setFailed(true);
		return event;
	}

}
