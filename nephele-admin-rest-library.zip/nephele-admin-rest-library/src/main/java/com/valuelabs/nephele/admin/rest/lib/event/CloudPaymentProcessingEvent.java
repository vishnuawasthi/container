package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudPaymentProcessingDetail;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Created by snagaboina on 30/11/15.
 */
@Setter
@Getter
@Accessors(chain = true)
public class CloudPaymentProcessingEvent {

  private CloudPaymentProcessingDetail paymentProcessingDetail;

  private boolean invalid;
  private boolean failed;

  public CloudPaymentProcessingEvent(CloudPaymentProcessingDetail paymentProcessingDetail) {
    this.paymentProcessingDetail = paymentProcessingDetail;
  }

  public static CloudPaymentProcessingEvent invalid(CloudPaymentProcessingDetail paymentProcessingDetail) {
    CloudPaymentProcessingEvent event = new CloudPaymentProcessingEvent(paymentProcessingDetail);
    event.setInvalid(true);
    return event;
  }

  public static CloudPaymentProcessingEvent failed(CloudPaymentProcessingDetail paymentProcessingDetail) {
    CloudPaymentProcessingEvent event = new CloudPaymentProcessingEvent(paymentProcessingDetail);
    event.setFailed(true);
    return event;
  }
}
