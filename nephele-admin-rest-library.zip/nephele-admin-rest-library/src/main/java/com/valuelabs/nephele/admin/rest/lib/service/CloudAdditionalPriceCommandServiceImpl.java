package com.valuelabs.nephele.admin.rest.lib.service;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudAdditionalPrice;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.repository.CloudAdditionalPriceRepository;
import com.valuelabs.nephele.admin.data.repository.CloudCodeSequenceGenerationPatternDAO;
import com.valuelabs.nephele.admin.data.repository.CloudServiceRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAdditionalPriceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudAdditionalPriceCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudAdditionalPriceEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

@Slf4j
@Service
public class CloudAdditionalPriceCommandServiceImpl implements CloudAdditionalPriceCommandService {

/*	@Autowired
	private CloudAdditionalPriceDAO cloudAdditionalPriceDAO;

	@Autowired
	private CloudServiceDAO cloudServiceDAO;
	
	@Autowired
	private CloudLifeCycleConfigDAO lifeCycleConfigDAO;
	*/
	@Autowired
	private CloudCodeSequenceGenerationPatternDAO patternDAO;
	
	/*@Autowired
	private CodeSequenceGeneratorPatternRepository patternRepository;*/
	
	@Autowired
	private CloudAdditionalPriceRepository additionalPriceRepository;
	
	@Autowired
	private CloudServiceRepository serviceRepository;

	@Override
	public CloudAdditionalPriceCreatedEvent createCloudAdditionalPrice(CreateCloudAdditionalPriceEvent request) throws IllegalArgumentException {
		log.debug("createCloudAdditionalPrice() - start");
		CloudAdditionalPriceDetails details = request.getCloudAdditionalPriceDetails();
		CloudService service = serviceRepository.findOne(details.getCloudServiceId());
		if(null == service)
			throw new ResourceNotFoundException("service", details.getCloudServiceId());
		CloudAdditionalPrice entity = CloudAdditionalPrice.builder().name(details.getName()).price(details.getPrice())
				.cloudService(service)
				.location(details.getLocation())
				.description(details.getDescription())
				.status(details.getStatus())
				.planCode(getAdditionalPriceCodePatternSequenceValue(service))
				.build();
		additionalPriceRepository.save(entity);
		log.debug("createCloudAdditionalPrice() - end");
		return new CloudAdditionalPriceCreatedEvent().setCloudAdditionalPriceDetails(details);
	}

	@Override
	public CloudAdditionalPriceCreatedEvent updateCloudAdditionalPrice(CreateCloudAdditionalPriceEvent request) throws ResourceNotFoundException,
			IllegalArgumentException {
		log.debug("updateCloudAdditionalPrice() - start");
		CloudAdditionalPriceDetails details = request.getCloudAdditionalPriceDetails();
		CloudAdditionalPrice entity = additionalPriceRepository.findOne(details.getAdditionalPriceId());
		if (null == entity) {
			throw new ResourceNotFoundException("Resource not found with given id");

		} else {
			if(!StringUtils.isEmpty(details.getPrice()))
				entity.setPrice(details.getPrice());
			if(!StringUtils.isEmpty(details.getStatus()))
				entity.setStatus(details.getStatus());
			additionalPriceRepository.save(entity);
		}
		log.debug("updateCloudAdditionalPrice() - end");
		return new CloudAdditionalPriceCreatedEvent().setCloudAdditionalPriceDetails(details);
	}
	
	
	@Override
    public String getAdditionalPriceCodePatternSequenceValue(CloudService cloudService) {
		log.debug("getAdditionalPriceCodePatternSequenceValue() - start");
      StringBuilder sb = new StringBuilder(200);
      try {
    	sb.append(cloudService.getPlanPrefix());
    	sb.append("-ADL");
        Long patternNumber = patternDAO.getNextAdditionalPricePatternNumber();
        if (!patternNumber.equals(0L))
          sb.append(patternNumber);
        sb.trimToSize();
      } catch (Exception e) {
        log.error("Exception occurs while getting next sequence value ", e.getMessage());
      }
      log.debug("getAdditionalPriceCodePatternSequenceValue() - end");
      return sb.toString();
    }


}
