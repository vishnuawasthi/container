package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.*;
import lombok.experimental.Accessors;

/**
 * Created by snagaboina on 30/11/15.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Accessors(chain = true)
public class CloudPaymentProcessingDetail {

  private String merchantId;

  private String vpnTokenNumber;

  private String expiryDate;

  private String cvv;

  private String amount;

  private String invoiceId;

  private String invoiceNumber;

  private Double surcharge;

  private Double surchargeGST;

}
