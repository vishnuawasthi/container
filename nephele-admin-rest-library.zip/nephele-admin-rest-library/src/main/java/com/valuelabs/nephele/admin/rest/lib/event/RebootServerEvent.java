package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
@Accessors(chain = true)
public class RebootServerEvent {

	private Long serverId;
	private String cspServerId;
	private Long locationId;
	private String rebootType;
	private Long serverActionId;
	private Long cloudServiceId;
	private Long resellerCompanyId;
	private String externalResellerCompanyCode;
	private String resellerEmail;
	private Long customerCompanyId;
}
