package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudLocationEvent {
	private CloudLocationDetails cloudLocationDetails;
	private List< CloudLocationDetails> cloudLocationDetailsList;

}
