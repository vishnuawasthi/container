package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServicePricingModelDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServicePricingModelDetailsCreatedEvent {
	
	private CloudServicePricingModelDetails cloudServicePricingModelDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServicePricingModelDetailsCreatedEvent(CloudServicePricingModelDetails cloudServicePricingModelDetails) {
		this.cloudServicePricingModelDetails = cloudServicePricingModelDetails;
	}
	
	public static ServicePricingModelDetailsCreatedEvent invalid(CloudServicePricingModelDetails cloudServicePricingModelDetails) {
		ServicePricingModelDetailsCreatedEvent event = new ServicePricingModelDetailsCreatedEvent(cloudServicePricingModelDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServicePricingModelDetailsCreatedEvent failed(CloudServicePricingModelDetails cloudServicePricingModelDetails) {
		ServicePricingModelDetailsCreatedEvent event = new ServicePricingModelDetailsCreatedEvent(cloudServicePricingModelDetails);
		event.setFailed(true);
		return event;
	}
	

}
