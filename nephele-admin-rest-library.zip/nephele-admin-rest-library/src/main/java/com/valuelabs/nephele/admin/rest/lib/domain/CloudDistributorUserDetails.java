package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudDistributorUserDetails {
	private Long distributorId;
	private String distributorName;
 	private Long cloudDistributorCompanyId;
 	private String cloudDistributorCompanyName;
 	private String firstName;
	private String lastName;
	private String email;
	private Boolean isEnabled;
	private Date createdAt;
	private Date updatedAt;
	private String resetPasswordToken;
	private Date resetPasswordExpireTime;
	private String password;
	private String newPassword;
	private String oldPassword;
	private String confirmPassword;
	private Long userRoleId;
	private String userRoleName;
	private String apiKey;
	private Date apiKeyExpireTime;
	
}
