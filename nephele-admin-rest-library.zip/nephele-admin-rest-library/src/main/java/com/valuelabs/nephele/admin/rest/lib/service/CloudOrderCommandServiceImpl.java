package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudOrder;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.repository.CloudCodeSequenceGenerationPatternDAO;
import com.valuelabs.nephele.admin.data.repository.CloudCustomerCompanyRepository;
import com.valuelabs.nephele.admin.data.repository.CloudOrderRepository;
import com.valuelabs.nephele.admin.data.repository.CloudProductPlanRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudOrderCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudOrderEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Slf4j
@Service("CloudOrderCommandServiceLib")
public class CloudOrderCommandServiceImpl implements CloudOrderCommandService {

	/*@Autowired
	private CloudOrderDAO cloudOrderDAO;
	
	@Autowired
	private CloudProductDAO cloudProductDAO;
	
	@Autowired
	private CloudProductPlanDAO cloudProductPlanDAO;

	@Autowired
	private CloudCustomerCompanyDAO cloudCustomerCompanyDAO;*/
	
	/*@Autowired
	CloudLifeCycleConfigDAO lifeCycleConfigDAO;*/
	
	@Autowired
	CloudCodeSequenceGenerationPatternDAO patternDAO;
	
	/*@Autowired
	private CodeSequenceGeneratorPatternRepository patternRepository;*/	
	
	@Autowired
	private CloudOrderRepository orderRepository;
	
	@Autowired
	private CloudProductPlanRepository productPlanRepository;
	
	@Autowired
	private CloudCustomerCompanyRepository customerCompanyRepository;
	
	

	@Override
	public CloudOrderCreatedEvent createServiceCloudOrder(
			CreateCloudOrderEvent request)  throws ResourceNotFoundException,IllegalArgumentException{
		log.debug("createServiceCloudOrder() START");
		CloudOrderDetails cloudOrderDetails = request.getCloudOrderDetails();
		
		CloudProductPlan  cloudProductPlan = productPlanRepository.findOne(cloudOrderDetails.getPlanId());
		
		CloudCustomerCompany cloudCustomerCompany  =  customerCompanyRepository.findOne(cloudOrderDetails.getCustomerId());
		
		if(cloudProductPlan==null) {
		  throw new ResourceNotFoundException("CloudProductPlan", cloudOrderDetails.getPlanId());
		}
		
		if(cloudCustomerCompany==null) {
		  throw new ResourceNotFoundException("CloudCustomerCompany", cloudOrderDetails.getCustomerCompanyId());
		}
		
		CloudOrder cloudOrder = CloudOrder.builder().orderCode(cloudOrderDetails.getOrderCode())
										  //.cloudProduct(cloudProductDAO.findOne(cloudOrderDetails.getProductId()))
										  .cloudProductPlan(cloudProductPlan)
										  .quantity(cloudOrderDetails.getQuantity())
										  .status(cloudOrderDetails.getStatus())
										  .cloudCustomerCompany(cloudCustomerCompany)
										  .purchaseOrderNumber(cloudOrderDetails.getPurchaseOrderNumber())
										  //.locationId(cloudOrderDetails.getLocationId())
										  .build();

		
		orderRepository.save(cloudOrder);
		cloudOrderDetails.setOrderId(cloudOrder.getId());
		log.debug("createServiceCloudOrder() END");
		return new CloudOrderCreatedEvent(cloudOrderDetails);
	}

	@Override
	public CloudOrderCreatedEvent updateServiceCloudOrder(
			CreateCloudOrderEvent request) throws IllegalArgumentException, ResourceNotFoundException {
		log.debug("updateServiceCloudOrder() START");
		CloudOrder cloudOrder = orderRepository.findOne(request
				.getCloudOrderDetails().getOrderId());
		if (cloudOrder == null) {
			throw new ResourceNotFoundException("CloudOrder",request.getCloudOrderDetails().getOrderId());
		}
		CloudOrderDetails cloudOrderDetails = request.getCloudOrderDetails();
		if(!StringUtils.isEmpty(cloudOrderDetails.getStatus()))
			cloudOrder.setStatus(cloudOrderDetails.getStatus());
		if (!StringUtils.isEmpty(cloudOrderDetails.getOrderCode()))
			cloudOrderDetails.setOrderCode(cloudOrder.getOrderCode());
		if(!StringUtils.isEmpty(cloudOrderDetails.getRemarks()))
			cloudOrder.setRemarks(cloudOrderDetails.getRemarks());
		orderRepository.save(cloudOrder);
		log.debug("updateServiceCloudOrder() END");
		return new CloudOrderCreatedEvent(cloudOrderDetails);
	}
	
	@Override
    public String getOrderCodePatternSequenceValue() {
		log.debug("getOrderCodePatternSequenceValue() START");
      StringBuilder sb = new StringBuilder(200);
      try {

        Long patternNumber = patternDAO.getNextOrderPatternNumber();
        if (!patternNumber.equals(0L))
          sb.append(patternNumber);
        sb.trimToSize();
      } catch (Exception e) {
        log.error("Exception occurs while getting next sequence value ", e.getMessage());
      }
      log.debug("getOrderCodePatternSequenceValue() END");
      return sb.toString();
    }
}
