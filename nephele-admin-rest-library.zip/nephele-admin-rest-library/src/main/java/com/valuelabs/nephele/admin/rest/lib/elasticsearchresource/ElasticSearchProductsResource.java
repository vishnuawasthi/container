package com.valuelabs.nephele.admin.rest.lib.elasticsearchresource;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@JsonInclude(value=Include.NON_DEFAULT)
@EqualsAndHashCode(callSuper = false)
public class ElasticSearchProductsResource  
{
	// id is noting but productId
	@Id  
	private Long id;
	private String name;
	private String description;
	private String type;
	private String status;	
    private Long operatingSystemId;   
    private Long cloudServiceId;
    private String serviceCode;  
	private Boolean isFeatured;
	private Boolean hasFreeTrial;
	private Boolean hasRelatedProducts;
  

}