package com.valuelabs.nephele.admin.rest.lib.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = false)
@ToString
@JsonInclude(Include.NON_NULL)
public class SolrCloudProduct {

	private Long productId;
	private String name;
	private String description;
	private String Type;
    private String brandCode;
    private String brandName;
    private Long categoryId;
    private String categoryName;
}
