package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductCategoryDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudProductCategoryCreatedEvent {
	
private CloudProductCategoryDetails cloudProductCategoryDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudProductCategoryCreatedEvent(CloudProductCategoryDetails cloudProductCategoryDetails) {
		this.cloudProductCategoryDetails = cloudProductCategoryDetails;
	}
	
	public static CloudProductCategoryCreatedEvent invalid(CloudProductCategoryDetails cloudProductCategoryDetails) {
		CloudProductCategoryCreatedEvent event = new CloudProductCategoryCreatedEvent(cloudProductCategoryDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudProductCategoryCreatedEvent failed(CloudProductCategoryDetails cloudProductCategoryDetails) {
		CloudProductCategoryCreatedEvent event = new CloudProductCategoryCreatedEvent(cloudProductCategoryDetails);
		event.setFailed(true);
		return event;
	}

}
