package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductCategoryDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudProductCategoryEvent {
	
	private CloudProductCategoryDetails cloudProductCategoryDetails;

}
