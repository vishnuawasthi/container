package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Data;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;

@Data
@Accessors(chain = true)
public class ExternalProductCreatedEvent {
	
private ExternalProductDetails externalProductDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ExternalProductCreatedEvent(ExternalProductDetails externalProductDetails) {
		this.externalProductDetails = externalProductDetails;
	}

	public static ExternalProductCreatedEvent invalid(ExternalProductDetails externalProductDetails) {
		ExternalProductCreatedEvent event = new ExternalProductCreatedEvent(externalProductDetails);
		event.setInvalid(true);
		return event;
	}

	public static ExternalProductCreatedEvent failed(ExternalProductDetails externalProductDetails) {
		ExternalProductCreatedEvent event = new ExternalProductCreatedEvent(externalProductDetails);
		event.setFailed(true);
		return event;
	}

}
