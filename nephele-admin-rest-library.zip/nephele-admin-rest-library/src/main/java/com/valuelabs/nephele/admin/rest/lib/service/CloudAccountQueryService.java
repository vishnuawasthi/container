package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAccountEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAccountsEvent;

public interface CloudAccountQueryService {
  EntityReadEvent<CloudAccountDetails> readCloudAccount(ReadCloudAccountEvent request);

  PageReadEvent<CloudAccountDetails> readCloudAccounts(ReadCloudAccountsEvent requst);
  
  CloudAccountDetails getAccountDetailsWithCustomerIdAndServiceId(Long customerId, Long serviceId);

}
