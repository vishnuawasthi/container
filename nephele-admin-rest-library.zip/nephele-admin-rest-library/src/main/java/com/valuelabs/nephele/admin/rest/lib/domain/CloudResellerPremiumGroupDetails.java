package com.valuelabs.nephele.admin.rest.lib.domain;


import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.data.entity.CloudService;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerPremiumGroupDetails {

	private Long premiumGroupId;
	private String  name;
	private String  description;	
	private String status;
	private Long resellerCount;
	private Date createdDate;
	private Date updatedDate;
	private Long serviceId;
	private String serviceName;
	private String integrationCode;
}
