package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;

@Setter
@Getter
@Accessors(chain = true)
public class CreateCloudCurrencyConversionRateEvent  {
  		private CloudCurrencyConversionRateDetails details;
}
