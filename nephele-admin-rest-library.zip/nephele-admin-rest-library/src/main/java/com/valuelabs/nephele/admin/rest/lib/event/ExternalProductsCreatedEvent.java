package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;

@Data
@Accessors(chain = true)
public class ExternalProductsCreatedEvent {
	
private List<ExternalProductDetails> externalProductDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ExternalProductsCreatedEvent( List<ExternalProductDetails> externalProductDetails) {
		this.externalProductDetails = externalProductDetails;
	}

	public static ExternalProductsCreatedEvent invalid( List<ExternalProductDetails> externalProductDetails) {
		ExternalProductsCreatedEvent event = new ExternalProductsCreatedEvent(externalProductDetails);
		event.setInvalid(true);
		return event;
	}

	public static ExternalProductsCreatedEvent failed( List<ExternalProductDetails> externalProductDetails) {
		ExternalProductsCreatedEvent event = new ExternalProductsCreatedEvent(externalProductDetails);
		event.setFailed(true);
		return event;
	}

}
