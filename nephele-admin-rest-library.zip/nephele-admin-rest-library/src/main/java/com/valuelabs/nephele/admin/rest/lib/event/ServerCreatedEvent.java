package com.valuelabs.nephele.admin.rest.lib.event;


import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServerCreatedEvent {
	
	private CloudServerDetails serverDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServerCreatedEvent(CloudServerDetails serverDetails) {
		this.serverDetails=serverDetails;		
	}
	
	public static ServerCreatedEvent invalid(CloudServerDetails serverDetails) {
		ServerCreatedEvent event = new ServerCreatedEvent(serverDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServerCreatedEvent failed(CloudServerDetails serverDetails) {
		ServerCreatedEvent event = new ServerCreatedEvent(serverDetails);
		event.setFailed(true);
		return event;
	}

}
