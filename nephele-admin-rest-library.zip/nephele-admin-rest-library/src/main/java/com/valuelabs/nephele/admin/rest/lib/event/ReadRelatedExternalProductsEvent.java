package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadRelatedExternalProductsEvent extends ReadPageEvent<ReadRelatedExternalProductsEvent>{
	
	private Long relatedExtProductId;
	private List<Long> relatedExtProductIds;
	private Long cloudProductId;
	private List<Long> cloudProductIds;
	private Long externalProductId;
	private List<String> externalProductIds;
	
}
