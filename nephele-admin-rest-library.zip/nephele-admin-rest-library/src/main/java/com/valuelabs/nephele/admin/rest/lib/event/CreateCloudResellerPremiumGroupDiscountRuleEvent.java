package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDiscountRuleDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudResellerPremiumGroupDiscountRuleEvent {
	
	private CloudResellerPremiumGroupDiscountRuleDetails cloudResellerPremiumGroupDiscountRuleDetails;
	
}
