package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudInvoiceLineEvent extends ReadEntityEvent<ReadCloudInvoiceLineEvent>{

	private Long cloudInvoiceLineId;
	private String description;
	private String price;
	private String quantity;
	private String total;
	private Long cloudInvoiceId;
}
