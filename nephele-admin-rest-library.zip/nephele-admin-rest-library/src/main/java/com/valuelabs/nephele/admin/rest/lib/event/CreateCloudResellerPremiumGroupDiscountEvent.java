package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerPremiumGroupDiscountDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudResellerPremiumGroupDiscountEvent {
	
	private CloudResellerPremiumGroupDiscountDetails cloudResellerPremiumGroupDiscountDetails;
	
}
