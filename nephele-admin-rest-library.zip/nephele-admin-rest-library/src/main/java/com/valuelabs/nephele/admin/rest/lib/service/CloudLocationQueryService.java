package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.Map;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudLocationDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntitiesReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudLocationEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudLocationsEvent;

public interface CloudLocationQueryService {

	EntityReadEvent<CloudLocationDetails> readCloudLocation(ReadCloudLocationEvent request);
	PageReadEvent<CloudLocationDetails> readCloudLocations(ReadCloudLocationsEvent request);
	PageReadEvent<CloudLocationDetails> findByStatus(ReadCloudLocationsEvent request);
	EntitiesReadEvent<CloudLocationDetails> findByNameNStatus(ReadCloudLocationsEvent request);
	//Map<String, String> getGeographiesMap();
	// Map<String, String> getLocationsMap();
	
}
