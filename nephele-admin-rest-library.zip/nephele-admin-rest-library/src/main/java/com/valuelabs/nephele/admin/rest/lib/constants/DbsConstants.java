package com.valuelabs.nephele.admin.rest.lib.constants;

/**
 * Created by snagaboina on 28/12/15.
 */
public class DbsConstants {

  public static final String FAIL_STATUS = "Fail";
  public static final String DATA_ALREADY_EXIST = "dataId already exist";
  public static final String INVOICE_ID_REPEAT = "Invoice Id is repeat";
  public static final String PAYMENT_ID_REPEAT = "The status of payment has been updated and cannot be modified";

}
