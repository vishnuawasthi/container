package com.valuelabs.nephele.admin.rest.lib.domain;

import com.valuelabs.nephele.admin.data.entity.RevenueServiceDetail;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * Created by snagaboina on 9/9/15.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Accessors(chain = true)
public class YearlyTopServiceDetails {

  List<RevenueServiceDetail> serviceDetailList;
  private String month;
  private Integer monthNumber;

  private Long serviceId;

  private String serviceName;

  private String revenue;

  private String integrationCode;
}
