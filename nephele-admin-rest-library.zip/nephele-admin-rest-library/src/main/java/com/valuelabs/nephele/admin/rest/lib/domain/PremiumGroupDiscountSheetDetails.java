package com.valuelabs.nephele.admin.rest.lib.domain;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class PremiumGroupDiscountSheetDetails implements Comparable<PremiumGroupDiscountSheetDetails>{ 
	private Long discountSheetId;
	private Double startRange;
	private Double endRange;
	private Double discount;
	private Long premiumGroupId;
	private String premiumGroupName;
	private String discountPlanType;
	private Long premiumGroupDiscountConfigId;
	private Long serviceId;
	private String serviceName;
	private String status;
	
	@Override
	public int compareTo(PremiumGroupDiscountSheetDetails details) {
		
		double compareQuantity = ((PremiumGroupDiscountSheetDetails) details).getStartRange();
		
		//ascending order
		return (int) (this.startRange - compareQuantity);
		
		//descending order
		//return compareQuantity - this.quantity;
		
	}

}
