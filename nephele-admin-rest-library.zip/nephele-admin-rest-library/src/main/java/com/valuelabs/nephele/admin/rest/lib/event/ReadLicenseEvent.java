package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadLicenseEvent extends ReadEntityEvent<ReadLicenseEvent> {

	private Long licenseId;
	private Long subscriptionId;
	private String licenseVendorId;
	private String status;
	private Long planId;	
	private Date licenseProvisionDate;
	private Date licenseNextRenewalDate;
	private Date licenseLastRenewalDate;
	private Date autoRenewalOffDate;
	private boolean licenseAutoRenewal;
}
