package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.cloud.dbs.integration.datamodel.DbsProductDetails;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain=true)
public class DbsProductIntegrationEvent {
	
	private List<DbsProductDetails> products;

  private String messageId;

}
