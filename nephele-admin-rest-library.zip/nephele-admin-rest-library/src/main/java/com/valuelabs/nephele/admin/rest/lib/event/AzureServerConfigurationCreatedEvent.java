package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.AzureServerConfigurationDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class AzureServerConfigurationCreatedEvent {
	private boolean invalid;
	private boolean failed;
	private AzureServerConfigurationDetails azureServerConfigurationDetails;
	
	public AzureServerConfigurationCreatedEvent() {
		this.azureServerConfigurationDetails = azureServerConfigurationDetails;
	}
	
	public AzureServerConfigurationCreatedEvent(AzureServerConfigurationDetails azureServerConfigurationDetails) {
		this.azureServerConfigurationDetails = azureServerConfigurationDetails;
	}

	public static AzureServerConfigurationCreatedEvent invalid(AzureServerConfigurationDetails azureServerConfigurationDetails) {
		AzureServerConfigurationCreatedEvent event = new AzureServerConfigurationCreatedEvent(azureServerConfigurationDetails);
		event.setInvalid(true);
		return event;
	}

	public static AzureServerConfigurationCreatedEvent failed(AzureServerConfigurationDetails azureServerConfigurationDetails) {
		AzureServerConfigurationCreatedEvent event = new AzureServerConfigurationCreatedEvent(azureServerConfigurationDetails);
		event.setFailed(true);
		return event;
	}
	
}
