package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudProductCreatedEvent {
	

private CloudProductDetails cloudProductDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudProductCreatedEvent(CloudProductDetails cloudProductDetails) {
		this.cloudProductDetails = cloudProductDetails;
	}
	
	public static CloudProductCreatedEvent invalid(CloudProductDetails cloudProductDetails) {
		CloudProductCreatedEvent event = new CloudProductCreatedEvent(cloudProductDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudProductCreatedEvent failed(CloudProductDetails cloudProductDetails) {
		CloudProductCreatedEvent event = new CloudProductCreatedEvent(cloudProductDetails);
		event.setFailed(true);
		return event;
	}

}
