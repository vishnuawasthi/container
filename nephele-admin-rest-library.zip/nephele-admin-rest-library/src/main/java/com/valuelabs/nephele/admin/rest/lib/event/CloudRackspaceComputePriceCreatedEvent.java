package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudRackspaceComputePriceDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudRackspaceComputePriceCreatedEvent {

	


		private  CloudRackspaceComputePriceDetails  cloudRackspaceComputePriceDetails;

		private boolean invalid;
		private boolean failed;

		public CloudRackspaceComputePriceCreatedEvent(CloudRackspaceComputePriceDetails cloudRackspaceComputePriceDetails) {
			this.cloudRackspaceComputePriceDetails = cloudRackspaceComputePriceDetails;
		}

		public static CloudRackspaceComputePriceCreatedEvent invalid(CloudRackspaceComputePriceDetails cloudRackspaceComputePriceDetails) {
			CloudRackspaceComputePriceCreatedEvent event = new CloudRackspaceComputePriceCreatedEvent(cloudRackspaceComputePriceDetails);
			event.setInvalid(true);
			return event;
		}

		public static CloudRackspaceComputePriceCreatedEvent failed(CloudRackspaceComputePriceDetails cloudRackspaceComputePriceDetails) {
			CloudRackspaceComputePriceCreatedEvent event = new CloudRackspaceComputePriceCreatedEvent(cloudRackspaceComputePriceDetails);
			event.setFailed(true);
			return event;
		}
}
