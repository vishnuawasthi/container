package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import com.valuelabs.nephele.admin.data.api.CloudTypes;
import com.valuelabs.nephele.admin.data.api.JobTypes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class CloudJobSchedularDetails {

	private Long jobId;
	private Long minutes;
	private Long hours;
	private Date scheduledDate;
	private CloudTypes serviceName;
	private String timezone;
	private JobTypes jobtype;
	private Long cloudserviceId;
	private String status;


}
