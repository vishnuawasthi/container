package com.valuelabs.nephele.admin.rest.lib.service;

import java.util.List;

import static com.valuelabs.nephele.admin.data.repository.CloudAdditionalPriceSpecifications.findPriceByServiceNStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.Lists;
import com.valuelabs.nephele.admin.data.entity.CloudAdditionalPrice;
import com.valuelabs.nephele.admin.data.repository.CloudAdditionalPriceRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudAdditionalPriceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAdditionalPriceEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAdditionalPricesEvent;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CloudAdditionalPriceQueryServiceImpl implements CloudAdditionalPriceQueryService {

	/*@Autowired
	private CloudAdditionalPriceDAO cloudAdditionalPriceDAO;*/
	
	@Autowired
	private CloudAdditionalPriceRepository additionalPriceRepository;

	@Override
	public EntityReadEvent<CloudAdditionalPriceDetails> readCloudAdditionalPrice(ReadCloudAdditionalPriceEvent request) {
		log.debug("readCloudAdditionalPrice() - start");
		CloudAdditionalPrice entity = additionalPriceRepository.findOne(request.getId());
		CloudAdditionalPriceDetails details = null;
		if (null != entity) {
			details = CloudAdditionalPriceDetails.builder().additionalPriceId(entity.getId()).name(entity.getName()).price(entity.getPrice())
					.cloudServiceId(entity.getCloudService().getId()).location(entity.getLocation()).description(entity.getDescription())
					.status(entity.getStatus()).serviceName(entity.getCloudService().getName()).planCode(entity.getPlanCode()).build();
		}
		log.debug("readCloudAdditionalPrice() - end");
		return new EntityReadEvent<CloudAdditionalPriceDetails>(details);
	}

	@Override
	public PageReadEvent<CloudAdditionalPriceDetails> readCloudAdditionalPrices(ReadCloudAdditionalPricesEvent requst) {
		log.debug("readCloudAdditionalPrices() - start");
		List<CloudAdditionalPrice> dbContent = Lists.newArrayList();
		dbContent = additionalPriceRepository.findAll();
		List<CloudAdditionalPriceDetails> content = Lists.newArrayList();
		long total = 0;
		for (CloudAdditionalPrice record : NepheleValidationUtils.nullSafe(dbContent)) {
			if (total >= requst.getPageable().getOffset() && total < requst.getPageable().getOffset() + requst.getPageable().getPageSize()) {
				CloudAdditionalPriceDetails details = CloudAdditionalPriceDetails.builder().additionalPriceId(record.getId()).name(record.getName())
						.price(record.getPrice()).cloudServiceId(record.getCloudService().getId())
						.location(record.getLocation())
						.description(record.getDescription())
						.status(record.getStatus())
						.serviceName(record.getCloudService().getName())
						.planCode(record.getPlanCode())
						.build();
				content.add(details);
			}
			++total;
		}
		Page<CloudAdditionalPriceDetails> page = new PageImpl<>(content, requst.getPageable(), total);
		log.debug("readCloudAdditionalPrices() - end");
		return new PageReadEvent<>(page);
	}
	
	@Override
	public PageReadEvent<CloudAdditionalPriceDetails> readCloudAdditionalPricesByCloudService(ReadCloudAdditionalPricesEvent request) {
		log.debug("readCloudAdditionalPricesByService() - start");
		List<CloudAdditionalPrice> dbContent = Lists.newArrayList();
		dbContent = additionalPriceRepository.findAll(findPriceByServiceNStatus(request.getServiceId(), request.getStatus()));
		log.debug("readCloudAdditionalPricesByService() { } - ",dbContent);
		List<CloudAdditionalPriceDetails> content =  Lists.newArrayList();
		long total = 0;
		for (CloudAdditionalPrice record : NepheleValidationUtils.nullSafe(dbContent) ) {
			if (total >= request.getPageable().getOffset() && total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
				CloudAdditionalPriceDetails details = CloudAdditionalPriceDetails.builder()
						.additionalPriceId(record.getId())
						.name(record.getName())
						.price(record.getPrice())
						.cloudServiceId(record.getCloudService().getId())
						.location(record.getLocation())
						.description(record.getDescription())
						.status(record.getStatus())
						.serviceName(record.getCloudService().getName())
						.planCode(record.getPlanCode())
						.build();
				content.add(details);
			}
			++total;
		}
		Page<CloudAdditionalPriceDetails> page = new PageImpl<>(content, request.getPageable(), total);
		log.debug("readCloudAdditionalPricesByService() - end");
		return new PageReadEvent<>(page);
	}

	@Override
	public PageReadEvent<CloudAdditionalPriceDetails> readAdditionalForProducts(
			ReadCloudAdditionalPricesEvent request) {
		log.debug("readAdditionalForProducts() - start");
		List<CloudAdditionalPrice> dbContent = Lists.newArrayList();
		dbContent = additionalPriceRepository.findAll(findPriceByServiceNStatus(request.getServiceId(), request.getStatus()));
		log.debug("readAdditionalForProducts() { } - ",dbContent);
		Long total = 0L;
		if(!CollectionUtils.isEmpty(dbContent)) {
			total =(long) dbContent.size();
		}
		
		List<CloudAdditionalPriceDetails> content =  Lists.newArrayList();
		for (CloudAdditionalPrice record : NepheleValidationUtils.nullSafe(dbContent) ) {
				CloudAdditionalPriceDetails details = CloudAdditionalPriceDetails.builder()
						.additionalPriceId(record.getId())
						.name(record.getName())
						.price(record.getPrice())
						.cloudServiceId(record.getCloudService().getId())
						.location(record.getLocation())
						.description(record.getDescription())
						.status(record.getStatus())
						.serviceName(record.getCloudService().getName())
						.planCode(record.getPlanCode())
						.build();
				content.add(details);
			}
		log.debug("readAdditionalForProducts() - end");
		Page<CloudAdditionalPriceDetails> page = new PageImpl<>(content, request.getPageable(), total);
		return new PageReadEvent<>(page);
	}
}
