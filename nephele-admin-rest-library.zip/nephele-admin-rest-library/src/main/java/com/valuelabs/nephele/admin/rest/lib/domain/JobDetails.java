package com.valuelabs.nephele.admin.rest.lib.domain;

import com.valuelabs.nephele.admin.data.api.JobName;
import com.valuelabs.nephele.admin.data.api.JobStatus;
import com.valuelabs.nephele.admin.rest.lib.enumerated.CloudTypes;
import lombok.*;
import lombok.experimental.Accessors;

/**
 * Created by btodupunoori.
 */
@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
@Builder
@Accessors(chain=true)
public class JobDetails {

	private Long jobId;
	
	private JobName jobName;
	
	private JobStatus jobStatus;

    private CloudTypes cloudTypes;
    
    private Long serviceId;

}
