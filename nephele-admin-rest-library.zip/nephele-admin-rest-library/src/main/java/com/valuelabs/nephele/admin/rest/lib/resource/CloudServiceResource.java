package com.valuelabs.nephele.admin.rest.lib.resource;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.hateoas.ResourceSupport;

/**
 * Created by snagaboina on 11/12/15.
 */
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class CloudServiceResource extends ResourceSupport {
  private Long serviceId;
  private String name;
  private String serviceCode;
  private String integrationCode;
  private String vendorCode;
}
