package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
public class ExternalProductDetails {
	private Long externalProductId;
	private String externalId;
	private String productName;
	private String description;
	private String brandName;
	private String status;
	private String type;
	private String categoryName;	

}
