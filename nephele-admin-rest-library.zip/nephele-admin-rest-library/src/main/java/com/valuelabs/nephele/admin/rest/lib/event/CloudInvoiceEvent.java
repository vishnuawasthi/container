package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudInvoiceDetails;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;


//@Data
@Setter
@Getter
@Accessors(chain=true)
public class CloudInvoiceEvent {
	
	private CloudInvoiceDetails cloudInvoiceDetails;

  private boolean invalid;
  private boolean failed;

  public CloudInvoiceEvent(CloudInvoiceDetails cloudInvoiceDetails) {
    this.cloudInvoiceDetails = cloudInvoiceDetails;
  }

  public static CloudInvoiceEvent invalid(CloudInvoiceDetails cloudInvoiceDetails) {
    CloudInvoiceEvent event = new CloudInvoiceEvent(cloudInvoiceDetails);
    event.setInvalid(true);
    return event;
  }

  public static CloudInvoiceEvent failed(CloudInvoiceDetails cloudInvoiceDetails) {
    CloudInvoiceEvent event = new CloudInvoiceEvent(cloudInvoiceDetails);
    event.setFailed(true);
    return event;
  }

}
