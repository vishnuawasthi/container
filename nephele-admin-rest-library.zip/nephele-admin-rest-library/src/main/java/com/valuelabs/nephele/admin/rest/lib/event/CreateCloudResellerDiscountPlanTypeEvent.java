package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerDiscountPlanTypeDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudResellerDiscountPlanTypeEvent {
	
	private CloudResellerDiscountPlanTypeDetails cloudResellerDiscountPlanTypeDetails;
	
}
