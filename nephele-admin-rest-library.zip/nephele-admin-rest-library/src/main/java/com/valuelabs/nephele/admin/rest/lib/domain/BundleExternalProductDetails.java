package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.data.entity.ExternalProduct;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
public class BundleExternalProductDetails {
	
	private Long bundleExternalProductId;
	private Set<ExternalProduct> externalProducts;

}
