package com.valuelabs.nephele.admin.rest.lib.resource;

import org.springframework.hateoas.ResourceSupport;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
public class CloudProductPlanExportResource extends ResourceSupport {
	
	private Long PLAN_ID;
	
	private String PLAN_NAME;
	
	private String SERVICE;
	
	private String PRODUCT_NAME;
	
	private String LOCATION;
	
	private Double PRICE;
	
	private Double VENDOR_PRICE;
	
	public CloudProductPlanExportResource(Long PLAN_ID, String PLAN_NAME, String SERVICE, String PRODUCT_NAME, String LOCATION) {
		this.PLAN_ID = PLAN_ID;
		this.PLAN_NAME = PLAN_NAME;
		this.SERVICE = SERVICE;
		this.PRODUCT_NAME = PRODUCT_NAME;
		this.LOCATION = LOCATION;
		
	}
}
