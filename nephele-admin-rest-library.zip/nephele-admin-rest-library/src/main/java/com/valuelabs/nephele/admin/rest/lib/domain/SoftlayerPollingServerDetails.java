package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain=true)
public class SoftlayerPollingServerDetails {

	private Long serverId;
	
	private String cspServerId;
	
	private Long orderId;
	
	private Long serviceId;
	
	private Long customerId;
	
	private Long accountId;
	
	private String poolingAction;
	
	private String customerEmail;
	
	private Long serverActionId;
	
	private Boolean rebootResultFlag;
	
	private Boolean isServerDeleted;
	
}
