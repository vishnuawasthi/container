package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.data.api.BundleStatus;
import com.valuelabs.nephele.admin.data.entity.*;
import com.valuelabs.nephele.admin.data.repository.BundleRepository;
import com.valuelabs.nephele.admin.data.repository.BundleSpecifications;
import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductDetails;
import com.valuelabs.nephele.admin.rest.lib.domain.ExternalProductDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundleEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadBundlesEvent;
import com.valuelabs.nephele.admin.rest.lib.util.NepheleValidationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static com.valuelabs.nephele.admin.data.repository.CloudServerSpecifications.sortByIdAsc;

@Service
@Slf4j
public class BundleQueryServiceImpl implements BundleQueryService {

  @Autowired
  private BundleRepository bundleRepository;
  
  @Autowired
  private CloudProductQueryServiceImpl productQueryService;

  @Override
  public EntityReadEvent<BundleDetails> readBundle(ReadBundleEvent request) {
    log.debug("readBundle() - start ");

    BundleDetails details = null;
    Bundle entity = bundleRepository.findOne(request.getId());

    if (entity != null) {
      details = BundleDetails.builder()
          .id(entity.getId())
          .name(entity.getName())
          .description(entity.getDescription())
          .status(entity.getStatus().name())
          .logoCode(entity.getLogoCode())
          .created(entity.getCreated())
          .updated(entity.getUpdated())
          .build();
      Set<BundleCloudProduct> bundleProductSet = entity.getBundleCloudProducts();
      List<CloudProductDetails> productList = new ArrayList<>();
      // Cloud Product
      for (BundleCloudProduct bundleProduct : NepheleValidationUtils.nullSafe(bundleProductSet)) {
        CloudProduct cloudProduct = bundleProduct.getCloudProduct();
        CloudProductDetails productDetails = CloudProductDetails.builder()
            .cloudProductId(cloudProduct.getId())
            .name(cloudProduct.getName())
            .status(cloudProduct.getStatus())
            .description(cloudProduct.getDescription())
            .type(cloudProduct.getType())
            .operatingSystemId(cloudProduct.getCloudOperatingSystem().getId())
            .operatingSystemName(cloudProduct.getCloudOperatingSystem().getName())
            .cloudServiceId(cloudProduct.getCloudService().getId())
            .serviceName(cloudProduct.getCloudService().getName())
            .integrationCode(cloudProduct.getCloudService().getIntegrationCode())
            .brandCode(cloudProduct.getCloudService().getCloudServiceProvider().getBrandCode())
            .brandName(cloudProduct.getCloudService().getCloudServiceProvider().getBrandName())
            .startingPlan(productQueryService.getMinPriceForPublishedPlans(cloudProduct))
            .categoryId(cloudProduct.getCloudService().getServiceCategory().getId())
            .categoryName(cloudProduct.getCloudService().getServiceCategory().getName())
            .isFeatured(cloudProduct.getIsFeatured())
            .hasFreeTrial(cloudProduct.getHasFreeTrial())
            .hasRelatedProducts(cloudProduct.getHasRelatedProducts())
            .build();
        productList.add(productDetails);

      }
      details.setCloudProductList(productList);
      // External Product
      Set<BundleExternalProduct> bundleExternalProductSet = entity.getBundleExternalProduct();
      List<ExternalProductDetails> externalProductList = new ArrayList<>();
      for (BundleExternalProduct bundleExternalProduct : NepheleValidationUtils.nullSafe(bundleExternalProductSet)) {
        ExternalProduct externalProduct = bundleExternalProduct.getExternalProduct();
        ExternalProductDetails externalProductDetails = ExternalProductDetails.builder()
            .externalProductId(externalProduct.getId())
            .externalId(externalProduct.getExternalId())
            .brandName(externalProduct.getBrandName())
            .description(externalProduct.getDescription())
            .productName(externalProduct.getProductName())
            .status(externalProduct.getStatus().name())
            .type(externalProduct.getType().name())
            .build();
        externalProductList.add(externalProductDetails);
      }
      details.setExternalProductList(externalProductList);
    }
    log.debug("readBundle() - end ");
    return new EntityReadEvent<BundleDetails>(details);
  }


  @Override
  public PageReadEvent<BundleDetails> readBundles(ReadBundlesEvent request) {
    log.debug("readBundles() -start");
    Page<Bundle> dbContent = null;
    Page<BundleDetails> page = null;
    List<BundleDetails> content = new ArrayList<>();
    dbContent = bundleRepository.findAll(BundleSpecifications.findByFilter(request.getName(), request.getStatus()), BundleSpecifications.constructPageSpecification(request.getPageable().getPageNumber(), request.getPageable().getPageSize(), sortByIdAsc()));
    if (dbContent != null) {
      for (Bundle record : NepheleValidationUtils.nullSafe(dbContent)) {
        BundleDetails details = BundleDetails.builder()
            .id(record.getId())
            .name(record.getName())
            .description(record.getDescription())
            .status(record.getStatus().name())
            .logoCode(record.getLogoCode())
            .created(record.getCreated())
            .updated(record.getUpdated())
            .build();
        Set<BundleCloudProduct> bundleProductSet = record.getBundleCloudProducts();
        List<CloudProductDetails> productList = new ArrayList<>();
        // Cloud Product
        for (BundleCloudProduct bundleProduct : NepheleValidationUtils.nullSafe(bundleProductSet)) {
          CloudProduct cloudProduct = bundleProduct.getCloudProduct();
          if (cloudProduct != null) {
            CloudProductDetails productDetails = CloudProductDetails.builder()
                .cloudProductId(cloudProduct.getId())
                .name(cloudProduct.getName())
                .status(cloudProduct.getStatus())
                .description(cloudProduct.getDescription())
                .type(cloudProduct.getType())
                .operatingSystemId(cloudProduct.getCloudOperatingSystem().getId())
                .operatingSystemName(cloudProduct.getCloudOperatingSystem().getName())
                .cloudServiceId(cloudProduct.getCloudService().getId())
                .serviceName(cloudProduct.getCloudService().getName())
                .startingPlan(productQueryService.getMinPriceForPublishedPlans(cloudProduct))
                .integrationCode(cloudProduct.getCloudService().getIntegrationCode())
                .brandCode(cloudProduct.getCloudService().getCloudServiceProvider().getBrandCode())
                .brandName(cloudProduct.getCloudService().getCloudServiceProvider().getBrandName())
                .categoryId(cloudProduct.getCloudService().getServiceCategory().getId())
                .categoryName(cloudProduct.getCloudService().getServiceCategory().getName())
                .isFeatured(cloudProduct.getIsFeatured())
                .hasFreeTrial(cloudProduct.getHasFreeTrial())
                .hasRelatedProducts(cloudProduct.getHasRelatedProducts())
                .build();
            productList.add(productDetails);
          }

          details.setCloudProductList(productList);
        }

        // External Product
        Set<BundleExternalProduct> bundleExternalProductSet = record.getBundleExternalProduct();
        List<ExternalProductDetails> externalProductList = new ArrayList<>();
        for (BundleExternalProduct bundleExternalProduct : NepheleValidationUtils.nullSafe(bundleExternalProductSet)) {
          ExternalProduct externalProduct = bundleExternalProduct.getExternalProduct();
          if (externalProduct != null) {
            ExternalProductDetails externalProductDetails = ExternalProductDetails.builder()
                .externalProductId(externalProduct.getId())
                .externalId(externalProduct.getExternalId())
                .brandName(externalProduct.getBrandName())
                .description(externalProduct.getDescription())
                .productName(externalProduct.getProductName())
                .status(externalProduct.getStatus().name())
                .type(externalProduct.getType().name())
                .build();
            externalProductList.add(externalProductDetails);
          }

          details.setExternalProductList(externalProductList);
        }

        content.add(details);
      }
      page = new PageImpl<>(content, request.getPageable(), dbContent.getTotalElements());
    } else {
      page = new PageImpl<>(content);
    }
    log.debug("readBundles() -end");
    return new PageReadEvent<>(page);
  }


  @Override
  public PageReadEvent<BundleDetails> readBundlesByIds(ReadBundlesEvent request) {
    log.debug("readBundlesByIds() - start");
    List<Bundle> dbContent = null;
    List<BundleDetails> content = new ArrayList<>();
    if (!CollectionUtils.isEmpty(request.getBundleIds())) {
      dbContent = bundleRepository.findBundlesByIds(request.getBundleIds());
    }
    int total = 0;
    for (Bundle record : NepheleValidationUtils.nullSafe(dbContent)) {
      if (total >= request.getPageable().getOffset() && total < request.getPageable().getOffset() + request.getPageable().getPageSize()) {
        BundleDetails details = BundleDetails.builder()
            .id(record.getId())
            .name(record.getName())
            .description(record.getDescription())
            .status(record.getStatus().name())
            .logoCode(record.getLogoCode())
            .created(record.getCreated())
            .updated(record.getUpdated())
            .build();
        Set<BundleCloudProduct> bundleProductSet = record.getBundleCloudProducts();
        List<CloudProductDetails> productList = new ArrayList<>();
        // Cloud Product
        for (BundleCloudProduct bundleProduct : NepheleValidationUtils.nullSafe(bundleProductSet)) {
          CloudProduct cloudProduct = bundleProduct.getCloudProduct();
          if (cloudProduct != null) {
            CloudProductDetails productDetails = CloudProductDetails.builder()
                .cloudProductId(cloudProduct.getId())
                .name(cloudProduct.getName())
                .status(cloudProduct.getStatus())
                .description(cloudProduct.getDescription())
                .type(cloudProduct.getType())
                .operatingSystemId(cloudProduct.getCloudOperatingSystem().getId())
                .operatingSystemName(cloudProduct.getCloudOperatingSystem().getName())
                .cloudServiceId(cloudProduct.getCloudService().getId())
                .serviceName(cloudProduct.getCloudService().getName())
                .integrationCode(cloudProduct.getCloudService().getIntegrationCode())
                .brandCode(cloudProduct.getCloudService().getCloudServiceProvider().getBrandCode())
                .brandName(cloudProduct.getCloudService().getCloudServiceProvider().getBrandName())
                .categoryId(cloudProduct.getCloudService().getServiceCategory().getId())
                .categoryName(cloudProduct.getCloudService().getServiceCategory().getName())
                .isFeatured(cloudProduct.getIsFeatured())
                .hasFreeTrial(cloudProduct.getHasFreeTrial())
                .hasRelatedProducts(cloudProduct.getHasRelatedProducts())
                .build();
            productList.add(productDetails);
          }
          details.setCloudProductList(productList);
        }
        // External Product
        Set<BundleExternalProduct> bundleExternalProductSet = record.getBundleExternalProduct();
        List<ExternalProductDetails> externalProductList = new ArrayList<>();
        for (BundleExternalProduct bundleExternalProduct : NepheleValidationUtils.nullSafe(bundleExternalProductSet)) {
          ExternalProduct externalProduct = bundleExternalProduct.getExternalProduct();
          if (externalProduct != null) {
            ExternalProductDetails externalProductDetails = ExternalProductDetails.builder()
                .externalProductId(externalProduct.getId())
                .brandName(externalProduct.getBrandName())
                .externalId(externalProduct.getExternalId())
                .description(externalProduct.getDescription())
                .productName(externalProduct.getProductName())
                .status(externalProduct.getStatus().name())
                .type(externalProduct.getType().name())
                .build();
            externalProductList.add(externalProductDetails);
          }
          details.setExternalProductList(externalProductList);
        }
        total++;
        content.add(details);
      }
    }
    Page<BundleDetails> page = new PageImpl<>(content, request.getPageable(), total);
    log.debug("readBundlesByIds() -end");
    return new PageReadEvent<>(page);
  }


@Override
public List<BundleDetails> readPublishedBundles() {
	List<Bundle> dbContent;
	 List<BundleDetails> content = new ArrayList<>();
    dbContent = bundleRepository.findAll(BundleSpecifications.findByFilter(null, BundleStatus.PUBLISHED.name()));
    if (dbContent != null) {
        for (Bundle record : NepheleValidationUtils.nullSafe(dbContent)) {
          BundleDetails details = BundleDetails.builder()
              .id(record.getId())
              .name(record.getName())
              .description(record.getDescription())
              .status(record.getStatus().name())
              .logoCode(record.getLogoCode())
              .created(record.getCreated())
              .updated(record.getUpdated())
              .build();
          Set<BundleCloudProduct> bundleProductSet = record.getBundleCloudProducts();
          List<CloudProductDetails> productList = new ArrayList<>();
          // Cloud Product
          for (BundleCloudProduct bundleProduct : NepheleValidationUtils.nullSafe(bundleProductSet)) {
            CloudProduct cloudProduct = bundleProduct.getCloudProduct();
            if (cloudProduct != null) {
              CloudProductDetails productDetails = CloudProductDetails.builder()
                  .cloudProductId(cloudProduct.getId())
                  .name(cloudProduct.getName())
                  .status(cloudProduct.getStatus())
                  .description(cloudProduct.getDescription())
                  .type(cloudProduct.getType())
                  .operatingSystemId(cloudProduct.getCloudOperatingSystem().getId())
                  .operatingSystemName(cloudProduct.getCloudOperatingSystem().getName())
                  .cloudServiceId(cloudProduct.getCloudService().getId())
                  .serviceName(cloudProduct.getCloudService().getName())
                  .startingPlan(productQueryService.getMinPriceForPublishedPlans(cloudProduct))
                  .integrationCode(cloudProduct.getCloudService().getIntegrationCode())
                  .brandCode(cloudProduct.getCloudService().getCloudServiceProvider().getBrandCode())
                  .brandName(cloudProduct.getCloudService().getCloudServiceProvider().getBrandName())
                  .categoryId(cloudProduct.getCloudService().getServiceCategory().getId())
                  .categoryName(cloudProduct.getCloudService().getServiceCategory().getName())
                  .isFeatured(cloudProduct.getIsFeatured())
                  .hasFreeTrial(cloudProduct.getHasFreeTrial())
                  .hasRelatedProducts(cloudProduct.getHasRelatedProducts())
                  .build();
              productList.add(productDetails);
            }

            details.setCloudProductList(productList);
          }

          // External Product
          Set<BundleExternalProduct> bundleExternalProductSet = record.getBundleExternalProduct();
          List<ExternalProductDetails> externalProductList = new ArrayList<>();
          for (BundleExternalProduct bundleExternalProduct : NepheleValidationUtils.nullSafe(bundleExternalProductSet)) {
            ExternalProduct externalProduct = bundleExternalProduct.getExternalProduct();
            if (externalProduct != null) {
              ExternalProductDetails externalProductDetails = ExternalProductDetails.builder()
                  .externalProductId(externalProduct.getId())
                  .externalId(externalProduct.getExternalId())
                  .brandName(externalProduct.getBrandName())
                  .description(externalProduct.getDescription())
                  .productName(externalProduct.getProductName())
                  .status(externalProduct.getStatus().name())
                  .type(externalProduct.getType().name())
                  .build();
              externalProductList.add(externalProductDetails);
            }

            details.setExternalProductList(externalProductList);
          }

          content.add(details);
        }
      }
	return content;
}

  
}
