package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAdditionalPriceDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAdditionalPriceEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudAdditionalPricesEvent;

public interface CloudAdditionalPriceQueryService {
	EntityReadEvent<CloudAdditionalPriceDetails> readCloudAdditionalPrice(ReadCloudAdditionalPriceEvent request);
	PageReadEvent<CloudAdditionalPriceDetails>   readCloudAdditionalPrices(ReadCloudAdditionalPricesEvent requst);
	PageReadEvent<CloudAdditionalPriceDetails>   readCloudAdditionalPricesByCloudService(ReadCloudAdditionalPricesEvent requst);
	PageReadEvent<CloudAdditionalPriceDetails>   readAdditionalForProducts(ReadCloudAdditionalPricesEvent requst);	

	
} 
