package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadPremiumGroupDiscountConfigsEvent  extends ReadPageEvent< ReadPremiumGroupDiscountConfigsEvent> {
	private Integer id;
	private String activeFrom;
	private String activeTo;
	private String status;
	private String sheetName;
	private Long serviceId;

}
