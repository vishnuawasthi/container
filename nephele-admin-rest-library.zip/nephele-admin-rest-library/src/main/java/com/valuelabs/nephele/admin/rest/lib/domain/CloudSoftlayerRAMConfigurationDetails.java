package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = false)
public class CloudSoftlayerRAMConfigurationDetails {
	
	private Long softlayerRAMId;
	private Double hourlyRecurringFee;
	private String description;
	private Long maxMemory;
	private String status;

}
