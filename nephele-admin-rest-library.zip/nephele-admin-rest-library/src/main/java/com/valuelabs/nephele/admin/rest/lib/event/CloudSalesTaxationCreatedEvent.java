package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSalesTaxationDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CloudSalesTaxationCreatedEvent {
	
	private CloudSalesTaxationDetails cloudSalesTaxationDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudSalesTaxationCreatedEvent(CloudSalesTaxationDetails cloudSalesTaxationDetails) {
		this.cloudSalesTaxationDetails = cloudSalesTaxationDetails;
	}

	public static CloudSalesTaxationCreatedEvent invalid(CloudSalesTaxationDetails cloudSalesTaxationDetails) {
		CloudSalesTaxationCreatedEvent event = new CloudSalesTaxationCreatedEvent(cloudSalesTaxationDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudSalesTaxationCreatedEvent failed(CloudSalesTaxationDetails cloudSalesTaxationDetails) {
		CloudSalesTaxationCreatedEvent event = new CloudSalesTaxationCreatedEvent(cloudSalesTaxationDetails);
		event.setFailed(true);
		return event;
	}

}
