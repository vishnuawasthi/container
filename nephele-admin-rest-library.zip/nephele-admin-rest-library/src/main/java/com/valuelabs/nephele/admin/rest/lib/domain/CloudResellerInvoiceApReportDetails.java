package com.valuelabs.nephele.admin.rest.lib.domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Accessors(chain = true)
public class CloudResellerInvoiceApReportDetails {

   @JsonSerialize(using = CustomJsonDateSerializer.class)
   private String fromDate;
   @JsonSerialize(using = CustomJsonDateSerializer.class)
   private String toDate;
   private String currency;
   private String grossTotal ;
   private Integer numberOfRecords;
   private String sortBy;
   private String cloudServiceId;
 
}



