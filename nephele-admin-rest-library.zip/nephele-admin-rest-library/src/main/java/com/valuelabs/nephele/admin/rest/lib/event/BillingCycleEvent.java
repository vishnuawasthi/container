package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.JobDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Created by btodupunoori.
 */
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class BillingCycleEvent {

	private JobDetails jobDetails;

}
