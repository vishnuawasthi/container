package com.valuelabs.nephele.admin.rest.lib.domain;




import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudServerDetails {
	
	private Long serverId;
	private Long productId;
	private String name;
	private String description;
	private String status;
	private String vendorStatus;
	private String uri;
	private String serverGroup;
	private String username;
	private String publicIPv4Address;
	private String publicIPv6Address;
	private String privateIPv4Address;
	private String privateIPv6Address;
	private String password;
	private String cspServerId;
	private Long locationId;
	private String locationName;
	private String flavorCategory;
	private Long serviceId;
	private Long customerId;
	private String customerName;
	//private Integer cloudProductId;
	private Long planId;
	private Long planRam;
    private Long cloudServiceId;
    private Long cloudOrderId;
    //private Integer cloudOrderLineId;
    private String cloudServiceName;
    private String brandCode;
	private String brandName;
    //private String serviceCode;
    private String integrationCode;
    private Date dateRangeStart;
	private Date dateRangeEnd;
	private Date creationDate;
	private String categoryName;
	private String remarks;
}



