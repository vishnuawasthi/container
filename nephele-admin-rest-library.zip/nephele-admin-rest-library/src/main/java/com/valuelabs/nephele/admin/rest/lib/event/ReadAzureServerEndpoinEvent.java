package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadAzureServerEndpoinEvent extends ReadEntityEvent<ReadAzureServerEndpoinEvent>{
	private Integer id;
}
