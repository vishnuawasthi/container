package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudManagerAppPermissionDetails {
	private Long id;
	private Boolean isRead;
	private Boolean isWrite;
	
	private Long roleId;
	private String roleName;
	
	//private CloudManagerAppFeatureDetails appFeatureDetails ;
	private Long cloudManagerAppAccountId;
	private String cloudManagerAppAccountName;
	private String accountDescription;
}
