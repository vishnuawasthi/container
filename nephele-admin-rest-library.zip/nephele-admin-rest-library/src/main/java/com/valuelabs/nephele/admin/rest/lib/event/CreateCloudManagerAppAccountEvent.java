package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppAccountDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class CreateCloudManagerAppAccountEvent {
private CloudManagerAppAccountDetails cloudManagerAppAccountDetails;
}
