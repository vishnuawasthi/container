package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.event.CreateLicenseEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ServiceLicenseCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface CloudLicenseCommandService {

	ServiceLicenseCreatedEvent createLicense(CreateLicenseEvent request) throws IllegalArgumentException;
	ServiceLicenseCreatedEvent updateeLicense(CreateLicenseEvent request) throws  IllegalArgumentException, ResourceNotFoundException;
}
