package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudDistributorCompanyDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudDistributorCompanyCreatedEvent {

	private CloudDistributorCompanyDetails cloudDistributorCompanyDetails;
	private boolean invalid;
	private boolean failed;
	public CloudDistributorCompanyCreatedEvent(CloudDistributorCompanyDetails cloudDistributorCompanyDetails) {
		this.cloudDistributorCompanyDetails = cloudDistributorCompanyDetails;
	}

	public static CloudDistributorCompanyCreatedEvent invalid(CloudDistributorCompanyDetails cloudDistributorCompanyDetails) {
		CloudDistributorCompanyCreatedEvent event = new CloudDistributorCompanyCreatedEvent(cloudDistributorCompanyDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudDistributorCompanyCreatedEvent failed(CloudDistributorCompanyDetails cloudDistributorCompanyDetails) {
		CloudDistributorCompanyCreatedEvent event = new CloudDistributorCompanyCreatedEvent(cloudDistributorCompanyDetails);
		event.setFailed(true);
		return event;
	}
}
