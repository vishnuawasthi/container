package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.ServiceCategoryDetails;

@Setter
@Getter
@Accessors(chain = true)
public class ServiceCategoryCreatedEvent {
  private ServiceCategoryDetails serviceCategoryDetail;
  private boolean invalid;
  private boolean failed;

  public ServiceCategoryCreatedEvent(ServiceCategoryDetails serviceCategoryDetail) {
	this.serviceCategoryDetail = serviceCategoryDetail;
  }

  public static ServiceCategoryCreatedEvent invalid(ServiceCategoryDetails serviceCategoryDetail) {
	ServiceCategoryCreatedEvent event = new ServiceCategoryCreatedEvent(serviceCategoryDetail);
	event.setInvalid(true);
	return event;
  }

  public static ServiceCategoryCreatedEvent failed(ServiceCategoryDetails serviceCategoryDetail) {
	ServiceCategoryCreatedEvent event = new ServiceCategoryCreatedEvent(serviceCategoryDetail);
	event.setFailed(true);
	return event;
  }

}
