package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderLineDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CreateCloudOrderLineEvent {
	private    CloudOrderLineDetails  cloudOrderLineDetails;
}
