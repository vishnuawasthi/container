package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Accessors(chain = true)
public class CloudResellerInvoiceLineDetails {

  private Long cloudInvoiceLineId;
  private String description;
  private Double price = 0.0D;
  private String quantity;
  private String total;
  private Long cloudInvoiceId;
  private String cloudCustomerName;
  private String serviceName;
  private String productPlan;
  private String type;
}
