package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.event.BundleCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateBundleEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

public interface BundleCommandService {
   BundleCreatedEvent createBundle(CreateBundleEvent request)throws IllegalArgumentException;
   BundleCreatedEvent updateBundle(CreateBundleEvent request)throws ResourceNotFoundException,IllegalArgumentException;
   void deleteBundle(Long id) throws ResourceNotFoundException,IllegalArgumentException;
}
