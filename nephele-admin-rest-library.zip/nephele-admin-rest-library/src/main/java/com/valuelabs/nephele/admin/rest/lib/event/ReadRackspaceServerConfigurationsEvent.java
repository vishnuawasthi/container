package com.valuelabs.nephele.admin.rest.lib.event;

public class ReadRackspaceServerConfigurationsEvent extends
		ReadPageEvent<ReadRackspaceServerConfigurationsEvent> {
	private Long id;
}
