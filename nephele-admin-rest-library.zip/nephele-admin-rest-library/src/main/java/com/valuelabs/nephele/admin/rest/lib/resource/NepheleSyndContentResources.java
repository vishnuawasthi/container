package com.valuelabs.nephele.admin.rest.lib.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class NepheleSyndContentResources {

	private String type;

	private String mode;

	private CloudFeedEventResources event;

	/*
	 * public NepheleSyndContentResources() { }
	 * 
	 * public NepheleSyndContentResources(String type, String mode,
	 * EventResources event) { super(); this.type = type; this.mode = mode;
	 * this.event = event; }
	 */

}
