package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Set;

@Data
@Accessors(chain=true)
public class DbsIntegrationCreatedEvent {
	
	private String response;

  private Set<String> planCodeSet;

  private Set<String> invoiceSet;

  private Set<String> paymentSet;

}
