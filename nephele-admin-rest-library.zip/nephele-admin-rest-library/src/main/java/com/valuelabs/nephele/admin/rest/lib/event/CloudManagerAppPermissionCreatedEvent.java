package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudManagerAppPermissionDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudManagerAppPermissionCreatedEvent {
private CloudManagerAppPermissionDetails cloudManagerAppPermissionDetails;
private List<CloudManagerAppPermissionDetails> permissionsList;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudManagerAppPermissionCreatedEvent(CloudManagerAppPermissionDetails cloudManagerAppPermissionDetails) {
		this.cloudManagerAppPermissionDetails = cloudManagerAppPermissionDetails;
	}
	
	public static CloudManagerAppPermissionCreatedEvent invalid(CloudManagerAppPermissionDetails cloudManagerAppPermissionDetails) {
		CloudManagerAppPermissionCreatedEvent event = new CloudManagerAppPermissionCreatedEvent(cloudManagerAppPermissionDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudManagerAppPermissionCreatedEvent failed(CloudManagerAppPermissionDetails cloudManagerAppPermissionDetails) {
		CloudManagerAppPermissionCreatedEvent event = new CloudManagerAppPermissionCreatedEvent(cloudManagerAppPermissionDetails);
		event.setFailed(true);
		return event;
	}
}
