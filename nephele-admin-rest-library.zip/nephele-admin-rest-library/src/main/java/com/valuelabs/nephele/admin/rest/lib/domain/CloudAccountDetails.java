package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
//@Data
@Setter
@Getter
//@EqualsAndHashCode
@Builder
@Accessors(chain = true)
public class CloudAccountDetails {
  private Long id;
  private String vendorAccountId;
  private String username;
  private String password;
  private String vendorStatus;
  private String nepheleStatus;
  private String superUsername;
  private String superPassword;
  private String superAPIKey;
  private Long cloudCustomerCompanyId;
  private String cloudCustomerCompanyName;
  private Long orderId;
  private String orderCode;
  private Long monthlyLicenseCount;
  private Long yearlyLicenseCount;
  private Boolean isTrialAccount;
  private Long planId;
  
  // Service related properties 
    private Long cloudServiceId;
    private String cloudServiceName;
	private Boolean isPublished;
	private Boolean isLive;
	private String description;
	private String integrationCode;
	private String serviceCode;
	private String vendorCode;
	private String billingCycle;
	private Integer billingDay;	
	private String planPrefix;
	private String subscriptionNamePrefix;	
	private String vendorCurrency;
	
	private List<CloudSubscriptionDetails> subscriptionDetails;

}
