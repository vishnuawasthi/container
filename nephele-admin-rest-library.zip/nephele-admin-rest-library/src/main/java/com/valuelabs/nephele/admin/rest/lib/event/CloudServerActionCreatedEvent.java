package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudServerActionDetails;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CloudServerActionCreatedEvent {
	private CloudServerActionDetails cloudServerActionDetails;
	private boolean invalid;
	private boolean failed;
	public CloudServerActionCreatedEvent(CloudServerActionDetails cloudServerActionDetails) {
		this.cloudServerActionDetails = cloudServerActionDetails;
	}

	public static CloudServerActionCreatedEvent invalid( CloudServerActionDetails cloudServerActionDetails) {
		CloudServerActionCreatedEvent event = new CloudServerActionCreatedEvent(cloudServerActionDetails);
		event.setInvalid(true);
		return event;
	}

	public static CloudServerActionCreatedEvent failed( CloudServerActionDetails cloudServerActionDetails) {
		CloudServerActionCreatedEvent event = new CloudServerActionCreatedEvent(cloudServerActionDetails);
		event.setFailed(true);
		return event;
	}
	
	
}
