package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.BundleDetails;

@Setter
@Getter
@Accessors(chain = true)
public class BundleCreatedEvent {
  private BundleDetails bundleDetails;

  private boolean invalid;
  private boolean failed;

  public BundleCreatedEvent(BundleDetails bundleDetails) {
	this.bundleDetails = bundleDetails;
  }

  public static BundleCreatedEvent invalid(BundleDetails bundleDetails) {
	BundleCreatedEvent event = new BundleCreatedEvent(bundleDetails);
	event.setInvalid(true);
	return event;
  }

  public static BundleCreatedEvent failed(BundleDetails bundleDetails) {
	BundleCreatedEvent event = new BundleCreatedEvent(bundleDetails);
	event.setFailed(true);
	return event;
  }

}
