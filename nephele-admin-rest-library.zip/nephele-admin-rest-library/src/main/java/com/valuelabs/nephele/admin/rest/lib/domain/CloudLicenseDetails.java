package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudLicenseDetails {

	private Long licenseId;
	private Long subscriptionId;
	private String licenseVendorId;
	private String status;
	//private Long planId;	
	private Date licenseProvisionDate;
	//private Date licenseNextRenewalDate;
	//private Date licenseLastRenewalDate;
	//private Date autoRenewalOffDate;
	//private boolean licenseAutoRenewal;
	
}
