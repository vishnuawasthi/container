package com.valuelabs.nephele.admin.rest.lib.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.valuelabs.nephele.admin.rest.lib.util.CustomJsonDateSerializer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
@Accessors(chain = true)
public class BundleDetails {
  
  private Long id;
  private String name;
  private String description;
  private String status;
  private String logoCode;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date created;
  @JsonSerialize(using = CustomJsonDateSerializer.class)
  private Date updated;
  private List<Long> bundleCloudproducts;
  private List<Long> bundleExternalproducts;
  private List<CloudProductDetails> cloudProductList;
  private List<ExternalProductDetails> externalProductList;
  private Long cloudProductId;
  private Long externalProductId;
}
  

