package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerCompanyDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerCompanyCreatedEvent {

private CloudResellerCompanyDetails resellerCompanyDetails;
private List<CloudResellerCompanyDetails> resellerCompanyDetailsList;

	private boolean invalid;
	private boolean failed;
	
	public CloudResellerCompanyCreatedEvent(CloudResellerCompanyDetails resellerCompanyDetails) {
		this.resellerCompanyDetails = resellerCompanyDetails;
	}
	
	public static CloudResellerCompanyCreatedEvent invalid(CloudResellerCompanyDetails resellerCompanyDetails) {
		CloudResellerCompanyCreatedEvent event = new CloudResellerCompanyCreatedEvent(resellerCompanyDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudResellerCompanyCreatedEvent failed(CloudResellerCompanyDetails resellerCompanyDetails) {
		CloudResellerCompanyCreatedEvent event = new CloudResellerCompanyCreatedEvent(resellerCompanyDetails);
		event.setFailed(true);
		return event;
	}
}
