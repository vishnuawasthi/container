package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateAuditDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRateAuditEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRatesAuditEvent;

public interface CloudCurrencyConversionRateAuditQueryService {
  EntityReadEvent<CloudCurrencyConversionRateAuditDetails> readCloudCurrencyConversionRateAudit(ReadCloudCurrencyConversionRateAuditEvent request);
  PageReadEvent<CloudCurrencyConversionRateAuditDetails> readCloudCurrencyConversionRatesAudit(ReadCloudCurrencyConversionRatesAuditEvent request);
}
