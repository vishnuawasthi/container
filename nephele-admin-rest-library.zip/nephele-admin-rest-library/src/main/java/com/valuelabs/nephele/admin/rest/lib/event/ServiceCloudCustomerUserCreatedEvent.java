package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCustomerUserDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceCloudCustomerUserCreatedEvent {

private CloudCustomerUserDetails cloudCustomerUserDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceCloudCustomerUserCreatedEvent(CloudCustomerUserDetails cloudCustomerUserDetails) {
		this.cloudCustomerUserDetails = cloudCustomerUserDetails;
	}
	
	public static ServiceCloudCustomerUserCreatedEvent invalid(CloudCustomerUserDetails cloudCustomerUserDetails) {
		ServiceCloudCustomerUserCreatedEvent event = new ServiceCloudCustomerUserCreatedEvent(cloudCustomerUserDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceCloudCustomerUserCreatedEvent failed(CloudCustomerUserDetails cloudCustomerUserDetails) {
		ServiceCloudCustomerUserCreatedEvent event = new ServiceCloudCustomerUserCreatedEvent(cloudCustomerUserDetails);
		event.setFailed(true);
		return event;
	}
}
