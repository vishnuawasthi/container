package com.valuelabs.nephele.admin.rest.lib.resource;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Setter
@Getter
public class NepheleCloudFeedResources {

	private String feedId;
	private String id;
	private String encoding;
	private String author;
	private String uuid;
	private String title;
	private String feedType;
	private String link;
	private String description;
	private Date publishedDate;
	private Date updatedDate;
	private String copyright;
	private String language;

	private NepheleSyndContentResources titleEx;

	private List<CloudFeedEntryResources> entries;
	private List<CloudFeedLinksResources> links;

}
