package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Data;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudAccountDetails;

@Data
@Accessors(chain = true)
public class CreateCloudAccountEvent {
  private  CloudAccountDetails accountDetails;
}
