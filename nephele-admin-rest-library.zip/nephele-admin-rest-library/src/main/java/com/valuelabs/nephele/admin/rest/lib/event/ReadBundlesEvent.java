package com.valuelabs.nephele.admin.rest.lib.event;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;


@Setter
@Getter
@Accessors(chain = true)
public class ReadBundlesEvent  extends ReadPageEvent<ReadBundlesEvent> {
	
	private Long id;
	private List<Long> bundleIds;
	private String name;
	private String status;
	

}
