package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudInvoiceLineDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudInvoiceLineDetailsCreatedEvent {

private CloudInvoiceLineDetails cloudInvoiceLineDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudInvoiceLineDetailsCreatedEvent(CloudInvoiceLineDetails cloudInvoiceLineDetails) {
		this.cloudInvoiceLineDetails = cloudInvoiceLineDetails;
	}
	
	public static CloudInvoiceLineDetailsCreatedEvent invalid(CloudInvoiceLineDetails cloudInvoiceLineDetails) {
		CloudInvoiceLineDetailsCreatedEvent event = new CloudInvoiceLineDetailsCreatedEvent(cloudInvoiceLineDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudInvoiceLineDetailsCreatedEvent failed(CloudInvoiceLineDetails cloudInvoiceLineDetails) {
		CloudInvoiceLineDetailsCreatedEvent event = new CloudInvoiceLineDetailsCreatedEvent(cloudInvoiceLineDetails);
		event.setFailed(true);
		return event;
	}
}
