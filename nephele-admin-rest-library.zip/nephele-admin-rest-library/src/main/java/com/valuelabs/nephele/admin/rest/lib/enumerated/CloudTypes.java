/**
 *
 */
package com.valuelabs.nephele.admin.rest.lib.enumerated;

/**
 * @author rrsanepalle
 */
public enum CloudTypes {

  rackspace,
  softlayer,
  azure,
  nomadesk

}
