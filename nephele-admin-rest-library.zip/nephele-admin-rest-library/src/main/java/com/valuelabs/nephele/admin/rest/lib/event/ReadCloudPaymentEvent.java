package com.valuelabs.nephele.admin.rest.lib.event;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.util.Date;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudPaymentEvent extends ReadEntityEvent<ReadCloudPaymentEvent>{

	private Long paymentId;
	private Double total;
	private Long invoiceId;
	private Double invoiceAmount;
	private Double surcharge;
	private String paymentMode;
	private String transactionId;
	private String instrumentType;
	private Date fromDate;
	private  Date toDate;
}
