package com.valuelabs.nephele.admin.rest.lib.event;


import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
public class ReadAccountServerViewEvent extends ReadPageEvent<ReadAccountServerViewEvent>{

	private Long serverId;
	private Long customerId;
	private String status;
	private Long orderId;
	private Date dateRangeStart;
	private Date dateRangeEnd;
	private String name;
	private String resellerCode;
	private String externalCustomerCode;
	private String orderCode;
	private Long providerId;
	private Long categoryId;
	private List<Long> serversId;
	private String externalResellerCode;
	private Long serviceId;
	private String description;
	private Long customerCompanyId;
	private Long resellerCompanyId;
	private Date fromDate;
	private Date toDate;
}
