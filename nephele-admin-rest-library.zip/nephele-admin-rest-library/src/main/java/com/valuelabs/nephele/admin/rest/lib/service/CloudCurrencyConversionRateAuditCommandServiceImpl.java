package com.valuelabs.nephele.admin.rest.lib.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRate;
import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRateAudit;
import com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateAuditRepository;
import com.valuelabs.nephele.admin.data.repository.CloudCurrencyConversionRateRepository;
import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateAuditDetails;
import com.valuelabs.nephele.admin.rest.lib.event.CloudCurrencyConversionRateAuditCreatedEvent;
import com.valuelabs.nephele.admin.rest.lib.event.CreateCloudCurrencyConversionAuditRateEvent;
import com.valuelabs.nephele.admin.rest.lib.exception.ResourceNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CloudCurrencyConversionRateAuditCommandServiceImpl implements CloudCurrencyConversionRateAuditCommandService {

  @Autowired
  private CloudCurrencyConversionRateAuditRepository rateAuditRepository;
  
  @Autowired
  private CloudCurrencyConversionRateRepository rateRepository;
  
  @Override
  public CloudCurrencyConversionRateAuditCreatedEvent createCloudCurrencyConversionRateAudit(
	  CreateCloudCurrencyConversionAuditRateEvent request) throws IllegalArgumentException {
	log.debug("createCloudCurrencyConversionRateAudit() -start");
	CloudCurrencyConversionRateAuditDetails details = request.getDetails();
	
	CloudCurrencyConversionRate rateEntity=rateRepository.findOne(details.getCurrencyConversionRateId());
	if(rateEntity==null){
		throw new ResourceNotFoundException("CloudCurrencyConversionRate", details.getCurrencyConversionRateId());
	}
	
	
	CloudCurrencyConversionRateAudit entity = CloudCurrencyConversionRateAudit.builder()
                                                              		.conversionRate(details.getConversionRate())
                                                              		.createdOn(details.getCreatedOn())
                                                              		.cloudCurrencyConversionRate(rateEntity)
                                                              		.build();
	
	rateAuditRepository.save(entity);
	log.debug("createCloudCurrencyConversionRateAudit() -end");
	return new CloudCurrencyConversionRateAuditCreatedEvent(details);
  }

}
