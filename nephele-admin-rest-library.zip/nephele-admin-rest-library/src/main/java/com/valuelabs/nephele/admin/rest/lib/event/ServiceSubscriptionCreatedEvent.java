package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudSubscriptionDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ServiceSubscriptionCreatedEvent {
	
	private CloudSubscriptionDetails cloudSubscriptionDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public ServiceSubscriptionCreatedEvent(CloudSubscriptionDetails cloudSubscriptionDetails) {
		this.cloudSubscriptionDetails = cloudSubscriptionDetails;
	}
	
	public static ServiceSubscriptionCreatedEvent invalid(CloudSubscriptionDetails cloudSubscriptionDetails) {
		ServiceSubscriptionCreatedEvent event = new ServiceSubscriptionCreatedEvent(cloudSubscriptionDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static ServiceSubscriptionCreatedEvent failed(CloudSubscriptionDetails cloudSubscriptionDetails) {
		ServiceSubscriptionCreatedEvent event = new ServiceSubscriptionCreatedEvent(cloudSubscriptionDetails);
		event.setFailed(true);
		return event;
	}
	

}
