package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudLocationDetails {

	private Long cloudLocationId;
	private String name;
	private String locationCode;
	private String status;
	//private String cspResource;
	private Long cloudServiceId; 
	private String cloudServiceName;
	private String geographyCode;
	private String geographyName;
	private String currency;

}
