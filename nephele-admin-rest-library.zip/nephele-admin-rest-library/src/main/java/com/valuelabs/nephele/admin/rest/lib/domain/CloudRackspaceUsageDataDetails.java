package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudRackspaceUsageDataDetails {

	private Long id;
	//private CloudCustomerCompany cloudCustomerCompany;
	//private CloudServer cloudServer;
	private Long cloudCustomerCompanyId;
	private Long cloudServerId;
	private String cspServerId;

	private String serverName;
	private String productType;

	private Long cloudServiceId;

	private String serviceType;

	private String flavourName;

	private Double usageQuantity;

	private Double unitPrice;

	private String currency;

	private Double totalPrice;

}
