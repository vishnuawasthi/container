package com.valuelabs.nephele.admin.rest.lib.event;


import java.sql.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper=true)
public class ReadCloudOrdersEvent extends ReadPageEvent<ReadCloudOrdersEvent> {

	private Long cloudOrderId;
	private String orderCode;
	private String status;
	private String externalCustomerCode;
	private Date dateRangeStart;
	private Date dateRangeEnd;
	private String externalResellerCode;
	
}