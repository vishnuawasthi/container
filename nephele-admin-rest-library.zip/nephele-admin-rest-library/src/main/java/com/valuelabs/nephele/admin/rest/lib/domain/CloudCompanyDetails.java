package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.*;
import lombok.experimental.Accessors;

/**
 * Created by snagaboina on 30/11/15.
 */
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
@Accessors(chain = true)
public class CloudCompanyDetails {

  private Long companyId;
  private String companyName;
  private String firstName;
  private String lastName;
  private String email;
  private String addressLine1;
  private String addressLine2;
  private String city;
  private String state;
  private String country;
  private String zipCode;
  private String externalCompanyCode;
  private String terriCode;
  private String abnNumber;
  private String salesPerson;

}

