package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudOrderDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;


//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudOrderCreatedEvent {
	
	private CloudOrderDetails cloudOrderDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudOrderCreatedEvent(CloudOrderDetails cloudOrderDetails) {
		this.cloudOrderDetails = cloudOrderDetails;
	}
	
	public static CloudOrderCreatedEvent invalid(CloudOrderDetails cloudOrderDetails) {
		CloudOrderCreatedEvent event = new CloudOrderCreatedEvent(cloudOrderDetails);
		event.setInvalid(true);
		return event;
	}
	
	public static CloudOrderCreatedEvent failed(CloudOrderDetails cloudOrderDetails) {
		CloudOrderCreatedEvent event = new CloudOrderCreatedEvent(cloudOrderDetails);
		event.setFailed(true);
		return event;
	}
	

}