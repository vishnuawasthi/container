package com.valuelabs.nephele.admin.rest.lib.resource;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@Builder
@AllArgsConstructor
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
public class CloudDistributorResource {

  private String companyName;
  private String addressLine1;
  private String addressLine2;
  private String city;
  private String state;
  private String country;
  private String zipCode;
  private String phone;
  private String fax;
  private String ABN;
  private String ACN;

}
