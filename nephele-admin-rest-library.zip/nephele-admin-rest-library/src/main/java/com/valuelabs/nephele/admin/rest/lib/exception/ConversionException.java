package com.valuelabs.nephele.admin.rest.lib.exception;


/**
 * An instance of this class is thrown when the conversion from one type to
 * another is impossible.
 *
 * @author Srinivas Ch, ValueLabs
 * @version 1.0.0
 */
public class ConversionException extends RuntimeException {

  private static final long serialVersionUID = 6103952390916087956L;

  // Conversion Exception Messages.
  public static final String ERROR_FROM_AND_TO = "Could not convert from %s to %s";
  public static final String ERROR_FROM = "Could not convert from %s";

  public ConversionException(final Class<?> fromClass, final Class<?> toClass) {
    super(String.format(ERROR_FROM_AND_TO, fromClass, toClass));
  }
}
