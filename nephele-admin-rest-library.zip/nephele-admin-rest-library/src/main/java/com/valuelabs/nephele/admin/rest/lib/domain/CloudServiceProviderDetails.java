package com.valuelabs.nephele.admin.rest.lib.domain;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudServiceProviderDetails implements Serializable{

	private Long serviceProviderId;
	private String brandName;
	private String brandCode;
	private String description;
}
