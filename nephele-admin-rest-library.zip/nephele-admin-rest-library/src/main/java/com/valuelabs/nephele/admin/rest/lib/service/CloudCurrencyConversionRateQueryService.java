package com.valuelabs.nephele.admin.rest.lib.service;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudCurrencyConversionRateDetails;
import com.valuelabs.nephele.admin.rest.lib.event.EntityReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.PageReadEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRateEvent;
import com.valuelabs.nephele.admin.rest.lib.event.ReadCloudCurrencyConversionRatesEvent;

public interface CloudCurrencyConversionRateQueryService {
  EntityReadEvent<CloudCurrencyConversionRateDetails> readCloudCurrencyConversionRate(ReadCloudCurrencyConversionRateEvent request);
  PageReadEvent<CloudCurrencyConversionRateDetails> readCloudCurrencyConversionRates(ReadCloudCurrencyConversionRatesEvent request);
}
