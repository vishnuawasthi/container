package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudResellerSlabDiscountDetails {
	
	 private Integer cloudResellerSlabDiscountId;
	 private Double startRange;
	 private Double endRange;
	 private Double discountPercentage;
	 private Integer cloudResellerVolumeDiscountId;
	 private CloudResellerVolumeDiscountDetails resellerVolumeDiscountDetails;

}
