package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudProductPlanDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudProductPlanCreatedEvent {
	
private CloudProductPlanDetails cloudProductPlanDetails;
	
	private boolean invalid;
	private boolean failed;
	
	public CloudProductPlanCreatedEvent(CloudProductPlanDetails cloudProductPlanDetails) {
		this.cloudProductPlanDetails = cloudProductPlanDetails;
	}
	public static CloudProductPlanCreatedEvent invalid(CloudProductPlanDetails cloudProductPlanDetails) {
		CloudProductPlanCreatedEvent event = new CloudProductPlanCreatedEvent(cloudProductPlanDetails);
		event.setInvalid(true);
		return event;
	}
	public static CloudProductPlanCreatedEvent failed(CloudProductPlanDetails cloudProductPlanDetails) {
		CloudProductPlanCreatedEvent event = new CloudProductPlanCreatedEvent(cloudProductPlanDetails);
		event.setFailed(true);
		return event;
	}

}
