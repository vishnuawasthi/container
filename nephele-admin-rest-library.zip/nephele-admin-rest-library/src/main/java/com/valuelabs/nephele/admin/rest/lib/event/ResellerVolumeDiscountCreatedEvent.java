package com.valuelabs.nephele.admin.rest.lib.event;

import com.valuelabs.nephele.admin.rest.lib.domain.CloudResellerVolumeDiscountDetails;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

//@Data
@Setter
@Getter
@Accessors(chain = true)
public class ResellerVolumeDiscountCreatedEvent {
	private CloudResellerVolumeDiscountDetails resellerVolumeDiscountDetails;

	private boolean invalid;
	private boolean failed;

	public ResellerVolumeDiscountCreatedEvent(CloudResellerVolumeDiscountDetails resellerVolumeDiscountDetails) {
		this.resellerVolumeDiscountDetails = resellerVolumeDiscountDetails;
	}

	public static ResellerVolumeDiscountCreatedEvent invalid(CloudResellerVolumeDiscountDetails resellerVolumeDiscountDetails) {
		ResellerVolumeDiscountCreatedEvent event = new ResellerVolumeDiscountCreatedEvent(resellerVolumeDiscountDetails);
		event.setInvalid(true);
		return event;
	}

	public static ResellerVolumeDiscountCreatedEvent failed(CloudResellerVolumeDiscountDetails resellerVolumeDiscountDetails) {
		ResellerVolumeDiscountCreatedEvent event = new ResellerVolumeDiscountCreatedEvent(resellerVolumeDiscountDetails);
		event.setFailed(true);
		return event;
	}
}
