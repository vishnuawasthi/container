package com.valuelabs.nephele.admin.rest.lib.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
public class CloudLifeCycleConfigDetails {

	private Long  	lifeCycleConfigId;
	private String 	orderPrefix;
	private String 	invoicePrefix;
	private String 	planPrefix;
	private String 	currency;
	private Integer invoiceTerm;
	private Double amexSurcharge;
	private Double masterSurcharge;
	private Double visaSurcharge;

}
