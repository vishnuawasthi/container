package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.JobStatus;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name="cloud_billing_cycle_seq",sequenceName="cloud_billing_cycle_seq",initialValue=1)
//@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name="cloud_billing_cycle")
public class CloudBillingCycle extends AbstractAuditEntity implements Serializable{
	
	private static final long serialVersionUID = -2054542748854770942L;
	
	@Id
    @GeneratedValue(generator="cloud_billing_cycle_seq")
    @Column(name = "cycle_id", nullable = false)
	private Long id;
	
	@Column(name = "billing_period_start_date", nullable = true)
	private Date billingPeriodStartDate;
	
	@Column(name = "billing_period_end_date", nullable = true)
	private Date billingPeriodEndDate;
	
	@Column(name = "host_name", nullable = true)
	private String hostName;
	
	@Column(name = "vendor_metering_status", nullable = true)
	@Enumerated(EnumType.STRING)
	private JobStatus vendorMeteringStatus;
	
	@Column(name = "nephele_metering_status", nullable = true)
	@Enumerated(EnumType.STRING)
	private JobStatus nepheleMeteringStatus;
	
	@Column(name = "invoice_status", nullable = true)
	@Enumerated(EnumType.STRING)
	private JobStatus invoiceStatus;
	
	@Column(name = "current_parse_job_status", nullable = true)
	@Enumerated(EnumType.STRING)
	private JobStatus currentParseJobStatus;
	
	@ManyToOne
	@JoinColumn(name = "cloud_service_id")
	private CloudService cloudService;
	
	@OneToMany(mappedBy = "billingCycle")
	private Set<RackspaceMeteringData> meteringDataSet = new HashSet<RackspaceMeteringData>();

}
