package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudRackspacePriceUnitMeasure;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudRackspacePriceUnitMeasureDAO extends AbstractJpaDAO<CloudRackspacePriceUnitMeasure> {

	public CloudRackspacePriceUnitMeasureDAO() {
		setClazz(CloudRackspacePriceUnitMeasure.class);
	}
}
