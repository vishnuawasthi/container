package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.api.ResellerDiscountPlanType;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
@Getter
@Setter
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_premium_group_discount_config_seq",sequenceName="cloud_premium_group_discount_config_seq",initialValue=1)
@NamedQueries({
	@NamedQuery(name = "premiumDiscountConfig.findByServiceIdandStatus", query = "FROM  PremiumGroupDiscountConfig pg WHERE pg.cloudService.id =:serviceId AND pg.status =:status"),
	@NamedQuery(name = "premiumDiscountConfig.findByServiceIdandDraftScheduledStatus", query = "FROM  PremiumGroupDiscountConfig pg WHERE pg.cloudService.id =:serviceId AND pg.status IN :statusList"),
	@NamedQuery(name = "premiumDiscountConfig.findBySheetName", query = "FROM  PremiumGroupDiscountConfig pg WHERE pg.discountSheetName =:sheetName")	
	})
@Entity
@Table(name="cloud_premium_group_discount_config")
public class PremiumGroupDiscountConfig extends AbstractAuditEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5964312760208441825L;
	@OneToMany(mappedBy = "premiumGroupDiscountConfig")
	Set<PremiumGroupDiscountSheet> premiumGroupDiscountSheet;
	@Id
    @GeneratedValue(generator="cloud_premium_group_discount_config_seq")
	@Column(name = "cloud_premium_group_discount_config_id", nullable = false)
	private Long id;
	@Column(name="discount_sheet_name")
	private String discountSheetName;
	@Column(name="active_from")
	private Date activeFrom;
	@Column(name="active_to")
	private Date activeTo;
	@Column(name="status")
	@Enumerated(EnumType.STRING)
	private ChangeManagementConfigStatus status;
	@ManyToOne
	@JoinColumn(name="cloud_service_id")
	private CloudService cloudService;
	@Column(name="comments")
	private String comments;
	@Column(name="custom_date")
	private Date customDate;
	@Column(name = "reseller_discount_plan_type", nullable = false)
	@Enumerated(EnumType.STRING)
	private ResellerDiscountPlanType planType;
	
	
}
