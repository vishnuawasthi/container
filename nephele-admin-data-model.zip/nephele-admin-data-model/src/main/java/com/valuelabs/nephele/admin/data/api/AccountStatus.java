package com.valuelabs.nephele.admin.data.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "AccountStatus")
@XmlEnum
public enum AccountStatus {
	@XmlEnumValue("Pending")
	Pending,
	@XmlEnumValue("New")
	New,
	@XmlEnumValue("Existing")
	Existing,
	@XmlEnumValue("ConfirmationExpired")
	ConfirmationExpired,
	@XmlEnumValue("Invited")
	Invited,
	@XmlEnumValue("Cancel")
	Cancel,
	@XmlEnumValue("Suspend")
	Suspend;
	
	private String value = "";

	AccountStatus() {
    }
	
	AccountStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AccountStatus fromValue(String v) {
        for (AccountStatus c: AccountStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    } 
}
