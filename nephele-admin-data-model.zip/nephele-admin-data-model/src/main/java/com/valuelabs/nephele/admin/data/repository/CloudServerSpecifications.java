package com.valuelabs.nephele.admin.data.repository;

import java.sql.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudOrder;
import com.valuelabs.nephele.admin.data.entity.CloudServer;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

@Slf4j
public final class CloudServerSpecifications  {
	
	 public static Specification<CloudServer> findServersByFilter(final String status, final Long orderId,
			 final String orderCode, final Date dateRangeStart, final Date dateRangeEnd, final String name, 
			 final String externalCustomerCode, final String resellerCode,final Long providerId, final Long categoryId,final Long serviceId,final String description) {
		 
		  return new Specification<CloudServer>(){
			
			@Override
			public Predicate toPredicate(Root<CloudServer> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();
				Join<CloudServer, CloudOrder> rootWithOrder = root.join("cloudOrder");
				
				Join<CloudServer, CloudCustomerCompany> rootWithCustomerCompany= root.join("cloudCustomerCompany");
				
					Path<Object> rootWithResellerCompany = rootWithCustomerCompany.get("cloudResellerCompany");
					// new 
				    Join<CloudServer, CloudService> rootWithCloudService = root.join("cloudService");
				    
					Path<Object> serviceProviderPath = rootWithCloudService.get("cloudServiceProvider");
					
					Path<Object> serviceCategoryPath = rootWithCloudService.get("serviceCategory");
				 
				 
				 predicate = criteriaBuilder.and(predicate,criteriaBuilder.notEqual(root.get("status"), "TERMINATED"));
				
        		if (!StringUtils.isEmpty(serviceId)) {
        		  	predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithCloudService.get("id"), serviceId));
        		}
				 
				if(!StringUtils.isEmpty(resellerCode)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithResellerCompany.get("resellerCompanyCode"), resellerCode));
				}
				
				if(!StringUtils.isEmpty(externalCustomerCode)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithCustomerCompany.get("customerCompanyCode"), externalCustomerCode));
				}
				
				
				if (!StringUtils.isEmpty(status)) {
					Expression<String>  rootStatus = root.get("status");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), "%" + status.toLowerCase() + "%"));
				}
				if (!StringUtils.isEmpty(orderId)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithOrder.get("id"), orderId));
					  
				}
				
				if (!StringUtils.isEmpty(orderCode)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithOrder.get("orderCode"), orderCode));
						  
					}
				if (!StringUtils.isEmpty(name)) {
					Expression<String>  rootName = root.get("name");
					  predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootName), "%" + name.toLowerCase() + "%"));
						  
				}
				if ( !StringUtils.isEmpty(dateRangeStart)) {
					
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(root.<Date>get("created"), dateRangeStart, 
						  DateFormatterUtility.getAfterDate(dateRangeEnd, 23)));
					  
				}
				
				
				if (!StringUtils.isEmpty(providerId)) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceProviderPath.get("id"), providerId));
				}
				
				if (!StringUtils.isEmpty(categoryId)) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceCategoryPath.get("id"), categoryId));
				}
				if (!StringUtils.isEmpty(description)) {
					Expression<String>  rootDescription = root.get("description");
					  predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootDescription), "%" + description.toLowerCase() + "%"));
						  
				}
				
				
		  		return predicate;
			}
		};
	 }
	 
  public static Specification<CloudServer> findServersByProviderAndCategory(final Long providerId, final Long categoryId ,final String externalResellerCode,final Long serviceId,final String description) {
	return new Specification<CloudServer>() {

	  @Override
	  public Predicate toPredicate(Root<CloudServer> root, CriteriaQuery<?> criteriaQuery,
		  CriteriaBuilder criteriaBuilder) {
		Predicate predicate = criteriaBuilder.conjunction();
		Join<CloudServer, CloudService> rootWithCloudService = root.join("cloudService");
		Path<Object> serviceProviderPath = rootWithCloudService.get("cloudServiceProvider");
		Path<Object> serviceCategoryPath = rootWithCloudService.get("serviceCategory");
		
		Join<CloudServer, CloudCustomerCompany> rootWithCustomerCompany= root.join("cloudCustomerCompany");
		
		 Path<Object> cloudResellerCompany = rootWithCustomerCompany.get("cloudResellerCompany");
		
		if (!StringUtils.isEmpty(serviceId)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithCloudService.get("id"), serviceId));
		}

		if (!StringUtils.isEmpty(providerId)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceProviderPath.get("id"), providerId));
		}
		
		if (!StringUtils.isEmpty(categoryId)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceCategoryPath.get("id"), categoryId));
		}
		
		if(!StringUtils.isEmpty(externalResellerCode)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(cloudResellerCompany.get("resellerCompanyCode"), externalResellerCode));
		}
		if (!StringUtils.isEmpty(description)) {
			Expression<String>  rootDescription = root.get("description");
			  predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootDescription), "%" + description.toLowerCase() + "%"));
				  
		}
		
		return predicate;
	  }

	};

  }
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts persons in ascending order by using the last name.
	     * @return
	     */
	    public static Sort sortByLastNameAsc() {
	        return new Sort(Sort.Direction.ASC, "lastName");
	    }


}
