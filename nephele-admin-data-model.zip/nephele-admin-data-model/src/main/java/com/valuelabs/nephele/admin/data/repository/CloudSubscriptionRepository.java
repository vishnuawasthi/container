package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudSubscription;

public interface CloudSubscriptionRepository extends TableRepository<CloudSubscription, Long>, JpaSpecificationExecutor<CloudSubscription>{

	
	@Query("SELECT cs FROM  CloudSubscription cs WHERE cs.cloudAccount.id = :accountId  AND cs.vendorSubscrioptionId = :licenseId") 
	public CloudSubscription findByAccountIdAndLicenseId(@Param("accountId") Long accountId, @Param("licenseId") String licenseId);
	
}
