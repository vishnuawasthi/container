package com.valuelabs.nephele.admin.data.api;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "AuthMethod")
@XmlEnum
public enum AuthMethod {
	@XmlEnumValue("Password")
	Password,
	@XmlEnumValue("SAML")
	SAML;
	
	private String value = "";

	AuthMethod() {
    }
	
	AuthMethod(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AuthMethod fromValue(String v) {
        for (AuthMethod c: AuthMethod.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    } 
	
}
