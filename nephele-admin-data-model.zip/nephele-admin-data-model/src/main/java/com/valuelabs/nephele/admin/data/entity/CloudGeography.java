package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@SequenceGenerator(name = "cloud_geography_seq", sequenceName = "cloud_geography_seq", initialValue = 1)
@Entity
@Table(name = "cloud_geography")
public class CloudGeography extends AbstractAuditEntity implements Serializable {
  
  
  @Id
  @GeneratedValue(generator = "cloud_geography_seq")
  @Column(name = "cloud_geography_id")
  private Long id;
  
  @Column(name="geography_name")
  private String geographyName;
  
  @Column(name="geography_code")
  private String geographyCode;
  
  @OneToMany(mappedBy="cloudGeography")
  private Set<CloudLocation> cloudLocations = new HashSet<CloudLocation>();
}
