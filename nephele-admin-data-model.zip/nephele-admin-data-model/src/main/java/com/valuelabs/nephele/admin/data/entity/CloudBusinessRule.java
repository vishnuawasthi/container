package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.BusinessRuleNames;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_business_rule_seq",sequenceName="cloud_business_rule_seq",initialValue=1)
@Entity
@Table(name="cloud_business_rule")
public class CloudBusinessRule extends AbstractAuditEntity implements Serializable {
	private static final long serialVersionUID = 314276904479003689L;

	@Id
	@GeneratedValue(generator="cloud_business_rule_seq")
	@Column(name="rule_id")
	private Long ruleId;
	
	@Column(name="rule_name",unique=true)
	@Enumerated(EnumType.STRING)
	private BusinessRuleNames ruleName;
	
	@Column(name="rule_description")
	private String ruleDescription;

	@Column(name = "rule_value", nullable = true, length = 512)
	private String ruleValue;
	

	/*@OneToMany(mappedBy = "cloudBusinessRule", fetch = FetchType.EAGER)
	private Set<CloudBusinessRuleValue> cloudBusinessRuleValue=new HashSet<CloudBusinessRuleValue>();*/
	
	
	
}
