package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@SequenceGenerator(name="cloud_subscription_edition_seq",sequenceName="cloud_subscription_edition_seq",initialValue=1)
@Entity
@Table(name="cloud_subscription_edition")
public class CloudSubscriptionEdition extends AbstractAuditEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5964312760208441825L;
	
	@Id
    @GeneratedValue(generator="cloud_subscription_edition_seq")
    @Column(name = "cloud_subscription_edition_id", nullable = false)
	private Long id;
	
	/*@ManyToOne
	@JoinColumn(name="cloud_subscription_id")
	private CloudSubscription cloudSubscription;*/
	
	@Column(name="edition_id")
	private String editionId;
	
	@Column(name="seat_count")
	private String seatCount;
	
	@Column(name="subscribed_at")
	private String subscribeAt;
	

}
