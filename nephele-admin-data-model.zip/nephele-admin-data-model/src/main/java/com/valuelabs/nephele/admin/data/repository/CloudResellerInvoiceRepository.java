package com.valuelabs.nephele.admin.data.repository;


import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudResellerInvoice;


/*
 * Created by ranjith on 5/10/15.
 */


public interface CloudResellerInvoiceRepository extends TableRepository<CloudResellerInvoice, Long>, JpaSpecificationExecutor<CloudResellerInvoice> {


  @Query("FROM  CloudResellerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate ORDER BY c.netTotal DESC")
  public List<CloudResellerInvoice> getInvoiceByOrder(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

  @Query("SELECT sum(grossTotal)  as NUMBER FROM  CloudResellerInvoice  WHERE created BETWEEN :fromDate AND :toDate")
  public Double getRevenue(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

  @Query("FROM  CloudResellerInvoice ci WHERE ci.cloudResellerCompany.id =:cloudResellerCompanyId")
  public List<CloudResellerInvoice> getCloudInvoiceByResellerId(@Param("cloudResellerCompanyId") Long cloudResellerId);


  @Query("SELECT sum(cri.grossTotal) as total, cri.cloudService.id as service_id, cs.name as service_name, " +
      "cs.integrationCode as integration_Code FROM CloudResellerInvoice cri, CloudService cs " +
      "WHERE cri.cloudService.id=cs.id  AND cri.created BETWEEN :fromDate AND :toDate GROUP BY cri.cloudService.id, cs.name, cs.integrationCode ORDER BY total DESC")
  public List<Object[]> getServicesByRevenue(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);


  @Query("SELECT sum(cri.grossTotal) as total, cri.cloudService.id as service_id," +
      "  cs.name as service_name, cs.integrationCode as integration_Code FROM CloudResellerInvoice cri , CloudService cs WHERE " +
      " cri.cloudService.id=cs.id  AND cri.created between :fromDate AND :toDate AND cri.cloudResellerCompany.id= " +
      " :cloudResellerCompanyId GROUP BY cri.cloudService.id, cs.name, cs.integrationCode ORDER BY total DESC")
  public List<Object[]> getServicesByResellerRevenue(@Param("cloudResellerCompanyId") Long resellerId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);


  @Query("SELECT i.cloudResellerCompany.id, sum(i.grossTotal) AS AMOUNT, c.resellerCompanyName," +
      "c.resellerCompanyCode FROM CloudResellerInvoice i , CloudResellerCompany c WHERE " +
      " i.cloudResellerCompany.id=c.id AND i.created BETWEEN :fromDate AND :toDate " +
      "GROUP BY i.cloudResellerCompany.id, c.resellerCompanyName, c.resellerCompanyCode  ORDER BY AMOUNT DESC")
  public List<Object[]> topReseller(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

  @Query("SELECT cs.vendorCurrency , i.fromDate, i.toDate ,SUM(i.vendorTotal) AS AMOUNT,i.cloudService.id FROM CloudResellerInvoice i , CloudService cs WHERE " +
      " ( EXTRACT(YEAR FROM i.fromDate) = :year  OR EXTRACT(YEAR FROM i.toDate) = :year) AND i.cloudService.id = cs.id AND  cs.serviceCode = :cloudServiceCode" +
      " GROUP BY cs.vendorCurrency,i.fromDate,i.toDate,i.cloudService.id ORDER BY AMOUNT DESC")
  public List<Object[]> getApReport(@Param("year") Integer year,@Param("cloudServiceCode") String cloudServiceCode);
  

  @Query("SELECT sum(grossTotal) FROM  CloudResellerInvoice c  WHERE c.cloudResellerCompany.id =:cloudResellerCompanyId AND c.created BETWEEN :fromDate AND :toDate")
  public Double getRevenueByResellerId(@Param("cloudResellerCompanyId") Long resellerId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

  @Query("SELECT sum(cri.grossTotal), cri.cloudService.id, cri.cloudCustomerCompany.id,  sc.name, sc.id " +
      "FROM  CloudResellerInvoice cri, CloudService cs, ServiceCategory sc where cri.cloudService.id=cs.id and cs.serviceCategory.id=sc.id " +
      " AND cri.cloudResellerCompany.id =:cloudResellerCompanyId AND cri.created BETWEEN :fromDate AND :toDate " +
      "group by sc.id, cri.cloudService.id, cri.cloudCustomerCompany.id, sc.name ")
  List<Object[]> getRevenueDetailsByResellerId(@Param("cloudResellerCompanyId") Long resellerId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

  @Query("SELECT INVOICE.cloudCustomerCompany.id, SUM(INVOICE.grossTotal) AS AMOUNT, COMPANY.customerCompanyName ,COMPANY.customerCompanyCode" +
      " FROM  CloudResellerInvoice INVOICE, CloudCustomerCompany COMPANY WHERE INVOICE.cloudCustomerCompany.id = COMPANY.id " +
      " AND INVOICE.cloudResellerCompany.id =:cloudResellerCompanyId AND INVOICE.created BETWEEN :fromDate AND :toDate GROUP BY " +
      " INVOICE.cloudCustomerCompany.id, COMPANY.customerCompanyName ,COMPANY.customerCompanyCode  ORDER BY AMOUNT DESC")
  public List<Object[]> getCustomerRevenueDetailByDate(@Param("cloudResellerCompanyId") Long resellerId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);


  @Query("SELECT INVOICE.cloudCustomerCompany.id, SUM(INVOICE.grossTotal) AS AMOUNT, COMPANY.customerCompanyName ,COMPANY.customerCompanyCode" +
      " FROM  CloudResellerInvoice INVOICE, CloudCustomerCompany COMPANY WHERE INVOICE.cloudCustomerCompany.id = COMPANY.id " +
      " AND INVOICE.cloudResellerCompany.id =:cloudResellerCompanyId GROUP BY " +
      " INVOICE.cloudCustomerCompany.id, COMPANY.customerCompanyName ,COMPANY.customerCompanyCode  ORDER BY AMOUNT DESC")
  public List<Object[]> getCustomerRevenueDetail(@Param("cloudResellerCompanyId") Long resellerId);

  @Query("FROM  CloudResellerInvoice c WHERE c.cloudInvoiceNumber=:invoiceNumber")
  public CloudResellerInvoice findByInvoiceNumber(@Param("invoiceNumber") String cloudInvoiceNumber);

  @Query("SELECT EXTRACT(YEAR FROM fromDate) AS invoiceYear FROM CloudResellerInvoice group by fromDate")
  List<Integer> findInvoiceYearFromDateList();

  @Query("SELECT EXTRACT(YEAR FROM toDate) AS invoiceYear FROM CloudResellerInvoice group by toDate")
  List<Integer> findInvoiceYearToDateList();

  @Query("SELECT cri.cloudService.id, cs.name, cs.integrationCode, cs.serviceCode FROM CloudResellerInvoice cri , CloudService cs WHERE cri.cloudService.id=cs.id " +
      " GROUP BY cri.cloudService.id, cs.name, cs.integrationCode, cs.serviceCode ORDER BY cs.name DESC")
  List<Object[]> findServiceList();

  @Query("FROM  CloudResellerInvoice c WHERE c.cloudInvoiceNumber in :invoiceNumber")
  List<CloudResellerInvoice> loadByInvoiceNumberSet(@Param("invoiceNumber") Set<String> invoiceNumber);
}

