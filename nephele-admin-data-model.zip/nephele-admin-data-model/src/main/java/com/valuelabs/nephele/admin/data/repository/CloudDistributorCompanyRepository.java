package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudDistributorCompany;

public interface CloudDistributorCompanyRepository extends TableRepository<CloudDistributorCompany, Long>, JpaSpecificationExecutor<CloudDistributorCompany>{

}
