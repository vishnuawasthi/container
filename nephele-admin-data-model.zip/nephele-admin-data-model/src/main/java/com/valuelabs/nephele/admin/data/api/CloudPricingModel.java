package com.valuelabs.nephele.admin.data.api;

public enum CloudPricingModel {
	PER_LICENSE,
	PER_HOUR, 
	PER_UNIT, 
	PER_GIGABYTE
}
