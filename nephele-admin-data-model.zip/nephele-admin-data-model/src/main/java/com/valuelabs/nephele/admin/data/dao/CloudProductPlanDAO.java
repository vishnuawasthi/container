package com.valuelabs.nephele.admin.data.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.data.entity.CloudLocation;
import com.valuelabs.nephele.admin.data.entity.CloudProduct;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudProductPlanDAO extends AbstractJpaDAO<CloudProductPlan> {

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudProductPlanDAO() {
		setClazz(CloudProductPlan.class);
	}
	
	public List<CloudProductPlan> getPublishedPlansByProductId(Long productId){
		
		TypedQuery<CloudProductPlan> query =
				entityManager.createNamedQuery("CloudProductPlan.findByProduct", CloudProductPlan.class)
				.setParameter("productId", productId);
	
		return query.getResultList();	
	}
	
	public List<CloudProductPlan> getPublishedPlansByServiceId(Long serviceId){
		
		TypedQuery<CloudProductPlan> query =
				entityManager.createNamedQuery("CloudProductPlan.findPublishedPlansByService", CloudProductPlan.class)
				.setParameter("serviceId", serviceId);
	
		return query.getResultList();	
	}
	
	public List<CloudProductPlan> getPublishedPlansByProductIdAndLocationId(Long productId, Long locationId){
		
		TypedQuery<CloudProductPlan> query =
				entityManager.createNamedQuery("CloudProductPlan.findByProductAndLocation", CloudProductPlan.class)
				.setParameter("productId", productId)
				.setParameter("locationId", locationId);
	
		return query.getResultList();	
	}
	
  public List<CloudProductPlan> getPublishedPlansByProductIdAndLocationIdAndCategory(Long productId, Long serviceId,
		  Long locationId, String flavorCategory) {

	/*
	 * TypedQuery<CloudProductPlan> query = entityManager.createNamedQuery(
	 * "CloudProductPlan.findByProductAndLocationAndCategory",
	 * CloudProductPlan.class) .setParameter("productId", productId)
	 * .setParameter("locationId", locationId) .setParameter("category",
	 * category); return query.getResultList();
	 */

	List<CloudProductPlan> list =   null;
	CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	CriteriaQuery<CloudProductPlan> criteriaQuery = criteriaBuilder.createQuery(CloudProductPlan.class);
	Root<CloudProductPlan> rootBase = criteriaQuery.from(CloudProductPlan.class);
	Predicate predicate = criteriaBuilder.conjunction();

	Join<CloudProductPlan, CloudProduct> rootWithProduct = rootBase.join("cloudProduct");
	Join<CloudProductPlan, CloudLocation> rootWithLocation= rootBase.join("cloudLocation");
	Join<CloudProductPlan, CloudService> rootWithService= rootBase.join("cloudService");
	
	List<Order> orderList = new ArrayList<Order>();
	 
	
	
	
	Expression<String>  rootStatus = rootBase.get("status");
	predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), InventoryStatus.PUBLISHED.name().toLowerCase()));
	
	predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("isPublished"), true));
	
	if (!StringUtils.isEmpty(flavorCategory)) {
		Expression<String>  rootCategory = rootBase.get("flavorCategory");
		predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootCategory), flavorCategory.toLowerCase()));
	}
	
	if(!StringUtils.isEmpty(serviceId)) {
	  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
	}
	if (!StringUtils.isEmpty(productId)) {
	  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithProduct.get("id"), productId));
		  
	}
	if ( !StringUtils.isEmpty(locationId)) {
	  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithLocation.get("id"), locationId));
	}
	
	criteriaQuery.where(predicate);
	
	orderList.add(criteriaBuilder.asc(rootBase.get("sortKey")));
	criteriaQuery.orderBy(orderList);
	
	list =entityManager.createQuery(criteriaQuery).getResultList();
	return list;
  }
	
	public List<CloudProductPlan> getStagedProdcutPlans(){
		
		TypedQuery<CloudProductPlan> query =
				entityManager.createNamedQuery("CloudProductPlan.findStagedPlans", CloudProductPlan.class);
	
		return query.getResultList();	
	}
	
    public List<CloudProductPlan> getProdcutPlansByserviceId(Long serviceId){
		
		TypedQuery<CloudProductPlan> query =
				entityManager.createNamedQuery("CloudProductPlan.findByService", CloudProductPlan.class)
				.setParameter("serviceId", serviceId);
	
		return query.getResultList();	
	}
    
	
	public void updateAll(List<Object> entityList) {
		for ( int i=0; i<entityList.size(); i++ ) {
			CloudProductPlan entity = (CloudProductPlan) entityList.get(i);
			entityManager.merge(entity);
		}
	}
	
	public void persistAll(List<Object> listOfbatchObjects) {
		for ( int i=0; i<listOfbatchObjects.size(); i++ ) {
			CloudProductPlan meteringData = (CloudProductPlan) listOfbatchObjects.get(i);
			entityManager.persist(meteringData);
		}
	}
	
	 public List<CloudProductPlan> getProductPlansByOperatingSystemIdNLocationIdNStatus(Long serviceId,Long operatingSystemId,
			 Long locationId, String status ,String flavorCategory) {
		List<CloudProductPlan> list =   null;
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CloudProductPlan> criteriaQuery = criteriaBuilder.createQuery(CloudProductPlan.class);
		Root<CloudProductPlan> rootBase = criteriaQuery.from(CloudProductPlan.class);
		Predicate predicate = criteriaBuilder.conjunction();
		
		 Join<CloudProductPlan, CloudService> rootWithService= rootBase.join("cloudService");
		 Join<CloudProductPlan, CloudLocation> rootWithLocation= rootBase.join("cloudLocation");
		 
		 Join<CloudProductPlan, CloudProduct> rootWithProduct= rootBase.join("cloudProduct");
		 Path<Object> rootWithOperatingSystem= rootWithProduct.get("cloudOperatingSystem");
		 
		List<Order> orderByList = new ArrayList<Order>();
		
		if(!StringUtils.isEmpty(serviceId)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
		} 
		
		if(!StringUtils.isEmpty(operatingSystemId)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithOperatingSystem.get("id"), operatingSystemId));
		}
		
		if(!StringUtils.isEmpty(status)) {
			Expression<String>  rootStatus = rootBase.get("status");
			predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), status.toLowerCase()));
		}
		 
		if (!StringUtils.isEmpty(flavorCategory)) {
			Expression<String>  rootCategory = rootBase.get("flavorCategory");
			predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootCategory), flavorCategory.toLowerCase()));
		}
		
		if (!StringUtils.isEmpty(locationId)) {
			predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithLocation.get("id"), locationId));
		}
		
		criteriaQuery.where(predicate);
		
		orderByList.add(criteriaBuilder.asc(rootBase.get("id")));
		criteriaQuery.orderBy(orderByList);
		
		list =entityManager.createQuery(criteriaQuery).getResultList();
		return list;
	  }
	 
  public List<Object[]> findPlansSummary(Long serviceId) {
	TypedQuery<Object[]> query = entityManager.createNamedQuery("CloudProductPlan.findSummary", Object[].class);
	query.setParameter("serviceId", serviceId);
	return query.getResultList();
  }
  
  public <T extends CloudProductPlan> Collection<T> bulkSave(Collection<T> entities) {
	  final List<T> savedEntities = new ArrayList<T>(entities.size());
	  int i = 0;
	  for (T t : entities) {
	    savedEntities.add(persistOrMerge(t));
	    i++;
	    if (i % 1000 == 0) {
	      // Flush a batch of inserts and release memory.
	      entityManager.flush();
	      entityManager.clear();
	    }
	  }
	  return savedEntities;
	}
	 
	private <T extends CloudProductPlan> T persistOrMerge(T t) {
	  if (t.getId() == null) {
	    entityManager.persist(t);
	    return t;
	  } else {
	    return entityManager.merge(t);
	  }
	}
	 
}
