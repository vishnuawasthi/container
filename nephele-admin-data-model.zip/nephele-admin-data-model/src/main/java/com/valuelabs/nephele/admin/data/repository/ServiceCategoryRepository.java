package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.ServiceCategory;

public interface ServiceCategoryRepository  extends TableRepository<ServiceCategory, Long>, JpaSpecificationExecutor<ServiceCategory> {
	
	@Query("SELECT sc FROM  ServiceCategory sc WHERE sc.name = :name") 
	public ServiceCategory findByCategoryName(@Param("name") String name);

}
