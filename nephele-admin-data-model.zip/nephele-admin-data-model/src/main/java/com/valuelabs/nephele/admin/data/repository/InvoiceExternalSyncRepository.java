package com.valuelabs.nephele.admin.data.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.DbsSyncStatus;
import com.valuelabs.nephele.admin.data.entity.InvoiceExternalSync;


public interface InvoiceExternalSyncRepository extends TableRepository<InvoiceExternalSync, String>, JpaSpecificationExecutor<InvoiceExternalSync> {

  @Query("from InvoiceExternalSync where invoiceNumber in :invoiceNumberSet")
  List<InvoiceExternalSync> loadByInvoiceNumberSet(@Param("invoiceNumberSet") Set<String> invoiceNumberSet);

  @Query("from InvoiceExternalSync where status <> :status")
  List<InvoiceExternalSync> loadByInvoiceStatus(@Param("status") DbsSyncStatus status);
}
