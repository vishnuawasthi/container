package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.DbsSyncStatus;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Entity
@Table(name = "invoice_external_sync")
public class InvoiceExternalSync extends AbstractAuditEntity implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -1162466511734827835L;

	@Id
	@Column(name = "invoice_number")
	private String invoiceNumber;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private DbsSyncStatus status;

	@Column(name = "request_payload",columnDefinition = "TEXT")
	private String request;

	@Column(name = "response_payload",columnDefinition = "TEXT")
	private String response;

  @Column(name = "error_message")
  private String errorMessage;


}
