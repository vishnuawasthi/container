package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudService;

public interface CloudServiceRepository extends TableRepository<CloudService, Long>, JpaSpecificationExecutor<CloudService>{

	@Query("SELECT cs FROM  CloudService cs WHERE cs.name = :name") 
	public CloudService findByName(@Param("name") String name);
	
	/*@Query("SELECT cs FROM  CloudService cs WHERE cs.serviceCode = :serviceCode")
	public CloudService findByServiceCode(@Param("serviceCode") String serviceCode);*/
	
	@Query("SELECT cs FROM  CloudService cs WHERE cs.integrationCode = :integrationCode")
	public CloudService findByIntegrationCode(@Param("integrationCode") String integrationCode);
	
	@Query(" FROM CloudService cs WHERE cs.isPublished = true")
	public List<CloudService> findByActiveServices();
	
	@Query("SELECT count(isPublished) FROM CloudService WHERE isPublished = true")
	public Object getCount();
	
	@Query("SELECT cs FROM  CloudService cs")
	public CloudService getCount2();
}
