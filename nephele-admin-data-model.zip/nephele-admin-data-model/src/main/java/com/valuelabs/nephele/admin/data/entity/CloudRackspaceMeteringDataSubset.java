package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.csv.CsvEntry;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@ToString
public class CloudRackspaceMeteringDataSubset extends AbstractAuditEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "RES_ID")
	@CsvEntry(header = "RES_ID")
	private String RES_ID;
	
	@Column(name = "SERVICE_TYPE")
	@CsvEntry(header = "SERVICE_TYPE")
	private String SERVICE_TYPE;
	
	@Column(name = "QUANTITY")
	@CsvEntry(header = "QUANTITY")
	private Double QUANTITY;
	
	@Column(name = "ATTRIBUTE_1")
	@CsvEntry(header = "ATTRIBUTE_1")
	private String ATTRIBUTE_1;
	
}
