package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudManagerAppPermission;
import com.valuelabs.nephele.admin.data.entity.CloudUserRole;

public class CloudManagerAppPermissionSpecifications {
  public static Specification<CloudManagerAppPermission> findRoleId(final Long roleId){
	
	return new Specification<CloudManagerAppPermission>() {
	  @Override
      public Predicate toPredicate(Root<CloudManagerAppPermission> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
		Join<CloudManagerAppPermission, CloudUserRole> rootWithRole = root.join("cloudUserRole");
		Predicate predicate = criteriaBuilder.conjunction();
		
		if(!StringUtils.isEmpty(roleId)) {
			 predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithRole.get("roleId"), roleId));
		}	
	    return predicate;
      }
	
  };
}
  
  public static Sort sortByIdAsc() {
    return new Sort(Sort.Direction.ASC, "id");
}

/**
* Returns a new object which specifies the the wanted result page.
* @param pageIndex The index of the wanted result page
* @return
*/
public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
    Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
    return pageSpecification;
}
}
