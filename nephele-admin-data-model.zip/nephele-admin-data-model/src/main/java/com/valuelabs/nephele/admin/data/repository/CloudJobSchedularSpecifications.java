package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public class CloudJobSchedularSpecifications {
	
	public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
        return pageSpecification;
 }
	
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }

}
