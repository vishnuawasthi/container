package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import java.io.Serializable;

@AllArgsConstructor
@Builder
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class RackspaceComputePriceExportData implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name = "SERVICE_ID")
	private Long SERVICE_ID;
	
	@Column(name = "SERVICE")
	private String SERVICE;
	
	@Column(name = "CLOUD_OPERATING_SYSTEM_ID")
	private Long CLOUD_OPERATING_SYSTEM_ID;
	
	@Column(name = "VENDOR_IMAGE_ID")
	private String VENDOR_IMAGE_ID;
	
	@Column(name = "VENDOR_IMAGE_NAME")
	private String VENDOR_IMAGE_NAME;
	
	@Column(name = "CLOUD_RACKSPACE_CONFIGURATION_ID")
	private Long CLOUD_RACKSPACE_CONFIGURATION_ID;
	
	@Column(name = "VENDOR_FLAVOR_ID")
	private String VENDOR_FLAVOR_ID;
	
	@Column(name = "VENDOR_FLAVOR_CLASS")
	private String VENDOR_FLAVOR_CLASS;
	
	@Column(name = "VENDOR_FLAVOR_STATUS")
	private String VENDOR_FLAVOR_STATUS;
	
	@Column(name = "VENDOR_FLAVOR_NAME")
	private String VENDOR_FLAVOR_NAME;
	
	@Column(name = "VENDOR_RAM")
	private Long VENDOR_RAM;
	
	@Column(name = "PRICING_UNIT")
	private String PRICING_UNIT;
	
	@Column(name = "CURRENCY")
	private String CURRENCY;
	
	@Column(name = "PRICE")
	private Double PRICE;
	
	public RackspaceComputePriceExportData(){
		
	}
	
	public RackspaceComputePriceExportData(Long SERVICE_ID, String SERVICE, Long CLOUD_OPERATING_SYSTEM_ID, String VENDOR_IMAGE_ID, String VENDOR_IMAGE_NAME, Long CLOUD_RACKSPACE_CONFIGURATION_ID,
			String VENDOR_FLAVOR_ID, String VENDOR_FLAVOR_CLASS, String VENDOR_FLAVOR_NAME, String VENDOR_FLAVOR_STATUS, Long VENDOR_RAM, Double PRICE){
		this.SERVICE_ID = SERVICE_ID;
		this.SERVICE = SERVICE;
		this.CLOUD_OPERATING_SYSTEM_ID = CLOUD_OPERATING_SYSTEM_ID;
		this.VENDOR_IMAGE_ID = VENDOR_IMAGE_ID;
		this.VENDOR_IMAGE_NAME = VENDOR_IMAGE_NAME;
		this.CLOUD_RACKSPACE_CONFIGURATION_ID = CLOUD_RACKSPACE_CONFIGURATION_ID;
		this.VENDOR_FLAVOR_ID = VENDOR_FLAVOR_ID;
		this.VENDOR_FLAVOR_CLASS = VENDOR_FLAVOR_CLASS;
		this.VENDOR_FLAVOR_NAME = VENDOR_FLAVOR_NAME;
		this.VENDOR_FLAVOR_STATUS = VENDOR_FLAVOR_STATUS;
		this.VENDOR_RAM = VENDOR_RAM;
		this.PRICE = PRICE;
	}
	
	public String getSERVICE() {
		return SERVICE;
	}

	public void setSERVICE(String sERVICE) {
		SERVICE = sERVICE;
	}

	public Long getCLOUD_OPERATING_SYSTEM_ID() {
		return CLOUD_OPERATING_SYSTEM_ID;
	}

	public void setCLOUD_OPERATING_SYSTEM_ID(Long cLOUD_OPERATING_SYSTEM_ID) {
		CLOUD_OPERATING_SYSTEM_ID = cLOUD_OPERATING_SYSTEM_ID;
	}

	public String getVENDOR_IMAGE_ID() {
		return VENDOR_IMAGE_ID;
	}

	public void setVENDOR_IMAGE_ID(String vENDOR_IMAGE_ID) {
		VENDOR_IMAGE_ID = vENDOR_IMAGE_ID;
	}

	public String getVENDOR_IMAGE_NAME() {
		return VENDOR_IMAGE_NAME;
	}

	public void setVENDOR_IMAGE_NAME(String vENDOR_IMAGE_NAME) {
		VENDOR_IMAGE_NAME = vENDOR_IMAGE_NAME;
	}

	public Long getCLOUD_RACKSPACE_CONFIGURATION_ID() {
		return CLOUD_RACKSPACE_CONFIGURATION_ID;
	}

	public void setCLOUD_RACKSPACE_CONFIGURATION_ID(
			Long cLOUD_RACKSPACE_CONFIGURATION_ID) {
		CLOUD_RACKSPACE_CONFIGURATION_ID = cLOUD_RACKSPACE_CONFIGURATION_ID;
	}

	public String getVENDOR_FLAVOR_ID() {
		return VENDOR_FLAVOR_ID;
	}

	public void setVENDOR_FLAVOR_ID(String vENDOR_FLAVOR_ID) {
		VENDOR_FLAVOR_ID = vENDOR_FLAVOR_ID;
	}

	public String getVENDOR_FLAVOR_CLASS() {
		return VENDOR_FLAVOR_CLASS;
	}

	public void setVENDOR_FLAVOR_CLASS(String vENDOR_FLAVOR_CLASS) {
		VENDOR_FLAVOR_CLASS = vENDOR_FLAVOR_CLASS;
	}

	public String getVENDOR_FLAVOR_NAME() {
		return VENDOR_FLAVOR_NAME;
	}

	public void setVENDOR_FLAVOR_NAME(String vENDOR_FLAVOR_NAME) {
		VENDOR_FLAVOR_NAME = vENDOR_FLAVOR_NAME;
	}

	public String getPRICING_UNIT() {
		return PRICING_UNIT;
	}

	public void setPRICING_UNIT(String pRICING_UNIT) {
		PRICING_UNIT = pRICING_UNIT;
	}

	public String getCURRENCY() {
		return CURRENCY;
	}

	public void setCURRENCY(String cURRENCY) {
		CURRENCY = cURRENCY;
	}

	public Double getPRICE() {
		return PRICE;
	}

	public void setPRICE(Double pRICE) {
		PRICE = pRICE;
	}

	public Long getSERVICE_ID() {
		return SERVICE_ID;
	}

	public void setSERVICE_ID(Long sERVICE_ID) {
		SERVICE_ID = sERVICE_ID;
	}

	public String getVENDOR_FLAVOR_STATUS() {
		return VENDOR_FLAVOR_STATUS;
	}

	public void setVENDOR_FLAVOR_STATUS(String vENDOR_FLAVOR_STATUS) {
		VENDOR_FLAVOR_STATUS = vENDOR_FLAVOR_STATUS;
	}

	public Long getVENDOR_RAM() {
		return VENDOR_RAM;
	}

	public void setVENDOR_RAM(Long vENDOR_RAM) {
		VENDOR_RAM = vENDOR_RAM;
	}
	
	
}
