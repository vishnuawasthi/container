package com.valuelabs.nephele.admin.data.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudPayment;

public interface CloudPaymentRepository extends TableRepository<CloudPayment, Long>, JpaSpecificationExecutor<CloudPayment>{

  @Query("from CloudPayment where transactionId in :transactionIdSet")
  List<CloudPayment> loadCloudPaymentByPaymentId(@Param("transactionIdSet") Set<String> transactionIdSet);

}
