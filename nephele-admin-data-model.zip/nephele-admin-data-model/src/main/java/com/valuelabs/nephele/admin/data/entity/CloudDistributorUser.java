package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@NamedQueries({
    @NamedQuery(name = "CloudDistributorUser.findUserByUserName", query = "FROM  CloudDistributorUser WHERE email = :email AND isEnabled =:isEnabled")
    , @NamedQuery(name = "CloudDistributorUser.findUserByPswdToken", query = "FROM  CloudDistributorUser WHERE passwordResetToken = :passwordResetToken")
    , @NamedQuery(name = "CloudDistributorUser.findUserByFirstName", query = "FROM  CloudDistributorUser WHERE firstName = :firstName")
    , @NamedQuery(name = "CloudDistributorUser.findUserByLastName", query = "FROM  CloudDistributorUser WHERE lastName = :lastName")
    , @NamedQuery(name = "CloudDistributorUser.findUserByEmail", query = "FROM  CloudDistributorUser WHERE email = :email AND isEnabled =:isEnabled")
    , @NamedQuery(name = "CloudDistributorUser.findUserByApiKey", query = "FROM  CloudDistributorUser WHERE apiKey = :apiKey")
})

//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_distributor_user_seq", sequenceName = "cloud_distributor_user_seq", initialValue = 1)
@Builder
@Table(name = "cloud_distributor_user")
public class CloudDistributorUser extends AbstractAuditEntity implements Serializable //extends CloudUserType 
{
  /**
   *
   */
  private static final long serialVersionUID = 747647436216810531L;

  @Id
  @GeneratedValue(generator = "cloud_distributor_user_seq")
  @Column(name = "DISTRIBUTOR_ID")
  private Long distributorId;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "email", unique = true)
  private String email;
  
  @Column(name = "isEnabled",nullable = true)
  private Boolean isEnabled;

  @Column(name = "password", nullable = true)
  private String password;
  

  @ManyToOne
  @JoinColumn(name = "ROLE_ID")
  private CloudUserRole userRole;

  @Column(name = "password_reset_token")
  private String passwordResetToken;

  @Column(name = "password_reset_expiration_time")
  private Date pswdResetExpireTime;

  @Column(name = "last_login_time")
  private Date lastLoginTime;

  @Column(name = "last_logout_time")
  private Date lastLogoutTime;

  @Column(name = "api_key")
  private String apiKey;

  @Column(name = "api_key_expire_time")
  private Date apiKeyExpireTime;

}