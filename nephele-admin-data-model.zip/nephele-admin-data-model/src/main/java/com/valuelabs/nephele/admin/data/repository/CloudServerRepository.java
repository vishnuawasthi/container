package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudServer;

public interface CloudServerRepository extends TableRepository<CloudServer, Long>, JpaSpecificationExecutor<CloudServer>{

	@Query("SELECT cs FROM  CloudServer cs WHERE cs.cspServerId =:cspServerId ORDER BY cs.id ASC") 
	public CloudServer getServerByCspServerId(@Param("cspServerId") String cspServerId);
	
	@Query("SELECT cs FROM  CloudServer cs WHERE cs.name =:name  ORDER BY cs.id ASC")
	public CloudServer getServerByName(@Param("name") String serverName);
	
	@Query("SELECT status,count(status) FROM  CloudServer cs WHERE cs.cloudCustomerCompany.customerCompanyCode =:customerCode  AND cs.cloudService.id =:serviceId " 
			+ "GROUP BY status")
	public List<Object[]>  findServerSummaryByCustomerCode(@Param("customerCode") String customerCode,@Param("serviceId") Long serviceId);
	
	@Query("SELECT  status, count(id) FROM  CloudServer cs WHERE cs.cloudCustomerCompany.cloudResellerCompany.resellerCompanyCode = :resellerCode  AND cs.cloudService.id =:serviceId GROUP BY status")
	public List<Object[]> findServerSummaryByResellerCode(@Param("resellerCode") String resellerCode ,@Param("serviceId") Long serviceId);
	
	@Query("SELECT  status, count(id) FROM  CloudServer cs WHERE cs.cloudCustomerCompany.cloudResellerCompany.resellerCompanyCode = :resellerCode"
			+ " AND cs.cloudCustomerCompany.customerCompanyCode  =:externalCustomerCode  AND cs.cloudService.id =:serviceId  GROUP BY status")
	public List<Object[]> findServerSummaryByFilter(@Param("resellerCode") String resellerCode, @Param("externalCustomerCode") String externalCustomerCode, @Param("serviceId") Long serviceId);
	
	@Query("SELECT cs FROM  CloudServer cs WHERE cs.cloudCustomerCompany.id =:customerId AND status != 'TERMINATED'  ORDER BY cs.id ASC ")
	public List<CloudServer> findServerByCustomerId(@Param("customerId") Long customerId);
	
	@Query("SELECT cs FROM  CloudServer cs WHERE cs.cloudOrder.id =:orderId ORDER BY cs.id ASC")
	public List<CloudServer> findServerByOrderId(@Param("orderId") Long orderId);
	
	@Query("SELECT cs FROM  CloudServer cs WHERE status != 'TERMINATED'")
	public List<CloudServer> findAllServers();
	
	@Query("SELECT cs FROM  CloudServer cs WHERE cs.id in (:serversId)  ORDER BY cs.id ASC")
	public List<CloudServer> findStatusByServersId(@Param("serversId") List<Long> serversId);
	
	
}
