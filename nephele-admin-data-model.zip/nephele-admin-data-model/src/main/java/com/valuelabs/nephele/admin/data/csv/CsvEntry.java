package com.valuelabs.nephele.admin.data.csv;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * An annotation to supply Class/CSV record metadata.
 * 
 * @author Srinivas Ch, ValueLabs
 * @version 1.0.0
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ java.lang.annotation.ElementType.FIELD })
public @interface CsvEntry {

  /** The default position. */
  int DEFAULT_POSITION = -1;

  /**
   * The header in the CSV file. The default is an empty string.
   */
  String header() default EMPTY;

  /**
   * The position in the CSV file. The default is the static value -1.
   */
  int position() default DEFAULT_POSITION;

  /**
   * The format in the CSV file. The default is an empty string.
   */
  String format() default EMPTY;

  /**
   * Whether it is optional or not. The default is false.
   */
  boolean optional() default true;

  /**
   * Whether it is to be ignored or not. The default is false.
   */
  boolean ignore() default false;

  /**
   * Default value. The default is an empty string.
   */
  String defaultValue() default EMPTY;

  /**
   * The data length will be trimmed to the specified max length while parsing. This is only applicable for String
   * types. if the value is set to '0' or left default then No trimming will be imposed.
   * 
   * @return max length.
   */
  int maxLength() default 0;
}
