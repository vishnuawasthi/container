package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudResellerDiscountPlanType;

public interface CloudResellerDiscountPlanTypeRepository extends TableRepository<CloudResellerDiscountPlanType, Long> {
	
	@Query("from CloudResellerDiscountPlanType where typeName = :type")
	public CloudResellerDiscountPlanType byType(@Param("type") String type);	
}
