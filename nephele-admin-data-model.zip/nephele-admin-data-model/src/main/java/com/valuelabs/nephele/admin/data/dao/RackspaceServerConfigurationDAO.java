package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.RackspaceServerConfiguration;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class RackspaceServerConfigurationDAO extends AbstractJpaDAO<RackspaceServerConfiguration> {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public RackspaceServerConfigurationDAO() {
		setClazz(RackspaceServerConfiguration.class);
	}
	
	public List<RackspaceServerConfiguration> getConfigurationByCloudServerIdNFlag(Long cloudServerId, Boolean isActive){
		
		TypedQuery<RackspaceServerConfiguration> query =
				entityManager.createNamedQuery("Configuration.findByCloudServerIdNActiveFlag", RackspaceServerConfiguration.class).
									setParameter("cloudServerId", cloudServerId)
									.setParameter("isActive", isActive);
		
		return query.getResultList();
		
	}
}
