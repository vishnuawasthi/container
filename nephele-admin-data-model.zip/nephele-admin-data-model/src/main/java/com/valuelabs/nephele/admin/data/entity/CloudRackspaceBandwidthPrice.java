package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NamedQuery(name = "BandwidthPrice.byResourceIdAndUnit", query = "SELECT bp FROM CloudRackspaceBandwidthPrice bp where bp.resourceId = :resourceId AND bp.pricingUnit = :pricingUnit "
		+ "AND bp.cloudService.id = :serviceId")
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name="cloud_rackspace_bandwidth_price_seq",sequenceName="cloud_rackspace_bandwidth_price_seq",initialValue=1)
//@EqualsAndHashCode(callSuper = false)
@ToString
@Entity
@Table(name = "cloud_rackspace_bandwidth_price")
public class CloudRackspaceBandwidthPrice extends AbstractAuditEntity implements Serializable {
	private static final long serialVersionUID = 7134383092451105658L;

	@Id
    @GeneratedValue(generator="cloud_rackspace_bandwidth_price_seq")
    @Column(name = "cloud_rackspace_bandwidth_price_id", nullable = false)
	private Long id;
	
	@Column(name = "RESOURCE_ID", nullable = false)
	private String resourceId;
	
	@Column(name = "NAME")
	private String name;
		
	@Column(name = "PRICING_UNIT", nullable = false)
	private String pricingUnit;
	
	@Column(name = "PRICE", nullable = false)
	private Double price;
	
	@Column(name = "CURRENCY")
	private String currency;
	
	@Column(name="RESOURCE_TYPE")
	private String resourceType;
	
	@ManyToOne
	@JoinColumn(name = "cloud_service_id" , nullable=false)
	private CloudService cloudService;
	
}
