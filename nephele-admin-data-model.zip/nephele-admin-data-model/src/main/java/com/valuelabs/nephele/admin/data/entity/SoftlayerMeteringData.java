package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.GregorianCalendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Accessors(chain = true)
@SequenceGenerator(name = "softlayer_metering_data_seq", sequenceName = "softlayer_metering_data_seq", initialValue = 1)
@Entity
@Table(name = "softlayer_metering_data")
public class SoftlayerMeteringData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "softlayer_metering_data_seq")
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "ACCOUNT_ID")
	private Long accountId;

	@Column(name = "ADDRESS1")
	private String address1;

	@Column(name = "CITY")
	private String city;

	@Column(name = "CLAIMED_TAX_EXEMPT_TXFLAG")
	private Boolean claimedTaxExemptTxFlag;

	@Column(name = "CLOSED_DATE")
	private GregorianCalendar closedDate;

	@Column(name = "COMPANY_NAME")
	private String companyName;

	@Column(name = "COUNTRY")
	private String country;

	@Column(name = "CREATE_DATE")
	private GregorianCalendar createDate;

	@Column(name = "DOCUMENTS_GENERATED_FLAG")
	private Boolean documentsGeneratedFlag;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "ENDING_BALANCE")
	private BigDecimal endingBalance;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "MODIFY_DATE")
	private GregorianCalendar modifyDate;

	@Column(name = "OFFICE_PHONE")
	private String officePhone;

	@Column(name = "POSTAL_CODE")
	private String postalCode;

	@Column(name = "STATE")
	private String state;

	@Column(name = "STATUS_CODE")
	private String statusCode;

	@Column(name = "TAX_STATUS_ID")
	private Long taxStatusId;

	@Column(name = "TAX_TYPE_ID")
	private Long taxTypeId;

	@Column(name = "TYPE_CODE")
	private String typeCode;

}
