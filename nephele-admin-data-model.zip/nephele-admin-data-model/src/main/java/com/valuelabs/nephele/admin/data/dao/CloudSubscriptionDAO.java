package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudSubscription;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudSubscriptionDAO extends AbstractJpaDAO<CloudSubscription> {

	public CloudSubscriptionDAO(){
		
		setClazz(CloudSubscription.class);
	}
}
