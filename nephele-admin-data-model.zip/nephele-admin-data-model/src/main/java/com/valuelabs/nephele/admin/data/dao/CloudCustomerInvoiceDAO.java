package com.valuelabs.nephele.admin.data.dao;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerInvoice;
import com.valuelabs.nephele.admin.data.entity.CloudRackspaceUsageData;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import com.valuelabs.nephele.admin.data.api.InvoiceStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Repository
public class CloudCustomerInvoiceDAO extends AbstractJpaDAO<CloudCustomerInvoice> {

  @Autowired
  private EntityManager entityManager;

  public CloudCustomerInvoiceDAO() {
    setClazz(CloudCustomerInvoice.class);
  }

  /**
   * Save the Invoice Lines into the CLOUD_CUSTOMER_INVOICE & CLOUD_CUSTOMER_INVOICE_LINES tables
   * Updates Cloud Usage Data Status as COMPLETED after successful invoice creation
   *
   * @param cloudCustomerInvoice  - Cloud Customer Invoice Object for saving into Database
   * @param usageDataList - List of <code>CloudRackspaceUsageData</code>  object needs to updated
   */
  @Transactional
  public void createInvoiceAndUpdateUsageDataStatus(CloudCustomerInvoice cloudCustomerInvoice, List<CloudRackspaceUsageData> usageDataList) {
      create(cloudCustomerInvoice);
      if (null != usageDataList && !usageDataList.isEmpty()) {
        for (CloudRackspaceUsageData usageData : usageDataList)
          entityManager.merge(usageData);
      }
  }

	public List<CloudCustomerInvoice> getCustomerInvoiceLineByStatus(String statusValue) {

		TypedQuery<CloudCustomerInvoice> query = entityManager.createNamedQuery("CloudCustomerInvoice.findBystatus",
						CloudCustomerInvoice.class).setParameter("status",	InvoiceStatus.valueOf(statusValue));
		return query.getResultList();

	}

	public List<CloudCustomerInvoice> getCustomerInvoiceLineBycustId(
			Long customerId) {
		TypedQuery<CloudCustomerInvoice> query = entityManager.createNamedQuery("CloudCustomerInvoice.findByCustId",
						CloudCustomerInvoice.class).setParameter("customerId", customerId);
		return query.getResultList();

	}

	public List<CloudCustomerInvoice> getCustomerInvoiceLineByDates(Date fromDate, Date toDate) {

		TypedQuery<CloudCustomerInvoice> query = entityManager.createNamedQuery("CloudCustomerInvoice.findByDates", CloudCustomerInvoice.class)
				.setParameter("fromDate", getFormattedDate(fromDate),TemporalType.TIMESTAMP)
				.setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP);
		return query.getResultList();

	}

	public List<CloudCustomerInvoice> getCustomerInvoiceLineByDatesAndStatus(
			Date fromDate, Date toDate, String status) {

		TypedQuery<CloudCustomerInvoice> query = entityManager
				.createNamedQuery("CloudCustomerInvoice.findByDatesAndStatus",
						CloudCustomerInvoice.class)
				.setParameter("fromDate", getFormattedDate(fromDate),
						TemporalType.TIMESTAMP)
				.setParameter("toDate", getFormattedDate(toDate),
						TemporalType.TIMESTAMP)
				.setParameter("status", InvoiceStatus.valueOf(status));
		return query.getResultList();

	}

	private Date getFormattedDate(Date givenDate) {
		Timestamp dateTimeValue = null;
		try {
			if (null != givenDate) {
				SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy-MM-DD HH:mm:ss z");
				Date date = timeStampFormat.parse(timeStampFormat.format(givenDate));
				dateTimeValue = new java.sql.Timestamp(date.getTime());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateTimeValue;
	}
}