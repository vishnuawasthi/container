package com.valuelabs.nephele.admin.data.api;

public enum ResourceType {
	FLAVOR,
	BANDWIDTH_OUT,
	BANDWIDTH_IN;
}
