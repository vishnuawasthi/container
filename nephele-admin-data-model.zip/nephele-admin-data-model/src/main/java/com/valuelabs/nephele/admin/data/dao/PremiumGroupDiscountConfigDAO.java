package com.valuelabs.nephele.admin.data.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementConfig;
import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountConfig;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

@Repository
public class PremiumGroupDiscountConfigDAO extends AbstractJpaDAO<PremiumGroupDiscountConfig> {

	@PersistenceContext
	EntityManager entityManager;
	
	public PremiumGroupDiscountConfigDAO() {
		setClazz(PremiumGroupDiscountConfig.class);
	}

	public List<PremiumGroupDiscountConfig> getPremiumGroupDiscountConfigsBySheetNameAndStatusAndActiveDateRanges(String SheetName, String status,
			  String activeFrom, String activeTo) {

		
		List<PremiumGroupDiscountConfig> list =   null;
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PremiumGroupDiscountConfig> criteriaQuery = criteriaBuilder.createQuery(PremiumGroupDiscountConfig.class);
		Root<PremiumGroupDiscountConfig> rootBase = criteriaQuery.from(PremiumGroupDiscountConfig.class);
		Predicate predicate = criteriaBuilder.conjunction();		
		List<Order> orderList = new ArrayList<Order>();		 
		
		if(!StringUtils.isEmpty(SheetName)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("discountSheetName"), SheetName));
		}
		if (!StringUtils.isEmpty(status)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("status"), ChangeManagementConfigStatus.valueOf(status)));
			  
		}
		if ( !StringUtils.isEmpty(activeFrom) && !StringUtils.isEmpty(activeTo)) {
			Expression<Date>  rootCategory = rootBase.get("activeTo");  
		    predicate = criteriaBuilder.and(predicate,criteriaBuilder.greaterThanOrEqualTo(rootCategory, DateFormatterUtility.formatStringToDate(activeFrom)));		    
		    predicate = criteriaBuilder.and(predicate,criteriaBuilder.lessThanOrEqualTo(rootCategory, DateFormatterUtility.formatStringToDate(activeTo)));
		}		
		criteriaQuery.where(predicate);			
		list =entityManager.createQuery(criteriaQuery).getResultList();
		return list;
	  }
	// this method is used for find records with statusList like status in "DRAFT and SCHEDULED"
	public List<PremiumGroupDiscountConfig> findByServiceIdandStatus(Long serviceId, List<ChangeManagementConfigStatus> statusList) {
	    TypedQuery<PremiumGroupDiscountConfig> query = entityManager.createNamedQuery("premiumDiscountConfig.findByServiceIdandDraftScheduledStatus", PremiumGroupDiscountConfig.class)
	    		.setParameter("serviceId", serviceId)
	    		.setParameter("statusList", statusList);
	    return query.getResultList();
    }
	
	public List<PremiumGroupDiscountConfig> findByServiceIdandStatus(Long serviceId, String status) {
	    TypedQuery<PremiumGroupDiscountConfig> query = entityManager.createNamedQuery("premiumDiscountConfig.findByServiceIdandStatus", PremiumGroupDiscountConfig.class)
	    		.setParameter("serviceId", serviceId)
	    		.setParameter("status", ChangeManagementConfigStatus.valueOf(status));
	    return query.getResultList();
    }
	
	public List<PremiumGroupDiscountConfig> findBySheetName(String sheetName) {
	    TypedQuery<PremiumGroupDiscountConfig> query = entityManager.createNamedQuery("premiumDiscountConfig.findBySheetName", PremiumGroupDiscountConfig.class)
	    		.setParameter("sheetName", sheetName);	    		
	    return query.getResultList();
    }	
	
	  
	
}
