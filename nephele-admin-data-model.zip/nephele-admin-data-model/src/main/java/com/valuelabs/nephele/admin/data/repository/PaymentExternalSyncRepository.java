package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.DbsSyncStatus;
import com.valuelabs.nephele.admin.data.entity.PaymentExternalSync;


public interface PaymentExternalSyncRepository extends TableRepository<PaymentExternalSync, String>, JpaSpecificationExecutor<PaymentExternalSync> {

	@Query("FROM PaymentExternalSync where paymentId= :paymentId")
  PaymentExternalSync getPaymentByPaymentId(@Param("paymentId") String paymentId);

  @Query("FROM PaymentExternalSync where status <> :status")
  List<PaymentExternalSync> loadNonSyncRecord(@Param("status") DbsSyncStatus status);

}
