package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.valuelabs.nephele.admin.data.entity.BundleCloudProduct;

public interface BundleCloudProductRepository extends TableRepository<BundleCloudProduct, Long>, JpaSpecificationExecutor<BundleCloudProduct> {
	
	@Modifying
    @Transactional
    @Query("delete from BundleCloudProduct rcp where rcp.bundle.id = ?1")
    void deleteByBundleId(Long bundleId);

}
