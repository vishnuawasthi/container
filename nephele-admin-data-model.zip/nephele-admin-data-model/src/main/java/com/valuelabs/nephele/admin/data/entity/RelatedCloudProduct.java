package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name="related_cloud_product_seq",sequenceName="related_cloud_product_seq",initialValue=1)
@Entity
@Table(name="related_cloud_product")
public class RelatedCloudProduct extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = 7134383092451105658L;

	@Id
    @GeneratedValue(generator="related_cloud_product_seq")
    @Column(name = "id", nullable = false)
	private Long id;	
	
	@ManyToOne
    @JoinColumn(name = "cloud_product_id") 
    private CloudProduct cloudProduct;
	
	@ManyToOne
    @JoinColumn(name = "related_cloud_product_id") 
    private CloudProduct relatedCloudProduct;
	
}
