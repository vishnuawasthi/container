package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.google.common.base.Strings;
import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementConfig;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementSheet;
import com.valuelabs.nephele.admin.data.entity.CloudService;

public class CloudProductPriceManagementSheetSpecifications {
	
	
	 public static Specification<CloudProductPriceManagementSheet> findBySheetNameOrStatus(final String sheetName, final ChangeManagementConfigStatus status, final Long serviceId){
		 
		  return new Specification<CloudProductPriceManagementSheet>(){
			
			@Override
			public Predicate toPredicate(Root<CloudProductPriceManagementSheet> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
							
				Predicate predicate = criteriaBuilder.conjunction();	
				
				Join<CloudProductPriceManagementSheet, CloudProductPriceManagementConfig> rootWithConfig = root.join("priceManagementConfig");
				Join<CloudProductPriceManagementConfig, CloudService> rootWithService = rootWithConfig.join("cloudService");
				
				if(!Strings.isNullOrEmpty(sheetName)) {
					predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithConfig.get("priceSheetName"), sheetName));
				}
				
				if(status != null) {
					 predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithConfig.get("status"), status));
				}
				if(!StringUtils.isEmpty(serviceId)){
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}
				
				
				
		  		return predicate;
			}
		};
	 }
	
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }

}
