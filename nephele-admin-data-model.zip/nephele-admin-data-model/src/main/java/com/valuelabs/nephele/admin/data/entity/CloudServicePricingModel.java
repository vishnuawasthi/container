package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_service_pricing_model_seq", sequenceName="cloud_service_pricing_model_seq", initialValue=1)
@Entity
@Setter
@Getter
@Table(name="cloud_service_pricing_model")
public class CloudServicePricingModel extends AbstractAuditEntity implements Serializable{
	
	private static final long serialVersionUID = -3287705489559552723L;

	@Id
    @GeneratedValue(generator="cloud_service_pricing_model_seq")
    @Column(name = "cloud_service_pricing_model_id", nullable = false)
	private Long id;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	/*@OneToMany(mappedBy="cloudServicePricingModel")
    private Set<CloudService> cloudServices = new HashSet<CloudService>();*/
}
