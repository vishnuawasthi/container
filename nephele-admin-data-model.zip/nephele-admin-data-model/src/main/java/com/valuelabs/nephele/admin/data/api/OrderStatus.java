package com.valuelabs.nephele.admin.data.api;

public enum OrderStatus {
	RECEIVED,
	INPROGRESS,
	COMPLETED,
	FAILED,
	PARTIALLY_COMPLETED;
}
