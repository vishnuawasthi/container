package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_configuration_type_seq",sequenceName="cloud_configuration_type_seq",initialValue=1)
@Entity
@Table(name="cloud_configuration_type")
public class CloudConfigurationType extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = -8201744599762098687L;

	@Id
    @GeneratedValue(generator="cloud_configuration_type_seq")
    @Column(name = "cloud_configuration_type_id", nullable = false)
	private Long id;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "description", nullable = false)
	private String description;
	
	/*@OneToMany(mappedBy="cloudConfigurationType")
    private Set<CloudRackspaceConfiguration> cloudRackspaceConfigurations = new HashSet<CloudRackspaceConfiguration>();*/
	
}
