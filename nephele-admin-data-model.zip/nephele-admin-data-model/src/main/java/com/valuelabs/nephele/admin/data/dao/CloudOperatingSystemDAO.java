package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudOperatingSystem;
import com.valuelabs.nephele.admin.data.entity.RackspaceComputePriceExportData;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudOperatingSystemDAO extends AbstractJpaDAO<CloudOperatingSystem>{

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudOperatingSystemDAO() {
		setClazz(CloudOperatingSystem.class );
	}
	
	public List<CloudOperatingSystem> getByService(Long serviceId) {
		
		TypedQuery<CloudOperatingSystem> query =
				entityManager.createNamedQuery("OperatingSystem.getByService", CloudOperatingSystem.class).
							  setParameter("serviceId", serviceId);
		
		return query.getResultList();
		
	}

	public List<CloudOperatingSystem> getByServiceAndStatus(Long serviceId, String status) {
		
		TypedQuery<CloudOperatingSystem> query =
				entityManager.createNamedQuery("OperatingSystem.getByServiceAndStatus", CloudOperatingSystem.class).
							  setParameter("serviceId", serviceId).
							  setParameter("status", status);
		
		return query.getResultList();
	}
	public List<CloudOperatingSystem> findByStatus(String status) {
		TypedQuery<CloudOperatingSystem> query = entityManager.createNamedQuery("OperatingSystem.findByStatus", CloudOperatingSystem.class)
				.setParameter("status", status);
		return query.getResultList();
	}
	
	/*public List<RackspaceComputePriceExportData> getFalvorCombinationsByOSId(Integer osId){
		
		TypedQuery<RackspaceComputePriceExportData> query =
				entityManager.createNamedQuery("OperatingSystem.getOSNConfigByOSId", RackspaceComputePriceExportData.class)
							 .setParameter("osId", osId);
	
		return query.getResultList();	
	}*/
	
	public List<Object[]>  findOperatingSystemSummaryByServiceId(Long serviceId){
		TypedQuery<Object[]> query=entityManager.createNamedQuery("CloudOperatingSystem.findOperatingSystemSummaryByServiceId",Object[].class).setParameter("serviceId", serviceId);
		return query.getResultList();
	}

}
