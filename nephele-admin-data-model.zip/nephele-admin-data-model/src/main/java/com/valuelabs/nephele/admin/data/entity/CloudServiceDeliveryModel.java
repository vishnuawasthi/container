package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@SequenceGenerator(name="cloud_service_delivery_model_seq",sequenceName="cloud_service_delivery_model_seq",initialValue=1)
@Entity
@Table(name="cloud_service_delivery_model")
public class CloudServiceDeliveryModel extends AbstractAuditEntity implements Serializable{
	
	private static final long serialVersionUID = 4211041043862357455L;

	@Id
    @GeneratedValue(generator="cloud_service_delivery_model_seq")
    @Column(name = "cloud_service_delivery_model_id", nullable = false)
	private Long id;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "description", nullable = false)
	private String description;
	
	/*@OneToMany(mappedBy="cloudServiceDeliveryModel")
    private Set<CloudService> cloudServices = new HashSet<CloudService>();*/
}
