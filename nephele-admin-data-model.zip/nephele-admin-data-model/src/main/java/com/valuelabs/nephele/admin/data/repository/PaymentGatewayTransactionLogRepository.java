package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.PaymentGatewayTransactionLog;

/**
 * Created by snagaboina on 30/11/15.
 */
public interface PaymentGatewayTransactionLogRepository extends TableRepository<PaymentGatewayTransactionLog, Long>, JpaSpecificationExecutor<PaymentGatewayTransactionLog> {

  @Query("from PaymentGatewayTransactionLog where pgAuditId = :pgAuditId")
  public List<PaymentGatewayTransactionLog> findTransactionLogByAuditId(@Param("pgAuditId") Long pgAuditId);
}
