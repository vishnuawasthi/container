package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.valuelabs.nephele.admin.data.api.NepheleCurrency;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Builder
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_currency_conversion_rate_seq", sequenceName = "cloud_currency_conversion_rate_seq", initialValue = 1)
@Entity
@Table(name="cloud_currency_conversion_rate",uniqueConstraints=
@UniqueConstraint(columnNames = {"source_currency", "target_currency"}))
public class CloudCurrencyConversionRate extends AbstractAuditEntity implements Serializable {

  
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator="cloud_currency_conversion_rate_seq")
  @Column(name = "cloud_currency_conversion_rate_id", nullable = false)
  private Long id;

  /*@Column(name="status")
  @Enumerated(EnumType.STRING)
  private CurrencyConversionStatus status;
  */
  @Column(name="conversion_rate")
  private Double conversionRate;

 /* @Column(name="active_from")
  private Date activeFrom;
  
  @Column(name="active_to")
  private Date activeTo;*/
  
  @Column(name="source_currency")
  @Enumerated(EnumType.STRING)
  private NepheleCurrency sourceCurrency;
  
  @Column(name="target_currency")
  @Enumerated(EnumType.STRING)
  private NepheleCurrency targetCurrency;
  
 /* @OneToMany(mappedBy = "cloud_currency_conversion_rate_audit")
  private Set<CloudCurrencyConversionRateAudit> cloudCurrencyConversionRateAudit = new HashSet<CloudCurrencyConversionRateAudit>();*/

}
