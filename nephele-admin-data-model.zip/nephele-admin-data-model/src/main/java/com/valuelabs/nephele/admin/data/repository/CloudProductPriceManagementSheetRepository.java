package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementSheet;

public interface CloudProductPriceManagementSheetRepository extends TableRepository<CloudProductPriceManagementSheet, Long>, JpaSpecificationExecutor<CloudProductPriceManagementSheet>{

	@Query("FROM CloudProductPriceManagementSheet pms where pms.cloudProductPlan.id = :planId")
	public List<CloudProductPriceManagementSheet> findByPlanId(@Param("planId") Long planId);
	
	@Query("FROM CloudProductPriceManagementSheet pms where pms.cloudProductPlan.id = :planId AND "
			+ "pms.priceManagementConfig.id = :configId ")
	public List<CloudProductPriceManagementSheet> findByPlanIdNdConfigId(@Param("planId") Long planId, @Param("configId") Long configId);
	
	@Query("FROM CloudProductPriceManagementSheet pms where pms.priceManagementConfig.id = :configId order by "
			+ " pms.cloudProductPlan.cloudProduct.id,pms.cloudProductPlan.flavorCategory,pms.cloudProductPlan.sortKey")	
	public List<CloudProductPriceManagementSheet> findByConfigId(@Param("configId") Long configId);
	
	@Query("FROM  CloudProductPriceManagementSheet pms WHERE pms.priceManagementConfig.priceSheetName = :sheetName")
	 public List<CloudProductPriceManagementSheet> findBySheetName(@Param("sheetName") String sheetName); 
	
	@Query("FROM  CloudProductPriceManagementSheet pms WHERE pms.priceManagementConfig.status = :status")
	public List<CloudProductPriceManagementSheet> findBySheetStatus(@Param("status") ChangeManagementConfigStatus status);

}
