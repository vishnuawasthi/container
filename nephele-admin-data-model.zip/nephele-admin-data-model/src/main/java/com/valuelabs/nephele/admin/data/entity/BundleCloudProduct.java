package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@SequenceGenerator(name = "bundle_cloud_product_seq", sequenceName = "bundle_cloud_product_seq", initialValue = 1)
@Entity
@Table(name = "bundle_cloud_product")
public class BundleCloudProduct extends AbstractAuditEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "bundle_cloud_product_seq")
  @Column(name = "bundle_cloud_product_id")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "bundle_id")
  private Bundle bundle;

  @ManyToOne
  @JoinColumn(name = "cloud_product_id") 
  private CloudProduct cloudProduct;

}
