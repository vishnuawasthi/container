/**
 * 
 */
package com.valuelabs.nephele.admin.data.api;

/**
 * @author btodupunoori
 *
 */
public enum FlavourTypes {
	
	io1,
	standard1,
	general1

}
