package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NamedQuery(name = "ServiceCredentials.findByServiceId", query = " FROM CloudServiceCredential sc where sc.cloudService.id = :cloudServiceId")
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_service_credential_seq", sequenceName="cloud_service_credential_seq",initialValue=1)
@Entity
@Table(name="cloud_service_credential")
public class CloudServiceCredential extends AbstractAuditEntity implements Serializable{
	
	private static final long serialVersionUID = 4211041043862357455L;

	@Id
    @GeneratedValue(generator="cloud_service_credential_seq")
    @Column(name = "cloud_service_credential_id", nullable = false)
	private Long id;
	
	@Column(name = "username", nullable = false)
	private String username;
	
	@Column(name = "apikey", nullable = true)
	private String apikey;
	
	@Column(name = "account_no", nullable = true)
	private String accountNo;
	
	@Column(name = "password", nullable = true)
	private String password;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
    @JoinColumn(name="cloud_service_id",insertable=true,updatable=true,nullable=true,unique=true)
    private CloudService cloudService;
	
}
