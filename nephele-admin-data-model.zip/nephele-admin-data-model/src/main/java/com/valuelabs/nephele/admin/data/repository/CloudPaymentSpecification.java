package com.valuelabs.nephele.admin.data.repository;

import com.valuelabs.nephele.admin.data.common.ReadCloudPayment;
import com.valuelabs.nephele.admin.data.entity.CloudPayment;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by ranjith on 28/12/15.
 */

public class CloudPaymentSpecification {
  public static Specification<CloudPayment> searchPayment(final ReadCloudPayment request) {
    return new Specification<CloudPayment>() {
      @Override
      public Predicate toPredicate(Root<CloudPayment> rootBase, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        Predicate predicate = criteriaBuilder.conjunction();
        if (null != request.getFromDate() && null != request.getToDate())
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(rootBase.<Date>get("created"), getFormattedDate(request.getFromDate()), getFormattedDate(request.getToDate())));
        return predicate;

      }
    };
  }

  private static Date getFormattedDate(Date givenDate) {
    Timestamp dateTimeValue = null;
    try {
      if (null != givenDate) {
        SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy-MM-DD HH:mm:ss z");
        java.util.Date date = timeStampFormat.parse(timeStampFormat.format(givenDate));
        dateTimeValue = new java.sql.Timestamp(date.getTime());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return dateTimeValue;
  }
}
