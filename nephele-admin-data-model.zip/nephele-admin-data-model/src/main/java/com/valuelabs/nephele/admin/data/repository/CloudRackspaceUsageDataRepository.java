package com.valuelabs.nephele.admin.data.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;
import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudRackspaceUsageData;

public interface CloudRackspaceUsageDataRepository  extends TableRepository<CloudRackspaceUsageData, Long>, JpaSpecificationExecutor<CloudRackspaceUsageData>  {

  @Query("SELECT sum(usageQuantity) as NUMBER FROM  CloudRackspaceUsageData  WHERE cloudCustomerCompany in :customerCompanyIdList and resellerInvoiceStatus=:status")
  public Double getRackspaceResellerUsageData(@Param("status") MeteringDataInvoiceStatus status, @Param("customerCompanyIdList") Set<CloudCustomerCompany> customerCompanies);
 
}
