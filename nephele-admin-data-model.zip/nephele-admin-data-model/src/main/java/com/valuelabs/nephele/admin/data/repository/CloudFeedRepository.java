package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudFeed;

public interface CloudFeedRepository extends TableRepository<CloudFeed, Long>, JpaSpecificationExecutor<CloudFeed> {

	
	@Query("FROM  CloudFeed cf WHERE cf.uuid = :uuid") 
	public CloudFeed findByUuid(@Param("uuid") String uuid);
	
	@Query("Select cf from CloudFeed cf order by cf.cloudFeedPublishedDate desc")
	public Page<CloudFeed> findRecentFeed(Pageable pageable);
}
