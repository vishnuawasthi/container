package com.valuelabs.nephele.admin.data.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.valuelabs.nephele.admin.data.entity.CloudResellerDiscountPlanType;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import org.springframework.stereotype.Repository;


@Repository
public class CloudResellerDiscountPlanTypeDAO extends AbstractJpaDAO<CloudResellerDiscountPlanType> {

  @PersistenceContext
  EntityManager entityManager;

  public CloudResellerDiscountPlanTypeDAO() {
    setClazz(CloudResellerDiscountPlanType.class);
  }

  public CloudResellerDiscountPlanType findPlanType(String type) {
    return entityManager.createNamedQuery("CloudResellerDiscountPlanType.byType", CloudResellerDiscountPlanType.class)
        .setParameter("type", type).getSingleResult();
  }
}