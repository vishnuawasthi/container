package com.valuelabs.nephele.admin.data.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.MeteringDataLoadUsers;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class MeteringDataLoadUsersDAO extends AbstractJpaDAO<MeteringDataLoadUsers> {

	@PersistenceContext
	private EntityManager entityManager;

	public MeteringDataLoadUsersDAO() {
		setClazz(MeteringDataLoadUsers.class);
	}
	
	@Transactional
	  public MeteringDataLoadUsers getByUserName(String username) {
		TypedQuery<MeteringDataLoadUsers> query = entityManager.createNamedQuery("MeteringDataLoadUsers.getByUserName" ,MeteringDataLoadUsers.class)
				.setParameter("username", username);
		return query.getSingleResult();
	      }
}
