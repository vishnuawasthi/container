package com.valuelabs.nephele.admin.data.api;

/**
 * Created by btodupunoori.
 */
public enum JobStatus {
  INITIATED,
  INPROGRESS,
  COMPLETED,
  FAILED,
  NOT_YET_INITIATED
}
