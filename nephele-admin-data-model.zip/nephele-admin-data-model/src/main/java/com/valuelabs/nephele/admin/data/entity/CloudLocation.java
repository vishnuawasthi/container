package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.util.StringJsonUserType;
import lombok.*;
import lombok.experimental.Accessors;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.Serializable;

@NamedQueries({
	@NamedQuery(name="CloudLocation.findByStatus",query="SELECT cl FROM  CloudLocation cl WHERE cl.status = :status"),
	@NamedQuery(name="CloudLocation.findByServiceAndStatus",query="SELECT cl FROM  CloudLocation cl WHERE cl.cloudService.id = :serviceId AND cl.status = :status"),
	@NamedQuery(name="CloudLocation.findByServiceLocationCodeAndStatus",query="SELECT cl FROM  CloudLocation cl WHERE cl.cloudService.id = :serviceId "
			+ "AND cl.locationCode = :locationCode AND cl.status = :status"),
	@NamedQuery(name="CloudLocation.findByNameNStatus",query="SELECT cl FROM  CloudLocation cl WHERE cl.name = :name AND cl.status = :status"),
	@NamedQuery(name = "CloudLocation.findLocationSummaryByServiceId", query = "SELECT status,count(status) FROM  CloudLocation cl"
				+" WHERE cl.cloudService.id= :serviceId GROUP BY status")
})
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@SequenceGenerator(name="cloud_location_seq",sequenceName="cloud_location_seq",initialValue=1)
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
@Entity
@Table(name="cloud_location")
public class CloudLocation extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = -5191956038191797063L;

	@Id
    @GeneratedValue(generator="cloud_location_seq")
    @Column(name = "cloud_location_id", nullable = false)
	private Long id;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "location_code", nullable = true)
	private String locationCode;
	
	@Column(name = "currency", nullable = true)
	private String currency;
	
	@Column(name = "status", nullable = false)
	private String status;
	
/*	@Column(name="geography_code")
	private String geographyCode;
	
	@Column(name="geography_name")
	private String geographyName;*/
	
	/*@Type(type = "StringJsonObject")
	@Column(name = "csp_resource", nullable = false)
	private String cspResource;*/
	
	@ManyToOne
    @JoinColumn(name = "cloud_service_id") 
    private CloudService cloudService; 
	
	@ManyToOne
    @JoinColumn(name = "cloud_geography_id") 
	private CloudGeography cloudGeography;
	
	/*@OneToMany(mappedBy="cloudLocation")
	private Set<RackspaceServerConfiguration> rackspaceServerConfigurations=new HashSet<RackspaceServerConfiguration>();*/
	
	/*@OneToMany(mappedBy="cloudLocation")
	private Set<SoftlayerServerConfiguration> softlayerServerServerConfigurations=new HashSet<SoftlayerServerConfiguration>();
	
	@OneToMany(mappedBy="cloudLocation")
	private Set<AzureServerConfiguration> azureServerConfigurations=new HashSet<AzureServerConfiguration>();*/
	
	/*@OneToMany(mappedBy="cloudLocation")
	private Set<CloudServer> cloudServers=new HashSet<CloudServer>();*/
	
	
}
