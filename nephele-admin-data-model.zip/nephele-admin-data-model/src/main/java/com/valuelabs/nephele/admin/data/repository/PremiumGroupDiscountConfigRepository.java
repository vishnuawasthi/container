package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountConfig;

public interface PremiumGroupDiscountConfigRepository extends TableRepository<PremiumGroupDiscountConfig, Long> , JpaSpecificationExecutor<PremiumGroupDiscountConfig>{
	
	@Query("FROM  PremiumGroupDiscountConfig pg WHERE pg.cloudService.id =:serviceId AND pg.status IN :statusList")
	public List<PremiumGroupDiscountConfig> findByServiceIdandStatus(@Param("serviceId") Long serviceId, @Param("statusList") List<ChangeManagementConfigStatus> statusList );
	
	@Query("FROM  PremiumGroupDiscountConfig pg WHERE pg.cloudService.id =:serviceId AND pg.status =:status") 
	public List<PremiumGroupDiscountConfig> findByServiceIdandStatus(@Param("serviceId") Long serviceId, @Param("status") ChangeManagementConfigStatus status );
	
	@Query("Select count(*) FROM  PremiumGroupDiscountConfig pg WHERE pg.cloudService.id =:serviceId AND pg.status =:status") 
	public Long findCountByServiceIdandStatus(@Param("serviceId") Long serviceId, @Param("status") ChangeManagementConfigStatus status );
	
	@Query("FROM  PremiumGroupDiscountConfig pg WHERE pg.discountSheetName =:sheetName") 
	public List<PremiumGroupDiscountConfig> findBySheetName(@Param("sheetName") String sheetName);
	
	@Query("FROM  PremiumGroupDiscountConfig pg WHERE pg.cloudService.id =:serviceId ")
	public List<PremiumGroupDiscountConfig> findByServiceId(@Param("serviceId") Long serviceId);
	
	
	
	
}
