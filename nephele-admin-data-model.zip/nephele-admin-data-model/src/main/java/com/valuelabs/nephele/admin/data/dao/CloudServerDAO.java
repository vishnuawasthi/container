package com.valuelabs.nephele.admin.data.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudOrder;
import com.valuelabs.nephele.admin.data.entity.CloudServer;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

@Repository
public class CloudServerDAO extends AbstractJpaDAO<CloudServer>{

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudServerDAO() {
		setClazz(CloudServer.class );
	}

	public CloudServer getServerByCspServerId(String cspServerId){
		
		TypedQuery<CloudServer> query =
				entityManager.createNamedQuery("Server.findBycspServerId", CloudServer.class).
									setParameter("cspServerId", cspServerId);
		
		return query.getSingleResult();
		
	}
	
	public CloudServer getServerByName(String serverName){
		
		TypedQuery<CloudServer> query =
				entityManager.createNamedQuery("Server.findByName", CloudServer.class).
									setParameter("name", serverName);
		
		return query.getSingleResult();
		
	}
	
	public List<Object[]>  findServerSummaryByCustomerCode(String externalCustomerCode){
		TypedQuery<Object[]> query=entityManager.createNamedQuery("Server.findServerSummaryByCustomerCode",Object[].class).setParameter("customerCode", externalCustomerCode);
		return query.getResultList();
	}
	
  public List<Object[]> findServerSummaryByResellerCode(String resellerCode, String externalCustomerCode) {

	StringBuilder queryBuilder = new StringBuilder(
	    "SELECT  status, count(id) FROM  CloudServer cs WHERE cs.cloudCustomerCompany.cloudResellerCompany.resellerCompanyCode = '"
	        + resellerCode + "'  ");
	if (!StringUtils.isEmpty(externalCustomerCode)) {
	  queryBuilder.append(" AND   cs.cloudCustomerCompany.customerCompanyCode  = '" + externalCustomerCode + "'");
	}
	queryBuilder.append(" GROUP BY status ");
	TypedQuery<Object[]> query = entityManager.createQuery(queryBuilder.toString(), Object[].class);
	return query.getResultList();
  }
	
	public List<CloudServer>  findServerByCustomerId(Long customerId){
		TypedQuery<CloudServer> query =
		entityManager.createNamedQuery("Server.findServerByCustomerId", CloudServer.class).
							setParameter("customerId", customerId);
		return query.getResultList();
	}
	
	public List<CloudServer>  findServerByOrderId(Long orderId){
		TypedQuery<CloudServer> query =
		entityManager.createNamedQuery("Server.findServerByOrderId", CloudServer.class).
							setParameter("orderId", orderId);
		return query.getResultList();
	}
	

	 /** 
	  * This method will return List of results from DB by passing required parameters.
	 * @param status
	 * @param orderId
	 * @param dateRangeStart
	 * @param dateRangeEnd
	 * @param name
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<CloudServer> findServerByStatusOrderIdNameAndDate(String status, Long orderId,String orderCode, Date dateRangeStart,
			 																		 Date dateRangeEnd,String name,String externalCustomerCode, String resellerCode) {	

			
		List<CloudServer> list =   null;
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CloudServer> criteriaQuery = criteriaBuilder.createQuery(CloudServer.class);
		Root<CloudServer> rootBase = criteriaQuery.from(CloudServer.class);
		Predicate predicate = criteriaBuilder.conjunction();
		Join<CloudServer, CloudOrder> rootWithOrder = rootBase.join("cloudOrder");
		
		Join<CloudServer, CloudCustomerCompany> rootWithCustomerCompany= rootBase.join("cloudCustomerCompany");
		
		 Path<Object> rootWithResellerCompany = rootWithCustomerCompany.get("cloudResellerCompany");
		
		List<Order> orderByList = new ArrayList<Order>();
		
		 predicate = criteriaBuilder.and(predicate,criteriaBuilder.notEqual(rootBase.get("status"), "TERMINATED"));
		
		if(!StringUtils.isEmpty(resellerCode)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithResellerCompany.get("resellerCompanyCode"), resellerCode));
		}
		
		if(!StringUtils.isEmpty(externalCustomerCode)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithCustomerCompany.get("customerCompanyCode"), externalCustomerCode));
		}
		
		
		if (!StringUtils.isEmpty(status)) {
			Expression<String>  rootStatus = rootBase.get("status");
			predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), status.toLowerCase()));
		}
		if (!StringUtils.isEmpty(orderId)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithOrder.get("id"), orderId));
			  
		}
		
		if (!StringUtils.isEmpty(orderCode)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithOrder.get("orderCode"), orderCode));
				  
			}
		if (!StringUtils.isEmpty(name)) {
			Expression<String>  rootName = rootBase.get("name");
			  predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootName), name.toLowerCase()));
				  
		}
		if ( !StringUtils.isEmpty(dateRangeStart)) {
			
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(rootBase.<Date>get("created"), dateRangeStart, 
				  DateFormatterUtility.getAfterDate(dateRangeEnd, 23)));
			  
		}
		
				
		criteriaQuery.where(predicate);
		
		orderByList.add(criteriaBuilder.asc(rootBase.get("id")));
		criteriaQuery.orderBy(orderByList);
		
		list =entityManager.createQuery(criteriaQuery).getResultList();
		
		return list;
	}
}
