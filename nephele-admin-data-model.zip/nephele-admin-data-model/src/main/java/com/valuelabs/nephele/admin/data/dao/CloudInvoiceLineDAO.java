package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudResellerInvoiceLine;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
@Repository
public class CloudInvoiceLineDAO extends AbstractJpaDAO<CloudResellerInvoiceLine>{

	public CloudInvoiceLineDAO(){
		setClazz(CloudResellerInvoiceLine.class);
	}
}
