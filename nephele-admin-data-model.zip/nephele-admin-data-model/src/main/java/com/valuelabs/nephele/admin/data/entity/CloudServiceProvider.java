package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_service_provider_seq",sequenceName="cloud_service_provider_seq",initialValue=1)
@Entity
@Table(name="cloud_service_provider")
public class CloudServiceProvider extends AbstractAuditEntity implements Serializable{

	private static final long serialVersionUID = 3888359936096607662L;

	@Id
    @GeneratedValue(generator="cloud_service_provider_seq")
    @Column(name = "cloud_service_provider_id", nullable = false)
	private Long id;
	
	@Column(name = "brand_name", nullable = false,unique=true)
	private String brandName;
	
	@Column(name = "brand_code", nullable = true)
	private String brandCode;
	
	@Column(name = "description", nullable = true)
	private String description;
	
	 @OneToMany(mappedBy="cloudServiceProvider")
    private Set<CloudService> cloudServices = new HashSet<CloudService>();
	
}
