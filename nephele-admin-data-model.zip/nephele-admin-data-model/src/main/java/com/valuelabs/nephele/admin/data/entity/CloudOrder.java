package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.valuelabs.nephele.admin.data.util.StringJsonUserType;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_order_seq",sequenceName="cloud_order_seq",initialValue=1)
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
@Entity
@Table(name="cloud_order")
public class CloudOrder extends AbstractAuditEntity implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 6339963575142170464L;

	@Id
    @GeneratedValue(generator="cloud_order_seq")
    @Column(name = "cloud_order_id", nullable = false)
	private Long id;
	
	@Column(name = "order_code", unique = true, nullable = true)
	private String orderCode;
	
	@ManyToOne
	@JoinColumn(name="cloud_product_plan_id")
	private CloudProductPlan cloudProductPlan;
	
	@Column(name = "quantity", nullable = false)
	private Integer quantity;
		
	@ManyToOne
	@JoinColumn(name="CUSTOMER_COMPANY_ID")
	private CloudCustomerCompany cloudCustomerCompany;//todo mapping
	
	@Column(name="status")
	private String status;
	
	@Column(name="purchase_order_number", nullable = true)
	private String purchaseOrderNumber;
	
	@OneToMany(mappedBy="cloudOrder")
	private Set<CloudServer> cloudServers=new HashSet<CloudServer>();
	
	@OneToMany(mappedBy="cloudOrder")
	private Set<CloudSubscription> cloudSubscriptions=new HashSet<CloudSubscription>();
	
	@OneToOne(mappedBy = "cloudOrder")
	private CloudAccount cloudAccount = new CloudAccount();
	
	@Column(name="remarks", nullable = true)
    private String remarks;	
}
