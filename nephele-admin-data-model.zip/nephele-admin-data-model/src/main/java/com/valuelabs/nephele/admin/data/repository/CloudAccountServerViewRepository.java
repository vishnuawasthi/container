package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudAccountServerView;

public interface CloudAccountServerViewRepository extends ViewRepository<CloudAccountServerView, Long>, JpaSpecificationExecutor<CloudAccountServerView> {
  
  @Query("SELECT casv.nepheleStatus, count(casv.nepheleStatus) FROM CloudAccountServerView  casv WHERE  casv.cloudServiceId =:serviceId AND casv.customerCompanyId =:customerCompanyId GROUP BY casv.nepheleStatus ")
  public List<Object[]> findAccountServerViewSummaryByCustomerCode(@Param("serviceId") Long serviceId,
	  @Param("customerCompanyId") Long customerCompanyId);
  
  
  @Query("SELECT casv.nepheleStatus, count(casv.nepheleStatus) FROM CloudAccountServerView  casv WHERE  casv.cloudServiceId =:serviceId AND casv.customerCompanyId =:customerCompanyId  AND  casv.cloudServiceId in(:serviceIds) GROUP BY casv.nepheleStatus ")
  public List<Object[]> findAccountServerViewSummaryByCustomerCodeAndCategoryId(@Param("serviceId") Long serviceId,
	  @Param("customerCompanyId") Long customerCompanyId,@Param("serviceIds") List<Long> serviceIds);
  


  @Query("SELECT casv.nepheleStatus, count(casv.nepheleStatus) FROM CloudAccountServerView  casv WHERE  casv.cloudServiceId =:serviceId AND casv.customerCompanyId in (:customerCompanyies) GROUP BY casv.nepheleStatus ")
  public List<Object[]> findAccountServerViewSummaryByResellerCode(@Param("serviceId") Long serviceId,
	  @Param("customerCompanyies") List<Long> customerCompanyies);
  
  
  @Query("SELECT casv.nepheleStatus, count(casv.nepheleStatus) FROM CloudAccountServerView  casv WHERE  casv.cloudServiceId =:serviceId AND casv.customerCompanyId in(:customerCompanyies)  AND  casv.cloudServiceId in(:serviceIds) GROUP BY casv.nepheleStatus ")
  public List<Object[]> findAccountServerViewSummaryByResellerCodeAndCategoryId(@Param("serviceId") Long serviceId,
	  @Param("customerCompanyies") List<Long> customerCompanyies,@Param("serviceIds") List<Long> serviceIds);
  
  
}
