package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudGeography;

public interface CloudGeographyRepository  extends TableRepository<CloudGeography, Long>, JpaSpecificationExecutor<CloudGeography>{
	
	@Query("SELECT cg FROM  CloudGeography cg WHERE cg.geographyCode = :geographyCode") 
	public CloudGeography findByGeographyCode(@Param("geographyCode") String geographyCode);
}
