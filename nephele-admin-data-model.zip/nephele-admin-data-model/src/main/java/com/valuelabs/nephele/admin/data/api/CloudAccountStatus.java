package com.valuelabs.nephele.admin.data.api;

public enum CloudAccountStatus {
ACTIVE,
PENDING,
EXPIRED,
ERROR,
SUSPENDED

}
