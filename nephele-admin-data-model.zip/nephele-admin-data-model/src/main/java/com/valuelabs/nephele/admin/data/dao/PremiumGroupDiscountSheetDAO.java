package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudResellerPremiumGroup;
import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountConfig;
import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountSheet;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
@Slf4j
@Repository
public class PremiumGroupDiscountSheetDAO extends AbstractJpaDAO<PremiumGroupDiscountSheet> {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public PremiumGroupDiscountSheetDAO() {
		setClazz(PremiumGroupDiscountSheet.class);
	}
	
	public List<PremiumGroupDiscountSheet> getDiscountSheetsByName(String sheetName){
		
		TypedQuery<PremiumGroupDiscountSheet> query = entityManager.createNamedQuery("PremiumGroupDiscountSheet.getBySheetName", PremiumGroupDiscountSheet.class)
																	.setParameter("sheetName", sheetName);
		return query.getResultList();
	
	}
	
	public List<PremiumGroupDiscountSheet> getByServiceNplanTypeNgroupName(Long serviceId, String groupName, String planType){
		
		List<PremiumGroupDiscountSheet> result = null;
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<PremiumGroupDiscountSheet> criteriaQuery = criteriaBuilder.createQuery(PremiumGroupDiscountSheet.class);
		Root<PremiumGroupDiscountSheet> rootBase = criteriaQuery.from(PremiumGroupDiscountSheet.class);
		Predicate predicate = criteriaBuilder.conjunction();
		
		Join<PremiumGroupDiscountSheet, PremiumGroupDiscountConfig> rootWithDiscountConfig = rootBase.join("premiumGroupDiscountConfig");
		Join<PremiumGroupDiscountSheet, CloudResellerPremiumGroup> rootWithPremiumGroup= rootBase.join("premiumGroup");
		Path<Object> rootWithService= rootWithDiscountConfig.get("cloudService");
		Path<Object> rootWithPlanType= rootWithDiscountConfig.get("planType");
		if(!StringUtils.isEmpty(groupName)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithPremiumGroup.get("name"), groupName));
			}
		if(!StringUtils.isEmpty(serviceId)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
			}
		if(!StringUtils.isEmpty(planType)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithPlanType.get("typeName"), planType));
			}
		
		criteriaQuery.where(predicate);
		result =entityManager.createQuery(criteriaQuery).getResultList();
		return result;
	}
	
	
}
