package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.net.URI;
import java.util.HashSet;
import java.util.Set;

@NamedQueries({@NamedQuery(name = "Server.findBycspServerId", query = "FROM  CloudServer cs WHERE cs.cspServerId =:cspServerId"),
			   @NamedQuery(name = "Server.findByName", query = "FROM  CloudServer cs WHERE cs.name =:name"),
			   @NamedQuery(name = "Server.findServerSummaryByCustomerCode", query = "SELECT status,count(status) FROM  CloudServer cs "
			   																	+ "WHERE cs.cloudCustomerCompany.customerCompanyCode =:customerCode "
			   																	+ "GROUP BY status"),
			   @NamedQuery(name = "Server.findServerByOrderId", query = "FROM  CloudServer cs WHERE cs.cloudOrder.id =:orderId"),
			   @NamedQuery(name = "Server.findServerByCustomerId", query = "FROM  CloudServer cs WHERE cs.cloudCustomerCompany.id =:customerId "
			   															 + "AND status != 'TERMINATED'")
			  })
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_server_seq",sequenceName="cloud_server_seq",initialValue=1)
@Entity
@Table(name="cloud_server")
public class CloudServer extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = 7134383092451105658L;
	@ManyToOne
	@JoinColumn(name = "CUSTOMER_COMPANY_ID")
	CloudCustomerCompany cloudCustomerCompany;
	@Id
    @GeneratedValue(generator="cloud_server_seq")
    @Column(name = "cloud_server_id", nullable = false)
	private Long id;
	@Column(name = "csp_server_id", nullable = true)
	private String cspServerId;
	@Column(name = "csp_uri", nullable = true)
	private URI uri;
	@Column(name = "name", nullable = true)
	private String name;
	@Column(name = "description", nullable = true, length = 1000)
	private String description;
	@Column(name = "SERVER_GROUP", nullable = true)
	private String serverGroup;
	@Column(name = "status", nullable = true)
	private String status;
	@Column(name = "vendor_status", nullable = true)
	private String vendorStatus;
	@Column(name = "PUBLIC_IPV4_ADDRESS", nullable = true)
	private String publicIPv4Address;
	@Column(name = "PUBLIC_IPV6_ADDRESS", nullable = true)
	private String publicIPv6Address;
	@Column(name = "PRIVATE_IPV4_ADDRESS", nullable = true)
	private String privateIPv4Address;
	@Column(name = "PRIVATE_IPV6_ADDRESS", nullable = true)
	private String privateIPv6Address;
	@Column(name = "username", nullable = true)
	private String username;
	
	/*@ManyToOne
	@JoinColumn(name = "cloud_location_id", nullable = true)
	private CloudLocation cloudLocation;*/
	@Column(name = "password", nullable = true)
	private String password;
	@ManyToOne
	@JoinColumn(name="cloud_product_plan_id", nullable = true)
	private CloudProductPlan cloudProductPlan;
	
	@ManyToOne
    @JoinColumn(name = "cloud_service_id") 
    private CloudService cloudService;
	
	@ManyToOne
    @JoinColumn(name = "cloud_order_id") 
    private CloudOrder cloudOrder;
	
	/*@ManyToOne
    @JoinColumn(name = "cloud_order_line_id") 
    private CloudOrderLine cloudOrderLine;*/
	
	@OneToMany(mappedBy="cloudServer")
	private Set<CloudServerAction> cloudServerActions=new HashSet<CloudServerAction>();
	
	@OneToMany(mappedBy="cloudServer")
	private Set<RackspaceServerConfiguration> rackspaceServerConfigurations=new HashSet<RackspaceServerConfiguration>();
	
	@OneToMany(mappedBy="cloudServer")
	private Set<RackspaceServerConfiguration> rackSpaceServerConfigurations=new HashSet<RackspaceServerConfiguration>();
	
	@Column(name="remarks", nullable = true)
    private String remarks;
	
/*	@OneToMany(mappedBy="cloudServer")
	private Set<SoftlayerServerConfiguration> softlayerServerServerConfigurations=new HashSet<SoftlayerServerConfiguration>();
	
	@OneToMany(mappedBy="cloudServer")
	private Set<AzureServerConfiguration> azureServerConfigurations=new HashSet<AzureServerConfiguration>();
	
	@OneToMany(mappedBy="cloudServer")
	private Set<AzureServerEndpoint> azureServerEndPoints=new HashSet<AzureServerEndpoint>();*/
	
	
}
