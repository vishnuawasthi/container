package com.valuelabs.nephele.admin.data.api;

public enum SubscriptionStatus {
	
	PENDING,
	ACTIVE,
	EXPIRED,
	ERROR,
	SUSPENDED,
	Assigned,
	Unassigned

}
