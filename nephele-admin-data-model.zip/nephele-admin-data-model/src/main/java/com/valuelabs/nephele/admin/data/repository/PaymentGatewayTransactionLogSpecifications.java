package com.valuelabs.nephele.admin.data.repository;

/**
 * Created by snagaboina on 30/11/15.
 */
public class PaymentGatewayTransactionLogSpecifications {
}
