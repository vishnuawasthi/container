package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudOperatingSystem;

public interface CloudOperatingSystemRepository extends TableRepository<CloudOperatingSystem, Long>, JpaSpecificationExecutor<CloudOperatingSystem>{
	
	@Query("SELECT os FROM  CloudOperatingSystem os WHERE os.cloudService.id = :serviceId")
	public List<CloudOperatingSystem> getByService(@Param("serviceId") Long serviceId);
	
	@Query("SELECT os FROM  CloudOperatingSystem os WHERE os.cloudService.id = :serviceId AND os.status = :status")
	public List<CloudOperatingSystem> getByServiceAndStatus(@Param("serviceId") Long serviceId, @Param("status") String status);
	
	@Query("Select NEW com.valuelabs.nephele.admin.data.entity.RackspaceComputePriceExportData(cos.cloudService.id as SERVICE_ID, cos.cloudService.name as SERVICE, "
			   														 + "cos.id as CLOUD_OPERATING_SYSTEM_ID, cos.imageId as VENDOR_IMAGE_ID, cos.name as VENDOR_IMAGE_NAME, "
			   														 + "crc.id as CLOUD_RACKSPACE_CONFIGURATION_ID, crc.flavorId as VENDOR_FLAVOR_ID, crc.flavor_class as VENDOR_FLAVOR_CLASS, "
			   														 + "crc.name as VENDOR_FLAVOR_NAME, crc.status as VENDOR_FLAVOR_STATUS, crc.ram as VENDOR_RAM, crc.price+cos.price as PRICE) "
			   														 + "FROM CloudOperatingSystem cos , CloudRackspaceConfiguration crc where cos.cloudService.id = crc.cloudService.id "
			   														 + "AND crc.ram >= cos.minRam AND crc.disk >= cos.minDisk "
			   														 + "order by cos.id, cos.imageId, crc.id, crc.flavor_class, crc.flavorId")
	public List<CloudOperatingSystem> getOSInfo();
	
	@Query("Select NEW com.valuelabs.nephele.admin.data.entity.RackspaceComputePriceExportData(cos.cloudService.id as SERVICE_ID, cos.cloudService.name as SERVICE, "
																	 + "cos.id as CLOUD_OPERATING_SYSTEM_ID, cos.imageId as VENDOR_IMAGE_ID, cos.name as VENDOR_IMAGE_NAME, "
																	 + "crc.id as CLOUD_RACKSPACE_CONFIGURATION_ID, crc.flavorId as VENDOR_FLAVOR_ID, crc.flavor_class as VENDOR_FLAVOR_CLASS, "
																	 + "crc.name as VENDOR_FLAVOR_NAME, crc.status as VENDOR_FLAVOR_STATUS, crc.ram as VENDOR_RAM, crc.price+cos.price as PRICE) "
																	 + "FROM CloudOperatingSystem cos , CloudRackspaceConfiguration crc where cos.id = :osId AND cos.cloudService.id = crc.cloudService.id "
																	 + "AND crc.ram >= cos.minRam AND crc.disk >= cos.minDisk AND cos.status in ('STAGED', 'PUBLISHED') "
			   														 + "AND crc.status in ('STAGED', 'PUBLISHED') "
																	 + "order by cos.id, cos.imageId, crc.id, crc.flavor_class, crc.flavorId")
	public List<CloudOperatingSystem> getOSNConfigByOSId(@Param("osId") Long osId);
	
	@Query("SELECT os FROM  CloudOperatingSystem os WHERE os.status = :status")
	public List<CloudOperatingSystem> findByStatus(@Param("status") String status);
	
	@Query("SELECT status,count(status) FROM  CloudOperatingSystem cos"
			   					+" WHERE cos.cloudService.id= :serviceId GROUP BY status")
	public  List<Object[]> findOperatingSystemSummaryByServiceId(@Param("serviceId") Long serviceId);
	
	
	
	

}