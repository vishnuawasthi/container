package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.GregorianCalendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name = "softlayer_usage_data_seq", sequenceName = "softlayer_usage_data_seq", initialValue = 1)
@Entity
@Table(name = "softlayer_usage_data")
public class SoftlayerUsageData extends AbstractAuditEntity implements Serializable {

	private static final long serialVersionUID = 7134383092451105658L;

	@Id
	@GeneratedValue(generator = "softlayer_usage_data_seq")
	@Column(name = "softlayer_usage_data_id", nullable = false)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "CUSTOMER_COMPANY_ID")
	private CloudCustomerCompany cloudCustomerCompany;

	@ManyToOne
	@JoinColumn(name = "cloud_account_id")
	private CloudAccount cloudAccount;

	@Column(name = "product_type", nullable = false)
	private String productType;

	@ManyToOne
	@JoinColumn(name = "cloud_service_id")
	private CloudService cloudService;

	@Column(name = "service_type", nullable = false)
	private String serviceType;

	@Column(name = "quantity", nullable = false)
	private Long quantity;

	@Column(name = "unit_price", nullable = true)
	private Double unitPrice;

	@Column(name = "currency", nullable = false)
	private String currency;

	@Column(name = "recurring_charge", nullable = true)
	private Double recurringCharge;

	@Column(name = "setup_charge", nullable = true)
	private Double setupCharge;

	@Column(name = "labor_charge", nullable = true)
	private Double laborCharge;

	@Column(name = "one_time_charge", nullable = true)
	private Double onetimeCharge;
	
	@Column(name = "total_price", nullable = true)
	private Double totalPrice;

	@Column(name = "description", nullable = false)
	private String description;

	@Column(name = "INVOICE_STATUS", nullable = true)
	@Enumerated(EnumType.STRING)
	private MeteringDataInvoiceStatus invoiceStatus;

	@ManyToOne
	@JoinColumn(name = "cycle_id")
	private CloudBillingCycle billingCycle;

	@Column(name = "event_start_time")
	private GregorianCalendar eventStartDate;

}
