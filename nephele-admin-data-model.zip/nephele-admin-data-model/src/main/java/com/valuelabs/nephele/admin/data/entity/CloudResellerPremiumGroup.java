package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Setter
@Getter
@Accessors(chain = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@NamedQueries({
		@NamedQuery(name = "CloudResellerPremiumGroup.byName", query = "from CloudResellerPremiumGroup where name = :name")
})
@SequenceGenerator(name = "cloud_reseller_premium_group_seq", sequenceName = "cloud_reseller_premium_group_seq", initialValue = 1)
@Builder
@Table(name = "cloud_reseller_premium_group")
public class CloudResellerPremiumGroup extends AbstractAuditEntity implements Serializable {

	private static final long serialVersionUID = 9064591024249055329L;

	@Id
	@GeneratedValue(generator = "cloud_reseller_premium_group_seq")
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "description")
	private String description;	
	
	/*@ManyToOne
	@JoinColumn(name = "cloud_service_id")
	private CloudService cloudService;*/
	
	//@Column(name="status")
	//@Enumerated(EnumType.STRING)
	//private ChangeManagementConfigStatus status;

	@OneToMany(mappedBy = "premiumGroup", fetch = FetchType.EAGER)
	private Set<CloudResellerCompany> cloudResellerCompanySet = new HashSet<CloudResellerCompany>();

	@OneToMany(mappedBy = "premiumGroup", fetch = FetchType.EAGER)
	private Set<PremiumGroupDiscountSheet> priceGroupDiscountSheetSet = new HashSet<PremiumGroupDiscountSheet>();
}
