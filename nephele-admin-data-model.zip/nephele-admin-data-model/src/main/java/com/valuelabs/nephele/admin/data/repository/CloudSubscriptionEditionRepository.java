package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudSubscriptionEdition;

public interface CloudSubscriptionEditionRepository extends TableRepository<CloudSubscriptionEdition, Long>, JpaSpecificationExecutor<CloudSubscriptionEdition>{

}
