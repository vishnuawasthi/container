package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudAccount;
import com.valuelabs.nephele.admin.data.entity.CloudService;

@Slf4j
public class CloudAccountSpecifications {
  public static Specification<CloudAccount> findByFilter(final Long serviceId) {

	return new Specification<CloudAccount>() {

	  @Override
	  public Predicate toPredicate(Root<CloudAccount> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
		Predicate predicate = criteriaBuilder.conjunction();
		Join<CloudAccount, CloudService> rootWithService = root.join("cloudService");
		
		if(!StringUtils.isEmpty(serviceId)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
		}
		
		return predicate;

	  }
	};
  }
  public static Sort sortByIdAsc() {
    return new Sort(Sort.Direction.ASC, "id");
}

/**
* Returns a new object which specifies the the wanted result page.
* @param pageIndex The index of the wanted result page
* @return
*/
public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
    Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
    return pageSpecification;
}

/**
 * Returns a Sort object which sorts persons in ascending order by using the last name.
 * @return
 */
public static Sort sortByLastNameAsc() {
    return new Sort(Sort.Direction.ASC, "lastName");
}


}
