package com.valuelabs.nephele.admin.data.dao;

import com.google.common.base.Strings;
import com.valuelabs.nephele.admin.data.entity.CloudDistributorUser;
import com.valuelabs.nephele.admin.data.exception.ResourceNotFoundException;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import java.util.List;

@Slf4j
@Repository
public class CloudDistributorUserDAO extends AbstractJpaDAO<CloudDistributorUser> {

	@Autowired
	private EntityManager entityManager;

	public CloudDistributorUserDAO() {
		setClazz(CloudDistributorUser.class);
	}

	public CloudDistributorUser findUserByUserName(String distributorName) {
			TypedQuery<CloudDistributorUser> query = entityManager.createNamedQuery("CloudDistributorUser.findUserByUserName", CloudDistributorUser.class)
					.setParameter("email", distributorName).setParameter("isEnabled", true);
		return query.getSingleResult();
	}

	public CloudDistributorUser findUserByPswdResetToken(String passwordResetToken) {
		TypedQuery<CloudDistributorUser> query = entityManager.createNamedQuery("CloudDistributorUser.findUserByPswdToken", CloudDistributorUser.class)
				.setParameter("passwordResetToken", passwordResetToken);
		return query.getSingleResult();
	}

	public CloudDistributorUser findUserByEmail(String email) throws ResourceNotFoundException{
		try{
			TypedQuery<CloudDistributorUser> query = entityManager.createNamedQuery("CloudDistributorUser.findUserByEmail", CloudDistributorUser.class)
					.setParameter("email", email).setParameter("isEnabled", true);
			return query.getSingleResult();
		}catch(Exception e){
			log.error("Exception occurs while retrieving the details from DB: ", e.getMessage());
			throw new ResourceNotFoundException("CloudDistributorUser", email);
		}
		
	}

	public CloudDistributorUser findUserByApiKey(String apiKey) {
		TypedQuery<CloudDistributorUser> query = entityManager.createNamedQuery("CloudDistributorUser.findUserByApiKey", CloudDistributorUser.class)
				.setParameter("apiKey", apiKey);
		return query.getSingleResult();
	}
	
	public List<CloudDistributorUser> findUsers(String firstName, String lastName , String email , Boolean isEnabled , String createdDate) {
		List<CloudDistributorUser> result = null;
		log.debug("findUser - START {}",isEnabled);
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CloudDistributorUser> criteriaQuery = criteriaBuilder.createQuery(CloudDistributorUser.class);
		Root<CloudDistributorUser> rootBase = criteriaQuery.from(CloudDistributorUser.class);
		Predicate predicate = criteriaBuilder.conjunction();
		
		if(!Strings.isNullOrEmpty(firstName)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("firstName"), firstName));
		}
		
		if(!Strings.isNullOrEmpty(lastName)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("lastName"), lastName));
		}
		
		if(!Strings.isNullOrEmpty(email)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("email"), email));
		}
		
		if(null != isEnabled ){
			 predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("isEnabled"), isEnabled));
		}
	   
		if(!Strings.isNullOrEmpty(createdDate)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(
					  criteriaBuilder.function("TO_CHAR",
				                String.class,rootBase.get("created"), 
				                criteriaBuilder.literal("dd-MM-yyyy")), createdDate));		    
		}
		
		
		criteriaQuery.where(predicate);
		result =entityManager.createQuery(criteriaQuery).getResultList();
		log.debug("findUser - END ");
		return result;
	}


}
