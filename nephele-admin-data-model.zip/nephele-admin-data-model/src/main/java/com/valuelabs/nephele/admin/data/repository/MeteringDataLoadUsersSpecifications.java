package com.valuelabs.nephele.admin.data.repository;

public final class MeteringDataLoadUsersSpecifications {

}
