package com.valuelabs.nephele.admin.data.api;

public enum NepheleCurrency {
  USD,
  AUD       

}
