package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.csv.CsvEntry;
import com.valuelabs.nephele.admin.data.csv.CsvFile;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

/*@NamedQuery(name = "MeterData.GroupBy", query = "select RES_ID, UOM, sum(QUANTITY) QUANTITY, ATTRIBUTE_1 from CloudRackspaceMeteringData c" + 
												"where c.res_id is not null and c.UOM is not null group by c.RES_ID, c.UOM, c.ATTRIBUTE_1")*/

/*@NamedQuery(name = "MeterData.ByUnits", 
query = " Select NEW com.valuelabs.nephele.admin.data.entity.CloudRackspaceMeteringDataSubset(RES_ID, UOM, sum(QUANTITY) as QUANTITY, ATTRIBUTE_1) "
		+ "from CloudRackspaceMeteringData c where c.RES_ID is not null and c.UOM is not null group by c.RES_ID, c.UOM, c.ATTRIBUTE_1")*/
@NamedQuery(name = "MeterData.ByUnits", query = " Select NEW com.valuelabs.nephele.admin.data.entity.CloudRackspaceMeteringDataSubset(RES_ID, SERVICE_TYPE, sum(QUANTITY) as QUANTITY, ATTRIBUTE_1) "
		+ "from CloudRackspaceMeteringData c where c.RES_ID is not null AND c.IMPACT_TYPE = 'CHARGE' group by c.RES_ID, c.SERVICE_TYPE, c.ATTRIBUTE_1 ORDER BY 1")
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@ToString
@SequenceGenerator(name="cloud_rackspace_metering_data_seq", sequenceName="cloud_rackspace_metering_data_seq" ,initialValue=1)
@Entity
@Table(name = "cloud_rackspace_metering_data")
@CsvFile(delimiter = ",", fileName = "")
public class CloudRackspaceMeteringData extends AbstractAuditEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue( generator="cloud_rackspace_metering_data_seq")
	@Column(name = "id")
	private Long id;
	
	@Column(name = "ACCOUNT_NO")
	@CsvEntry(header = "ACCOUNT_NO")
	private String accountNo;
	
	@Column(name = "BILL_NO")
	@CsvEntry(header = "BILL_NO")
	private String BILL_NO;
	
	@Column(name = "BILL_START_DATE")
	@CsvEntry(header = "BILL_START_DATE")
	private String BILL_START_DATE;
	
	@Column(name = "BILL_END_DATE")
	@CsvEntry(header = "BILL_END_DATE")
	private String BILL_END_DATE;
	
	@Column(name = "SERVICE_TYPE")
	@CsvEntry(header = "SERVICE_TYPE")
	private String SERVICE_TYPE;
	
	@Column(name = "EVENT_TYPE")
	@CsvEntry(header = "EVENT_TYPE")
	private String EVENT_TYPE;
	
	@Column(name = "EVENT_START_DATE")
	@CsvEntry(header = "EVENT_START_DATE")
	private String EVENT_START_DATE;
	
	@Column(name = "EVENT_END_DATE")
	@CsvEntry(header = "EVENT_END_DATE")
	private String EVENT_END_DATE;
	
	@Column(name = "IMPACT_TYPE")
	@CsvEntry(header = "IMPACT_TYPE")
	private String IMPACT_TYPE;
	
	@Column(name = "QUANTITY")
	@CsvEntry(header = "QUANTITY")
	private Double QUANTITY;
	
	@Column(name = "UOM")
	@CsvEntry(header = "UOM")
	private String UOM;
	
	@Column(name = "RATE")
	@CsvEntry(header = "RATE")
	private String RATE;
	
	@Column(name = "AMOUNT")
	@CsvEntry(header = "AMOUNT")
	private Float AMOUNT;
	
	@Column(name = "USAGE_RECORD_ID")
	@CsvEntry(header = "USAGE_RECORD_ID")
	private String USAGE_RECORD_ID;
	
	@Column(name = "DC_ID")
	@CsvEntry(header = "DC_ID")
	private String DC_ID;
	
	@Column(name = "REGION_ID")
	@CsvEntry(header = "REGION_ID")
	private String REGION_ID;
	
	@Column(name = "RES_ID")
	@CsvEntry(header = "RES_ID")
	private String RES_ID;
	
	@Column(name = "RES_NAME")
	@CsvEntry(header = "RES_NAME")
	private String RES_NAME;
	
	@Column(name = "ATTRIBUTE_1")
	@CsvEntry(header = "ATTRIBUTE_1")
	private String ATTRIBUTE_1;
	
	@Column(name = "ATTRIBUTE_2")
	@CsvEntry(header = "ATTRIBUTE_2")
	private String ATTRIBUTE_2;
	
	@Column(name = "ATTRIBUTE_3")
	@CsvEntry(header = "ATTRIBUTE_3")
	private String ATTRIBUTE_3;

	
}
