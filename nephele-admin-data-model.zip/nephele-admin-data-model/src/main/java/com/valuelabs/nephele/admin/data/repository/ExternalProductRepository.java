package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.ExternalProduct;

public interface ExternalProductRepository extends TableRepository<ExternalProduct, Long>, JpaSpecificationExecutor<ExternalProduct>{

	@Query("FROM  ExternalProduct ep WHERE ep.productName = :productName")
	public List<ExternalProduct> findExternalProductsByProductName(@Param("productName") String productName);
	
	@Query("FROM  ExternalProduct ep WHERE ep.externalId = :externalId")
	public ExternalProduct findExternalProductsByExternalId(@Param("externalId") String externalId);
}
