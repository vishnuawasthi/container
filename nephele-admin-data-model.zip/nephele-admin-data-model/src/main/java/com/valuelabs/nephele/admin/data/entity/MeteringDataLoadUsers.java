package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@Entity
@SequenceGenerator(name="cloud_metering_dataload_users_seq" ,sequenceName="cloud_metering_dataload_users_seq",initialValue=1)
@Table(name="cloud_Metering_DataLoad_Users")
@NamedQuery(name="MeteringDataLoadUsers.getByUserName",query="from MeteringDataLoadUsers where userName=:username")
public class MeteringDataLoadUsers extends AbstractAuditEntity  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Integer id;
	@GeneratedValue(generator="cloud_metering_dataload_users_seq")
	@Column(name = "user_id",nullable = false)
	private String userId;
	@Column(name = "user_name", nullable = false)
	private String userName;
	@Column(name = "user_password", nullable = false)
	private String password;
	@Column(name = "user_email")
	private String email;

}
