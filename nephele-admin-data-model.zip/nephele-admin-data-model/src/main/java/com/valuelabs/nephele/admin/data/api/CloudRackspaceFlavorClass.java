/**
 * 
 */
package com.valuelabs.nephele.admin.data.api;

/**
 * @author sivanaresh bandarupalli
 *
 */
public enum CloudRackspaceFlavorClass {
	
	standard,
	general,
	io,
	performance;

}
