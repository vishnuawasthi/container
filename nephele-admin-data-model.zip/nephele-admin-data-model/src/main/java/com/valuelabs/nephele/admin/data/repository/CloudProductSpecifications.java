package com.valuelabs.nephele.admin.data.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProduct;
import com.valuelabs.nephele.admin.data.entity.CloudService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CloudProductSpecifications {

	public static Specification<CloudProduct> getPublishedProductsByService(final Long serviceId) {

		return new Specification<CloudProduct>() {

			@Override
			public Predicate toPredicate(Root<CloudProduct> root, CriteriaQuery<?> criteriaQuery,
					CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();

				Join<CloudProduct, CloudService> rootWithService = root.join("cloudService");
				List<Order> orderList = new ArrayList<Order>();
				Expression<String> rootStatus = root.get("status");
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus),
						"%" + InventoryStatus.PUBLISHED.name().toLowerCase() + "%"));
				predicate = criteriaBuilder.and(predicate,
						criteriaBuilder.equal(rootWithService.get("isPublished"), true));
				if (null != serviceId && serviceId > 0) {
					predicate = criteriaBuilder.and(predicate,
							criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}

				/*
				 * criteriaQuery.where(predicate);
				 * orderList.add(criteriaBuilder.asc(root.get("id")));
				 * criteriaQuery.orderBy(orderList);
				 */
				return predicate;
			}
		};
	}

	public static Specification<CloudProduct> getProductByNameNStatusNFeaturedNRelatedProducts(final Long serviceId,final String productName,
			final String status, final Boolean isFeatured, final Boolean isRelatedProducts) {

		return new Specification<CloudProduct>() {

			@Override
			public Predicate toPredicate(Root<CloudProduct> root, CriteriaQuery<?> criteriaQuery,
					CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();

				Join<CloudProduct, CloudService> rootWithService = root.join("cloudService");
				
				if (null != serviceId && serviceId > 0) {
					predicate = criteriaBuilder.and(predicate,
							criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}

				if (!StringUtils.isEmpty(productName)) {
					Expression<String> rootName = root.get("name");
					predicate = criteriaBuilder.and(predicate,
							criteriaBuilder.like(criteriaBuilder.lower(rootName), productName.toLowerCase() + "%"));

				}
				if (!StringUtils.isEmpty(status)) {
					Expression<String> rootStatus = root.get("status");
					predicate = criteriaBuilder.and(predicate,
							criteriaBuilder.like(criteriaBuilder.lower(rootStatus), status.toLowerCase() + "%"));
				}

				if (!StringUtils.isEmpty(isFeatured)) {
					predicate = criteriaBuilder.and(predicate,
							criteriaBuilder.equal(root.get("isFeatured"), isFeatured));
				}
				if (!StringUtils.isEmpty(isRelatedProducts)) {
					predicate = criteriaBuilder.and(predicate,
							criteriaBuilder.equal(root.get("hasRelatedProducts"), isRelatedProducts));

				}
				return predicate;
			}
		};
	}

	public static Specification<CloudProduct> getProductsByService(final Long serviceId) {

		return new Specification<CloudProduct>() {

			@Override
			public Predicate toPredicate(Root<CloudProduct> root, CriteriaQuery<?> criteriaQuery,
					CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();

				Join<CloudProduct, CloudService> rootWithService = root.join("cloudService");
				if (null != serviceId && serviceId > 0) {
					predicate = criteriaBuilder.and(predicate,
							criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}
				return predicate;
			}
		};
	}

	public static Sort sortByIdAsc() {
		return new Sort(Sort.Direction.ASC, "id");
	}

	/**
	 * Returns a new object which specifies the the wanted result page.
	 * 
	 * @param pageIndex
	 *            The index of the wanted result page
	 * @return
	 */
	public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
		Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
		return pageSpecification;
	}

}
