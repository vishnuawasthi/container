package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_manager_app_permission_seq", sequenceName = "cloud_manager_app_permission_seq",initialValue = 1)
@Builder
@Table(name = "cloud_manager_app_permission")
public class CloudManagerAppPermission  extends AbstractAuditEntity implements Serializable{

  /**
   * 
   */
  private static final long serialVersionUID = -5208562042293315979L;
  
  @Id
  @GeneratedValue(generator = "cloud_manager_app_permission_seq")
  @Column(name = "cloud_manager_app_permission_id")
  private Long id;
  
  @Column(name="is_read")
  private Boolean isRead;
  
  @Column(name="is_write")
  private Boolean isWrite;
  
  @ManyToOne
  @JoinColumn(name = "cloud_manager_app_account_id") 
  private CloudManagerAppAccount cloudManagerAppAccount ;
  
  @ManyToOne
  @JoinColumn(name = "cloud_user_role_id") 
  private CloudUserRole cloudUserRole;

}
