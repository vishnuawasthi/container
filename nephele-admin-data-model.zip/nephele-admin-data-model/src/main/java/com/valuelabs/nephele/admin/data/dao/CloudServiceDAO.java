package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudLocation;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.entity.CloudServiceProvider;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudServiceDAO extends AbstractJpaDAO<CloudService>{
	
	@PersistenceContext
	EntityManager entityManager;
	
	public CloudServiceDAO() {
		setClazz(CloudService.class );
	}
	
	public CloudService findByName(String serviceName) {
		TypedQuery<CloudService> query =
				entityManager.createNamedQuery("CloudService.findByName", CloudService.class).
									setParameter("name", serviceName);
		return query.getSingleResult();
		
	}
	
	public CloudService findByServiceCode(String serviceCode) {
		TypedQuery<CloudService> query =
				entityManager.createNamedQuery("CloudService.findByServiceCode", CloudService.class).
									setParameter("serviceCode", serviceCode);
		return query.getSingleResult();
		
	}
	
	public List<CloudService> findByActiveServices() {
		TypedQuery<CloudService> query =
				entityManager.createNamedQuery("CloudService.findActiveServices", CloudService.class);
									
		
		return query.getResultList();
		
	}
	
	public Object getCount() {
		TypedQuery<Object> query =
				entityManager.createNamedQuery("CloudService.findActiveServicesCount", Object.class);
		return query.getSingleResult();
		
	}

  public List<CloudService> getCloudServiceWithBrandNameAndServiceName(String brandName, String serviceName) {
	List<CloudService> list = null;
	CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	CriteriaQuery<CloudService> criteriaQuery = criteriaBuilder.createQuery(CloudService.class);
	Root<CloudService> rootBase = criteriaQuery.from(CloudService.class);
	Predicate predicate = criteriaBuilder.conjunction();
	Join<CloudService, CloudServiceProvider> rootWithServiceProvider = rootBase.join("cloudServiceProvider");
	if (!StringUtils.isEmpty(serviceName)) {
	  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootBase.get("name"), serviceName));
	}
	if (!StringUtils.isEmpty(brandName)) {
	  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithServiceProvider.get("brandName"), brandName));
	}

	criteriaQuery.where(predicate);
	list = entityManager.createQuery(criteriaQuery).getResultList();
	return list;
  }
	
	
	
}
