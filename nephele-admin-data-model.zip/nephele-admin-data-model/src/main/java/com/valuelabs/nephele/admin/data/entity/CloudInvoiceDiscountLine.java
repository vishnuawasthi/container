package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.ResellerDiscountPlanType;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name = "cloud_invoice_discount_line_seq", sequenceName = "cloud_invoice_discount_line_seq", initialValue = 1)
@Entity
@Table(name = "cloud_invoice_discount_line")
public class CloudInvoiceDiscountLine extends AbstractAuditEntity implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = -307274343442707232L;

  @Id
  @GeneratedValue(generator = "cloud_invoice_discount_line_seq")
  @Column(name = "cloud_invoice_discount_line_id", nullable = false)
  private Long id;

  @Column(name = "brand")
  private String brand;

  @Column(name = "description")
  private String description;

  @Column(name = "quantity")
  private String quantity;

  @Column(name = "total")
  private Double total;

  @Column(name = "discount_percent")
  private Double discountPercent;

  @Column(name = "discount_type")
  @Enumerated(EnumType.STRING)
  private ResellerDiscountPlanType discountType;

  @ManyToOne(cascade = {CascadeType.MERGE})
  @JoinColumn(name = "cloud_invoice_id")
  private CloudResellerInvoice cloudInvoice;

  public int compareTo(CloudInvoiceDiscountLine o) {
    int val = o == null ? 1 : 0;
    if (val == 0 && this.getId() != null) {
      if (o.getId() == null) {
        val = 1;
      } else {
        val = (int) (this.getId().longValue() - o.getId().longValue());
      }
    }
    if (val == 0 && o.getId() != null && this.id == null) {
      val = -1;
    }
    return 0;
  }
}
