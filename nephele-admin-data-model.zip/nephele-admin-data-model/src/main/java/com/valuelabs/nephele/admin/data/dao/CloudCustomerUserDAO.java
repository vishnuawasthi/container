package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerUser;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudCustomerUserDAO extends AbstractJpaDAO<CloudCustomerUser> {

	public CloudCustomerUserDAO() {
		setClazz(CloudCustomerUser.class);
	}
}
