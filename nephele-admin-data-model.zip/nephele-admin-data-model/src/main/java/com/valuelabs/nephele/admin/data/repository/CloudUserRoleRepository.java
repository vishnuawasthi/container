package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudUserRole;

public interface CloudUserRoleRepository extends TableRepository<CloudUserRole, Long>, JpaSpecificationExecutor<CloudUserRole>{

	@Query("FROM CloudUserRole where roleName= :roleName")
	public CloudUserRole getUserRoleByName(@Param("roleName")String roleName);
}
