package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NamedQuery(name = "SalesTaxation.findByCountry", query = " FROM CloudSalesTaxation cs where cs.countryName = :countryName")
@Setter
@Getter
@Accessors(chain = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_sales_taxation_seq", sequenceName = "cloud_sales_taxation_seq", initialValue = 1)
@Builder
@Table(name = "cloud_sales_taxation")
public class CloudSalesTaxation extends AbstractAuditEntity implements Serializable{
	
	private static final long serialVersionUID = 6339963575142170464L;

	@Id
	@GeneratedValue(generator = "cloud_sales_taxation_seq")
	@Column(name = "cloud_sales_taxation_id ")
	private Long cloudSalesTaxationId;
	
	/*@Column(name = "country_code")
	private String countryCode;*/
	
	@Column(name = "country_name")
	private String countryName;
	
	/*@Column(name = "property_name")
	private String propertyName;
	*/
	@Column(name = "value")
	private Double value;
	
	

}
