/**
 * 
 */
package com.valuelabs.nephele.admin.data.repository;

import java.util.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementConfig;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

/**
 * @author btodupunoori
 *
 */
public final class CloudProductPriceManagementConfigSpecifications {
	
	public static Specification<CloudProductPriceManagementConfig> getPriceMgmtConfigByserviceIdNnameNstatus(final String sheetName, final String status, final Long serviceId,
																											 final String activeFrom, final String activeTo){
		
		return new Specification<CloudProductPriceManagementConfig>() {

			@Override
			public Predicate toPredicate(Root<CloudProductPriceManagementConfig> rootBase,CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();
				Join<CloudProductPriceManagementConfig, CloudService> rootWithService = rootBase.join("cloudService");
				
				if(!StringUtils.isEmpty(serviceId)){
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}
				
				if(!StringUtils.isEmpty(sheetName)){
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootBase.get("priceSheetName"), sheetName));
				}
				
				if(!StringUtils.isEmpty(status)){
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootBase.get("status"), ChangeManagementConfigStatus.valueOf(status)));
				}
				
				if(!StringUtils.isEmpty(activeFrom) && !StringUtils.isEmpty(activeTo)){
					Expression<Date> rootCategory = rootBase.get("activeFrom");
					 predicate = criteriaBuilder.and(predicate,criteriaBuilder.greaterThanOrEqualTo(rootCategory, DateFormatterUtility.formatDate(activeFrom)));		    
					 predicate = criteriaBuilder.and(predicate,criteriaBuilder.lessThanOrEqualTo(rootCategory, DateFormatterUtility.formatDate(activeTo)));
				}
				
				criteriaQuery.where(predicate);					
		  		return predicate;
			}
		};
		
	}
	
	public static Sort sortByIdAsc() {
        return new Sort(Sort.Direction.ASC, "id");
 }

}
