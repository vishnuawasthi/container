package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudGeography;

public class CloudGeographySpecifications {

  public static Specification<CloudGeography> getByGeographyCode(final String code ) {
	 
	  return new Specification<CloudGeography>(){
		@Override
		public Predicate toPredicate(Root<CloudGeography> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
			Predicate predicate = cb.conjunction();				
	  		if (!StringUtils.isEmpty(code)) {
	  			predicate= cb.and(predicate, cb.equal(root.get("geographyCode"), code));
	  		}
	  		return predicate;
		}
	};
}
  
  
  
  /**
	 * Returns a Sort object which sorts services in ascending order by using the
	 * Id.
	 * 
	 * @return
	 */
	public static Sort sortByIdAsc() {
		return new Sort(Sort.Direction.ASC, "id");
	}
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
}
