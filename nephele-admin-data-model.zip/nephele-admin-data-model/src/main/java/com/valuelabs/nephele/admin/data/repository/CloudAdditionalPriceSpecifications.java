package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudAdditionalPrice;
import com.valuelabs.nephele.admin.data.entity.CloudService;

@Slf4j
public final class CloudAdditionalPriceSpecifications  {
	
	 public static Specification<CloudAdditionalPrice> findPriceByServiceNStatus(final Long serviceId, final String status)
	 {		 
		  return new Specification<CloudAdditionalPrice>(){
			
			@Override
			public Predicate toPredicate(Root<CloudAdditionalPrice> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Join<CloudAdditionalPrice, CloudService> rootWithService = root.join("cloudService");
				Predicate predicate = criteriaBuilder.conjunction();		  		
				if(!StringUtils.isEmpty(status)) {
					Expression<String>  rootStatus = root.get("status");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), "%" + status.toLowerCase() + "%"));
				}				
				if(null != serviceId) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}				
		  		return predicate;
			}
		};
	 }


}
