package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.BundleStatus;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@SequenceGenerator(name = "bundle_seq", sequenceName = "bundle_seq", initialValue = 1)
@Entity
@Table(name = "bundle")
public class Bundle extends AbstractAuditEntity implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "bundle_seq")
  @Column(name = "bundle_id")
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "description")
  private String description;

  @Column(name = "status")
  @Enumerated(EnumType.STRING)
  private BundleStatus status;

  @Column(name = "logo_code")
  private String logoCode;

  @OneToMany(mappedBy = "bundle", cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  private Set<BundleCloudProduct> bundleCloudProducts = new HashSet<BundleCloudProduct>();

  @OneToMany(mappedBy = "bundle", cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  private Set<BundleExternalProduct> bundleExternalProduct = new HashSet<BundleExternalProduct>();
  
  
  
  
   
}
