package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@SequenceGenerator(name = "cloud_feed_seq", sequenceName = "cloud_feed_seq", initialValue = 1)
@Entity
@Table(name = "cloud_feed")
public class CloudFeed extends AbstractAuditEntity implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -30595648297874805L;

  @Id
  @GeneratedValue(generator = "cloud_feed_seq")
  @Column(name = "cloud_feed_id")
  private Long id;

  @Column(name = "feed_uuid", nullable = false, unique=true)
  private String uuid;

  @Column(name = "feed_title")
  private String title;

  @Column(name = "Link_self")
  private String self;

  @Column(name = "Link_next")
  private String next;

  @Column(name = "Link_previous")
  private String previous;
  
  @Column(name = "Link_last")
  private String last;
  
  @Column(name = "Link_current")
  private String current;

 /* @Column(name = "encoding")
  private String encoding;*/
  
  @Column(name = "author")
  private String author;
  
 /* @Column(name = "feed_type")
  private String feedType;
  
  @Column(name = "link")
  private String link;
  
  @Column(name = "description")
  private String description;*/
  
  @Column(name = "cloud_feed_published_date")
  private Date cloudFeedPublishedDate;
  
  @Column(name = "cloud_feed_updated_date")
  private Date cloudFeedUpdatedDate;
  
  /*@Column(name = "copyright")
  private String copyright;
  
  @Column(name = "language")
  private String language;
  */
  @Column(name = "entrys_size")
  private Long entrysSize;

  @OneToMany(mappedBy = "cloudFeed")
  private List<CloudFeedEntry> cloudFeedEntries = new ArrayList<CloudFeedEntry>();

}
