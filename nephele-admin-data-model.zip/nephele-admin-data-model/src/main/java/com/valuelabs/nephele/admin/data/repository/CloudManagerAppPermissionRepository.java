package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudManagerAppPermission;

public interface CloudManagerAppPermissionRepository extends  TableRepository<CloudManagerAppPermission, Long>, JpaSpecificationExecutor<CloudManagerAppPermission>{
	
	@Query("SELECT cap FROM CloudManagerAppPermission cap where cap.cloudManagerAppAccount.id = :accountId AND cap.cloudUserRole.roleId = :roleId")
	public CloudManagerAppPermission getPermissionByRoleNAccount(@Param("roleId")Long roleId, @Param("accountId")Long accountId);

	@Query("SELECT cap FROM CloudManagerAppPermission cap where cap.cloudManagerAppAccount.name = :accountName AND cap.cloudUserRole.roleId = :roleId")
	public CloudManagerAppPermission getPermissionByAccountName(@Param("accountName")String accountName,@Param("roleId")Long roleId);
}
