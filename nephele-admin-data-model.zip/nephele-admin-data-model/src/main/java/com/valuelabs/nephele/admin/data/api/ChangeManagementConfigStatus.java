package com.valuelabs.nephele.admin.data.api;

public enum ChangeManagementConfigStatus {
	DRAFT,
	ACTIVE,
	SCHEDULED,
	INACTIVE,
	ARCHIVED
}
