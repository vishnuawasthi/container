package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudResellerPremiumGroup;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudResellerCompanyDAO extends AbstractJpaDAO<CloudResellerCompany> {

	@PersistenceContext
	EntityManager entityManager;

	public CloudResellerCompanyDAO() {
		setClazz(CloudResellerCompany.class);
	}

	public void saveResellerCompanies(List<CloudResellerCompany> entityList) {

		for (CloudResellerCompany entity : entityList) {
			entityManager.persist(entity);
		}
	}
	
	public void updateResellerCompanies(List<CloudResellerCompany> entityList) {

		for (CloudResellerCompany entity : entityList) {
			entityManager.merge(entity);
		}
	}

	public List<Object[]> findResellerSummaryByDistributorPriceGroupId(Long distributorPriceGroupId) {
		TypedQuery<Object[]> query = entityManager.createNamedQuery("ResellerCompany.findResellerSummaryByResellerPremiumGroupId", Object[].class)
				.setParameter("distributorPriceGroupId", distributorPriceGroupId);
		return query.getResultList();
	}
	
	public CloudResellerCompany findByExternalResellerCode(String resellerCompanyCode){
		TypedQuery<CloudResellerCompany> query = entityManager.createNamedQuery("ResellerCompany.findByCode", CloudResellerCompany.class)
				.setParameter("resellerCompanyCode", resellerCompanyCode);
		
		return query.getSingleResult();
	}
	
	public Object findResellerCount() {
		TypedQuery<Object> query = entityManager.createNamedQuery("ResellerCompany.findResellerCount", Object.class);
		return query.getSingleResult();
	}
	
  public List<CloudResellerCompany> getResellersOnSearch(String companyName, String premiumGroupName, String email,
	  String address, String zipcode, String status) {
	List<CloudResellerCompany> list = null;
	CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	CriteriaQuery<CloudResellerCompany> criteriaQuery = criteriaBuilder.createQuery(CloudResellerCompany.class);
	Root<CloudResellerCompany> root = criteriaQuery.from(CloudResellerCompany.class);
	Predicate predicate = criteriaBuilder.conjunction();

	Join<CloudResellerCompany, CloudResellerPremiumGroup> rootWithPremiumGroup = root.join("premiumGroup");

	if (!StringUtils.isEmpty(companyName)) {
	  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("resellerCompanyName"), companyName));
	}

	if (!StringUtils.isEmpty(email)) {
	  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("email"), email));
	}

	if (!StringUtils.isEmpty(address)) {
	  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("addressLine1"), address));
	}

	if (!StringUtils.isEmpty(zipcode)) {
	  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("zipcode"), zipcode));
	}

	if (!StringUtils.isEmpty(status)) {
	  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("status"), status));
	}
	if (!StringUtils.isEmpty(premiumGroupName)) {
	  predicate = criteriaBuilder.and(predicate,
		  criteriaBuilder.equal(rootWithPremiumGroup.get("name"), premiumGroupName));
	}
	criteriaQuery.where(predicate);

	list = entityManager.createQuery(criteriaQuery).getResultList();
	return list;
  }

}
