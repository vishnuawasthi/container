package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;
@Setter
@Getter
@Accessors(chain = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_manager_app_account_seq", sequenceName = "cloud_manager_app_account_seq",
    initialValue = 1)
@Builder
@Table(name = "cloud_manager_app_account")
public class CloudManagerAppAccount extends AbstractAuditEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "cloud_manager_app_account_seq")
  @Column(name = "cloud_manager_app_account_id")
  private Long id;
  
  @Column(name = "name")
  private String name;
  
  @Column(name = "description")
  private String description;

  @OneToMany(mappedBy = "cloudManagerAppAccount", fetch = FetchType.EAGER)
  private Set<CloudManagerAppPermission> cloudManagerAppPermission = new HashSet<CloudManagerAppPermission>();

}
