/*package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.valuelabs.nephele.admin.data.entity.CloudServer;

public interface CodeSequenceGeneratorPatternRepository extends TableRepository<CloudServer, Long>{

	*//**
	 * Save the Invoice Lines into the CLOUD_INVOICE & CLOUD_INVOICE_LINES
	 * tables Updates Cloud Usage Data Status as COMPLETED after successful
	 * invoice creation
	 *//*
	@Query("SELECT NEXTVAL('CLOUD_INVOICE_NUMBER_SEQUENCE')  AS NUMBER")
	public Long getNextInvoicePatternNumber();

	*//**
	 * Get next sequence number for plan code pattern
	 *//*
	@Query("SELECT NEXTVAL('CLOUD_PLAN_NUMBER_SEQUENCE')  AS NUMBER")
	public Long getNextPlanPatternNumber();

	*//**
	 * Get next sequence number for Order code pattern
	 *//*
	@Query("SELECT NEXTVAL('CLOUD_ORDER_NUMBER_SEQUENCE')  AS NUMBER")
	public Long getNextOrderPatternNumber();

	*//**
	 * Get next sequence number for Additionalprice code pattern
	 *//*
	@Query("SELECT NEXTVAL('CLOUD_ADDITIONAL_PRICE_SEQUENCE')  AS NUMBER")
	public Long getNextAdditionalPricePatternNumber();
	
}
*/