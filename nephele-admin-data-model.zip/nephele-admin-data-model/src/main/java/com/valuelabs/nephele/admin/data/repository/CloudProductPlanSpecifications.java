package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.data.entity.CloudLocation;
import com.valuelabs.nephele.admin.data.entity.CloudProduct;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudService;

@Slf4j
public final class CloudProductPlanSpecifications  {
	
	 public static Specification<CloudProductPlan> getPublishedPlansByProductIdAndLocationIdAndCategory(final Long productId,final Long serviceId,
			 final Long locationId, final String flavorCategory, final Long ram) {
		 
		  return new Specification<CloudProductPlan>(){
			
			@Override
			public Predicate toPredicate(Root<CloudProductPlan> rootBase, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				
				Predicate predicate = criteriaBuilder.conjunction();
				Join<CloudProductPlan, CloudProduct> rootWithProduct = rootBase.join("cloudProduct");
				Join<CloudProductPlan, CloudLocation> rootWithLocation= rootBase.join("cloudLocation");
				Join<CloudProductPlan, CloudService> rootWithService= rootBase.join("cloudService");				
				Expression<String>  rootStatus = rootBase.get("status");
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), "%" + InventoryStatus.PUBLISHED.name().toLowerCase() + "%"));				
				predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("isPublished"), true));
				
				if (!StringUtils.isEmpty(flavorCategory)) {
					Expression<String>  rootCategory = rootBase.get("flavorCategory");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootCategory), "%" + flavorCategory.toLowerCase() + "%"));
				}				
				if(!StringUtils.isEmpty(serviceId)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}
				if (!StringUtils.isEmpty(productId)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithProduct.get("id"), productId));
					  
				}
				if ( !StringUtils.isEmpty(locationId)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithLocation.get("id"), locationId));
				}
				if (null != ram && ram > 0) {
					Expression<Long> rootRam = rootBase.get("sortKey");
					predicate = criteriaBuilder.and(predicate,criteriaBuilder.greaterThan(rootRam, ram));
				}
				
				/*criteriaQuery.where(predicate);				
				orderList.add(criteriaBuilder.asc(rootBase.get("sortKey")));
				criteriaQuery.orderBy(orderList);
				*/
		  		return predicate;
			}
		};
	 }
	 
	 public static Specification<CloudProductPlan>  getProductPlansByOperatingSystemIdNLocationIdNStatus(final Long serviceId, final Long operatingSystemId,
			 final Long locationId, final String status ,final String flavorCategory,final String serviceName,final String locationName, 
			 final String operatingSystemName, final String planName) {
		 
		    return new Specification<CloudProductPlan>(){
			
			@Override
			public Predicate toPredicate(Root<CloudProductPlan> rootBase, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				
				Predicate predicate = criteriaBuilder.conjunction();
				try{
				Join<CloudProductPlan, CloudService> rootWithService= rootBase.join("cloudService");
				Join<CloudProductPlan, CloudLocation> rootWithLocation= rootBase.join("cloudLocation");				 
				Join<CloudProductPlan, CloudProduct> rootWithProduct= rootBase.join("cloudProduct");
				Path<Object> rootWithOperatingSystem = rootWithProduct.get("cloudOperatingSystem");				 
				
				if(!StringUtils.isEmpty(serviceId)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				} 	
				
				if(!StringUtils.isEmpty(serviceName)) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithService.get("name"), serviceName));
				}
				
				if(!StringUtils.isEmpty(operatingSystemId)) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithOperatingSystem.get("id"), operatingSystemId));
				}	
				
				if(!StringUtils.isEmpty(operatingSystemName)) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithOperatingSystem.get("name"), operatingSystemName));
				}
				
				if(!StringUtils.isEmpty(status)) {
					Expression<String>  rootStatus = rootBase.get("status");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), "%" + status.toLowerCase() + "%"));
				}				 
				if (!StringUtils.isEmpty(flavorCategory)) {
					Expression<String>  rootCategory = rootBase.get("flavorCategory");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootCategory), "%" + flavorCategory.toLowerCase() + "%"));
				}				
				if (!StringUtils.isEmpty(locationId)) {
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithLocation.get("id"), locationId));
				}	
				
				if (!StringUtils.isEmpty(locationName)) {
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithLocation.get("name"), locationName));
				}
				
				if (!StringUtils.isEmpty(planName)) {
					Expression<String>  rootPlanName = rootBase.get("planName");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootPlanName), "%" + planName.toLowerCase() + "%"));
				}
				
				/*criteriaQuery.where(predicate);				
				orderByList.add(criteriaBuilder.asc(rootBase.get("id")));
				criteriaQuery.orderBy(orderByList);
				*/
				}catch(Exception ex){
					ex.printStackTrace();
				}
		  		return predicate;
			}
		};
	 }
	 
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts Objects in ascending order by using the sortKey.
	     * @return
	     */
	    public static Sort sortBySortkey() {
	        return new Sort(Sort.Direction.ASC, "sortKey");
	    }

	 
	
}
