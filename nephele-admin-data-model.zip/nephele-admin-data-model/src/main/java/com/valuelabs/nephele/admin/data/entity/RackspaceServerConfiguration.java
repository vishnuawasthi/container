package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
@SequenceGenerator(name="rackspace_server_configuration_seq",sequenceName="rackspace_server_configuration_seq",initialValue=1)
@Entity
@Table(name="rackspace_server_configuration")
public class RackspaceServerConfiguration extends AbstractAuditEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5964312760208441825L;
	
	@Id
    @GeneratedValue(generator="rackspace_server_configuration_seq")
    @Column(name = "rackspace_server_configuration_id", nullable = false)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="cloud_server_id")
	private CloudServer cloudServer;
	
	/*@ManyToOne
	@JoinColumn(name="cloud_operating_system_id")
	private CloudOperatingSystem cloudOperatingSystem;*/
	
	/*@ManyToOne
	@JoinColumn(name="cloud_rackspace_configuration_id")
	private CloudRackspaceConfiguration cloudRackspaceConfiguration;*/
	
	@ManyToOne
	@JoinColumn(name="cloud_product_plan_id", nullable = false)
	private CloudProductPlan cloudProductPlan;
	
	@Column(name = "status", nullable = false)
	private String status;
	

}
