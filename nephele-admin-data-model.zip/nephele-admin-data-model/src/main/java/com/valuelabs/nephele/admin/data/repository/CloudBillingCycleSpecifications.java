package com.valuelabs.nephele.admin.data.repository;

import java.sql.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudBillingCycle;

@Slf4j
public final class CloudBillingCycleSpecifications  {
	
	 public static Specification<CloudBillingCycle> findServersByFilter(final Date currentDate) {
		 
		  return new Specification<CloudBillingCycle>(){
			
			@Override
			public Predicate toPredicate(Root<CloudBillingCycle> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();
				
				predicate = criteriaBuilder.and(predicate,criteriaBuilder.notEqual(root.get("status"), "TERMINATED"));
				
				if ( !StringUtils.isEmpty(currentDate)) {
					
				  /*predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(currentDate, root.<Date>get("billingPeriodStartDate"), 
						  root.<Date>get("billingPeriodEndDate")));*/
					  
				}
				
		  		return predicate;
			}
		};
	 }
	 
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts persons in ascending order by using the last name.
	     * @return
	     */
	    public static Sort sortByLastNameAsc() {
	        return new Sort(Sort.Direction.ASC, "lastName");
	    }


}
