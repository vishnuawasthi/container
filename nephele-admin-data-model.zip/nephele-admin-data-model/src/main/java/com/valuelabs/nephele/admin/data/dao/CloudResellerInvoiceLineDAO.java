package com.valuelabs.nephele.admin.data.dao;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudResellerInvoiceLine;
import com.valuelabs.nephele.admin.data.entity.RankCustomerReport;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@Repository
public class CloudResellerInvoiceLineDAO extends AbstractJpaDAO<CloudResellerInvoiceLine> {

  @Autowired
  private EntityManager entityManager;

  public CloudResellerInvoiceLineDAO() {
    setClazz(CloudResellerInvoiceLine.class);
  }


  //Get Invoice data using Reseller ID
  public List<CloudResellerInvoiceLine> getInvoiceByResellerId(Integer resellerId) {
    TypedQuery<CloudResellerInvoiceLine> query = entityManager.createNamedQuery("invoice.findInvoiceByResellerId", CloudResellerInvoiceLine.class)
        .setParameter("cloudResellerCompanyId", resellerId);
    return query.getResultList();
  }

  public List<CloudResellerInvoiceLine> searchInvoice(Set<CloudCustomerCompany> customerList, Integer maxRecords, Date fromDate, Date toDate) {
    List<CloudResellerInvoiceLine> result = null;
    try {
      CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
      CriteriaQuery<CloudResellerInvoiceLine> criteriaQuery = criteriaBuilder.createQuery(CloudResellerInvoiceLine.class);
      Root<CloudResellerInvoiceLine> rootBase = criteriaQuery.from(CloudResellerInvoiceLine.class);
      Predicate predicate = criteriaBuilder.conjunction();

      if (null != customerList && !customerList.isEmpty())
        predicate = criteriaBuilder.and(predicate, criteriaBuilder.and(rootBase.get("cloudCustomerCompany").in(customerList)));

      if (null != fromDate && null != toDate)
        predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(rootBase.<java.sql.Date>get("created"), getFormattedDate(fromDate), getFormattedDate(toDate)));

      criteriaQuery.where(predicate);
      TypedQuery<CloudResellerInvoiceLine> query = entityManager.createQuery(criteriaQuery);

      if (null != maxRecords && !maxRecords.equals(0))
        query.setMaxResults(maxRecords);

      result = query.getResultList();
    } catch (Exception e) {
      log.error("Exception occurs while searching invoice detail: ", e.getMessage());
    }
    return result;
  }

  public List<RankCustomerReport> searchCustomer(Set<CloudCustomerCompany> customerList, Integer maxRecords, Date fromDate, Date toDate) {
    List<RankCustomerReport> reportList = new ArrayList<>();
    StringBuilder sb = new StringBuilder();
    boolean isWhereClauseAdded = false;
    sb.append("SELECT LINE.CLOUD_CUSTOMER_COMPANY_ID, SUM(LINE.TOTAL) AS AMOUNT, COMPANY.CUSTOMER_COMPANY_NAME ,")
        .append(" COMPANY.CUSTOMER_COMPANY_CODE FROM CLOUD_RESELLER_INVOICE_LINE LINE LEFT OUTER JOIN CLOUD_CUSTOMER_COMPANY COMPANY ")
        .append(" ON LINE.CLOUD_CUSTOMER_COMPANY_ID = COMPANY.CUSTOMER_COMPANY_ID ");
    if (null != customerList && !customerList.isEmpty()) {
      if (!isWhereClauseAdded) {
        sb.append("WHERE ");
        isWhereClauseAdded = true;
      }
      sb.append(" CLOUD_CUSTOMER_COMPANY_ID IN ( ").append(StringUtils.collectionToCommaDelimitedString(loadCustomerId(customerList)));
      sb.append(" ) ");
    }
    if (null != fromDate && null != toDate) {
      if (!isWhereClauseAdded) {
        sb.append("WHERE ");
        isWhereClauseAdded = true;
      } else
        sb.append(" AND ");
      sb.append(" LINE.CREATED BETWEEN ");
      sb.append("'").append(getFormattedDate(fromDate)).append("' AND ");
      sb.append("'").append(getFormattedDate(toDate)).append("'");
    }
    sb.append(" GROUP BY LINE.CLOUD_CUSTOMER_COMPANY_ID, COMPANY.CUSTOMER_COMPANY_NAME, COMPANY.CUSTOMER_COMPANY_CODE  ORDER BY AMOUNT DESC");
    sb.trimToSize();
    try {
      Query query = entityManager.createNativeQuery(sb.toString());

      if (null != maxRecords && !maxRecords.equals(0))
        query.setMaxResults(maxRecords);

      List<Object[]> results = query.getResultList();

      for (Object[] obj : results) {
        RankCustomerReport report = RankCustomerReport.builder()
            .customerId(((BigInteger) obj[0]).longValue())
            .revenue(String.valueOf(obj[1]))
            .customerName(String.valueOf(obj[2]))
            .customerCode(String.valueOf(obj[3]))
            .build();
        reportList.add(report);
      }
    } catch (Exception e) {
      log.error("Exception occurs while searching invoice detail: ", e.getMessage());
    }
    return reportList;
  }

  private Set<Long> loadCustomerId(Set<CloudCustomerCompany> customerList) {
    Set<Long> customerIdSet = new HashSet<>();
    if (null != customerList && !customerList.isEmpty()) {
      for (CloudCustomerCompany company : customerList) {
        customerIdSet.add(company.getId());
      }
    }
    return customerIdSet;
  }

  private Date getFormattedDate(Date givenDate) {
    Timestamp dateTimeValue = null;
    try {
      if (null != givenDate) {
        SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy-MM-DD HH:mm:ss z");
        Date date = timeStampFormat.parse(timeStampFormat.format(givenDate));
        dateTimeValue = new java.sql.Timestamp(date.getTime());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return dateTimeValue;
  }
}