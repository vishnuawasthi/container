package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudCustomerCompanyDAO extends AbstractJpaDAO<CloudCustomerCompany> {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public CloudCustomerCompanyDAO() {
		setClazz(CloudCustomerCompany.class);
	}
	
	public void persistAll(List<CloudCustomerCompany> entityList) {
		for ( int i=0; i<entityList.size(); i++ ) {
			CloudCustomerCompany entity = (CloudCustomerCompany) entityList.get(i);
			entityManager.persist(entity);
		}
	}
	
	public void updateAll(List<CloudCustomerCompany> entityList) {
		for ( int i=0; i<entityList.size(); i++ ) {
			CloudCustomerCompany entity = (CloudCustomerCompany) entityList.get(i);
			entityManager.merge(entity);
		}
	}
	
	public CloudCustomerCompany findByExternalCustomerCode(String customerCompanyCode) throws Exception{
		/*try{
			TypedQuery<CloudCustomerCompany> query = entityManager.createNamedQuery("CustomerCompany.findByCode", CloudCustomerCompany.class)
					.setParameter("customerCompanyCode", customerCompanyCode);
			
			return query.getSingleResult();
		}catch(Exception ex){
			throw new Exception(ex.getMessage());
		}*/
		TypedQuery<CloudCustomerCompany> query = entityManager.createNamedQuery("CustomerCompany.findByCode", CloudCustomerCompany.class)
				.setParameter("customerCompanyCode", customerCompanyCode);
		
		return query.getSingleResult();
	}
}
