package com.valuelabs.nephele.admin.data.repository;

public class ServiceIndustryVerticalSpecifications {

}
