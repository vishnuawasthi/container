package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.valuelabs.nephele.admin.data.entity.Bundle;

public interface BundleRepository extends TableRepository<Bundle, Long>, JpaSpecificationExecutor<Bundle> {
	@Query("FROM   Bundle bundle WHERE bundle.id in (:bundleIds) ORDER BY bundle.id ASC ")
	public List<Bundle> findBundlesByIds(@Param("bundleIds") List<Long> bundleIds);
	
	@Modifying
    @Transactional
    @Query("delete from BundleCloudProduct rcp where rcp.bundle.id = ?1")
    void deleteByBundleId(Long bundleId);
	
	@Query("FROM Bundle b where b.status = :status")
	public List<Bundle> getBundlesByStatus(@Param("status") String status);
}
