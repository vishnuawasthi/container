package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudSoftlayerCPUConfiguration;

public interface CloudSoftLayerCPUConfigurationRepository extends TableRepository<CloudSoftlayerCPUConfiguration, Long>, JpaSpecificationExecutor<CloudSoftlayerCPUConfiguration>{

}
