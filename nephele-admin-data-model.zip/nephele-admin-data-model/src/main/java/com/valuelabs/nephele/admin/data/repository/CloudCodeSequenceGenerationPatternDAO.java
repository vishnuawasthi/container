package com.valuelabs.nephele.admin.data.repository;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudResellerInvoice;

@Slf4j
@Repository
public class CloudCodeSequenceGenerationPatternDAO extends AbstractJpaDAO<CloudResellerInvoice> {

  @Autowired
  private EntityManager entityManager;

  public CloudCodeSequenceGenerationPatternDAO() {
    setClazz(CloudResellerInvoice.class);
  }

  /**
   * Save the Invoice Lines into the CLOUD_INVOICE & CLOUD_INVOICE_LINES tables
   * Updates Cloud Usage Data Status as COMPLETED after successful invoice creation
   */
  public Long getNextInvoicePatternNumber() {
    Query query = entityManager.createNativeQuery("SELECT NEXTVAL('CLOUD_INVOICE_NUMBER_SEQUENCE')  AS NUMBER");
    BigInteger result = (BigInteger) query.getSingleResult();
    return result.longValue();
  }
  
  /**
   * Get next sequence number for plan code pattern
   */
  public Long getNextPlanPatternNumber() {
    Query query = entityManager.createNativeQuery("SELECT NEXTVAL('CLOUD_PLAN_NUMBER_SEQUENCE')  AS NUMBER");
    BigInteger result = (BigInteger) query.getSingleResult();
    return result.longValue();
  }
  
  /**
   * Get next sequence number for Order code pattern
   */
  public Long getNextOrderPatternNumber() {
    Query query = entityManager.createNativeQuery("SELECT NEXTVAL('CLOUD_ORDER_NUMBER_SEQUENCE')  AS NUMBER");
    BigInteger result = (BigInteger) query.getSingleResult();
    return result.longValue();
  }
  
  /**
   * Get next sequence number for Additionalprice code pattern
   */
  public Long getNextAdditionalPricePatternNumber() {
    Query query = entityManager.createNativeQuery("SELECT NEXTVAL('CLOUD_ADDITIONAL_PRICE_SEQUENCE')  AS NUMBER");
    BigInteger result = (BigInteger) query.getSingleResult();
    return result.longValue();
  }


}