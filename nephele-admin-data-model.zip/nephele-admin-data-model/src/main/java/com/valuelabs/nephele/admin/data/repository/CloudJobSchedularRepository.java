package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudJobSchedular;

public interface CloudJobSchedularRepository extends TableRepository<CloudJobSchedular, Long>, JpaSpecificationExecutor<CloudJobSchedular> {
	
	@Query("select ce from  CloudJobSchedular ce order by ce.id desc") 
	public Page<CloudJobSchedular> findRecentRecord(Pageable pageable);
	
	@Query(" Select ce from CloudJobSchedular ce where ce.status =:status")
	public List<CloudJobSchedular> getByStatus(@Param("status")String status);
	
	@Query("select ce from  CloudJobSchedular ce where ce.status='ACTIVE'") 
	public Page<CloudJobSchedular> findActiveRecords(Pageable pageable);
}
