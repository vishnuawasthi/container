package com.valuelabs.nephele.admin.data.api;

public enum MeteringDataStatus {

	PENDING,
	COMPLETED
}
