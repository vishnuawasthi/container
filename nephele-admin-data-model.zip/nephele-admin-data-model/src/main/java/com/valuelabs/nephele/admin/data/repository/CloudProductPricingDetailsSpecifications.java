package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudRackspacePriceUnitMeasure;
import com.valuelabs.nephele.admin.data.entity.CloudRackspacePricingDetails;

@Slf4j
public final class CloudProductPricingDetailsSpecifications  {
	
	 public static Specification<CloudRackspacePricingDetails> getProductPlan(final String flavorId,final String osType,
			 final String options, final String geo) {
		 
		  return new Specification<CloudRackspacePricingDetails>(){
			
			@Override
			public Predicate toPredicate(Root<CloudRackspacePricingDetails> rootBase, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				
				Predicate predicate = criteriaBuilder.conjunction();
				Join<CloudRackspacePricingDetails, CloudRackspacePriceUnitMeasure> rootWithUnitMeasure = rootBase.join("cloudRackspacePriceUnits");
				
				if(!StringUtils.isEmpty(osType)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("flavorId"), flavorId));
				}							
				if(!StringUtils.isEmpty(osType)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("osType"), osType));
				}
				if (!StringUtils.isEmpty(options)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("options"), options));
					  
				}
				if ( !StringUtils.isEmpty(geo)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithUnitMeasure.get("geo"), geo));
				}
				
				//log.debug("pre"+predicate);
		  		return predicate;
			}
		};
	 }
	 
	
	 
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts Objects in ascending order by using the sortKey.
	     * @return
	     */
	    public static Sort sortBySortkey() {
	        return new Sort(Sort.Direction.ASC, "sortKey");
	    }

	 
	
}
