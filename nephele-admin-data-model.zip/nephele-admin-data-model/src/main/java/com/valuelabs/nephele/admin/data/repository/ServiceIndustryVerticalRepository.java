package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.ServiceIndustryVertical;

public interface ServiceIndustryVerticalRepository extends TableRepository<ServiceIndustryVertical, Long>, JpaSpecificationExecutor<ServiceIndustryVertical> {

	@Query("SELECT sv FROM  ServiceIndustryVertical sv WHERE sv.name = :name") 
	public ServiceIndustryVertical findByServiceName(@Param("name") String name);
}
