package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudRackspaceConfiguration;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudConfigurationDAO extends AbstractJpaDAO<CloudRackspaceConfiguration> {

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudConfigurationDAO() {
		setClazz(CloudRackspaceConfiguration.class );
	}
	
	public List<CloudRackspaceConfiguration> readByRamAndDisk(Integer minRam, Integer minDisk) {
		TypedQuery<CloudRackspaceConfiguration> query =
				entityManager.createNamedQuery("RackspaceConfiguration.readByRamAndDisk", CloudRackspaceConfiguration.class).
									setParameter("minRam", minRam).
									setParameter("minDisk", minDisk);
		return query.getResultList();
		
	}
	
	
	public List<CloudRackspaceConfiguration> readByStatus(String status) {
		TypedQuery<CloudRackspaceConfiguration> query =
				entityManager.createNamedQuery("RackspaceConfiguration.readByStatus", CloudRackspaceConfiguration.class).
									setParameter("status", status);
		return query.getResultList();
		
	}
	
	public List<Object[]> findRackspaceConfigurationSummaryByServiceId(Long serviceId) {
		TypedQuery<Object[]> query = entityManager.createNamedQuery("CloudRackspaceConfiguration.findRackspaceConfigurationSummaryByServiceId",
				Object[].class).setParameter("serviceId", serviceId);
		return query.getResultList();
	}
	
}
