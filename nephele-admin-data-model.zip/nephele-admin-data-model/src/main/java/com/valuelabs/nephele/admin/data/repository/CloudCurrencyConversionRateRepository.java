package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.NepheleCurrency;
import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRate;

public interface CloudCurrencyConversionRateRepository  extends TableRepository<CloudCurrencyConversionRate, Long>, JpaSpecificationExecutor<CloudCurrencyConversionRate>{

  @Query("from CloudCurrencyConversionRate cr where cr.sourceCurrency = :sourceCurrency and cr.targetCurrency = :targetCurrency")
  CloudCurrencyConversionRate getCloudCurrencyConversionRate(@Param("sourceCurrency") NepheleCurrency sourceCurrency, @Param("targetCurrency") NepheleCurrency targetCurrency);

}
