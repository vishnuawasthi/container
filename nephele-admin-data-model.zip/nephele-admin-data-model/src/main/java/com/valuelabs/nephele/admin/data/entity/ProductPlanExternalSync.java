package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.DbsSyncStatus;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Entity
@Table(name = "product_plan_external_sync")
public class ProductPlanExternalSync extends AbstractAuditEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3818210224734189155L;

	@Id
	@Column(name = "plan_code")
	private String planCode;

	@Column(name = "status")
	@Enumerated(EnumType.STRING)
	private DbsSyncStatus status;

	@Column(name = "request",columnDefinition = "TEXT")
	private String request;

	@Column(name = "response",columnDefinition = "TEXT")
	private String response;

	@Column(name = "error_message")
	private String errorMessage;

}
