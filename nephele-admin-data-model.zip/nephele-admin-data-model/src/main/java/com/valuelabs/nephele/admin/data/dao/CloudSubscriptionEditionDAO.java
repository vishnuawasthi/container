package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;
import com.valuelabs.nephele.admin.data.entity.CloudSubscriptionEdition;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudSubscriptionEditionDAO extends AbstractJpaDAO<CloudSubscriptionEdition> {

	public CloudSubscriptionEditionDAO(){
		
		setClazz(CloudSubscriptionEdition.class);
	}
}
