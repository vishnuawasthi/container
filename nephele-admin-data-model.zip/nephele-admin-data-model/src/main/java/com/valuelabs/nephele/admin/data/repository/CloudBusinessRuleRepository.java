package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudBusinessRule;

public interface CloudBusinessRuleRepository extends TableRepository<CloudBusinessRule, Long>, JpaSpecificationExecutor<CloudBusinessRule>{

}
