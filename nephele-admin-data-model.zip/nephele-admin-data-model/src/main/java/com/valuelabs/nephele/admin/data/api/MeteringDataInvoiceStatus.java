package com.valuelabs.nephele.admin.data.api;

/**
 * Created by srikanth on 11/8/15.
 */
public enum MeteringDataInvoiceStatus {
  PENDING,
  COMPLETED,
  FAILED,
  REQUIRED,
  NOT_REQUIRED
}
