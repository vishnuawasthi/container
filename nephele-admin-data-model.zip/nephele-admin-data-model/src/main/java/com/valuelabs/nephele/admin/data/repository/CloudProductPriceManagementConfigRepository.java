package com.valuelabs.nephele.admin.data.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementConfig;

public interface CloudProductPriceManagementConfigRepository extends TableRepository<CloudProductPriceManagementConfig, Long>, JpaSpecificationExecutor<CloudProductPriceManagementConfig>{

	@Query("FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId")
	public List<CloudProductPriceManagementConfig> findByServiceId(@Param("serviceId") Long serviceId);	
	
	@Query("FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND status in ('DRAFT','SCHEDULED') ")
	public List<CloudProductPriceManagementConfig> findByServiceIdandStatus(@Param("serviceId") Long serviceId);
	
	@Query("FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND cpm.status =:status")	
	public List<CloudProductPriceManagementConfig> findByServiceIdandStatus(@Param("serviceId") Long serviceId, @Param("status") ChangeManagementConfigStatus status);
	
	@Query("Select count(*) FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND cpm.status =:status")	
	public Long findCountByServiceIdandStatus(@Param("serviceId") Long serviceId, @Param("status") ChangeManagementConfigStatus status);
	
	@Query("FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND cpm.status =:status AND cpm.priceSheetName =:sheetName")
	public List<CloudProductPriceManagementConfig> findByServiceIdandStatusandSheetname(@Param("serviceId") Long serviceId, @Param("status") ChangeManagementConfigStatus status ,@Param("sheetName") String sheetName); 
	
	@Query("FROM  CloudProductPriceManagementConfig cpm WHERE cpm.status ='ACTIVE'")
	public List<CloudProductPriceManagementConfig> findByActiveStatus();
	
	@Query("FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND cpm.activeTo >:billingEndDate OR cpm.status = 'ACTIVE'")
	public List<CloudProductPriceManagementConfig> findByDate(@Param("serviceId") Long serviceId, @Param("billingEndDate") Date billingEndDate);

}
