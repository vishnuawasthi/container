package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.valuelabs.nephele.admin.data.entity.CloudRackspacePricingDetails;

public interface CloudRackspacePricingDetailsRepository  extends TableRepository<CloudRackspacePricingDetails, Long>, JpaSpecificationExecutor<CloudRackspacePricingDetails>  {
 
 
	@Query(" FROM CloudRackspacePricingDetails  order by version desc")
	public List<CloudRackspacePricingDetails> getLatestVersion();	
	

}
