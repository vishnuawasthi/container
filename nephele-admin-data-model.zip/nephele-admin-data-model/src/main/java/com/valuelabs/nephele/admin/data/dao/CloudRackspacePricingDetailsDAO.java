package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudRackspacePricingDetails;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudRackspacePricingDetailsDAO extends AbstractJpaDAO<CloudRackspacePricingDetails> {

	public CloudRackspacePricingDetailsDAO() {
		setClazz(CloudRackspacePricingDetails.class);
	}
}
