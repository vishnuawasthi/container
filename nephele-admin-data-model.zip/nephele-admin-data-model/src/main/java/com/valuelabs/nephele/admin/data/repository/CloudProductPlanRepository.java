package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;

public interface CloudProductPlanRepository extends TableRepository<CloudProductPlan, Long>, JpaSpecificationExecutor<CloudProductPlan>{

	@Query(" FROM CloudProductPlan pp where pp.cloudProduct.id = :productId AND pp.status = 'PUBLISHED' order by pp.id")
	public List<CloudProductPlan> getPublishedPlansByProductId(@Param("productId") Long productId);	
	
	@Query(" FROM CloudProductPlan pp where pp.status = 'PUBLISHED' AND pp.cloudService.id= :serviceId  ORDER BY pp.id ASC")
	public List<CloudProductPlan> getPublishedPlansByServiceId(@Param("serviceId") Long serviceId);
	
	@Query(" FROM CloudProductPlan pp where pp.cloudProduct.id = :productId AND pp.cloudLocation.id = :locationId AND pp.status = 'PUBLISHED' order by pp.id")	
	public List<CloudProductPlan> getPublishedPlansByProductIdAndLocationId(@Param("productId") Long productId, @Param("locationId") Long locationId);
	
	@Query(" FROM CloudProductPlan pp where pp.status in ('STAGED')  order by pp.cloudProduct.id,pp.flavorCategory,pp.sortKey")
	public List<CloudProductPlan> getStagedProdcutPlans();
	
	@Query(" FROM CloudProductPlan pp where pp.status in ('DISCOVERED') AND pp.cloudService.id= :serviceId")
	public List<CloudProductPlan> getDiscoveredPlansByService(@Param("serviceId") Long serviceId);
	

	@Query(" FROM CloudProductPlan pp where pp.status in ('STAGED') AND pp.cloudService.id= :serviceId order by pp.cloudProduct.id,pp.flavorCategory,pp.sortKey")
	public List<CloudProductPlan> getStagedProdcutPlansWithServiceId(@Param("serviceId") Long serviceId);
	
	@Query(" FROM CloudProductPlan pp where pp.cloudService.id= :serviceId")
	public List<CloudProductPlan> getProdcutPlansByserviceId(@Param("serviceId") Long serviceId);
	
	@Query("SELECT  status, count(id) FROM  CloudProductPlan  cpp WHERE cpp.cloudService.id= :serviceId  GROUP BY status")
	public List<Object[]> findPlansSummary(@Param("serviceId") Long serviceId);
	
	
	@Query(" FROM CloudProductPlan pp where pp.id in ( :ids)  order by pp.id asc")	
	public List<CloudProductPlan> getPlansStatusByIds(@Param("ids") List<Long> ids);
	
}
