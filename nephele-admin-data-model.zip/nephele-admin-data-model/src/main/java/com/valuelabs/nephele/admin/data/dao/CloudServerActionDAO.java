package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudServerAction;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudServerActionDAO extends AbstractJpaDAO<CloudServerAction> {

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudServerActionDAO() {
		setClazz(CloudServerAction.class);
	}
	
	public List<CloudServerAction> getComputePriceByOSId(Long serverId){
		
		TypedQuery<CloudServerAction> query =
				entityManager.createNamedQuery("ComputePrice.findActiveByServerId", CloudServerAction.class).
									setParameter("serverId", serverId);
		
		return query.getResultList();
	}
}
