package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@SequenceGenerator(name = "cloud_user_role_seq", sequenceName = "cloud_user_role_seq", initialValue = 1)
@Table(name = "cloud_user_role")
public class CloudUserRole extends AbstractAuditEntity implements Serializable {
  
  private static final long serialVersionUID = -4671084411754048715L;

  @Id
  @GeneratedValue(generator ="cloud_user_role_seq")
  @Column(name = "role_id")
  private Long roleId;

  @Column(name = "role_name", unique = true)
  private String roleName;

  @Column(name = "role_description")
  private String roleDescription;

  @OneToMany(mappedBy = "userRole")
  private Set<CloudDistributorUser> distributorUserSet = new HashSet<CloudDistributorUser>();
  
  @OneToMany(mappedBy = "cloudUserRole", fetch = FetchType.EAGER)
  private Set<CloudManagerAppPermission> cloudManagerAppPermission = new HashSet<CloudManagerAppPermission>();
}