package com.valuelabs.nephele.admin.data.common;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * Created by ranjith on 28/12/15.
 */

@Setter
@Getter
@Builder
@Accessors(chain = true)
public class ReadCloudPayment {

  private Long paymentId;
  private Double total;
  private Long invoiceId;
  private Double invoiceAmount;
  private Double surcharge;
  private String paymentMode;
  private String transactionId;
  private String instrumentType;
  private Date fromDate;
  private Date toDate;

}
