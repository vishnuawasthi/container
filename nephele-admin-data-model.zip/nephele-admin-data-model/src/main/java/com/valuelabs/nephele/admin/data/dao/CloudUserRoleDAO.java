package com.valuelabs.nephele.admin.data.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudUserRole;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudUserRoleDAO extends AbstractJpaDAO<CloudUserRole> {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public CloudUserRoleDAO() {
		setClazz(CloudUserRole.class);
	}
	
	
	
	
	
}
