package com.valuelabs.nephele.admin.data.api;

public enum JobTypes {
	
	INVENTORY,
	METERINGDATA,
	ELASTICSEARCH,
	PRICEMANAGEMENT,
	SYNCPLAN,
	SYNCINVOICE,
	SYNCPAYMENTDATA,
	SOLARSEARCH,
	REBUILDBUNDLES

}
