package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementConfig;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudProductPriceMgmtConfigDAO extends AbstractJpaDAO<CloudProductPriceManagementConfig> {

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudProductPriceMgmtConfigDAO() {
		setClazz(CloudProductPriceManagementConfig.class);
	}
	
	  //Get Invoice data by status
	  public List<CloudProductPriceManagementConfig> findByServiceId(Long serviceId) {
	    TypedQuery<CloudProductPriceManagementConfig> query = entityManager.createNamedQuery("priceMgmtConfig.findByServiceId", CloudProductPriceManagementConfig.class)
	    		.setParameter("serviceId", serviceId);
	    return query.getResultList();
	  }  
	  
	  public List<CloudProductPriceManagementConfig> findByServiceIdandStatus(Long serviceId) {
		    TypedQuery<CloudProductPriceManagementConfig> query = entityManager.createNamedQuery("priceMgmtConfig.findByServiceIdandDraftScheduledStatus", CloudProductPriceManagementConfig.class)
		    		.setParameter("serviceId", serviceId);
		    return query.getResultList();
      }
	  
	  public List<CloudProductPriceManagementConfig> findByServiceIdandStatus(Long serviceId, String status) {
		    TypedQuery<CloudProductPriceManagementConfig> query = entityManager.createNamedQuery("priceMgmtConfig.findByServiceIdandStatus", CloudProductPriceManagementConfig.class)
		    		.setParameter("serviceId", serviceId)
		    		.setParameter("status", ChangeManagementConfigStatus.valueOf(status));
		    return query.getResultList();
	  }	  
	  
	  public List<CloudProductPriceManagementConfig> findByServiceIdandStatusandSheetname(Long serviceId, String status ,String sheetName) {
		    TypedQuery<CloudProductPriceManagementConfig> query = entityManager.createNamedQuery("priceMgmtConfig.findByServiceIdandStatusandSheetname", CloudProductPriceManagementConfig.class)
		    		.setParameter("serviceId", serviceId)
		    		.setParameter("status", ChangeManagementConfigStatus.valueOf(status))
		    		.setParameter("sheetName", sheetName);
		    return query.getResultList();
	  }	  
	
}
