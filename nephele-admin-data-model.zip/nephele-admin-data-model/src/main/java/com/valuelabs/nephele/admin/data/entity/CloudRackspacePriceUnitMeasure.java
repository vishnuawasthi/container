package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;
@Setter
@Getter
@Accessors(chain = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_rackspace_price_unit_measure_seq", sequenceName = "cloud_rackspace_price_unit_measure_seq",
    initialValue = 1)
@Builder
@Table(name = "cloud_rackspace_price_unit_measure")
public class CloudRackspacePriceUnitMeasure extends AbstractAuditEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "cloud_rackspace_price_unit_measure_seq")
  @Column(name = "cloud_rackspace_price_unit_measure_id")
  private Long id;  
  
  @Column(name = "currency")
  private String currency;
  
  @Column(name = "amount")
  private String amount;
  
  @Column(name = "geo")
  private String geo;
  
  @Column(name = "unit_of_measure")
  private String unitOfMeasure; 
  
  @ManyToOne
  @JoinColumn(name = "cloud_rackspace_pricing_details_id") 
  private CloudRackspacePricingDetails cloudRackspacePriceDetails ;
  
}
