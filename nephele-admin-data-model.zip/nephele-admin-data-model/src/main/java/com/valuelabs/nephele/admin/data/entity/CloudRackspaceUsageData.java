package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;

@NamedQueries({@NamedQuery(name = "ResellerUsageData.findByStatus",
		query = "FROM CloudRackspaceUsageData ud WHERE ud.resellerInvoiceStatus = :status AND ud.cloudCustomerCompany.id in :cloudCustomerCompanyList"),
@NamedQuery(name = "CustomerUsageData.findByStatus",
		query = "FROM CloudRackspaceUsageData ud WHERE ud.customerInvoiceStatus = :status AND ud.cloudCustomerCompany.id = :customerCompanyId")})
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_rackspace_usage_data_seq",sequenceName="cloud_rackspace_usage_data_seq", initialValue=1)
@Entity
@Table(name="cloud_rackspace_usage_data")
public class CloudRackspaceUsageData extends AbstractAuditEntity  implements Serializable {
	

	private static final long serialVersionUID = 7134383092451105658L;

	@Id
    @GeneratedValue(generator="cloud_rackspace_usage_data_seq")
    @Column(name = "cloud_rackspace_usage_data_id", nullable = false)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "CUSTOMER_COMPANY_ID")
	private CloudCustomerCompany cloudCustomerCompany;
	
	@ManyToOne
	@JoinColumn(name="cloud_server_id")
	private CloudServer cloudServer;
	
	@Column(name = "server_name")
	private String serverName;
	
	@Column(name = "csp_server_id", nullable = false)
	private String cspServerId;
	
	@Column(name = "product_type", nullable = false)
	private String productType;
	
	@ManyToOne
	@JoinColumn(name = "cloud_service_id")
	private CloudService cloudService;
	
	@Column(name = "service_type", nullable = false)
	private String serviceType;
	
	@Column(name = "flavour_name", nullable = false)
	private String flavourName;
	
	@Column(name = "usage_quantity", nullable = false)
	private Double usageQuantity;
	
	@Column(name = "unit_price", nullable = true)
	private Double unitPrice;
	
	@Column(name = "currency", nullable = false)
	private String currency;
	
	@Column(name = "total_price", nullable = true)
	private Double totalPrice;

	//TODO: Make this column as not null
	@Column(name = "CUSTOMER_INVOICE_STATUS", nullable = true)
	@Enumerated(EnumType.STRING)
	private MeteringDataInvoiceStatus customerInvoiceStatus;

	//TODO: Make this column as not null
	@Column(name = "RESELLER_INVOICE_STATUS", nullable = true)
	@Enumerated(EnumType.STRING)
	private MeteringDataInvoiceStatus resellerInvoiceStatus;
	
	@ManyToOne
	@JoinColumn(name = "cycle_id")
	private CloudBillingCycle billingCycle;
	
	@Column(name="event_start_time")
	private Date eventStartDate;
	
	@Column(name="event_end_time")
	private Date eventEndTime; 

	/*@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		CloudRackspaceUsageData that = (CloudRackspaceUsageData) o;

		if (cloudCustomerCompany != null ? !cloudCustomerCompany.equals(that.cloudCustomerCompany) : that.cloudCustomerCompany != null)
			return false;
		if (cloudServer != null ? !cloudServer.equals(that.cloudServer) : that.cloudServer != null) return false;
		if (cloudService != null ? !cloudService.equals(that.cloudService) : that.cloudService != null) return false;
		if (cspServerId != null ? !cspServerId.equals(that.cspServerId) : that.cspServerId != null) return false;
		if (currency != null ? !currency.equals(that.currency) : that.currency != null) return false;
		if (customerInvoiceStatus != that.customerInvoiceStatus) return false;
		if (id != null ? !id.equals(that.id) : that.id != null) return false;
		if (productType != null ? !productType.equals(that.productType) : that.productType != null) return false;
		if (resellerInvoiceStatus != that.resellerInvoiceStatus) return false;
		if (resourceName != null ? !resourceName.equals(that.resourceName) : that.resourceName != null) return false;
		if (resourceType != null ? !resourceType.equals(that.resourceType) : that.resourceType != null) return false;
		if (serverName != null ? !serverName.equals(that.serverName) : that.serverName != null) return false;
		if (totalPrice != null ? !totalPrice.equals(that.totalPrice) : that.totalPrice != null) return false;
		if (unit != null ? !unit.equals(that.unit) : that.unit != null) return false;
		if (unitPrice != null ? !unitPrice.equals(that.unitPrice) : that.unitPrice != null) return false;
		if (usage != null ? !usage.equals(that.usage) : that.usage != null) return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = id != null ? id.hashCode() : 0;
		result = 31 * result + (cloudCustomerCompany != null ? cloudCustomerCompany.hashCode() : 0);
		result = 31 * result + (cloudServer != null ? cloudServer.hashCode() : 0);
		result = 31 * result + (serverName != null ? serverName.hashCode() : 0);
		result = 31 * result + (cspServerId != null ? cspServerId.hashCode() : 0);
		result = 31 * result + (productType != null ? productType.hashCode() : 0);
		result = 31 * result + (cloudService != null ? cloudService.hashCode() : 0);
		result = 31 * result + (resourceType != null ? resourceType.hashCode() : 0);
		result = 31 * result + (resourceName != null ? resourceName.hashCode() : 0);
		result = 31 * result + (usage != null ? usage.hashCode() : 0);
		result = 31 * result + (unit != null ? unit.hashCode() : 0);
		result = 31 * result + (unitPrice != null ? unitPrice.hashCode() : 0);
		result = 31 * result + (currency != null ? currency.hashCode() : 0);
		result = 31 * result + (totalPrice != null ? totalPrice.hashCode() : 0);
		result = 31 * result + (customerInvoiceStatus != null ? customerInvoiceStatus.hashCode() : 0);
		result = 31 * result + (resellerInvoiceStatus != null ? resellerInvoiceStatus.hashCode() : 0);
		return result;
	}*/
}
