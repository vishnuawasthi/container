package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudServiceCredential;

public interface CloudServiceCredentialRepository extends TableRepository<CloudServiceCredential, Long>, JpaSpecificationExecutor<CloudServiceCredential> {

	@Query("FROM CloudServiceCredential sc where sc.cloudService.id = :cloudServiceId") 
	public CloudServiceCredential getCredentilsByServiceId(@Param("cloudServiceId") Long cloudServiceId);
}
