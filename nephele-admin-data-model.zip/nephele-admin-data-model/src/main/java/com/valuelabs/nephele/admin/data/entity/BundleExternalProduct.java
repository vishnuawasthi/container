package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name = "bundle_external_product_seq", sequenceName = "bundle_external_product_seq", initialValue = 1)
@Entity
@Table(name = "bundle_external_product")
public class BundleExternalProduct extends AbstractAuditEntity implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	  @Id
	  @GeneratedValue(generator = "bundle_external_product_seq")
	  @Column(name = "bundle_external_product_id", nullable = false)
	  private Long id;
	  
	  
	  @ManyToOne
	  @JoinColumn(name = "externalProduct_id")
	  private ExternalProduct externalProduct;
	  
	  @ManyToOne
	  @JoinColumn(name = "bundle_id")
	  private Bundle bundle;

}
