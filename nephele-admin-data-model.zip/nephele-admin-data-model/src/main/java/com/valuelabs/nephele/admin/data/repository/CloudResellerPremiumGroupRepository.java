package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudResellerPremiumGroup;

public interface CloudResellerPremiumGroupRepository  extends TableRepository< CloudResellerPremiumGroup, Long>, JpaSpecificationExecutor< CloudResellerPremiumGroup> {

  @Query("SELECT crp  from CloudResellerPremiumGroup crp where name = :name")
  public CloudResellerPremiumGroup findPremiumGroup(@Param("name") String name);
}
