package com.valuelabs.nephele.admin.data.repository;

import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudResellerPremiumGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import javax.persistence.criteria.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@Slf4j
public final class CloudResellerCompanySpecifications {
	
	 public static Specification<CloudResellerCompany> getResellersOnSearch(final String companyName,final String premiumGroupName,
			 final String email, final String address, final String zipcode, final String status) {
		 
		  return new Specification<CloudResellerCompany>(){
			  
			  @Override
				public Predicate toPredicate(Root<CloudResellerCompany> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
					
					Predicate predicate = criteriaBuilder.conjunction();
					Join<CloudResellerCompany, CloudResellerPremiumGroup> rootWithPremiumGroup = root.join("premiumGroup");

					if (!StringUtils.isEmpty(companyName)) {
					  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("resellerCompanyName"), companyName));
					}
					if (!StringUtils.isEmpty(email)) {
					  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("email"), email));
					}
					if (!StringUtils.isEmpty(address)) {
					  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("addressLine1"), address));
					}
					if (!StringUtils.isEmpty(zipcode)) {
					  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("zipcode"), zipcode));
					}
					if (!StringUtils.isEmpty(status)) {
					  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("status"), status));
					}
					if (!StringUtils.isEmpty(premiumGroupName)) {
					  predicate = criteriaBuilder.and(predicate,
					  criteriaBuilder.equal(rootWithPremiumGroup.get("name"), premiumGroupName));
					}
					return predicate;
				}
			  
		  };
		  
	 }
	 
	 public static Specification<CloudResellerCompany> findResellerByExternalResellerCode(final String externalResellerCode) {
	 
	  return new Specification<CloudResellerCompany>(){

		@Override
        public Predicate toPredicate(Root<CloudResellerCompany> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
      log.debug("findResellerByExternalResellerCode from repository start", new SimpleDateFormat("yyyy-MM-DD HH:mm:ss.SSS").format(new Date()));
      Predicate predicate = criteriaBuilder.conjunction();
			
			if (!StringUtils.isEmpty(externalResellerCode)) {
			  Expression<String>  resellerCompanyCode = root.get("resellerCompanyCode");
				predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(criteriaBuilder.lower(resellerCompanyCode), externalResellerCode.toLowerCase()));
			}
      log.debug("findResellerByExternalResellerCode from repository end", new SimpleDateFormat("yyyy-MM-DD HH:mm:ss.SSS").format(new Date()));
      return predicate;
        }

    };
	 
	 }
	
	 
	 
	 

}
