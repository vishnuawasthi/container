package com.valuelabs.nephele.admin.data.api;

public enum NepheleTimeZone {

	UTC,
	/*GMT,
	IST,
	ACT,
	AET*/
	
}
