package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudServiceProvider;

public interface CloudServiceProviderRepository extends TableRepository<CloudServiceProvider, Long>, JpaSpecificationExecutor<CloudServiceProvider>{

}
