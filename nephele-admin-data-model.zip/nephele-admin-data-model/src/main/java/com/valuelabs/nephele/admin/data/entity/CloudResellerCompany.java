package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NamedQueries({@NamedQuery(name = "ResellerCompany.findResellerSummaryByResellerPremiumGroupId", query = "SELECT  crc.premiumGroup.name , count(id) FROM  CloudResellerCompany crc "
																										   + "WHERE crc.premiumGroup.id =:resellerPremiumGroupId "
																										   + "GROUP BY crc.premiumGroup.name "),
			   @NamedQuery(name = "ResellerCompany.findByCode", query = " FROM CloudResellerCompany rc where rc.resellerCompanyCode = :resellerCompanyCode"),
			   
			   @NamedQuery(name = "ResellerCompany.findResellerCount", query = "SELECT  count(id) FROM  CloudResellerCompany crc") 
			})

//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_reseller_company_seq", sequenceName = "cloud_reseller_company_seq", initialValue = 1)
@Table(name = "cloud_reseller_company")
public class CloudResellerCompany extends AbstractAuditEntity implements Serializable //extends CloudUserType 
{
  /**
   *
   */
  private static final long serialVersionUID = -4698123407483358168L;

  @Id
  @GeneratedValue(generator = "cloud_reseller_company_seq")
  @Column(name = "RESELLER_COMPANY_ID")
  private Long id;

  @Column(name = "RESELLER_COMPANY_NAME")
  private String resellerCompanyName;

  @Column(name="first_name")
  private String firstName;
  
  @Column(name="last_name")
  private String lastName;
  
  @Column(name="email")
  private String email;
  
  @Column(name="address_line1")
  private String addressLine1;
  
  @Column(name="address_line2")
  private String addressLine2;
  
  @Column(name="credit_card_token")
  private String creditCardToken; 
  
  @Column(name="city")
  private String city;
  
  @Column(name="state")
  private String state;
  
  @Column(name="country")
  private String country;
  
  @Column(name="zipcode")
  private String zipcode;
  
  @Column(name="reseller_company_code" , unique=true , nullable= false)
  private String resellerCompanyCode;
  
  @Column(name = "isActive", nullable = true)
  private Boolean isActive;
  
  @Column(name="account_hold_Status")
  private Boolean accountHoldStatus;
  
  //@Column(name="credit_card_expiry_date")
  //private Date creditCardExpiryDate;
  
  @Column(name="credit_card_expiry_year")
  private Integer creditCardExpiryYear;
  
  @Column(name="credit_card_expiry_month")
  private Integer creditCardExpiryMonth;
  
  @Column(name="abn_number")
  private String abnNumber;
  
  @Column(name="terr_code")
  private String terrCode;
  
  @Column(name="credit_card_type")
  private String creditCardType;
  
  @Column(name="sales_person")
  private String salesPerson;
  
  @Column(name = "country_code_un")
  private String countryCodeUN;
  
  @Column(name = "country_code_iso")
  private String countryCodeISO;
  /*@ManyToOne
  @JoinColumn(name = "DISTRIBUTOR_COMPANY_ID", nullable = true)
  private CloudDistributorCompany cloudDistributorCompany;*/

  @OneToMany(mappedBy = "cloudResellerCompany", fetch = FetchType.EAGER)
  private Set<CloudCustomerCompany> cloudCustomerCompanies = new HashSet<CloudCustomerCompany>();

  @OneToMany(mappedBy = "cloudResellerCompany")
  private Set<CloudResellerUser> cloudResellerUsers = new HashSet<CloudResellerUser>();

  @OneToMany(mappedBy = "cloudResellerCompany")
  private Set<CloudResellerInvoice> cloudInvoiceSet = new HashSet<CloudResellerInvoice>();

  @ManyToOne
  @JoinColumn(name = "cloud_reseller_premium_group_id")
  private CloudResellerPremiumGroup premiumGroup;

}