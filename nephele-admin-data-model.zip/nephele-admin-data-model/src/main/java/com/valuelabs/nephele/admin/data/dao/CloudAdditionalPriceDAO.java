package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudAdditionalPrice;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudAdditionalPriceDAO extends AbstractJpaDAO<CloudAdditionalPrice> {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public CloudAdditionalPriceDAO() {
		setClazz(CloudAdditionalPrice.class);
	}
	
	public List<CloudAdditionalPrice> findByCloudServiceIdandStatus(Long serviceId, String status) {
	  return entityManager.createNamedQuery("CloudAdditionalPrice.byCloudServiceId", CloudAdditionalPrice.class)
	       .setParameter("serviceId", serviceId).setParameter("status", status).getResultList();
	}
	
	public List<CloudAdditionalPrice> findPriceByServiceNStatus(Long serviceId, String status) {	
		List<CloudAdditionalPrice> list =   null;
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CloudAdditionalPrice> criteriaQuery = criteriaBuilder.createQuery(CloudAdditionalPrice.class);
		Root<CloudAdditionalPrice> rootBase = criteriaQuery.from(CloudAdditionalPrice.class);
		Predicate predicate = criteriaBuilder.conjunction();
		Join<CloudAdditionalPrice, CloudService> rootWithService = rootBase.join("cloudService");
		if(!StringUtils.isEmpty(status)) {
			Expression<String>  rootStatus = rootBase.get("status");
			predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), "%" + status.toLowerCase() + "%"));
		}
		
		if(null != serviceId) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
		}
		
		criteriaQuery.where(predicate);
		
		list =entityManager.createQuery(criteriaQuery).getResultList();
		
		return list;
	}
}
