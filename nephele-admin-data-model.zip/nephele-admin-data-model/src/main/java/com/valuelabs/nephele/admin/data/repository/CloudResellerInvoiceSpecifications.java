package com.valuelabs.nephele.admin.data.repository;

import com.google.common.base.Strings;
import com.valuelabs.nephele.admin.data.api.InvoiceStatus;
import com.valuelabs.nephele.admin.data.common.ReadCloudInvoice;
import com.valuelabs.nephele.admin.data.entity.CloudResellerInvoice;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by ranjith on 5/10/15.
 */


@Slf4j
public class CloudResellerInvoiceSpecifications {
  public static Specification<CloudResellerInvoice> searchInvoice(final ReadCloudInvoice request) {
    return new Specification<CloudResellerInvoice>() {
      @Override
      public Predicate toPredicate(Root<CloudResellerInvoice> rootBase, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {

        Predicate predicate = criteriaBuilder.conjunction();
        Expression<String> path = rootBase.<String>get("cloudInvoiceNumber");
        Expression<String> upperInvoice = criteriaBuilder.upper(path);
        Path<Object> pathObject = rootBase.join("cloudResellerCompany").get("id");
        Path<Object> serviceCodeObj = rootBase.join("cloudService").get("serviceCode");
        Path<Object> serviceIdObj = rootBase.join("cloudService").get("id");
        Path<Object> resellerCodeObj = rootBase.join("cloudResellerCompany").get("resellerCompanyCode");
        Path<Object> resellerCompanyName = rootBase.join("cloudResellerCompany").get("resellerCompanyName");

        if (!Strings.isNullOrEmpty(request.getInvoiceNumber()))
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(upperInvoice, "%" + request.getInvoiceNumber().toUpperCase() + "%"));

        if (!Strings.isNullOrEmpty(request.getStatus()))
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootBase.get("invoiceStatus"), InvoiceStatus.valueOf(request.getStatus())));

        if (!Strings.isNullOrEmpty(request.getNotEqualStatus()))
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.notEqual(rootBase.get("invoiceStatus"), InvoiceStatus.valueOf(request.getNotEqualStatus())));

        if (null != request.getFromDate() && null != request.getToDate())
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(rootBase.<Date>get("created"), getFormattedDate(request.getFromDate()), getFormattedDate(request.getToDate())));

        if (null != request.getBillingStartDate() && null != request.getBillingEndDate()) {
          predicate = criteriaBuilder.and(criteriaBuilder.lessThanOrEqualTo(rootBase.<Date>get("toDate"), getFormattedDate(request.getBillingEndDate())),
              criteriaBuilder.greaterThanOrEqualTo(rootBase.<Date>get("fromDate"), getFormattedDate(request.getBillingStartDate())));
        }

        if (null != request.getFromDueDate() && null != request.getToDueDate())
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(rootBase.<Date>get("dueDate"), getFormattedDate(request.getFromDueDate()), getFormattedDate(request.getToDueDate())));
        else if (null == request.getFromDueDate() && null != request.getToDueDate())
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.lessThan(rootBase.<Date>get("dueDate"), getFormattedDate(request.getToDueDate())));

        if (null != request.getResellerId() && !request.getResellerId().equals(0L))
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(pathObject, request.getResellerId()));

        if (null != request.getResellerCode() && !request.getResellerCode().isEmpty())
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(resellerCodeObj, request.getResellerCode()));

        if (null != request.getResellerName() && !request.getResellerName().isEmpty())
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(resellerCompanyName, request.getResellerName()));

        if (null != request.getServiceCode() && !request.getServiceCode().isEmpty())
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceCodeObj, request.getServiceCode()));

        if (null != request.getServiceId() && !request.getServiceId().equals(0L))
          predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceIdObj, request.getServiceId()));

        return predicate;
      }
    };
  }

  private static Date getFormattedDate(Date givenDate) {
    Timestamp dateTimeValue = null;
    try {
      if (null != givenDate) {
        SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy-MM-DD HH:mm:ss z");
        java.util.Date date = timeStampFormat.parse(timeStampFormat.format(givenDate));
        dateTimeValue = new java.sql.Timestamp(date.getTime());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return dateTimeValue;
  }

}
