package com.valuelabs.nephele.admin.data.dao;

import com.valuelabs.nephele.admin.data.entity.CloudLifeCycleConfig;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

@Repository
@Slf4j
public class CloudLifeCycleConfigDAO extends AbstractJpaDAO<CloudLifeCycleConfig>{
	
	
	@PersistenceContext
	EntityManager entityManager;
	
	public CloudLifeCycleConfigDAO() {
		setClazz(CloudLifeCycleConfig.class );
	}

	public CloudLifeCycleConfig getConfigDetailByKey(String key) {
		CloudLifeCycleConfig cycleConfig = null;
		try {
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaQuery<CloudLifeCycleConfig> criteriaQuery = criteriaBuilder.createQuery(CloudLifeCycleConfig.class);
			Root<CloudLifeCycleConfig> rootBase = criteriaQuery.from(CloudLifeCycleConfig.class);
			Predicate predicate = criteriaBuilder.conjunction();

			if (null != key && !key.isEmpty())
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootBase.get("distributorKey"), key));

			criteriaQuery.where(predicate);
			TypedQuery<CloudLifeCycleConfig> query = entityManager.createQuery(criteriaQuery);

			cycleConfig = query.getSingleResult();
		} catch (Exception e) {
			log.error("Exception occurs while retrieving the details from DB: ", e.getMessage());
		}
		return cycleConfig;
	}

}
