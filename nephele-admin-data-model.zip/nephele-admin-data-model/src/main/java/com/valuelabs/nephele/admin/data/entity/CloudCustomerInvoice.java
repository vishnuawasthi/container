package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.InvoiceStatus;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

@NamedQueries({@NamedQuery(name = "CloudCustomerInvoice.findBystatus", query = "FROM  CloudCustomerInvoice c WHERE c.invoiceStatus =:status"),
    @NamedQuery(name = "CloudCustomerInvoice.findByDates", query = "FROM  CloudCustomerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate"),
    @NamedQuery(name = "CloudCustomerInvoice.findByDatesAndStatus", query = "FROM  CloudCustomerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate AND c.invoiceStatus=:status"),
    @NamedQuery(name = "CloudCustomerInvoice.findByCustId", query = "FROM  CloudCustomerInvoice c WHERE c.cloudCustomerCompany.id=:customerId")})
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name = "cloud_customer_invoice_seq", sequenceName = "cloud_customer_invoice_seq", initialValue = 1)
@Entity
@Table(name = "cloud_customer_invoice")
public class CloudCustomerInvoice extends AbstractAuditEntity implements Serializable {
  /**
   *
   */
  private static final long serialVersionUID = -1474672809756906149L;

  @Id
  @GeneratedValue(generator = "cloud_customer_invoice_seq")
  @Column(name = "cloud_customer_invoice_id", nullable = false)
  private Long id;

  @Column(name = "cloud_reseller_invoice_number")
  private String CloudInvoiceNumber;

  @Column(name = "currency")
  private String currency;

  @Column(name = "gross_total")
  private Double grossTotal;

  @Column(name = "tax")
  private Double tax;

  @Column(name = "net_total")
  private Double netTotal;
/*
  @Column(name = "is_closed")
  private Boolean isClosed;*/

  @Column(name = "due_date")
  @Temporal(TemporalType.DATE)
  private Date dueDate;
/*
  @Column(name = "created_date")
  private Date createdDate;*/

  @Column(name = "closed_date")
  private Date closedDate;

  @Column(name = "status")
  @Enumerated(EnumType.STRING)
  private InvoiceStatus invoiceStatus;

  @OneToMany(mappedBy = "cloudCustomerInvoice", cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  private List<CloudCustomerInvoiceLine> cloudCustomerInvoiceLineList;

  @OneToMany(mappedBy = "cloudInvoice")
  private Set<CloudPayment> cloudPayments;

  @ManyToOne
  @JoinColumn(name = "CLOUD_CUSTOMER_COMPANY_ID")
  private CloudCustomerCompany cloudCustomerCompany;

  @ManyToOne
  @JoinColumn(name = "CLOUD_RESELLER_COMPANY_ID")
  private CloudResellerCompany cloudResellerCompany;

  @ManyToOne
  @JoinColumn(name = "CLOUD_SERVICE_ID")
  private CloudService cloudService;

  @Column(name = "total_usage")
  private Double totalUsage;

  @Column(name = "discount_percentage")
  private Double discountPercentage;

  @Column(name = "discount_amount")
  private Double discountAmount;

  @Column(name = "from_date")
  private Date fromDate;

  @Column(name = "to_date")
  private Date toDate;
}
