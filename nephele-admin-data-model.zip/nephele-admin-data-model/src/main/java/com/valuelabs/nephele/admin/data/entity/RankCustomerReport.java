package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
@Getter
@Setter
public class RankCustomerReport {

  private Long customerId;

  private String customerCode;

  private String revenue;

  private String customerName;
}
