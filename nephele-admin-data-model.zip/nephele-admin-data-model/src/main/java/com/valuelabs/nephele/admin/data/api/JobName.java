package com.valuelabs.nephele.admin.data.api;

/**
 * Created by btodupunoori.
 */
public enum JobName {
  VENDOR_METERING,
  NEPHELE_METERING,
  INVOICE,
  PRICING_DATA
}
