package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name = "cloud_additional_price_seq", sequenceName = "cloud_additional_price_seq", initialValue = 1)
@NamedQueries({
	@NamedQuery(name = "CloudAdditionalPrice.byCloudServiceId", query = "from CloudAdditionalPrice where cloudService.id = :serviceId and status = :status")
})
@Entity
@Table(name = "cloud_additional_price")
public class CloudAdditionalPrice extends AbstractAuditEntity implements Serializable {


	private static final long serialVersionUID = 6983461072842215979L;
	
	@Id
	@GeneratedValue(generator = "cloud_additional_price_seq")
	@Column(name = "cloud_additional_price_id")
	private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name = "price", columnDefinition="double precision default '0.0'")
	private Double price;
	
	@Column(name = "status", nullable = true)
    private String status;

	@ManyToOne
	@JoinColumn(name = "cloud_Service_id")
	private CloudService cloudService;
	
	@Column(name="location")
	private String location;
	
	@Column(name="service_type")
	private String serviceType;
	
	@Column(name="description")
	private String description;
	
	 @Column(name = "plan_code", nullable = true)
	 private String planCode;
	}
