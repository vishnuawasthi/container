package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudLocation;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
@Repository
public class CloudLocationDAO extends AbstractJpaDAO<CloudLocation> {

	@PersistenceContext
	EntityManager entityManager;

	public CloudLocationDAO() {
		setClazz(CloudLocation.class);
	}

	public List<CloudLocation> findByStatus(String status) {
		TypedQuery<CloudLocation> query = entityManager.createNamedQuery("CloudLocation.findByStatus", CloudLocation.class).setParameter("status",
				status);
		return query.getResultList();
	}
	
	public List<CloudLocation> findByServiceAndStatus(Long serviceId, String status) {
		TypedQuery<CloudLocation> query = entityManager.createNamedQuery("CloudLocation.findByServiceAndStatus", CloudLocation.class)
													   .setParameter("serviceId", serviceId)
													   .setParameter("status", status);
		return query.getResultList();
	}
	
	public List<CloudLocation> findByServiceLocationCodeAndStatus(Long serviceId, String locationCode, String status) {
		TypedQuery<CloudLocation> query = entityManager.createNamedQuery("CloudLocation.findByServiceLocationCodeAndStatus", CloudLocation.class)
													   .setParameter("serviceId", serviceId)
													   .setParameter("locationCode", locationCode)
													   .setParameter("status", status);
		return query.getResultList();
	}
	
	public List<CloudLocation> findByNameNStatus(String name, String status) {
		TypedQuery<CloudLocation> query = entityManager.createNamedQuery("CloudLocation.findByNameNStatus", CloudLocation.class)
													   .setParameter("name", name)
													   .setParameter("status", status);
		return query.getResultList();
	}
	
	
	public List<Object[]>  findLocationSummaryByServiceId(Long serviceId){
		TypedQuery<Object[]> query=entityManager.createNamedQuery("CloudLocation.findLocationSummaryByServiceId",Object[].class).setParameter("serviceId", serviceId);
		return query.getResultList();
	}
}
