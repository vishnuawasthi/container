package com.valuelabs.nephele.admin.data.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.api.InventoryStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProduct;
import com.valuelabs.nephele.admin.data.entity.CloudService;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudProductDAO extends AbstractJpaDAO<CloudProduct> {

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudProductDAO() {
		setClazz(CloudProduct.class);
	}
	
	public List<CloudProduct> findProductsByServiceId(Long serviceId){
		
		TypedQuery<CloudProduct> query =
				entityManager.createNamedQuery("CloudProduct.findByServiceId", CloudProduct.class).
									setParameter("serviceId", serviceId);
		
		return query.getResultList();
		
	}
	
	public List<CloudProduct> findProductsByServiceAndOs(Long serviceId, Long osId){
		
		TypedQuery<CloudProduct> query =
				entityManager.createNamedQuery("CloudProduct.findByServiceAndOs", CloudProduct.class).
									setParameter("serviceId", serviceId)
									.setParameter("osId", osId);
		
		return query.getResultList();
		
	}
	
	public List<CloudProduct> findByIds(List<Long> productIds){
		TypedQuery<CloudProduct> query =
				entityManager.createNamedQuery("CloudProduct.findByIds", CloudProduct.class).
									setParameter("productIds",productIds);
		return query.getResultList();
		
	}
	
	public List<CloudProduct> findPublishedProducts(){
		TypedQuery<CloudProduct> query =
				entityManager.createNamedQuery("CloudProduct.findPublishedProducts", CloudProduct.class);
		return query.getResultList();
	}
	
	/*public List<CloudProduct> findByCategoryAndLocation(Long locationId,Long categoryId){
		TypedQuery<CloudProduct> query =
				entityManager.createNamedQuery("CloudProduct.findByCategoryAndLocation", CloudProduct.class);
		return query.getResultList();
	}*/
	
	public List<CloudProduct> getPublishedProductsByService(Long serviceId) {

		List<CloudProduct> list =   null;
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CloudProduct> criteriaQuery = criteriaBuilder.createQuery(CloudProduct.class);
		Root<CloudProduct> rootBase = criteriaQuery.from(CloudProduct.class);
		Predicate predicate = criteriaBuilder.conjunction();
		
		Join<CloudProduct, CloudService> rootWithService = rootBase.join("cloudService");
		
		List<Order> orderList = new ArrayList<Order>();
		 
		Expression<String>  rootStatus = rootBase.get("status");
		predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), InventoryStatus.PUBLISHED.name().toLowerCase()));
		
		predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithService.get("isPublished"), true));
		
		if(null != serviceId && serviceId > 0) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
		}
		
		criteriaQuery.where(predicate);
		
		orderList.add(criteriaBuilder.asc(rootBase.get("id")));
		criteriaQuery.orderBy(orderList);
		
		list = entityManager.createQuery(criteriaQuery).getResultList();
		return list;
	  }
	
}
