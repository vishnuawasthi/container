package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.NomadeskMeteringData;

public interface NomadeskMeteringDataRepository  extends TableRepository<NomadeskMeteringData, Long>, JpaSpecificationExecutor<NomadeskMeteringData>{

}
