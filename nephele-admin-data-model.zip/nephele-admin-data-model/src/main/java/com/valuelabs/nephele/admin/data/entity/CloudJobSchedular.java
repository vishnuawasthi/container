package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.valuelabs.nephele.admin.data.api.JobTypes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@SequenceGenerator(name = "cloud_job_schedular_seq", sequenceName = "cloud_job_schedular_seq", initialValue = 1)
@Entity
@Table(name = "cloud_job_schedular")
public class CloudJobSchedular extends AbstractAuditEntity implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -30595648297874805L;

  @Id
  @GeneratedValue(generator = "cloud_job_schedular_seq")
  @Column(name = "job_schedular_id")
  private Long id;
  @Column(name = "scheduled_date")
  private Date scheduledDate;

  @Column(name = "scheduled_minutes", nullable=false)
  private Long minutes;

  @Column(name = "scheduled_hours", nullable=false)
  private Long hours;
  
  @Column(name = "scheduler_status", nullable=false)
  private String status;

  @ManyToOne
  @JoinColumn(name = "cloud_service_id", nullable= false)
  private CloudService cloudService;
  
  @Column(name = "job_type", nullable= false)
  @Enumerated(EnumType.STRING)
  private JobTypes jobType;

}
