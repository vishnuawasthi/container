/**
 * 
 */
package com.valuelabs.nephele.admin.data.api;

/**
 * @author rrsanepalle
 *
 */
public enum InventoryStatus {
	
	DISCOVERED,
	STAGED,
	PUBLISHED,
	WITHDRAWN,
	ARCHIVED;

}
