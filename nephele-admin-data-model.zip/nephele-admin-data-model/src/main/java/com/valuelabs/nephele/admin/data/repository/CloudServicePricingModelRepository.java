package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudServicePricingModel;

public interface CloudServicePricingModelRepository extends TableRepository<CloudServicePricingModel, Long>, JpaSpecificationExecutor<CloudServicePricingModel> {

}
