package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudResellerPremiumGroup;

@Slf4j
public class CloudResellerPremiumGroupSpecifications {
  public static Specification<CloudResellerPremiumGroup> findPremiumGroupByNameorStatus(final String groupName,
	  final String status) {
	return new Specification<CloudResellerPremiumGroup>() {

	  @Override
	  public Predicate toPredicate(Root<CloudResellerPremiumGroup> root, CriteriaQuery<?> criteriaQuery,
		  CriteriaBuilder criteriaBuilder) {
		Predicate predicate = criteriaBuilder.conjunction();

		//List<Order> orderList = new ArrayList<Order>();
		if (!StringUtils.isEmpty(groupName)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("name"), groupName));
		}
		/*if (!StringUtils.isEmpty(status)) {
			predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("status"),  ChangeManagementConfigStatus.valueOf(status)));
		}*/
		/*criteriaQuery.where(predicate);
		orderList.add(criteriaBuilder.asc(root.get("id")));
		criteriaQuery.orderBy(orderList);*/
		return predicate;
	  }

	};
  }
  
  public static Sort sortByIdAsc() {
	return new Sort(Sort.Direction.ASC, "id");
  }

  /**
   * Returns a new object which specifies the the wanted result page.
   * @param pageIndex  The index of the wanted result page       
   * @return
   */
  public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	return pageSpecification;
  }
}
