package com.valuelabs.nephele.admin.data.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudRackspaceBandwidthPrice;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudRackspaceBandwidthPriceDAO extends AbstractJpaDAO<CloudRackspaceBandwidthPrice>{

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudRackspaceBandwidthPriceDAO() {
		setClazz(CloudRackspaceBandwidthPrice.class);
	}
	
	public Double getPriceByResourceIdServiceNservice (String resourceId, String pricingUnit, Long serviceId) {
		TypedQuery<CloudRackspaceBandwidthPrice> query = entityManager.createNamedQuery("BandwidthPrice.byResourceIdAndUnit", CloudRackspaceBandwidthPrice.class)
																	  .setParameter("resourceId", resourceId)
																	  .setParameter("pricingUnit", pricingUnit)
																	  .setParameter("serviceId", serviceId);
		return query.getSingleResult().getPrice();
	}
}
