package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.data.csv.CsvEntry;
import com.valuelabs.nephele.admin.data.csv.CsvFile;

@CsvFile(delimiter = ",", fileName = "")
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_product_price_management_sheet_seq",sequenceName="cloud_product_price_management_sheet_seq",initialValue=1)
@NamedQueries({@NamedQuery(name = "CloudProductPriceManagementSheet.findByPlanId", query = " FROM CloudProductPriceManagementSheet pms where pms.cloudProductPlan.id = :planId"),
	@NamedQuery(name = "CloudProductPriceManagementSheet.findByPlanIdNdConfigId", query = " FROM CloudProductPriceManagementSheet pms where pms.cloudProductPlan.id = :planId AND "
			+ "pms.priceManagementConfig.id = :configId"),
	@NamedQuery(name = "CloudProductPriceManagementSheet.findByConfigId", query = " FROM CloudProductPriceManagementSheet pms where pms.priceManagementConfig.id = :configId order by "
			+ " pms.cloudProductPlan.cloudProduct.id,pms.cloudProductPlan.flavorCategory,pms.cloudProductPlan.sortKey"),
@NamedQuery(name = "CloudProductPriceManagementSheet.findBySheetname", query = "FROM  CloudProductPriceManagementSheet pms WHERE pms.priceManagementConfig.priceSheetName = :sheetName"),
@NamedQuery(name = "CloudProductPriceManagementSheet.findBySheetStatus", query = "FROM  CloudProductPriceManagementSheet pms WHERE pms.priceManagementConfig.status = :status")
})

@Entity
@Table(name="cloud_product_price_management_sheet")
public class CloudProductPriceManagementSheet extends AbstractAuditEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5964312760208441825L;
	
	@Id
    @GeneratedValue(generator="cloud_product_price_management_sheet_seq")
    @Column(name = "cloud_product_price_management_sheet_id", nullable = false)
	@CsvEntry(header = "SHEET_ID", defaultValue = "0")
	private Long id;
	
	@Column(name="price",nullable = false)
	@CsvEntry(header = "PRICE", defaultValue = "0")
	private Double price;
	
	
	@Column(name="vendor_price",nullable = true)
	@CsvEntry(header = "VENDOR_PRICE", defaultValue = "0")
	private Double vendorPrice;
	
	/*
	@Column(name="status")
	@Enumerated(EnumType.STRING)
	private PriceManagementConfigStatus status;*/

	@ManyToOne
	@JoinColumn(name="cloud_product_price_management_config_id")	
	private CloudProductPriceManagementConfig priceManagementConfig;
	
	@ManyToOne
	@JoinColumn(name="cloud_product_plan_id")
	private CloudProductPlan cloudProductPlan;
	
	}
