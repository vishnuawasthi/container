package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudLicense;

public interface CloudLicenseRepository extends TableRepository<CloudLicense, Long>, JpaSpecificationExecutor<CloudLicense>{

}
