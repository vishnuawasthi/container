package com.valuelabs.nephele.admin.data.api;

public enum RackspaceServerAction {
	
	DELETE,
	REBOOT,
	REBUILT,
	RESETPASSWORD,
	RESIZE,
	CONFIRM_RESIZE;

}
