package com.valuelabs.nephele.admin.data.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudServiceCredential;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudServiceCredentialDAO extends AbstractJpaDAO<CloudServiceCredential>{

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudServiceCredentialDAO(){
		setClazz(CloudServiceCredential.class);
	}
	
	public CloudServiceCredential getCredentilsByServiceId(Long cloudServiceId) {
		TypedQuery<CloudServiceCredential> query =
				entityManager.createNamedQuery("ServiceCredentials.findByServiceId", CloudServiceCredential.class).
									setParameter("cloudServiceId", cloudServiceId);
		return query.getSingleResult();
		
	}
}
