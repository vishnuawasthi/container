package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Accessors(chain = true)
@Getter
@Setter
@SequenceGenerator(name = "service_category_seq", sequenceName = "service_category_seq", initialValue = 1)
@Entity
@Table(name = "service_category")
public class ServiceCategory  extends AbstractAuditEntity implements Serializable{

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "service_category_id")
  @GeneratedValue(generator = "service_category_seq")
  private Long id;

  @Column(name = "category_name",unique=true,nullable=false)
  private String name;

  @Column(name = "description")
  private String description;
    
  @OneToMany(mappedBy="serviceCategory")
  private Set<CloudService> cloudServices = new HashSet<CloudService>();
  

}
