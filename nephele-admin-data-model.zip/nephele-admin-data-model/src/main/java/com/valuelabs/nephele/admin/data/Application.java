package com.valuelabs.nephele.admin.data;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;


@Slf4j
@Configuration
@EnableAspectJAutoProxy
@EnableHystrixDashboard
@ConditionalOnExpression("${hystrix.enabled:true}")
@EnableHystrix
@ComponentScan(basePackages = "com.valuelabs.nephele")
@EnableAutoConfiguration
public class Application  {

	public Application() {

	}

	public static void main(String[] args) {
		log.debug("Starting nephele-admin-data-model");
		ApplicationContext ctx = SpringApplication.run(Application.class, args);
		log.debug("nephele-admin-data-model application name: {}", ctx.getApplicationName());
	}

}