package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.valuelabs.nephele.admin.data.entity.RelatedCloudProduct;

public interface RelatedCloudProductRepository extends TableRepository<RelatedCloudProduct, Long>, JpaSpecificationExecutor<RelatedCloudProduct>{
	
	
	@Query("FROM RelatedCloudProduct rcp where rcp.relatedCloudProduct.id =:cloudProductId")
	public List<RelatedCloudProduct> getRelatedProductsByRelatedCloudProduct(@Param("cloudProductId") Long cloudProductId);
	
	@Query("FROM RelatedCloudProduct rcp where rcp.cloudProduct.id  in (:cloudProductIds)")
	public List<RelatedCloudProduct> getRelatedProductsByCloudProduct(@Param("cloudProductIds") List<Long> cloudProductIds);
	
	@Modifying
    @Transactional
	@Query("delete from RelatedCloudProduct rcp where rcp.cloudProduct.id = ?1")
    void deleteByCloudProductId(Long cloudProductId);
	
	
}
