package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
// @Data
@Setter
@Getter
@SequenceGenerator(name = "cloud_softlayer_disk_configuration_seq", sequenceName = "cloud_softlayer_disk_configuration_seq", initialValue = 1)
@Entity
@Table(name = "cloud_softlayer_disk_configuration")
public class CloudSoftlayerDiskConfiguration extends AbstractAuditEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "softlayer_disk_configuration_id")
	@GeneratedValue(generator = "cloud_softlayer_disk_configuration_seq")
	private Long id;

	@Column(name = "hourly_recurring_fee")
	private Double hourlyRecurringFee;

	@Column(name = "description")
	private String description;

	@Column(name = "capacity")
	private Long capacity;

	@Column(name = "status")
	private String status;
	
	@Column(name = "device")
	private String device;
	
	@Column(name = "local_disk_flag")
	private Boolean localDiskFlag;
	
}