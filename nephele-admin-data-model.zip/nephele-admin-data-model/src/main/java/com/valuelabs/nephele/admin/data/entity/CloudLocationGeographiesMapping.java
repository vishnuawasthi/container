package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.util.StringJsonUserType;
import lombok.*;
import lombok.experimental.Accessors;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.Serializable;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@SequenceGenerator(name="cloud_loc_geo_mappings_seq",sequenceName="cloud_loc_geo_mappings_seq",initialValue=1)
@Entity
@Table(name="cloud_loc_geo_mappings")
public class CloudLocationGeographiesMapping extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = -5191956038191797063L;

	@Id
    @GeneratedValue(generator="cloud_loc_geo_mappings_seq")
    @Column(name = "cloud_loc_geo_mappings_id", nullable = false)
	private Long id;
	
	@Column(name = "geography_code", nullable = true)
	private String geographyCode;
	
	@Column(name = "location_code", nullable = true)
	private String locationCode;
	
	
}
