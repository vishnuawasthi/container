package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementConfig;
import com.valuelabs.nephele.admin.data.entity.CloudProductPriceManagementSheet;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudProductPriceManagementSheetDAO extends AbstractJpaDAO<CloudProductPriceManagementSheet> {

	public CloudProductPriceManagementSheetDAO() {
		setClazz(CloudProductPriceManagementSheet.class);
	}
	
	@PersistenceContext
	EntityManager entityManager;
	
    public List<CloudProductPriceManagementSheet> findByPlanId(Long planId){
		
		TypedQuery<CloudProductPriceManagementSheet> query =
				entityManager.createNamedQuery("CloudProductPriceManagementSheet.findByPlanId", CloudProductPriceManagementSheet.class)
				.setParameter("planId", planId);
	
		return query.getResultList();	
	}
    
    public List<CloudProductPriceManagementSheet> findByPlanIdNdConfigId(Long planId, Long configId){
		
		TypedQuery<CloudProductPriceManagementSheet> query =
				entityManager.createNamedQuery("CloudProductPriceManagementSheet.findByPlanIdNdConfigId", CloudProductPriceManagementSheet.class)
				.setParameter("planId", planId).setParameter("configId", configId);
	
		return query.getResultList();	
	}
    
    public List<CloudProductPriceManagementSheet> findByConfigId(Long configId){
		
		TypedQuery<CloudProductPriceManagementSheet> query =
				entityManager.createNamedQuery("CloudProductPriceManagementSheet.findByConfigId", CloudProductPriceManagementSheet.class)
				.setParameter("configId", configId);
	
		return query.getResultList();	
	}
    
    public List<CloudProductPriceManagementSheet> findBySheetName(String sheetName) {
	    TypedQuery<CloudProductPriceManagementSheet> query = entityManager.createNamedQuery("CloudProductPriceManagementSheet.findBySheetname", CloudProductPriceManagementSheet.class)		    		
	    		.setParameter("sheetName", sheetName);
	    return query.getResultList();
  }
  
  public List<CloudProductPriceManagementSheet> findBySheetStatus(String status) {
	    TypedQuery<CloudProductPriceManagementSheet> query = entityManager.createNamedQuery("CloudProductPriceManagementSheet.findBySheetStatus", CloudProductPriceManagementSheet.class)		    		
	    		.setParameter("status", ChangeManagementConfigStatus.valueOf(status));
	    		
	    return query.getResultList();
  }
 
	
}
