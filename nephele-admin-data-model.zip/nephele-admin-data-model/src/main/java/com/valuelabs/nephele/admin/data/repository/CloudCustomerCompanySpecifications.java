/**
 * 
 */
package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;

/**
 * @author bharath
 *
 */
@Slf4j
public final class CloudCustomerCompanySpecifications {

	public static Specification<CloudCustomerCompany> findCustomerCompany(final String customerCompanyCode){
		
		return new Specification<CloudCustomerCompany>() {

			@Override
			public Predicate toPredicate(Root<CloudCustomerCompany> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				log.debug("findCustomerCompany--start()");
				Predicate predicate = criteriaBuilder.conjunction();
				
				if(!StringUtils.isEmpty(customerCompanyCode)){
					Expression<String> rootCustomerCode = root.get("customerCompanyCode");
					predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(criteriaBuilder.lower(rootCustomerCode), customerCompanyCode.toLowerCase()));
				}else {
					predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("customerCompanyCode"), customerCompanyCode));
				}
				log.debug("findCustomerCompany--end()");
				
				return predicate;
			}
		};
	}
}
