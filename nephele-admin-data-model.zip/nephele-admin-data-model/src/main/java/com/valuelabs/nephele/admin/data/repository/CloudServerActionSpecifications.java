package com.valuelabs.nephele.admin.data.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudServer;
import com.valuelabs.nephele.admin.data.entity.CloudServerAction;

public class CloudServerActionSpecifications {
  public static Specification<CloudServerAction> getComputePriceByOSId(final Long serverId) {
	return new Specification<CloudServerAction>() {

	  @Override
      public Predicate toPredicate(Root<CloudServerAction> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
		Predicate predicate = criteriaBuilder.conjunction();
		Join<CloudServerAction, CloudServer> rootWithServer = root.join("cloudServer");		
		List<Order> orderList = new ArrayList<Order>();
		if (!StringUtils.isEmpty(serverId)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithServer.get("id"), serverId));
		}
		
		criteriaQuery.where(predicate);
		orderList.add(criteriaBuilder.asc(root.get("id")));
		criteriaQuery.orderBy(orderList);
		return predicate;

	   
      }
	  
	};
  }
}
