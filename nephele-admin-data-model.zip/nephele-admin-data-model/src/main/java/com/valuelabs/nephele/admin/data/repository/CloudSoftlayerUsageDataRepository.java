package com.valuelabs.nephele.admin.data.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;
import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.SoftlayerUsageData;

public interface CloudSoftlayerUsageDataRepository extends TableRepository<SoftlayerUsageData, Long>, JpaSpecificationExecutor<SoftlayerUsageData> {

  @Query("SELECT sum(quantity) as NUMBER FROM  SoftlayerUsageData  WHERE cloudCustomerCompany in :customerCompanyIdList and invoiceStatus=:status")
  public Double getSoftlayerResellerUsageData(@Param("status") MeteringDataInvoiceStatus status, @Param("customerCompanyIdList") Set<CloudCustomerCompany> customerCompanies);

}
