package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudAdditionalPrice;

public interface CloudAdditionalPriceRepository extends TableRepository<CloudAdditionalPrice, Long>, JpaSpecificationExecutor<CloudAdditionalPrice>{

	@Query("from CloudAdditionalPrice where cloudService.id = :serviceId and status = :status")	
	public List<CloudAdditionalPrice> findByCloudServiceIdandStatus(@Param("serviceId") Long serviceId, @Param("status") String status);
	
	@Query("from CloudAdditionalPrice where cloudService.id = :serviceId")	
	public CloudAdditionalPrice findByServiceId(@Param("serviceId") Long serviceId);
}
