package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudSoftlayerRAMConfiguration;

public interface CloudSoftLayerRAMConfigurationRepository extends TableRepository<CloudSoftlayerRAMConfiguration, Long>, JpaSpecificationExecutor<CloudSoftlayerRAMConfiguration>{

}
