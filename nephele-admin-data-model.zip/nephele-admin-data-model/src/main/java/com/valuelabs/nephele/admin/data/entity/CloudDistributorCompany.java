package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.*;
import lombok.experimental.Accessors;


//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_distributor_company_seq", sequenceName = "cloud_distributor_company_seq", initialValue = 1)
@Builder
@Table(name = "cloud_distributor_company")
public class CloudDistributorCompany extends AbstractAuditEntity implements Serializable//extends CloudUserType 
{
  /**
   *
   */
  private static final long serialVersionUID = 9064591024249055329L;

  @Id
  @GeneratedValue(generator = "cloud_distributor_company_seq")
  @Column(name = "DISTRIBUTOR_COMPANY_ID")
  private Long distributorCompanyId;

  @Column(name = "DISTRIBUTOR_COMPANY_NAME")
  private String distributorCompanyName;

  /*@OneToMany(mappedBy = "cloudDistributorCompany")
  private Set<CloudResellerCompany> cloudSupplierCompanies = new HashSet<CloudResellerCompany>();*/

  /*@OneToMany(mappedBy = "cloudDistributorCompany")
  private Set<CloudDistributorUser> cloudDistributorUsers = new HashSet<CloudDistributorUser>();*/

		/*@ManyToOne
		@JoinColumn(name="ROLE_ID")
	    private CloudUserRole userRole;*/

}