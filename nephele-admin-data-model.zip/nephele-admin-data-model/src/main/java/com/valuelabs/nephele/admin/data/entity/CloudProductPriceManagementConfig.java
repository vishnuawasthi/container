package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.csv.CsvEntry;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_product_price_management_config_seq",sequenceName="cloud_product_price_management_config_seq",initialValue=1)
@NamedQueries({
	@NamedQuery(name = "priceMgmtConfig.findByServiceId", query = "FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId"),
	@NamedQuery(name = "priceMgmtConfig.findByServiceIdandDraftScheduledStatus", query = "FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND status in ('DRAFT','SCHEDULED')"),
	@NamedQuery(name = "priceMgmtConfig.findByServiceIdandStatus", query = "FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND cpm.status =:status"),
	@NamedQuery(name = "priceMgmtConfig.findByActiveStaus", query = "FROM  CloudProductPriceManagementConfig cpm WHERE cpm.status ='ACTIVE'"),
	@NamedQuery(name = "priceMgmtConfig.findByServiceIdandStatusandSheetname", query = "FROM  CloudProductPriceManagementConfig cpm WHERE cpm.cloudService.id =:serviceId AND cpm.status =:status AND cpm.priceSheetName =:sheetName")
})
@Entity
@Table(name="cloud_product_price_management_config")
public class CloudProductPriceManagementConfig extends AbstractAuditEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5964312760208441825L;
	
	@Id
    @GeneratedValue(generator="cloud_product_price_management_config_seq")
    @Column(name = "cloud_product_price_management_config_id", nullable = false)
	@CsvEntry(header=  "CONFIG_ID")
	private Long id;
	
	@Column(name="price_sheet_name")
	private String priceSheetName;
	
	@Column(name="active_from")
	private Date activeFrom;
	
	@Column(name="active_to")
	private Date activeTo;
	
	@Column(name="status")
	@Enumerated(EnumType.STRING)
	private ChangeManagementConfigStatus status;

	@ManyToOne
	@JoinColumn(name="cloud_service_id")
	private CloudService cloudService;
	
	@Column(name="comments")
	private String comments;
	
	@Column(name="custom_date")
	private Date customDate;
	
	@OneToMany(mappedBy="priceManagementConfig")
	private Set<CloudProductPriceManagementSheet> priceManagementSheets=new HashSet<CloudProductPriceManagementSheet>();
	
}
