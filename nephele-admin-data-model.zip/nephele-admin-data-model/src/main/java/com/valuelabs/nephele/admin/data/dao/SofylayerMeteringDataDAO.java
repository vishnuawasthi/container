package com.valuelabs.nephele.admin.data.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.SoftlayerMeteringData;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class SofylayerMeteringDataDAO extends AbstractJpaDAO<SoftlayerMeteringData> {

	@PersistenceContext
	private EntityManager entityManager;

	public SofylayerMeteringDataDAO() {
		setClazz(SoftlayerMeteringData.class);
	}
}
