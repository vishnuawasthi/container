package com.valuelabs.nephele.admin.data.dao;

import com.google.common.base.Strings;
import com.valuelabs.nephele.admin.data.api.InvoiceStatus;
import com.valuelabs.nephele.admin.data.common.ReadCloudInvoice;
import com.valuelabs.nephele.admin.data.entity.*;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Repository
public class CloudResellerInvoiceDAO extends AbstractJpaDAO<CloudResellerInvoice> {

  @Autowired
  private EntityManager entityManager;

  public CloudResellerInvoiceDAO() {
    setClazz(CloudResellerInvoice.class);
  }

  /**
   * Save the Invoice Lines into the CLOUD_INVOICE & CLOUD_INVOICE_LINES tables
   * Updates Cloud Usage Data Status as COMPLETED after successful invoice creation
   *
   * @param cloudInvoice  - Cloud Invoice Object for saving into Database
   * @param usageDataList - List of <code>CloudRackspaceUsageData</code>  object needs to updated
   */
  @Transactional
  public void createInvoiceAndUpdateUsageDataStatus(CloudResellerInvoice cloudInvoice, List<CloudRackspaceUsageData> usageDataList) {
    create(cloudInvoice);
    if (null != usageDataList && !usageDataList.isEmpty()) {
      for (CloudRackspaceUsageData usageData : usageDataList)
        entityManager.merge(usageData);
    }
  }

  //Get Invoice data using Reseller ID
  public List<CloudResellerInvoice> getInvoiceByResellerId(Long resellerId) {
    TypedQuery<CloudResellerInvoice> query = entityManager.createNamedQuery("invoice.findInvoiceByResellerId", CloudResellerInvoice.class).setParameter("cloudResellerCompanyId", resellerId);
    return query.getResultList();
  }

  //Get Invoice data using Reseller ID
  public CloudResellerInvoice getInvoiceByResellerAndInvoiceId(Long resellerId, Long invoiceId) {
    TypedQuery<CloudResellerInvoice> query = entityManager.createNamedQuery("invoice.findByInvoiceAndResellerId", CloudResellerInvoice.class).setParameter("cloudResellerCompanyId", resellerId)
        .setParameter("invoiceId", invoiceId);
    return query.getSingleResult();
  }

  //Get Invoice data using InvoiceId, status and ResellerID
  public CloudResellerInvoice getInvoiceData(Long id, String status, Long resellerId) {
    log.debug("getInvoiceData START ");
    CriteriaBuilder builder = entityManager.getCriteriaBuilder();
    CriteriaQuery<CloudResellerInvoice> query = builder.createQuery(CloudResellerInvoice.class);
    Root r = query.from(CloudResellerInvoice.class);
    Join<CloudResellerInvoice, CloudResellerCompany> reseller = r.join("cloudResellerCompany");
    Predicate predicate = builder.conjunction();
    if (id != null) {
      predicate = builder.and(predicate, builder.equal(r.get("id"), id));
    }
    if (!StringUtils.isEmpty(status)) {
      predicate = builder.and(predicate, builder.equal(r.get("status"), status));
    }
    if (resellerId != null) {
      predicate = builder.and(predicate, builder.equal(reseller.get("resellerCompanyId"), resellerId));
    }
    query.where(predicate);
    CloudResellerInvoice result = entityManager.createQuery(query).getSingleResult();
    log.debug("getInvoiceData END ");
    return result;
  }

  //Get Invoice data by status
  public List<CloudResellerInvoice> getInvoiceByStatus(String status) {
    TypedQuery<CloudResellerInvoice> query = entityManager.createNamedQuery("invoice.findInvoiceByStatus", CloudResellerInvoice.class).setParameter("status", status);
    return query.getResultList();
  }

  public List<CloudResellerInvoice> getCloudInvoiceByResellerId(Long cloudResellerId) {
    TypedQuery<CloudResellerInvoice> query = entityManager.createNamedQuery("invoice.findInvoiceByResellerId", CloudResellerInvoice.class)
        .setParameter("cloudResellerCompanyId", cloudResellerId);
    return query.getResultList();

  }

  public List<CloudResellerInvoice> getResellerInvoiceByDateRange(Long cloudResellerId, Date fromDate, Date toDate) {
    TypedQuery<CloudResellerInvoice> query = entityManager.createNamedQuery("invoice.findLastMonthByResellerId", CloudResellerInvoice.class)
        .setParameter("cloudResellerCompanyId", cloudResellerId)
        .setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP);
    return query.getResultList();

  }

  public List<CloudResellerInvoice> getCloudInvoiceByStatus(String status) {
    TypedQuery<CloudResellerInvoice> query = entityManager.createNamedQuery("invoice.findInvoiceByStatus", CloudResellerInvoice.class)
        .setParameter("status", InvoiceStatus.valueOf(status));
    return query.getResultList();

  }

  public List<CloudResellerInvoice> getCloudInvoiceByStatusAndResellerId(String status, Long resellerId) {
    TypedQuery<CloudResellerInvoice> query = entityManager.createNamedQuery("invoice.findInvoiceByStatusAndResellerId", CloudResellerInvoice.class)
        .setParameter("status", InvoiceStatus.valueOf(status)).setParameter("cloudResellerCompanyId", resellerId);
    return query.getResultList();

  }

  public List<CloudResellerInvoice> getCloudInvoiceByDates(Date fromDate, Date toDate) {
    TypedQuery<CloudResellerInvoice> query = entityManager
        .createNamedQuery("CloudInvoice.findByDates", CloudResellerInvoice.class)
        .setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP);
    return query.getResultList();

  }

  public List<CloudResellerInvoice> getCloudInvoiceByDateAndResellerId(Date fromDate, Date toDate, Long resellerId) {
    TypedQuery<CloudResellerInvoice> query = entityManager
        .createNamedQuery("CloudInvoice.findByDatesAndResellerId", CloudResellerInvoice.class)
        .setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP)
        .setParameter("cloudResellerCompanyId", resellerId);
    return query.getResultList();

  }

  public List<CloudResellerInvoice> getResellerInvoiceByDatesAndStatus(Date fromDate, Date toDate, String status) {
    TypedQuery<CloudResellerInvoice> query = entityManager
        .createNamedQuery("CloudInvoice.findByDatesAndStatus", CloudResellerInvoice.class)
        .setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP)
        .setParameter("status", InvoiceStatus.valueOf(status));
    return query.getResultList();
  }

  public List<CloudResellerInvoice> getResellerInvoiceByDateResellerIdAndStatus(Date fromDate, Date toDate, String status, Long resellerId) {
    TypedQuery<CloudResellerInvoice> query = entityManager
        .createNamedQuery("CloudInvoice.findByDateResellerIdAndStatus", CloudResellerInvoice.class)
        .setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP)
        .setParameter("status", InvoiceStatus.valueOf(status))
        .setParameter("cloudResellerCompanyId", resellerId);
    return query.getResultList();
  }

  public List<CloudResellerInvoice> getInvoiceByOrder(int noOfRecords, String sortBy, Date fromDate, Date toDate) {
    TypedQuery<CloudResellerInvoice> query = null;
    if (sortBy.equalsIgnoreCase("REVENUE")) {
      query = entityManager.createNamedQuery("CloudResellerInvoice.sortByRevenue", CloudResellerInvoice.class)
          .setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
          .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP);
      if (0 != noOfRecords)
        query.setMaxResults(noOfRecords);
      return query.getResultList();
    } else if (sortBy.equalsIgnoreCase("NAME")) {
      query = entityManager.createNamedQuery("CloudResellerInvoice.sortByName", CloudResellerInvoice.class).setMaxResults(noOfRecords);
      return query.getResultList();
    }
    return null;
  }

  public Double getRevenueByResellerId(Long resellerId, Date fromDate, Date toDate) {
    Query query = entityManager.createNativeQuery("SELECT sum(net_total) as NUMBER FROM  cloud_reseller_invoice  WHERE cloud_reseller_company_id =:cloudResellerCompanyId AND created BETWEEN :fromDate AND :toDate");
    query.setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP)
        .setParameter("cloudResellerCompanyId", resellerId);
    return (Double) query.getSingleResult();
  }

  public Double getRevenue(Date fromDate, Date toDate) {
    Double returnVal = 0D;
    try {
      Query query = entityManager.createNativeQuery("SELECT sum(net_total) as NUMBER FROM  cloud_reseller_invoice  WHERE created BETWEEN :fromDate AND :toDate");
      query.setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
          .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP);
      returnVal = (Double) query.getSingleResult();
    } catch (Exception e) {
      log.error("Exception occurs while calculating revenue:", e.getMessage());
    }
    return returnVal;
  }

  public List<RevenueServiceDetail> getServicesByRevenue(Date fromDate, Date toDate/*, Integer maxResults*/) {
    Query query = entityManager.createNativeQuery("select sum(cri.net_total) as total, cri.cloud_service_id as service_id," +
        " cs.name as service_name, cs.service_code as service_code from cloud_reseller_invoice cri  join cloud_service cs on " +
        " cri.cloud_service_id=cs.cloud_service_id  and cri.created between :fromDate and :toDate " +
        " group by cri.cloud_service_id, cs.name, cs.service_code order by total desc");
    query.setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP);
   /* if (null != maxResults && 0 != maxResults)
      query.setMaxResults(maxResults);*/
    List<Object[]> results = query.getResultList();
    List<RevenueServiceDetail> serviceList = new ArrayList<>();
    for (Object[] obj : results) {
      RevenueServiceDetail service = new RevenueServiceDetail();
      service.setRevenue(String.valueOf(obj[0]));
      service.setServiceId(((BigInteger) obj[1]).longValue());
      service.setServiceName((String) obj[2]);
      service.setServiceCode((String) obj[3]);
      serviceList.add(service);
    }
    return serviceList;
  }

  public List<RevenueServiceDetail> getServicesByResellerRevenue(Long resellerId, Date fromDate, Date toDate/*, Integer maxResults*/) {
    Query query = entityManager.createNativeQuery("select sum(cri.net_total) as total, cri.cloud_service_id as service_id," +
        " cs.name as service_name, cs.service_code as service_code from cloud_reseller_invoice cri  join cloud_service cs on " +
        " cri.cloud_service_id=cs.cloud_service_id  and cri.created between :fromDate and :toDate and cri.cloud_reseller_company_id= " +
        " :cloudResellerCompanyId group by cri.cloud_service_id, cs.name, cs.service_code order by total desc");
    query.setParameter("fromDate", getFormattedDate(fromDate), TemporalType.TIMESTAMP)
        .setParameter("toDate", getFormattedDate(toDate), TemporalType.TIMESTAMP)
        .setParameter("cloudResellerCompanyId", resellerId);
    ;
    /*if (null != maxResults && 0 != maxResults)
      query.setMaxResults(maxResults);*/
    List<Object[]> results = query.getResultList();
    List<RevenueServiceDetail> serviceList = new ArrayList<>();
    for (Object[] obj : results) {
      RevenueServiceDetail service = new RevenueServiceDetail();
      service.setRevenue(String.valueOf(obj[0]));
      service.setServiceId(((BigInteger) obj[1]).longValue());
      service.setServiceName((String) obj[2]);
      service.setServiceCode((String) obj[3]);
      serviceList.add(service);
    }
    return serviceList;
  }

  public List<CloudResellerInvoice> searchInvoice(ReadCloudInvoice request) {
    List<CloudResellerInvoice> result = null;
    try {
      CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
      CriteriaQuery<CloudResellerInvoice> criteriaQuery = criteriaBuilder.createQuery(CloudResellerInvoice.class);
      Root<CloudResellerInvoice> rootBase = criteriaQuery.from(CloudResellerInvoice.class);
      Predicate predicate = criteriaBuilder.conjunction();
      Expression<String> path = rootBase.<String>get("cloudInvoiceNumber");
      Expression<String> upperInvoice = criteriaBuilder.upper(path);
      Path<Object> pathObject = rootBase.join("cloudResellerCompany").get("id");
      Path<Object> resellerCodeObj = rootBase.join("cloudResellerCompany").get("resellerCompanyCode");

      if (!Strings.isNullOrEmpty(request.getInvoiceNumber()))
        predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(upperInvoice, "%" + request.getInvoiceNumber().toUpperCase() + "%"));

      if (!Strings.isNullOrEmpty(request.getStatus()))
        predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootBase.get("invoiceStatus"), InvoiceStatus.valueOf(request.getStatus())));

      if (null != request.getFromDate() && null != request.getToDate())
        predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(rootBase.<java.sql.Date>get("created"), getFormattedDate(request.getFromDate()), getFormattedDate(request.getToDate())));

      if (null != request.getResellerId() && !request.getResellerId().equals(0L))
        predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(pathObject, request.getResellerId()));

      if (null != request.getResellerCode() && !request.getResellerCode().isEmpty())
        predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(resellerCodeObj, request.getResellerCode()));

      criteriaQuery.where(predicate);
      TypedQuery<CloudResellerInvoice> query = entityManager.createQuery(criteriaQuery);

      if (null != request.getNumberOfRecords() && !request.getNumberOfRecords().equals(0))
        query.setMaxResults(request.getNumberOfRecords());
      if (null == request.getSortBy() || request.getSortBy().isEmpty())
        criteriaQuery.orderBy(criteriaBuilder.desc(rootBase.<java.sql.Date>get("created")));
      else
        criteriaQuery.orderBy(criteriaBuilder.desc(rootBase.get(request.getSortBy())));
      result = query.getResultList();
    } catch (Exception e) {
      log.error("Exception occurs while searching invoice detail: ", e.getMessage());
    }
    return result;
  }

  public List<RankCustomerReport> topReseller(ReadCloudInvoice request) {
    List<RankCustomerReport> reportList = new ArrayList<>();
    StringBuilder sb = new StringBuilder();
    boolean isWhereClauseAdded = false;
    sb.append("SELECT INVOICE.CLOUD_RESELLER_COMPANY_ID, SUM(NET_TOTAL) AS AMOUNT, COMPANY.RESELLER_COMPANY_NAME, ");
    sb.append("COMPANY.RESELLER_COMPANY_CODE FROM CLOUD_RESELLER_INVOICE INVOICE JOIN CLOUD_RESELLER_COMPANY COMPANY ");
    sb.append("ON INVOICE.CLOUD_RESELLER_COMPANY_ID=COMPANY.RESELLER_COMPANY_ID ");
    if (null != request.getFromDate() && null != request.getToDate()) {
      sb.append("WHERE ");
      sb.append(" INVOICE.CREATED BETWEEN ");
      sb.append("'").append(getFormattedDate(request.getFromDate())).append("' AND ");
      sb.append("'").append(getFormattedDate(request.getToDate())).append("'");
    }
    sb.append(" GROUP BY INVOICE.CLOUD_RESELLER_COMPANY_ID, COMPANY.RESELLER_COMPANY_NAME, COMPANY.RESELLER_COMPANY_CODE  ORDER BY AMOUNT DESC");
    sb.trimToSize();
    try {
      Query query = entityManager.createNativeQuery(sb.toString());

      if (null != request.getNumberOfRecords() && !request.getNumberOfRecords().equals(0))
        query.setMaxResults(request.getNumberOfRecords());

      List<Object[]> results = query.getResultList();

      for (Object[] obj : results) {
        RankCustomerReport report = RankCustomerReport.builder()
            .customerId(((BigInteger) obj[0]).longValue())
            .revenue(String.valueOf(obj[1]))
            .customerName(String.valueOf(obj[2]))
            .customerCode(String.valueOf(obj[3]))
            .build();
        reportList.add(report);
      }
    } catch (Exception e) {
      log.error("Exception occurs while searching invoice detail: ", e.getMessage());
    }
    return reportList;
  }

  private Date getFormattedDate(Date givenDate) {
    Timestamp dateTimeValue = null;
    try {
      if (null != givenDate) {
        SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy-MM-DD HH:mm:ss z");
        Date date = timeStampFormat.parse(timeStampFormat.format(givenDate));
        dateTimeValue = new java.sql.Timestamp(date.getTime());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return dateTimeValue;
  }

}