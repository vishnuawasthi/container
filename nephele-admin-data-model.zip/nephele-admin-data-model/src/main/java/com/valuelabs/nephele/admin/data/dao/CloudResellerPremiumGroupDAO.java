package com.valuelabs.nephele.admin.data.dao;


import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudResellerPremiumGroup;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudResellerPremiumGroupDAO extends AbstractJpaDAO<CloudResellerPremiumGroup> {

  @PersistenceContext
  private EntityManager entityManager;

  public CloudResellerPremiumGroupDAO() {
    setClazz(CloudResellerPremiumGroup.class);
  }

  public CloudResellerPremiumGroup findPremiumGroup(String group) {
    return entityManager.createNamedQuery("CloudResellerPremiumGroup.byName", CloudResellerPremiumGroup.class)
        .setParameter("name", group).getSingleResult();
  }
  
  
  public List<CloudResellerPremiumGroup> findPremiumGroupByNameorStatus(String groupName, String status) {
	  
	List<CloudResellerPremiumGroup> list =   null;
	CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	CriteriaQuery<CloudResellerPremiumGroup> criteriaQuery = criteriaBuilder.createQuery(CloudResellerPremiumGroup.class);
	Root<CloudResellerPremiumGroup> rootBase = criteriaQuery.from(CloudResellerPremiumGroup.class);
	Predicate predicate = criteriaBuilder.conjunction();		
	
	if(!StringUtils.isEmpty(groupName)) {
	  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("name"), groupName));
	}
	if (!StringUtils.isEmpty(status)) {
	  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("status"), ChangeManagementConfigStatus.valueOf(status)));
		  
	}	
	criteriaQuery.where(predicate);			
	list =entityManager.createQuery(criteriaQuery).getResultList();
	return list;
  }
  

}

