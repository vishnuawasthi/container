package com.valuelabs.nephele.admin.data.api;

public enum BusinessRuleNames {
  ORDER_PREFIX("Order Prefix", "ORDER"),
  INVOICE_PREFIX("Invoice Prefix", "INVOICE PREFIX"),
  AMEX_SURCHARGE("Amex Surcharge", "AMEX"),
  MASTER_SURCHARGE("Master Surcharge", "MASTER"),
  VISA_SURCHARGE("Visa Surcharge", "VISA"),
  CURRENCY("Currency", "CURRENCY"),
  INVOICE_TERM("Invoice Term", "INVOICE TERM"),
  GST("Goods & Service Tax", "GST"),
  DISTRIBUTOR_NAME("Distributor Details", "DISTRIBUTOR"),
  PAYMENT_GATEWAY_MERCHANT_ID("Payment Gateway Merchant Id", "PAYMENT GATEWAY MERCHANT ID"),
  PAYMENT_GATEWAY_HASH_KEY("Payment Gateway Hash Key", "PAYMENT GATEWAY HASH KEY");

  public final String ruleDescription;
  public final String aliasName;

  BusinessRuleNames(String ruleDescription, String aliasName) {
    this.aliasName = aliasName;
    this.ruleDescription = ruleDescription;
  }
}
