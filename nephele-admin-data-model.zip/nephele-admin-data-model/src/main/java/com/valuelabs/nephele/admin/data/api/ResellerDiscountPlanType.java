package com.valuelabs.nephele.admin.data.api;

public enum ResellerDiscountPlanType {	
	VOLUME,
	FLAT
}
