package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudProduct;

public interface CloudProductRepository extends TableRepository<CloudProduct, Long>, JpaSpecificationExecutor<CloudProduct>{
	
	@Query("FROM  CloudProduct cp WHERE cp.cloudService.id =:serviceId ORDER BY cp.id ASC")
	public List<CloudProduct> findProductsByServiceId(@Param("serviceId") Long serviceId);
	
	@Query("FROM  CloudProduct cp WHERE cp.cloudService.id =:serviceId AND status = :status  ORDER BY cp.id ASC ")
	public List<CloudProduct> findProductsByServiceIdNStatus(@Param("serviceId") Long serviceId, @Param("status") String status);
	
	@Query("FROM  CloudProduct cp WHERE cp.cloudService.id =:serviceId AND cp.cloudOperatingSystem.id = :osId ORDER BY cp.id ASC ")
	public List<CloudProduct> findByServiceAndOs(@Param("serviceId") Long serviceId, @Param("osId") Long osId);
	
	@Query("FROM   CloudProduct cp WHERE cp.id in (:productIds) AND status = 'PUBLISHED' AND cp.cloudService.isPublished = true ORDER BY cp.id ASC ")
	public List<CloudProduct> findByIds(@Param("productIds") List<Long> productIds);
	
	@Query("FROM   CloudProduct cp WHERE status = 'PUBLISHED' AND cp.cloudService.isPublished = true ORDER BY cp.id ASC ")
	public List<CloudProduct> findPublishedProducts();
	
	@Query("FROM   CloudProduct cp WHERE status = :status AND cp.cloudService.isPublished = true ORDER BY cp.id ASC ")
	public List<CloudProduct> findProductsByStatus(@Param("status") String status);
	
	/*@Query("FROM   CloudProduct cp WHERE cp.cloudProductCategory.id =:categoryId ORDER BY cp.id ASC ")
	public List<CloudProduct> findByCategoryAndLocation(@Param("categoryId") Long categoryId);*/
	
	@Query("FROM  CloudProduct cp WHERE  cp.name = :name ORDER BY cp.id ASC ")
	public List<CloudProduct> findProductsByServiceIdAndProductName(@Param("name") String name);
	
	

}
