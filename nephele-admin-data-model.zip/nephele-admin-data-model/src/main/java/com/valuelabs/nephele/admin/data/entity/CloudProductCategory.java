/*package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_product_category_seq",sequenceName="cloud_product_category_seq",initialValue=1)
@Entity
@Table(name="cloud_product_category")
public class CloudProductCategory extends AbstractTimestampEntity implements Serializable{

	private static final long serialVersionUID = 3888359936096607662L;

	@Id
    @GeneratedValue(generator="cloud_product_category_seq")
    @Column(name = "cloud_product_category_id", nullable = false)
	private Long id;
	
	@Column(name = "name", nullable = false,unique=true)
	private String categoryName;
	
	@Column(name = "description", nullable = true)
	private String description;
	
	@OneToMany(mappedBy="cloudProductCategory")
    private Set<CloudProduct> cloudProducts = new HashSet<CloudProduct>();
	
}
*/