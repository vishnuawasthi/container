package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;


//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Entity
@Builder
@SequenceGenerator(name="cloud_customer_user_seq",sequenceName="cloud_customer_user_seq",initialValue=1)
@AllArgsConstructor
@NoArgsConstructor
@Table(name="cloud_customer_user")
public class CloudCustomerUser extends AbstractAuditEntity implements Serializable //extends CloudUserType 
{ 
		/**
	 * 
	 */
	private static final long serialVersionUID = -2988851998243095855L;

		@Id
		@GeneratedValue(generator="cloud_customer_user_seq")
        @Column(name="CUSTOMER_ID")
        private Long customerId;
		
		@Column(name="CUSTOMER_NAME")
        private String customerName;
		
		@ManyToOne
		@JoinColumn(name="CUSTOMER_COMPANY_ID")
	    private CloudCustomerCompany cloudCustomerCompany;

		/*@ManyToOne
	    @JoinColumn(name = "RESELLER_ID", nullable = false) 
	    private CloudResellerUser cloudSupplierUser;

		@ManyToOne
		@JoinColumn(name="ROLE_ID")
	    private CloudUserRole userRole;
		
		@OneToMany(mappedBy="cloudCustomerUser")
	    private Set<CloudOrder> cloudOrders = new HashSet<CloudOrder>();
		
		
		@OneToMany(mappedBy="cloudCustomerUser")
	    private Set<CloudServer> cloudServers = new HashSet<CloudServer>();
		
		@OneToMany(mappedBy="cloudCustomerUser")
	    private Set<CloudSubscription> cloudSubscriptions = new HashSet<CloudSubscription>();*/
		
		
 
}