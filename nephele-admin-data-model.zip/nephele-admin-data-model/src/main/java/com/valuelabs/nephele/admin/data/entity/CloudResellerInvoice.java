package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.InvoiceStatus;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name = "cloud_reseller_invoice_seq", sequenceName = "cloud_reseller_invoice_seq", initialValue = 1)
@NamedQueries({@NamedQuery(name = "invoice.findInvoiceByResellerId", query = "FROM  CloudResellerInvoice ci WHERE ci.cloudResellerCompany.id =:cloudResellerCompanyId"),
    @NamedQuery(name = "invoice.findInvoiceByStatus", query = "FROM  CloudResellerInvoice ci WHERE ci.invoiceStatus =:status"),
    @NamedQuery(name = "invoice.findLastMonthByResellerId", query = "FROM CloudResellerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate AND c.cloudResellerCompany.id =:cloudResellerCompanyId"),
    @NamedQuery(name = "invoice.findInvoiceByStatusAndResellerId", query = "FROM  CloudResellerInvoice ci WHERE ci.invoiceStatus =:status and ci.cloudResellerCompany.id =:cloudResellerCompanyId"),
        @NamedQuery(name = "CloudInvoice.findByDates", query = "FROM  CloudResellerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate"),
    @NamedQuery(name = "CloudInvoice.findByDatesAndResellerId", query = "FROM  CloudResellerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate and c.cloudResellerCompany.id =:cloudResellerCompanyId"),
    @NamedQuery(name = "CloudResellerInvoice.sortByRevenue", query = "FROM  CloudResellerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate ORDER BY c.netTotal DESC "),
        @NamedQuery(name = "CloudResellerInvoice.sortByName", query = "FROM  CloudResellerInvoice c ORDER BY c.cloudResellerCompany.resellerCompanyName"),
    @NamedQuery(name = "invoice.findByInvoiceAndResellerId", query = "FROM  CloudResellerInvoice c WHERE c.cloudResellerCompany.id =:cloudResellerCompanyId AND c.id=:invoiceId"),
    @NamedQuery(name = "CloudInvoice.findByDateResellerIdAndStatus", query = "FROM  CloudResellerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate AND c.invoiceStatus=:status AND c.cloudResellerCompany.id =:cloudResellerCompanyId"),
        @NamedQuery(name = "CloudInvoice.findByDatesAndStatus", query = "FROM  CloudResellerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate AND c.invoiceStatus=:status")})
@Entity
@Table(name = "cloud_reseller_invoice")
public class CloudResellerInvoice extends AbstractAuditEntity implements Serializable {
  /**
   *
   */
  private static final long serialVersionUID = -1474672809756906149L;

  @Id
  @GeneratedValue(generator = "cloud_reseller_invoice_seq")
  @Column(name = "cloud_reseller_invoice_id", nullable = false)
  private Long id;

  @Column(name = "cloud_reseller_invoice_number")
  private String cloudInvoiceNumber;

  @Column(name = "currency")
  private String currency;

  @Column(name = "gross_total")
  private Double grossTotal;

  @Column(name = "vendor_total")
  private Double vendorTotal;

  @Column(name = "tax")
  private Double tax;

  @Column(name = "net_total")
  private Double netTotal;

  @Column(name = "total")
  private Double total;

/*  @Column(name = "is_closed")
  private Boolean isClosed;*/

  @Column(name = "due_date")
  private Date dueDate;

/*  @Column(name = "created_date")
  private Date createdDate;*/

  @Column(name = "closed_date")
  private Date closedDate;

  @Column(name = "status")
  @Enumerated(EnumType.STRING)
  private InvoiceStatus invoiceStatus;

  @OneToMany(mappedBy = "cloudInvoice", cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  private List<CloudResellerInvoiceLine> cloudInvoiceLines;

  @OneToMany(mappedBy = "cloudInvoice", cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  private List<CloudInvoiceDiscountLine> discountLineList;

  @OneToMany(mappedBy = "cloudInvoice", cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  private Set<CloudPayment> cloudPayments;

  @ManyToOne
  @JoinColumn(name = "CLOUD_RESELLER_COMPANY_ID")
  private CloudResellerCompany cloudResellerCompany;

  @ManyToOne
  @JoinColumn(name = "CLOUD_CUSTOMER_COMPANY_ID")
  private CloudCustomerCompany cloudCustomerCompany;

  @ManyToOne
  @JoinColumn(name = "CLOUD_SERVICE_ID")
  private CloudService cloudService;

  @Column(name = "total_usage")
  private Double totalUsage;

  @Column(name = "discount_percentage")
  private Double discountPercentage;

  @Column(name = "discount_amount")
  private Double discountAmount;

  @Column(name = "from_date")
  private Date fromDate;

  @Column(name = "to_date")
  private Date toDate;

  @Column(name = "csv_file_path")
  private String csvFilePath;

  @Column(name = "pdf_file_path")
  private String pdfFilePath;
}
