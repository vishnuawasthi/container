/**
 * 
 */
package com.valuelabs.nephele.admin.data.api;

/**
 * @author sbandarupalli
 *
 */
public enum B2BResourceType {
	
	SERVER,
	ACCOUNT;

}
