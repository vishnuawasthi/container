
package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudSoftlayerDiskConfiguration;

public interface CloudSoftLayerDiskConfigurationRepository extends TableRepository<CloudSoftlayerDiskConfiguration, Long>, JpaSpecificationExecutor<CloudSoftlayerDiskConfiguration>{

}
