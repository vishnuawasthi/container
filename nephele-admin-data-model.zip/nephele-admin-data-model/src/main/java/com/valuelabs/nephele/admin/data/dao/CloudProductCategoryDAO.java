/*package com.valuelabs.nephele.admin.data.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudProductCategory;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudProductCategoryDAO extends AbstractJpaDAO<CloudProductCategory> {

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudProductCategoryDAO() {
		setClazz(CloudProductCategory.class);
	}
	
}
*/