package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NamedQuery(name = "ComputePrice.findActiveByServerId" , query = " FROM CloudServerAction ca where ca.cloudServer.id = :serverId")
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@Entity
@SequenceGenerator(name="cloud_server_action_seq" ,sequenceName="cloud_server_action_seq",initialValue=1)
@Table(name="cloud_server_action")
public class CloudServerAction extends AbstractAuditEntity implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 3136163930387710322L;
	
	@Id
    @GeneratedValue(generator="cloud_server_action_seq")
    @Column(name = "cloud_server_action_id", nullable = false)
	private Long id;
	
	@Column(name="action")
	private String action;
	
	@Column(name="status")
	private String status;
	
	@ManyToOne
	@JoinColumn(name="cloud_server_id")
	private CloudServer cloudServer;
	
	
	

}
