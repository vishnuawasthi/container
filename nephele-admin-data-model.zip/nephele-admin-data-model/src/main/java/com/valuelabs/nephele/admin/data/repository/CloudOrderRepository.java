package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudOrder;

public interface CloudOrderRepository extends TableRepository<CloudOrder, Long>, JpaSpecificationExecutor<CloudOrder> {
  
  @Query("SELECT co.id FROM  CloudOrder co WHERE co.orderCode =:orderCode ")
  public Long findCloudOrderByOrderCode(@Param("orderCode") String orderCode);
}
