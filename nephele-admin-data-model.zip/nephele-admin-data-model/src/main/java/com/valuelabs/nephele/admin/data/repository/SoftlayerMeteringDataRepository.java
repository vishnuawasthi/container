package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.SoftlayerMeteringData;

/**
 * Created by snagaboina on 19/12/15.
 */
public interface SoftlayerMeteringDataRepository extends TableRepository<SoftlayerMeteringData, Long>, JpaSpecificationExecutor<SoftlayerMeteringData> {

}
