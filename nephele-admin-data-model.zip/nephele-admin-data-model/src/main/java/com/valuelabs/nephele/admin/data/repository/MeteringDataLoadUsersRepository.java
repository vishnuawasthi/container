package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.MeteringDataLoadUsers;

public interface MeteringDataLoadUsersRepository extends TableRepository<MeteringDataLoadUsers, Long>, JpaSpecificationExecutor<MeteringDataLoadUsers>{
	
	@Query("from MeteringDataLoadUsers where userName=:username") 
	public MeteringDataLoadUsers getByUserName(@Param("username") String username);
	
}
