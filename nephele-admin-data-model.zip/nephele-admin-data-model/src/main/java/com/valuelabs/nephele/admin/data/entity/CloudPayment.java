package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name="cloud_payment_seq",sequenceName="cloud_payment_seq",initialValue=1)
//@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name="cloud_payment")
public class CloudPayment extends AbstractAuditEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 990212571925104182L;

	@Id
    @GeneratedValue(generator="cloud_payment_seq")
    @Column(name = "cloud_payment_id", nullable = false)
	private Long id;
	
	@Column(name="total")
	private Double total;

	@Column(name = "invoiceAmount")
	private Double invoiceAmount;

	@Column(name = "surcharge")
	private Double surcharge;

  @Column(name = "surcharge_gst")
  private Double surchargeGst;

  @Column(name = "service_name")
  private String serviceName;

	@Column(name = "paymentMode")
	private String paymentMode;

	@Column(name = "transactionId", nullable = false)
	private String transactionId;

	@Column(name = "instrumentType")
	private String instrumentType;

	@ManyToOne(cascade = {CascadeType.MERGE})
	@JoinColumn(name="cloud_invoice_id")
	private CloudResellerInvoice cloudInvoice;
}
