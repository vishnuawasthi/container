package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;

import com.valuelabs.nephele.admin.data.api.SubscriptionStatus;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_subscription_seq",sequenceName="cloud_subscription_seq",initialValue=1)
@Entity
@Table(name="cloud_subscription")
public class CloudSubscription extends AbstractAuditEntity implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = -7393005615546082737L;
	
	@Id
    @GeneratedValue(generator="cloud_subscription_seq")
    @Column(name = "cloud_subscription_id", nullable = false)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "RESELLER_COMPANY_ID")
	private CloudResellerCompany cloudResellerCompany;
	
	@ManyToOne
	@JoinColumn(name = "customer_company_id")
	private CloudCustomerCompany cloudCustomerCompany;
	
	//
	@Column(name="vendor_subscrioption_id")
	private String vendorSubscrioptionId;
	
	@Column(name = "subscibtion_status", nullable = true)
	@Enumerated(EnumType.STRING)
	private SubscriptionStatus subscriptionStatus;
	
	@Column(name="subscription_date")
	private Date subscriptionDate;
	
	@Column(name="description")
	private String description;
	
	@Column(name="license_count")
	private int licenseCount;
	
	@Column(name="is_new_subscription_arrear_invoiced")
	private boolean isNewSubscriptionArrearInvoiced;
	
	@Column(name="last_invoiced_date")
	private Date lastInvoicedDate;
	
	@ManyToOne
	@JoinColumn(name = "product_plan_id")
	private CloudProductPlan cloudProductPlan;
	
	@ManyToOne
	@JoinColumn(name = "account_id")
	private CloudAccount cloudAccount;
	
	@ManyToOne
	@JoinColumn(name="cloud_order_id")
	private CloudOrder cloudOrder;	


	@Column(name="subscription_last_renewal_date")
	private Date subscriptionLastRenewalDate;	
	
	@Column(name="license_auto_renewal")
	private boolean licenseAutoRenewal;
	
	@Column(name="auto_renewal_off_date")
	private Date autoRenewalOffDate;	
	
	@Column(name="cancellation_processed")
	private String cancellation;
	
	/*@OneToMany(mappedBy="cloudSubscription")
	private Set<CloudSubscriptionEdition> cloudSubscriptionEditions=new HashSet<CloudSubscriptionEdition>();*/
	
	@OneToOne(mappedBy="subscription")
	private CloudLicense cloudLicense = new CloudLicense();
	
    @OneToMany(mappedBy = "cloudSubscription")
    private Set<NomadeskMeteringData> nomadeskMeteringData = new HashSet<NomadeskMeteringData>();

}
