package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name = "cloud_reseller_invoice_line_seq", sequenceName = "cloud_reseller_invoice_line_seq", initialValue = 1)
@Entity
@Table(name = "cloud_reseller_invoice_line")
public class CloudResellerInvoiceLine extends AbstractAuditEntity implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = -307274343442707232L;

  @Id
  @GeneratedValue(generator = "cloud_reseller_invoice_line_seq")
  @Column(name = "cloud_reseller_invoice_line_id", nullable = false)
  private Long id;

  @Column(name = "description")
  private String description;

  @Column(name = "quantity")
  private String quantity;

  @Column(name = "unit_price")
  private Double unitPrice;

  @Column(name = "unit_cost")
  private Double unitCost;

  @Column(name = "total")
  private Double total;

  @Column(name = "total_vendor_cost")
  private Double totalVendorCost;

  @Column(name = "type")
  private String type;

  @ManyToOne(cascade = {CascadeType.MERGE})
  @JoinColumn(name = "cloud_invoice_id")
  private CloudResellerInvoice cloudInvoice;

  /*@ManyToOne
  @JoinColumn(name = "cloud_customer_company_id")
  private CloudCustomerCompany cloudCustomerCompany;*/

  @Column(name = "service_name")
  private String serviceName;

  @Column(name = "product_plan_name")
  private String productPlanName;

  @ManyToOne
  @JoinColumn(name = "cloud_order_id")
  private CloudOrder cloudOrder;

  public int compareTo(CloudResellerInvoiceLine o) {
    int val = o == null ? 1 : 0;
    if (val == 0 && this.getId() != null) {
      if (o.getId() == null) {
        val = 1;
      } else {
        val = (int) (this.getId().longValue() - o.getId().longValue());
      }
    }
    if (val == 0 && o.getId() != null && this.id == null) {
      val = -1;
    }
    return 0;
  }
}
