package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudServiceDeliveryModel;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudServiceDeliveryModelDAO extends AbstractJpaDAO<CloudServiceDeliveryModel> {

	public CloudServiceDeliveryModelDAO(){
		
		setClazz(CloudServiceDeliveryModel.class);
	}
}
