package com.valuelabs.nephele.admin.data.api;

/**
 * Created by snagaboina on 21/8/15.
 */
public enum CloudUserType {
  CUSTOMER,
  RESELLER,
  DISTRIBUTOR
}
