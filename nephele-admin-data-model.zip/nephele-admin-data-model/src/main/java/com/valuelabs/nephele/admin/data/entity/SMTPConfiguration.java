package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name = "smtp_configuration_seq", sequenceName = "smtp_configuration_seq", initialValue = 1)
@Entity
@Table(name = "smtp_configuration")
public class SMTPConfiguration extends AbstractAuditEntity implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "smtp_configuration_seq")
  @Column(name = "smtp_configuration_id")
  private Long id;

  @Column(name = "protocol")
  private String protocol;
  
  @Column(name = "host")
  private String host;
  
  @Column(name = "port")
  private Integer port;
  
  @Column(name = "smtp_auth")
  private Boolean smtpAuth;
  
  @Column(name = "smtp_starttls_enable")
  private Boolean smtpStarttlsEnable;
  
  @Column(name = "from_email")
  private String from;
  
  @Column(name = "username")
  private String username;
  
  @Column(name = "password")
  private String password;

}
