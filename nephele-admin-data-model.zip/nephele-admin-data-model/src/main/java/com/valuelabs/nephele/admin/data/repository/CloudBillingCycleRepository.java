package com.valuelabs.nephele.admin.data.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudBillingCycle;

public interface CloudBillingCycleRepository  extends TableRepository<CloudBillingCycle, Long>, JpaSpecificationExecutor<CloudBillingCycle>{
	
	@Query("FROM  CloudBillingCycle cb WHERE :currentDate BETWEEN cb.billingPeriodStartDate AND cb.billingPeriodEndDate")
	public CloudBillingCycle getBillingCycleByCurrentDate(@Param("currentDate")  Date currentDate);
	
}
