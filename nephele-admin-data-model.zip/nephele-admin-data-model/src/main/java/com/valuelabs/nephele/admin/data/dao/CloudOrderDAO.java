package com.valuelabs.nephele.admin.data.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudOrder;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

@Repository
public class CloudOrderDAO extends AbstractJpaDAO<CloudOrder>{

	@PersistenceContext
	EntityManager entityManager;
	
	public CloudOrderDAO() {
		setClazz(CloudOrder.class );
	}
	

	/**
	 * This method filters the DB records according to the requsted parameters and also it gives total existing records 
	 * records in the DB without parameters.
	 * @param status
	 * @param orderId
	 * @param externalCustomerCode
	 * @param dateRangeStart
	 * @param dateRangeEnd
	 * @return
	 */
	public List<CloudOrder> findOrdersByStatusAndDateRange(String status, Long orderId, String orderCode,
			String externalCustomerCode, Date dateRangeStart, Date dateRangeEnd, String externalResellerCode) {
		
			List<CloudOrder> list =   null;
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaQuery<CloudOrder> criteriaQuery = criteriaBuilder.createQuery(CloudOrder.class);
			Root<CloudOrder> rootBase = criteriaQuery.from(CloudOrder.class);
			Predicate predicate = criteriaBuilder.conjunction();
			Join<CloudOrder, CloudCustomerCompany> rootWithCustomer = rootBase.join("cloudCustomerCompany");
			
			Path<Object> rootWithResellerCompany = rootWithCustomer.get("cloudResellerCompany");
			
			List<Order> orderByList = new ArrayList<Order>();
			
			if (!StringUtils.isEmpty(status)) {
				Expression<String>  rootStatus = rootBase.get("status");
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), "%" + status.toLowerCase() + "%"));
			}
			if (!StringUtils.isEmpty(orderId)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootBase.get("id"), orderId));
				  
			}
			if (!StringUtils.isEmpty(orderCode)) {
				Expression<String>  rootOrderCode = rootBase.get("orderCode");
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootOrderCode), "%" + orderCode.toLowerCase() + "%"));
					  
			}
			if ( !StringUtils.isEmpty(externalCustomerCode)) {
			  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithCustomer.get("customerCompanyCode"), externalCustomerCode));
				  
			}
			if ( !StringUtils.isEmpty(externalResellerCode)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithResellerCompany.get("resellerCompanyCode"), externalResellerCode));
					  
				}
			if ( !StringUtils.isEmpty(dateRangeStart) && !StringUtils.isEmpty(dateRangeEnd)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.between(rootBase.<Date>get("created"), dateRangeStart, 
						  DateFormatterUtility.getAfterDate(dateRangeEnd, 23)));
			}
			
			criteriaQuery.where(predicate);
			
			orderByList.add(criteriaBuilder.asc(rootBase.get("id")));
			criteriaQuery.orderBy(orderByList);
			
			list =entityManager.createQuery(criteriaQuery).getResultList();
			
			return list;
		  }
}