package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.valuelabs.nephele.admin.data.entity.CloudRackspaceMeteringData;
import com.valuelabs.nephele.admin.data.entity.CloudRackspaceMeteringDataSubset;

public interface CloudRackspaceMeteringDataRepository  extends TableRepository<CloudRackspaceMeteringData, Long>, JpaSpecificationExecutor<CloudRackspaceMeteringData>  {
 
  @Query(" Select NEW com.valuelabs.nephele.admin.data.entity.CloudRackspaceMeteringDataSubset(RES_ID, SERVICE_TYPE, sum(QUANTITY) as QUANTITY, ATTRIBUTE_1) "
		+ "from CloudRackspaceMeteringData c where c.RES_ID is not null AND c.IMPACT_TYPE = 'CHARGE' group by c.RES_ID, c.SERVICE_TYPE, c.ATTRIBUTE_1 ORDER BY 1")
  public List<CloudRackspaceMeteringDataSubset> getMeteringDataList();
  
}
