package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudRackspaceConfiguration;

public interface CloudRackspaceConfigurationRepository extends TableRepository<CloudRackspaceConfiguration, Long>, JpaSpecificationExecutor<CloudRackspaceConfiguration>{

	@Query("FROM  CloudRackspaceConfiguration rc WHERE rc.cloudService.id = :serviceId")		
	public List<CloudRackspaceConfiguration> readByService(@Param("serviceId") Long serviceId);
	
	@Query("FROM CloudRackspaceConfiguration rc where rc.status = :status")		
	public List<CloudRackspaceConfiguration> readByStatus(@Param("status") String status);
	
	@Query("FROM CloudRackspaceConfiguration rc where rc.ram >= :minRam AND rc.disk >= :minDisk")		
	public List<CloudRackspaceConfiguration> readByRamAndDisk(@Param("minRam") Long minRam, @Param("minDisk") Long minDisk);
	
	/*@Query("FROM  CloudRackspaceConfiguration rc WHERE rc.cloudService.id = :serviceId")		
	public List<CloudRackspaceConfiguration> findRackspaceConfigurationSummaryByServiceId(@Param("serviceId") Long serviceId);*/
	
	@Query("SELECT status,count(status) FROM  CloudRackspaceConfiguration crc"
					+" WHERE crc.cloudService.id= :serviceId GROUP BY status")
	public List<Object[]> findRackspaceConfigurationSummaryByServiceId(@Param("serviceId") Long serviceId) ;
}
