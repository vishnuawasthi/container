package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountSheet;

public interface PremiumGroupDiscountSheetRepository  extends TableRepository<PremiumGroupDiscountSheet, Long>, JpaSpecificationExecutor<PremiumGroupDiscountSheet>{
	
	@Query("FROM PremiumGroupDiscountSheet ps where ps.premiumGroupDiscountConfig.discountSheetName =:sheetName")
	public List<PremiumGroupDiscountSheet> getDiscountSheetsByName(@Param("sheetName") String sheetName);
	
	@Query("FROM PremiumGroupDiscountSheet ps where ps.premiumGroupDiscountConfig.id =:configId AND ps.premiumGroup.id =:groupId" )
	public List<PremiumGroupDiscountSheet> getDiscountSheetsByConfigAndPremiumGroup(@Param("configId") Long configId, @Param("groupId") Long groupId);
	
	@Query("Select count(*) FROM PremiumGroupDiscountSheet ps where ps.premiumGroup.name =:name" )
	public Long getDiscountSheetsByPremiumGroupName(@Param("name") String name);
	

}
