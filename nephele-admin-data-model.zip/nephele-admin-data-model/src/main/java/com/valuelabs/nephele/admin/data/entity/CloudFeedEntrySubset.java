package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@ToString
public class CloudFeedEntrySubset extends AbstractAuditEntity implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "event_resource_id")
	private String eventResourceId;

	@Column(name = "product_flavor_id")
	private String productFlavorId;
	
	@Column(name = "product_flavor_name")
	private String productFlavorName;

	@Column(name = "product_bandwidth_out")
	private Double productBandwidthOut;

	@Column(name = "uptime_hours")
	private Double upTimeHours;

}
