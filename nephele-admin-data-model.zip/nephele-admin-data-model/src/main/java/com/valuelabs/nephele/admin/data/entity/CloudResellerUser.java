package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

@NamedQueries({
    @NamedQuery(name = "CloudResellerUser.findResellerUserByUserName", query = "SELECT cru FROM  CloudResellerUser cru WHERE resellerUserName = :resellerUserName")
})
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@SequenceGenerator(name = "cloud_reseller_user_seq", sequenceName = "cloud_reseller_user_seq", initialValue = 1)
@Table(name = "cloud_reseller_user")
public class CloudResellerUser extends AbstractAuditEntity implements Serializable {

  private static final long serialVersionUID = 4400504874020964359L;

  @Id
  @GeneratedValue(generator = "cloud_reseller_user_seq")
  @Column(name = "reseller_user_id")
  private Long resellerUserId;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "email")
  private String email;

  @Column(name = "reseller_user_name", nullable = false, unique = true)
  private String resellerUserName;

  @Column(name = "password", nullable = false)
  private String password;

  @ManyToOne
  @JoinColumn(name = "RESELLER_COMPANY_ID")
  private CloudResellerCompany cloudResellerCompany;

}