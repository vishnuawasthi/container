package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudManagerAppAccount;

public interface CloudManagerAppAccountRepository  extends TableRepository<CloudManagerAppAccount, Long>, JpaSpecificationExecutor<CloudManagerAppAccount>{

}
