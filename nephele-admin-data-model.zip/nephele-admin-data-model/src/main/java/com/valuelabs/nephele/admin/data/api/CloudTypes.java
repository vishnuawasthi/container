/**
 * 
 */
package com.valuelabs.nephele.admin.data.api;

/**
 * @author rrsanepalle
 *
 */
public enum CloudTypes {
	
	RACKSPACE,
	SOFTLAYER,
	AZURE

}
