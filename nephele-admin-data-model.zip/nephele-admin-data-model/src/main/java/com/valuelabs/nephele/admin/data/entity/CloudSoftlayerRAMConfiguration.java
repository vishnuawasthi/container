	package com.valuelabs.nephele.admin.data.entity;

	import java.io.Serializable;

	import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

	import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	// @Data
	@Setter
	@Getter
	@SequenceGenerator(name = "cloud_softalayer_ram_configuration_seq", sequenceName = "cloud_softalayer_ram_configuration_seq", initialValue = 1)
	@Entity
	@Table(name = "cloud_softalayer_ram_configuration")
	public class CloudSoftlayerRAMConfiguration extends AbstractAuditEntity implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "softalayer_ram_configuration_id")
		@GeneratedValue(generator = "cloud_softalayer_ram_configuration_seq")
		private Long id;

		@Column(name = "hourly_recurring_fee")
		private Double hourlyRecurringFee;

		@Column(name = "description")
		private String description;

		@Column(name = "max_memory")
		private Long maxMemory;
		
		@Column(name = "status")
		private String status;

		
	}


