
package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.hibernate.annotations.Type;

import com.valuelabs.nephele.admin.data.api.CloudPricingModel;
import com.valuelabs.nephele.admin.data.csv.CsvEntry;
import com.valuelabs.nephele.admin.data.csv.CsvFile;

@NamedQueries({@NamedQuery(name = "CloudProductPlan.findByProduct", query = " FROM CloudProductPlan pp where pp.cloudProduct.id = :productId AND pp.status = 'PUBLISHED' order by pp.id"),
			   @NamedQuery(name = "CloudProductPlan.findByProductAndLocation", query = " FROM CloudProductPlan pp where pp.cloudProduct.id = :productId "
			   																		 + "AND pp.cloudLocation.id = :locationId AND pp.status = 'PUBLISHED' order by pp.id"),
			   @NamedQuery(name = "CloudProductPlan.findByProductAndLocationAndCategory", query = " FROM CloudProductPlan pp where pp.cloudProduct.id = :productId "
					   																		 + "AND pp.cloudLocation.id = :locationId AND pp.flavorCategory = :category "
					   																		 + "AND pp.status = 'PUBLISHED' order by pp.id"),
			   @NamedQuery(name = "CloudProductPlan.findStagedPlans", query = " FROM CloudProductPlan pp where pp.status in ('STAGED') order by pp.cloudProduct.id,pp.flavorCategory,pp.sortKey"),
			   @NamedQuery(name = "CloudProductPlan.findByService", query = " FROM CloudProductPlan pp where pp.cloudService.id= :serviceId "),
			   @NamedQuery(name = "CloudProductPlan.findPublishedPlansByService", query = " FROM CloudProductPlan pp where pp.status = 'PUBLISHED' AND pp.cloudService.id= :serviceId "),			   
			   
			   @NamedQuery(name = "CloudProductPlan.findSummary", query = "SELECT  status, count(id) FROM  CloudProductPlan  cpp WHERE cpp.cloudService.id= :serviceId  GROUP BY status")

			})

@CsvFile(delimiter = ",", fileName = "")
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name = "cloud_product_plan_seq", sequenceName = "cloud_product_plan_seq", initialValue = 1)
@Entity
@Table(name = "cloud_product_plan")
public class CloudProductPlan extends AbstractAuditEntity implements Serializable {
  
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "cloud_product_plan_seq")
  @Column(name = "cloud_product_plan_id", nullable = false)
  @CsvEntry(header = "PLAN_ID", defaultValue = "0")
  private Long id;
  
  @Column(name = "plan_code", nullable = true)
  private String planCode;
  
  @Column(name = "plan_name", nullable = true)
  private String planName;

  @ManyToOne
  @JoinColumn(name = "cloud_service_id") 
  private CloudService cloudService;
  
  @Column(name = "price", columnDefinition="double precision default '0.0'")
  @CsvEntry(header = "PRICE", defaultValue = "0")
  private Double price;
  @CsvEntry(header = "VENDOR_PRICE", defaultValue = "0")
  @Column(name = "vendor_price", columnDefinition="double precision default '0.0'")  
  private Double vendorPrice;
  
  @Type(type = "StringJsonObject")
  @Column(name = "details", nullable = false)
  private String details;
  
  @Column(name = "status", nullable = true)
  private String status;
  
  @ManyToOne
  @JoinColumn(name="cloud_product_id" )
  private CloudProduct cloudProduct;
  
  @ManyToOne
  @JoinColumn(name = "cloud_location_id", nullable = true)
  private CloudLocation cloudLocation;
  
  @Column(name = "flavor_category", nullable = true)
  private String flavorCategory;
  
  @Column(name = "sort_key", nullable = true)
  private Long sortKey;
  
  @Column(name = "vendor_plan_code", nullable = true)
  private String vendorPlanCode;
  
  @Column(name = "is_trial_plan")
  private Boolean isTrialPlan;
  
  @Column(name = "description", nullable = true)
  private String description;
  
  @Column(name="cloud_pricing_model")
  @Enumerated(EnumType.STRING)
 private CloudPricingModel pricingModel;
  
  @OneToMany(mappedBy="cloudProductPlan")
  private Set<CloudOrder> cloudOrders=new HashSet<CloudOrder>();
  
  @OneToMany(mappedBy="cloudProductPlan")
  private Set<CloudProductPriceManagementSheet> priceManagementSheets=new HashSet<CloudProductPriceManagementSheet>();
  
  @OneToMany(mappedBy="cloudProductPlan")
  private Set<RackspaceServerConfiguration> rackspaceServerConfigurations=new HashSet<RackspaceServerConfiguration>();
  
  @OneToMany(mappedBy="cloudProductPlan")
  private Set<CloudSubscription> subscription = new HashSet<CloudSubscription>();
  
  @OneToMany(mappedBy="cloudProductPlan")
  private Set<CloudAccount> cloudAccount = new HashSet<CloudAccount>();
  
  @OneToMany(mappedBy="cloudProductPlan")
  private Set<NomadeskMeteringData> nomadeskMeteringData = new HashSet<NomadeskMeteringData>();
  
}
