package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Accessors(chain = true)
@Getter
@Setter
public class RevenueServiceDetail implements Serializable {

  private Long serviceId;

  private String serviceName;

  private String revenue;

  private String serviceCode;

  private String integrationCode;
}
