package com.valuelabs.nephele.admin.data.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.MeteringDataStatus;
import com.valuelabs.nephele.admin.data.entity.CloudFeedEntry;
import com.valuelabs.nephele.admin.data.entity.CloudFeedEntrySubset;

public interface CloudFeedEntryRepository  extends TableRepository<CloudFeedEntry, Long>, JpaSpecificationExecutor<CloudFeedEntry>{

	@Query("Select fe from CloudFeedEntry fe order by fe.entryPublished desc")
	public Page<CloudFeedEntry> findRecentEntry(Pageable pageble );
	
	/*@Query(" Select NEW com.valuelabs.nephele.admin.data.entity.CloudRackspaceMeteringDataSubset(RES_ID, SERVICE_TYPE, sum(QUANTITY) as QUANTITY, ATTRIBUTE_1) "
			+ "from RackspaceMeteringData c where c.RES_ID is not null AND c.IMPACT_TYPE = 'CHARGE' AND c.billingCycle.id =:cycleId group by c.billingCycle.id, c.RES_ID, c.SERVICE_TYPE, c.ATTRIBUTE_1 ORDER BY 1")
	public List<CloudRackspaceMeteringDataSubset> getMeteringDataList(@Param("cycleId")Long cycleId);*/
	
	@Query(" Select NEW com.valuelabs.nephele.admin.data.entity.CloudFeedEntrySubset(eventResourceId,productFlavorId,productFlavorName, sum(productBandwidthOut) as productBandwidthOut,"
			+ " sum(upTimeHours) as upTimeHours) from CloudFeedEntry c where c.eventResourceId is not null AND eventStartTime >=:eventStartTime "
			+ "AND eventEndTime <=:eventEndTime AND status =:status group by c.eventResourceId, c.productFlavorId, c.productFlavorName ORDER BY 1")
	public List<CloudFeedEntrySubset> getFeedDataList(@Param("eventStartTime")Date eventStartTime,@Param("eventEndTime")Date eventEndTime,@Param("status")MeteringDataStatus status);
	
	@Query(" Select c from CloudFeedEntry c where c.eventResourceId is not null AND eventStartTime >=:eventStartTime "
			+ "AND eventEndTime <=:eventEndTime")
	public List<CloudFeedEntry> getFeedDataWithStatus(@Param("eventStartTime")Date eventStartTime,@Param("eventEndTime")Date eventEndTime);
	
	@Query(" Select c from CloudFeedEntry c where c.eventResourceId = :eventResourceId AND c.productFlavorId = :productFlavourId")
	public List<CloudFeedEntry> getFeedEntryWithResourceId(@Param("eventResourceId")String eventResourceId,@Param("productFlavourId")String productFlavourId);
	
	
}
