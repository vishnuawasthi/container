package com.valuelabs.nephele.admin.data.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerInvoice;

public interface CloudCustomerInvoiceRepository extends TableRepository<CloudCustomerInvoice, Long>, JpaSpecificationExecutor<CloudCustomerInvoice>{
	
	@Query("FROM  CloudCustomerInvoice c WHERE c.invoiceStatus =:status")
	public List<CloudCustomerInvoice> getCustomerInvoiceLineByStatus(@Param("status") String statusValue);
	
	@Query("FROM  CloudCustomerInvoice c WHERE c.cloudCustomerCompany.id=:customerId")
	public List<CloudCustomerInvoice> getCustomerInvoiceLineBycustId(@Param("customerId") Long customerId);
	
	@Query("FROM  CloudCustomerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate")
	public List<CloudCustomerInvoice> getCustomerInvoiceLineByDates(@Param("fromDate") Date fromDate, @Param("toDate")  Date toDate);
	
	@Query("FROM  CloudCustomerInvoice c WHERE c.created BETWEEN :fromDate AND :toDate AND c.invoiceStatus=:status")
	public List<CloudCustomerInvoice> getCustomerInvoiceLineByDatesAndStatus(@Param("fromDate") Date fromDate, @Param("toDate")  Date toDate, @Param("status") String status);
}
