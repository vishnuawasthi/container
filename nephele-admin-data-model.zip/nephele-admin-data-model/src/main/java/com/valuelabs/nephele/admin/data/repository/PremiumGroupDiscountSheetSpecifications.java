package com.valuelabs.nephele.admin.data.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.api.ResellerDiscountPlanType;
import com.valuelabs.nephele.admin.data.entity.CloudResellerPremiumGroup;
import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountConfig;
import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountSheet;

public final class PremiumGroupDiscountSheetSpecifications {
	
	
	 public static Specification<PremiumGroupDiscountSheet> getByServiceNplanTypeNgroupName(final Long serviceId,final String groupName,final String planType,
			 																				final Long sheetId, final ChangeManagementConfigStatus status) {
		 
		  return new Specification<PremiumGroupDiscountSheet>(){
			
			@Override
			public Predicate toPredicate(Root<PremiumGroupDiscountSheet> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();

				Join<PremiumGroupDiscountSheet, PremiumGroupDiscountConfig> rootWithDiscountConfig = root.join("premiumGroupDiscountConfig");
				Join<PremiumGroupDiscountSheet, CloudResellerPremiumGroup> rootWithPremiumGroup= root.join("premiumGroup");
				Path<Object> rootWithService= rootWithDiscountConfig.get("cloudService");
				if(!StringUtils.isEmpty(sheetId)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithDiscountConfig.get("id"), sheetId));
				}
				
				if(!StringUtils.isEmpty(status)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithDiscountConfig.get("status"), status));
					}
				if(!StringUtils.isEmpty(groupName)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithPremiumGroup.get("name"), groupName));
					}
				if(!StringUtils.isEmpty(serviceId)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
					}
				if(!StringUtils.isEmpty(planType)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithDiscountConfig.get("planType"), ResellerDiscountPlanType.valueOf(planType)));
					}
				
				criteriaQuery.where(predicate);
						
		  		return predicate;
			}
		};
	 }
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts persons in ascending order by using the last name.
	     * @return
	     */
	 /*   public static Sort sortBystartRangeAsc() {
	        return new Sort(Sort.Direction.ASC, "startRange");
	    }
*/

}
