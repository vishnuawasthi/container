package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class AccountServerPK implements Serializable {
	 
	private static final long serialVersionUID = 9093924146821379905L;
	
	private Long resourceId;
	private String resourceType;
 
    /*public AccountServerPK(){
        // Your class must have a no-arq constructor
    }*/
 
    /*@Override
    public boolean equals(Object obj) {
        if(obj instanceof AccountServerPK){
        	AccountServerPK asPK = (AccountServerPK) obj;
 
            if(!asPK.getChassisSerialNumber().equals(chassisSerialNumber)){
                return false;
            }
 
            if(!asPK.getEngineSerialNumber().equals(engineSerialNumber)){
                return false;
            }
 
            return true;
        }
 
        return false;
    }
 
    @Override
    public int hashCode() {
        return chassisSerialNumber.hashCode() + engineSerialNumber.hashCode();
    }*/
 
}
