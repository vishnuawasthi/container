package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.valuelabs.nephele.admin.data.csv.CsvEntry;
import com.valuelabs.nephele.admin.data.util.StringJsonUserType;

@NamedQueries({
	@NamedQuery(name = "RackspaceConfiguration.readByRamAndDisk", 
			query = " FROM CloudRackspaceConfiguration rc where rc.ram >= :minRam AND rc.disk >= :minDisk "),
			
	@NamedQuery(name = "RackspaceConfiguration.readByStatus", 
			query = " FROM CloudRackspaceConfiguration rc where rc.status = :status"),

			@NamedQuery(name = "CloudRackspaceConfiguration.findRackspaceConfigurationSummaryByServiceId", query = "SELECT status,count(status) FROM  CloudRackspaceConfiguration crc"
					+" WHERE crc.cloudService.id= :serviceId GROUP BY status"),

	@NamedQuery(name="RackspaceConfiguration.readByService",
			query=" FROM  CloudRackspaceConfiguration rc WHERE rc.cloudService.id = :serviceId")

})

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
@SequenceGenerator(name="cloud_rackspace_configuration_seq",sequenceName="cloud_rackspace_configuration_seq", initialValue=1)
@Entity
@Table(name="cloud_rackspace_configuration")
public class CloudRackspaceConfiguration extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = -8201744599762098687L;

	@Id
	@GeneratedValue(generator="cloud_rackspace_configuration_seq")
    @Column(name = "cloud_rackspace_configuration_id", nullable = false)
	private Long id;
	
	@Column(name = "flavor_id", nullable = false)
	private String flavorId;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "flavor_class", nullable = false)
	private String flavor_class;
	
	@Column(name = "cpu", nullable = false)
	private Long cpu;
	
	@Column(name = "ram", nullable = false)
	private Long ram;
	
	@Column(name = "disk", nullable = false)
	private Long disk;
	
	@Column(name = "status", nullable = false)
	private String status;

	@Column(name = "price", columnDefinition = "double precision default '0.0'")
	private Double price;
	  
	@Type(type = "StringJsonObject")
	@Column(name = "csp_resource", nullable = false)
	private String cspResource;
	
	@ManyToOne
    @JoinColumn(name = "cloud_service_id") 
    private CloudService cloudService; 
	
	/*@OneToMany(mappedBy="cloudRackspaceConfiguration")
    private Set<CloudRackspaceComputePrice> cloudRackspaceComputePrices = new HashSet<CloudRackspaceComputePrice>();*/
	
	/*@OneToMany(mappedBy="cloudRackspaceConfiguration")
	private Set<RackspaceServerConfiguration> rackspaceServerConfigurations=new HashSet<RackspaceServerConfiguration>();*/
	
/*	@ManyToOne
    @JoinColumn(name = "cloud_configuration_type_id") 
    private CloudConfigurationType cloudConfigurationType;*/
	
}
