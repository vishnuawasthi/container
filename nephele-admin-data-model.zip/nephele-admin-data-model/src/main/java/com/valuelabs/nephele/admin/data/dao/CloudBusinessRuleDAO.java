package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.BusinessRuleNames;
import com.valuelabs.nephele.admin.data.entity.CloudBusinessRule;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
@Slf4j
public class CloudBusinessRuleDAO extends AbstractJpaDAO<CloudBusinessRule> {

	@Autowired
	private EntityManager entityManager;

	public CloudBusinessRuleDAO() {    
		setClazz(CloudBusinessRule.class);
	}

	public List< CloudBusinessRule> getBusinessRulesByRuleName(String ruleName) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CloudBusinessRule> criteriaQuery = criteriaBuilder.createQuery(CloudBusinessRule.class);
		Root<CloudBusinessRule> rootBase = criteriaQuery.from(CloudBusinessRule.class);
		Predicate predicate = criteriaBuilder.conjunction();
		
		if(!StringUtils.isEmpty(ruleName)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootBase.get("ruleName"), BusinessRuleNames.valueOf(ruleName)));
		}
		criteriaQuery.where(predicate);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

}
