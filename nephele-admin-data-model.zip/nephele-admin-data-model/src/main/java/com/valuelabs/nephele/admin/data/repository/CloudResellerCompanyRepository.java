package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudResellerCompany;

public interface CloudResellerCompanyRepository extends TableRepository<CloudResellerCompany, Long>, JpaSpecificationExecutor<CloudResellerCompany>{
	
	@Query("SELECT  crc.premiumGroup.name , count(id) FROM  CloudResellerCompany crc "
																										   + "WHERE crc.premiumGroup.id =:resellerPremiumGroupId "
																										   + "GROUP BY crc.premiumGroup.name  ")
	public List<Object[]> findResellerSummaryByDistributorPriceGroupId(@Param("resellerPremiumGroupId") Long distributorPriceGroupId);


	@Query("FROM CloudResellerCompany where resellerCompanyCode = :resellerCompanyCode")
	public CloudResellerCompany findByExternalResellerCode(@Param("resellerCompanyCode") String resellerCompanyCode);


	@Query("SELECT id, resellerCompanyName, resellerCompanyCode FROM CloudResellerCompany where resellerCompanyCode = :resellerCompanyCode")
	public List<Object[]> findByResellerCode(@Param("resellerCompanyCode") String resellerCompanyCode);

	@Query("SELECT  count(id) FROM  CloudResellerCompany crc")
	public Object findResellerCount();
	
	@Query("SELECT id FROM CloudResellerCompany where resellerCompanyCode = :resellerCompanyCode")
	public Long findIdByExternalResellerCode(@Param("resellerCompanyCode") String resellerCompanyCode);
	
	
}
