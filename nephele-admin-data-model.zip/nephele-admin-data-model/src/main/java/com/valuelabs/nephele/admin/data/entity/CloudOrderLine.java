/*package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name="cloud_order_line_seq",sequenceName="cloud_order_line_seq",initialValue=1)
//@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name="cloud_order_line")
public class CloudOrderLine extends AbstractTimestampEntity implements Serializable {*//**
	 * 
	 *//*
	private static final long serialVersionUID = -7393005615546082737L;
	
	@Id
	@GeneratedValue(generator="cloud_order_line_seq")
    @Column(name = "cloud_order_line_id", nullable = false)
	private Long id;
	
	@Column(name="quantity")
	private String quantity;
	
	@Column(name="configuration")
	private String configuration;//to change datatype
	
	@ManyToOne
	@JoinColumn(name="cloud_order_id")
	private CloudOrder cloudOrder;
	
	@ManyToOne
	@JoinColumn(name="cloud_product_id")
	private CloudProduct cloudProduct;
	
	@OneToMany(mappedBy="cloudOrderLine")
	private Set<CloudServer> cloudservers=new HashSet<CloudServer>();
	
	@OneToMany(mappedBy="cloudOrderLine")
	private Set<CloudSubscription> cloudSubscriptions=new HashSet<CloudSubscription>();
	
	@Column(name="status")
	private String status;
	
	

}
*/