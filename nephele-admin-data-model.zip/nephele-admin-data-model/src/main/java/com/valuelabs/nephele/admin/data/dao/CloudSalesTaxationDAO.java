package com.valuelabs.nephele.admin.data.dao;

import com.valuelabs.nephele.admin.data.entity.CloudSalesTaxation;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Repository
public class CloudSalesTaxationDAO extends AbstractJpaDAO<CloudSalesTaxation>{
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	public CloudSalesTaxationDAO() {
		setClazz(CloudSalesTaxation.class );
	}
	
public CloudSalesTaxation getByCountry(String countryCode) {
		TypedQuery<CloudSalesTaxation> query = entityManager.createNamedQuery("SalesTaxation.findByCountry", CloudSalesTaxation.class).
							  setParameter("countryCode", countryCode);
		return query.getSingleResult();
		
	}

}
