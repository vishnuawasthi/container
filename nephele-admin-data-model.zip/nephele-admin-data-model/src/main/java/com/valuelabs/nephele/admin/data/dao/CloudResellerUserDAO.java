package com.valuelabs.nephele.admin.data.dao;

import com.valuelabs.nephele.admin.data.entity.CloudResellerUser;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.List;

@Repository
public class CloudResellerUserDAO extends AbstractJpaDAO<CloudResellerUser> {

	@Autowired
	EntityManager entityManager;
	
	public CloudResellerUserDAO() {
		setClazz(CloudResellerUser.class);
	}
	
	public CloudResellerUser findUserByUserName(String resellerUserName) {
		CloudResellerUser cloudResellerUser = null;        
		TypedQuery<CloudResellerUser> query = entityManager.createNamedQuery("CloudResellerUser.findResellerUserByUserName", CloudResellerUser.class)
				   .setParameter("resellerUserName", resellerUserName);
		List <CloudResellerUser> userList = query.getResultList();
		if(!CollectionUtils.isEmpty(userList)) {
			cloudResellerUser = userList.get(0);
		}
		return cloudResellerUser;
		
	}
}
