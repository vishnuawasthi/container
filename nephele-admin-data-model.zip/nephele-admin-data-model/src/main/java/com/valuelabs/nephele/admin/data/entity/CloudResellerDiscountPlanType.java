package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import lombok.*;
import lombok.experimental.Accessors;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@NamedQueries({
    @NamedQuery(name = "CloudResellerDiscountPlanType.byType", query = "from CloudResellerDiscountPlanType where typeName = :type")
})
@SequenceGenerator(name = "cloud_reseller_discount_plan_type_seq", sequenceName = "cloud_reseller_discount_plan_type_seq", initialValue = 1)
@Entity
@Table(name = "cloud_reseller_discount_plan_type")
public class CloudResellerDiscountPlanType extends AbstractAuditEntity implements Serializable {

  private static final long serialVersionUID = 9064591024249055329L;

  @Id
  @GeneratedValue(generator = "cloud_reseller_discount_plan_type_seq")
  @Column(name = "id", nullable = false)
  private Long id;

  @Column(name = "type_name", nullable = false)
  private String typeName;

  @Column(name = "description")
  private String description;
  
  @OneToMany(mappedBy = "planType")
  private Set<PremiumGroupDiscountConfig> discountGroupSet = new HashSet<PremiumGroupDiscountConfig>();
}