package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Accessors(chain = true)
@Getter
@Setter
@Entity
@SequenceGenerator(name="nomadesk_metering_data_seq" ,sequenceName="nomadesk_metering_data_seq",initialValue=1)
@Table(name="nomadesk_metering_data")
public class NomadeskMeteringData extends AbstractAuditEntity implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  
  @Id
  @GeneratedValue(generator="nomadesk_metering_data_seq")
  @Column(name="metering_id")
  private Long id;
  
  @Column(name="plan_name")
  private String planName;
  
  @Column(name="charge_type")
  private String chargeType;
  
  @Column(name="charge_description")
  private String chargeDescription;
  
  @Column(name="subscription_start_date")
  private Date subscriptionStartDate;
  
  @Column(name="subscription_end_date")
  private Date subscriptionEndDate;
  
  @Column(name="charge_start_date")
  private Date chargeStartDate;
  
  @Column(name="charge_end_date")
  private Date chargeEndDate;
  
  @Column(name="currency")
  private String currency;
  
  @Column(name="unit_price")
  private Double unitPrice;
  
  @Column(name="quantity")
  private Integer quantity;
  
  @Column(name="vendor_price")
  private Double vendorPrice;
  
  @Column(name="vendor_currency")
  private String vendorCurrency;
  
  @Column(name="is_charged")
  private Boolean isCharged;
  
  @Column(name="comment")
  private String comment;
  
  @ManyToOne
  @JoinColumn(name = "cloud_service_id")
  private CloudService cloudService;
  
  @ManyToOne
  @JoinColumn(name = "customer_company_id")
  private CloudCustomerCompany cloudCustomerCompany;
  
  @ManyToOne
  @JoinColumn(name = "cloud_product_plan_id")
  private CloudProductPlan cloudProductPlan;
  	
  @ManyToOne
  @JoinColumn(name = "cloud_subscription_id")
  private CloudSubscription cloudSubscription;
  
  
  
  
}
