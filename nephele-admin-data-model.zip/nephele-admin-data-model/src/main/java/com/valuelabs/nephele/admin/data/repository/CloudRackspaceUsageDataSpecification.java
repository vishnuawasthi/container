package com.valuelabs.nephele.admin.data.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;
import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudRackspaceConfiguration;
import com.valuelabs.nephele.admin.data.entity.CloudRackspaceUsageData;

@Slf4j
public class CloudRackspaceUsageDataSpecification {
	public static Specification<CloudRackspaceUsageData> getRackspaceCustomersUsageDataByStatus(final String status,
																																															final Set<CloudCustomerCompany> customerCompanies) {
	return new Specification<CloudRackspaceUsageData>() {

	  @Override
	  public Predicate toPredicate(Root<CloudRackspaceUsageData> root, CriteriaQuery<?> criteriaQuery,CriteriaBuilder criteriaBuilder) {
		Predicate predicate = criteriaBuilder.conjunction();

			Join<CloudRackspaceConfiguration, CloudCustomerCompany> rootWithCustomerCompany = root.join("cloudCustomerCompany");
		List<Order> orderList = new ArrayList<Order>();
		if (!StringUtils.isEmpty(status)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("status"), status));
		}

			if (null != customerCompanies && !customerCompanies.isEmpty()) {
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.in(rootWithCustomerCompany.get("id")).value(getCustomerIdList(customerCompanies)));
		}

		criteriaQuery.where(predicate);
		orderList.add(criteriaBuilder.asc(root.get("id")));
		criteriaQuery.orderBy(orderList);
		return predicate;
	  }

	};
	}

	public static Specification<CloudRackspaceUsageData> getRackspaceCustomerUsageDataByStatus(final MeteringDataInvoiceStatus status,
																																														 final Long customerId) {
		return new Specification<CloudRackspaceUsageData>() {

			@Override
			public Predicate toPredicate(Root<CloudRackspaceUsageData> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();

				Join<CloudRackspaceConfiguration, CloudCustomerCompany> rootWithCustomerCompany = root.join("cloudCustomerCompany");
				List<Order> orderList = new ArrayList<Order>();
				if (!StringUtils.isEmpty(status)) {
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("resellerInvoiceStatus"), status));
				}

				if (null != customerId) {
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithCustomerCompany.get("id"), customerId));
				}

				criteriaQuery.where(predicate);
				orderList.add(criteriaBuilder.asc(root.get("id")));
				criteriaQuery.orderBy(orderList);
				return predicate;
			}

		};
	}
  
  public static  Specification<CloudRackspaceUsageData> getRackspaceResellerUsageDataByStatus(final String status){
	return new  Specification<CloudRackspaceUsageData>() {

	  @Override
      public Predicate toPredicate(Root<CloudRackspaceUsageData> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
		Predicate predicate = criteriaBuilder.conjunction();

		List<Order> orderList = new ArrayList<Order>();
		if (!StringUtils.isEmpty(status)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("status"), status));
		}

		criteriaQuery.where(predicate);
		orderList.add(criteriaBuilder.asc(root.get("id")));
		criteriaQuery.orderBy(orderList);
		return predicate;
      }
	  
	};
  }
  
  public static Sort sortByIdAsc() {
    return new Sort(Sort.Direction.ASC, "id");
}

/**
* Returns a new object which specifies the the wanted result page.
* @param pageIndex The index of the wanted result page
* @return
*/
public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
    Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
    return pageSpecification;
}

/**
 * Returns a Sort object which sorts persons in ascending order by using the last name.
 * @return
 */
public static Sort sortByLastNameAsc() {
    return new Sort(Sort.Direction.ASC, "lastName");
}


	private static Set<Long> getCustomerIdList(Set<CloudCustomerCompany> customerCompanies) {
		Set<Long> customerList = new HashSet<>();
		for (CloudCustomerCompany customerCompany : customerCompanies)
			customerList.add(customerCompany.getId());
		return customerList;
	}

  
}
