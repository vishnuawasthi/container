package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.util.StringJsonUserType;
import lombok.*;
import lombok.experimental.Accessors;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.Serializable;


@Setter
@Getter
@Accessors(chain = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@TypeDefs({@TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class)})
@SequenceGenerator(name = "cloud_lifecycle_config_seq", sequenceName = "cloud_lifecycle_config_seq", initialValue = 1)
@Builder
@Table(name = "cloud_lifecycle_config")
public class CloudLifeCycleConfig extends AbstractAuditEntity implements Serializable{
	
	private static final long serialVersionUID = 6339963575142170464L;

	@Id
	@GeneratedValue(generator = "cloud_lifecycle_config_seq")
	@Column(name = "cloud_lifecycle_config_id  ")
	private Long cloudLifeCycleConfigId;
	
	@Column(name = "orderid_prefix ")
	private String orderPrefix;
	
	@Column(name = "invoice_prefix")
	private String invoicePrefix;
	
	@Column(name = "currency")
	private String currency;
	
	@Column(name="amex_surcharge",nullable=true)
	private Double amexSurcharge;
	
	@Column(name="master_surcharge",nullable=true)
	private Double masterSurcharge;
	
	@Column(name="visa_surcharge",nullable=true)
	private Double visaSurcharge;
	
	@Column(name = "invoice_term")
	private Integer invoiceTerm;

	@Type(type = "StringJsonObject")
	@Column(name = "distributor_key")
	private String distributorKey;
	
}
