package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudDistributorUser;
import com.valuelabs.nephele.admin.data.exception.ResourceNotFoundException;

public interface CloudDistributorUserRepository extends TableRepository<CloudDistributorUser, Long>, JpaSpecificationExecutor<CloudDistributorUser>{

	@Query("FROM  CloudDistributorUser WHERE email = :email AND isEnabled =true")	
	public CloudDistributorUser findUserByUserName(@Param("email") String distributorName);
	
	@Query("FROM  CloudDistributorUser WHERE passwordResetToken = :passwordResetToken")	
	public CloudDistributorUser findUserByPswdResetToken(@Param("passwordResetToken") String passwordResetToken);
	
	@Query("FROM  CloudDistributorUser WHERE email = :email AND isEnabled =true")	
	public CloudDistributorUser findUserByEmail(@Param("email") String email) throws ResourceNotFoundException;
	
	@Query("FROM  CloudDistributorUser WHERE apiKey = :apiKey")	
	public CloudDistributorUser findUserByApiKey(@Param("apiKey") String apiKey);
}
