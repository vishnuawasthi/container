package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;

public interface CloudCustomerCompanyRepository extends TableRepository<CloudCustomerCompany, Long>, JpaSpecificationExecutor<CloudCustomerCompany>{
	
	@Query(" FROM CloudCustomerCompany ccc where ccc.customerCompanyCode = :customerCompanyCode")
	public CloudCustomerCompany findByExternalCustomerCode(@Param("customerCompanyCode") String customerCompanyCode);
	
	@Query(" FROM CloudCustomerCompany ccc where ccc.cloudResellerCompany.resellerCompanyCode = :resellerCompanyCode")
	public List<CloudCustomerCompany> findByExternalResellerCode(@Param("resellerCompanyCode") String resellerCompanyCode);
	
	@Query("SELECT ccc.id FROM CloudCustomerCompany ccc where ccc.customerCompanyCode = :customerCompanyCode")
	public Long findIdByExternalCustomerCode(@Param("customerCompanyCode") String customerCompanyCode);
	
	@Query("SELECT ccc.id FROM CloudCustomerCompany ccc where ccc.cloudResellerCompany.id = :resellerId")
	public List<Long> findCustomerIdByResellerId(@Param("resellerId") Long resellerId);

	@Query("SELECT id, customerCompanyName, customerCompanyCode FROM CloudCustomerCompany where customerCompanyCode = :customerCompanyCode")
	public List<Object[]> findByExternalCompanyCode(@Param("customerCompanyCode") String customerCompanyCode);


}
