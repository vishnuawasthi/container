package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudServerAction;
public interface CloudServerActionRepository extends TableRepository<CloudServerAction, Long>, JpaSpecificationExecutor<CloudServerAction> {
  @Query("SELECT csa FROM  CloudServerAction csa WHERE csa.cloudServer.id =:serverId") 
  public List<CloudServerAction> getComputePriceByOSId(@Param("serverId")   Long serverId);
}
