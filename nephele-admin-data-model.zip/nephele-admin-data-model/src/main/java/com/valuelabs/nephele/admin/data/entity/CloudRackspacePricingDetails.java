package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;
@Setter
@Getter
@Accessors(chain = true)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_rackspace_pricing_details_seq", sequenceName = "cloud_rackspace_pricing_details_seq",
    initialValue = 1)
@Builder
@Table(name = "cloud_rackspace_pricing_details")
public class CloudRackspacePricingDetails extends AbstractAuditEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "cloud_rackspace_pricing_details_seq")
  @Column(name = "cloud_rackspace_pricing_details_id")
  private Long id;
  
  @Column(name = "product_id")
  private String product_id;
  
  @Column(name = "product_name")
  private String productName;
  
  @Column(name = "product_description")
  private String productDescription;
  
  @Column(name = "product_status")
  private String status;
  
  @Column(name = "product_code")
  private String productCode;
  
  @Column(name = "sales_channel")
  private String salesChannel;
  
  @Column(name = "charge_type")
  private String chargeType;
  
  @Column(name = "service_level")
  private String serviceLevel;
  
  @Column(name = "service_type")
  private String serviceType;
  
  @Column(name = "flavor_class")
  private String className;
  
  @Column(name = "options")
  private String options;
  
  @Column(name = "flavor_id")
  private String flavorId;  
  
  @Column(name = "os_type")
  private String osType;
  
  @Column(name = "product_category")
  private String productCategory;
  
  @Column(name = "ram_in_mb")
  private String ramInMb;
  
  @Column(name = "version")
  private int version;
  
  @OneToMany(mappedBy = "cloudRackspacePriceDetails", fetch = FetchType.EAGER)
  private Set<CloudRackspacePriceUnitMeasure> cloudRackspacePriceUnits = new HashSet<CloudRackspacePriceUnitMeasure>();

}
