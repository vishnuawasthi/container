package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.valuelabs.nephele.admin.data.entity.RelatedExternalProduct;

public interface RelatedExternalProductRepository extends TableRepository<RelatedExternalProduct, Long>, JpaSpecificationExecutor<RelatedExternalProduct>{
	
	@Query("FROM RelatedExternalProduct rcp where rcp.externalProduct.id = :extProductId")
	public List<RelatedExternalProduct> getRelatedExternalProductsByExtId(@Param("extProductId") Long extProductId);
	
	@Query("FROM RelatedExternalProduct rcp where rcp.cloudProduct.id = :productId")
	public List<RelatedExternalProduct> readRelatedexternalproductsByCloudProductId(@Param("productId") Long productId);
	
	@Query("FROM RelatedExternalProduct rcp where rcp.cloudProduct.id in (:productIds)")
	public List<RelatedExternalProduct> readRelatedexternalproductsByCloudProductIds(@Param("productIds") List<Long> productIds);
	
	@Query("FROM RelatedExternalProduct rcp where rcp.externalProduct.externalId in (:extProductIds)")
	public List<RelatedExternalProduct> getRelatedCloudProductsByExtIds(@Param("extProductIds") List<String> extProductIds);
	
	@Modifying
    @Transactional
	@Query("delete from RelatedExternalProduct rep where rep.cloudProduct.id = ?1")
    void deleteByCloudProductId(Long cloudProductId);
	
}
