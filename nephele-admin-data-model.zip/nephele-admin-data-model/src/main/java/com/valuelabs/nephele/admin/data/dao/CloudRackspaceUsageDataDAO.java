package com.valuelabs.nephele.admin.data.dao;

import com.valuelabs.nephele.admin.data.api.MeteringDataInvoiceStatus;
import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudRackspaceUsageData;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Repository
@Slf4j
public class CloudRackspaceUsageDataDAO extends AbstractJpaDAO<CloudRackspaceUsageData> {

  @PersistenceContext
  EntityManager entityManager;

  public CloudRackspaceUsageDataDAO() {
    setClazz(CloudRackspaceUsageData.class);
  }

  public List<CloudRackspaceUsageData> getRackspaceCustomerUsageDataByStatus(MeteringDataInvoiceStatus status, CloudCustomerCompany cloudCustomerCompany) {
    TypedQuery<CloudRackspaceUsageData> usageDataList = entityManager.createNamedQuery("CustomerUsageData.findByStatus", CloudRackspaceUsageData.class)
        .setParameter("status", status).setParameter("customerCompanyId", cloudCustomerCompany.getId());
    return usageDataList.getResultList();
  }


  public List<CloudRackspaceUsageData> getRackspaceResellerUsageDataByStatus(MeteringDataInvoiceStatus status, Set<CloudCustomerCompany> customerCompanies) {
    TypedQuery<CloudRackspaceUsageData> usageDataList = entityManager.createNamedQuery("ResellerUsageData.findByStatus", CloudRackspaceUsageData.class)
        .setParameter("status", status).setParameter("cloudCustomerCompanyList", getCustomerIdList(customerCompanies));
    return usageDataList.getResultList();
  }

  public Double getRackspaceResellerUsageData(MeteringDataInvoiceStatus status, Set<CloudCustomerCompany> customerCompanies) {
    Double returnVal = null;
    try {
      Query query = entityManager.createNativeQuery("SELECT sum(usage_quantity) as NUMBER FROM  cloud_rackspace_usage_data  WHERE customer_company_id in :customerCompanyIdList and reseller_invoice_status=:status");
      query.setParameter("status", status.name())
          .setParameter("customerCompanyIdList", getCustomerIdList(customerCompanies));
      returnVal = (Double) query.getSingleResult();
    } catch (Exception e) {
      log.error("Exception occurs while generating calculating usage quantity for customer: ", e.getMessage());
    }
    return returnVal;
  }

  public void updateAll (List<CloudRackspaceUsageData> usageDataList) {
    if(null != usageDataList && !usageDataList.isEmpty()) {
      for (CloudRackspaceUsageData usageData : usageDataList)
        entityManager.merge(usageData);
    }
  }

  private Set<Long> getCustomerIdList(Set<CloudCustomerCompany> customerCompanies) {
    Set<Long> customerList = new HashSet<>();
    for(CloudCustomerCompany customerCompany: customerCompanies )
      customerList.add(customerCompany.getId());
    return customerList;
  }

}
