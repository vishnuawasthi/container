package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.valuelabs.nephele.admin.data.api.MeteringDataStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@SequenceGenerator(name = "cloud_feed_entry_seq", sequenceName = "cloud_feed_entry_seq", initialValue = 1)
@Entity
@Table(name = "cloud_feed_entry")
public class CloudFeedEntry extends AbstractAuditEntity implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -4234401086624620674L;

  // Entry related properties
  @Id
  @GeneratedValue(generator = "cloud_feed_entry_seq")
  @Column(name = "cloud_feed_entry_id")
  private Long id;
  
  @Column(name = "entry_uuid")
  private String entryUuid;

  @Column(name = "entry_title")
  private String title;

  @Column(name = "entry_published")
  private Date entryPublished;

  @Column(name = "entry_updated")
  private Date entryUpdated;
  
  @Column(name = "entry_link")
  private String entryLink;
  
  @Column(name = "feed_uuid")
  private String feedUuid;

  // Event related properties
  @Column(name = "event_data_center")
  private String eventDataCenter;

  @Column(name = "event_end_time")
  private Date eventEndTime;

  @Column(name = "event_environemnt")
  private String eventEnvironment;

  @Column(name = "event_region")
  private String eventRegion;

  @Column(name = "event_resource_id")
  private String eventResourceId;

  @Column(name = "event_resource_name")
  private String eventResourceName;

  @Column(name = "event_start_time")
  private Date eventStartTime;

  @Column(name = "event_tenant_id")
  private String eventTenantId;

  @Column(name = "event_type")
  private String eventType;

  @Column(name = "event_version")
  private String eventVersion;
  
  @Column(name = "event_id")
  private String eventId;

  // Product related properties
 /* @Column(name = "product_value")
  private String productValue;*/

  @Column(name = "product_bandwidth_in")
  private Double productBandwidthIn;

  @Column(name = "product_bandwidth_out")
  private Double productBandwidthOut;

  @Column(name = "product_flavor_id")
  private String productFlavorId;

  @Column(name = "product_flavor_name")
  private String productFlavorName;

  @Column(name = "product_is_managed")
  private String productIsManaged;

  @Column(name = "product_oslicence_type")
  private String productOsLicenseType;

  @Column(name = "product_resource_type")
  private String productResourceType;

  @Column(name = "product_service_code")
  private String productServiceCode;

  @Column(name = "product_status")
  private String productStatus;

  @Column(name = "product_version")
  private String productVersion;
  
  //Category properties 
  /*@Column(name = "category_tid")
  private String categoryTID;
  
  @Column(name = "category_rgn")
  private String categoryRGN;
  
  @Column(name = "category_dc")
  private String categoryDC;
  
  @Column(name = "category_rid")
  private String categoryRID;
  
  @Column(name = "category_stack")
  private String categoryStack;
  
  @Column(name = "category_type")
  private String categoryType;
  
  @Column(name = "category_compute")
  private String categoryCompute;
  
  @Column(name = "category_msgid")
  private String categoryOriginMsgId;
  */
  
  @Column(name = "entry_content", length=2000 )
  private String entryContent;

  @ManyToOne
  @JoinColumn(name = "cloud_feed_id")
  private CloudFeed cloudFeed;
  
  @Column(name = "uptime_hours")
  private Double upTimeHours;
  
  @Enumerated(EnumType.STRING)
  @Column(name="status")
  private MeteringDataStatus status;
  
@Override
public String toString() {
	return "uuid=" + entryUuid + ", title=" + title + ", entryPublished=" + entryPublished
			+ ", entryUpdated=" + entryUpdated + ", entryLink=" + entryLink + ", feedUuid=" + feedUuid
			+ ", eventDataCenter=" + eventDataCenter + ", eventEndTime=" + eventEndTime + ", eventEnvironment="
			+ eventEnvironment + ", eventRegion=" + eventRegion + ", eventResourceId=" + eventResourceId
			+ ", eventResourceName=" + eventResourceName + ", eventStartTime=" + eventStartTime + ", eventTenantId="
			+ eventTenantId + ", eventType=" + eventType + ", eventVersion=" + eventVersion + ", eventId=" + eventId
			+ ", productBandwidthIn=" + productBandwidthIn + ", productBandwidthOut=" + productBandwidthOut
			+ ", productFlavorId=" + productFlavorId + ", productFlavorName=" + productFlavorName
			+ ", productIsManaged=" + productIsManaged + ", productOsLicenseType=" + productOsLicenseType
			+ ", productResourceType=" + productResourceType + ", productServiceCode=" + productServiceCode
			+ ", productStatus=" + productStatus + ", productVersion=" + productVersion + ", entryContent="
			+ entryContent + ", cloudFeed=" + cloudFeed;
}



}
