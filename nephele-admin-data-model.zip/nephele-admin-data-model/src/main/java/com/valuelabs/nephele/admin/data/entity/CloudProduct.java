package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NamedQueries({@NamedQuery(name="CloudProduct.findByServiceId",
						   query="FROM  CloudProduct cp WHERE cp.cloudService.id =:serviceId"),
			   @NamedQuery(name="CloudProduct.findByServiceAndOs",
						   query="FROM  CloudProduct cp WHERE cp.cloudService.id =:serviceId AND cp.cloudOperatingSystem.id = :osId"),
			   
			   @NamedQuery(name="CloudProduct.findByIds",
						   query="FROM   CloudProduct cp WHERE cp.id in (:productIds) AND status = 'PUBLISHED' AND cp.cloudService.isPublished = true"),
						   
			 @NamedQuery(name="CloudProduct.findPublishedProducts",
						   query="FROM   CloudProduct cp WHERE status = 'PUBLISHED' AND cp.cloudService.isPublished = true")
				
			 /*@NamedQuery(name="CloudProduct.findByCategoryAndLocation",
						   query="FROM   CloudProduct cp WHERE cp.cloudProductCategory.id =:categoryId ")*/

})
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name="cloud_product_seq",sequenceName="cloud_product_seq",initialValue=1)
@Entity
@Table(name="cloud_product")
public class CloudProduct extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = 7134383092451105658L;

	@Id
    @GeneratedValue(generator="cloud_product_seq")
    @Column(name = "cloud_product_id", nullable = false)
	private Long id;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "description", nullable = false)
	private String description;
	
	@Column(name = "type", nullable = false)
	private String type;
	
	@Column(name = "status", nullable = true)
	private String status;
	
	@ManyToOne
    @JoinColumn(name = "cloud_operating_system_id") 
    private CloudOperatingSystem cloudOperatingSystem;
	
	@ManyToOne
    @JoinColumn(name = "cloud_service_id") 
    private CloudService cloudService;
	
	/*@OneToMany(mappedBy="cloudProduct")
	private Set<CloudOrder> cloudOrders=new HashSet<CloudOrder>();*/
	
	@OneToMany(mappedBy="cloudProduct" ,cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private Set<CloudProductPlan> cloudProductPlan=new HashSet<CloudProductPlan>();
	
	/*@ManyToOne
    @JoinColumn(name = "cloud_product_category_id") 
    private CloudProductCategory cloudProductCategory;*/
	
	/*@OneToMany(mappedBy="cloudProduct")
	private Set<CloudServer> cloudServers=new HashSet<CloudServer>();
	
	@OneToMany(mappedBy="cloudProduct")
	private Set<CloudSubscription> cloudSubscriptions=new HashSet<CloudSubscription>();*/
	
	@Column(name = "is_featured", nullable = true)
	private Boolean isFeatured;

	@Column(name = "has_free_trial", nullable = true)
	private Boolean hasFreeTrial;
	
	@Column(name = "has_related_products", nullable = true)
	private Boolean hasRelatedProducts;
	
	@OneToMany(mappedBy = "cloudProduct",fetch=FetchType.EAGER)
	private Set<BundleCloudProduct> bundleCloudProduct = new HashSet<BundleCloudProduct>();
	
}
