package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.data.api.CurrencyConversionStatus;
import com.valuelabs.nephele.admin.data.api.NepheleCurrency;

@Getter
@Setter
@Builder
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_currency_conversion_rate_audit_seq", sequenceName = "cloud_currency_conversion_rate_audit_seq", initialValue = 1)
@Entity
@Table(name="cloud_currency_conversion_rate_audit")
public class CloudCurrencyConversionRateAudit extends AbstractAuditEntity implements Serializable {

  
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator="cloud_currency_conversion_rate_audit_seq")
  @Column(name = "cloud_currency_conversion_rate_audit_id", nullable = false)
  private Long id;

  @Column(name="conversion_rate")
  private Double conversionRate;

  @Column(name="created_on")
  private Date createdOn;
  
  @ManyToOne
  @JoinColumn(name = "cloud_currency_conversion_rate_id", nullable = true)
  private CloudCurrencyConversionRate cloudCurrencyConversionRate;

}
