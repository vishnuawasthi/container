package com.valuelabs.nephele.admin.data.common;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * Created by snagaboina on 10/9/15.
 */
@Data
@Accessors(chain = true)
@Builder
public class ReadCloudInvoice {

  private Long cloudInvoiceId;
  private Long resellerId;
  private String resellerName;
  private String serviceCode;
  private Long serviceId;
  private String status;
  private String notEqualStatus;
  private Date fromDate;
  private Date toDate;
  private Date fromDueDate;
  private Date toDueDate;
  private Date billingStartDate;
  private Date billingEndDate;
  private Integer numberOfRecords;
  private String sortBy;
  private String invoiceNumber;
  private String resellerCode;
}
