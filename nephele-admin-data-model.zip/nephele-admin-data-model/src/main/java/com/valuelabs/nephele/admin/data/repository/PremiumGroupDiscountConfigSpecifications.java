package com.valuelabs.nephele.admin.data.repository;

import java.util.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.api.ChangeManagementConfigStatus;
import com.valuelabs.nephele.admin.data.entity.PremiumGroupDiscountConfig;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

public final class PremiumGroupDiscountConfigSpecifications {
	
	
	 public static Specification<PremiumGroupDiscountConfig> getPremiumGroupDiscountConfigsBySheetNameAndStatusAndActiveDateRanges(final String SheetName, final String status,
			final  String activeFrom, final String activeTo, final Long serviceId) {
		 
		  return new Specification<PremiumGroupDiscountConfig>(){
			
			@Override
			public Predicate toPredicate(Root<PremiumGroupDiscountConfig> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();
				

				if(!StringUtils.isEmpty(SheetName)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("discountSheetName"), SheetName));
				}
				if (!StringUtils.isEmpty(status)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("status"), ChangeManagementConfigStatus.valueOf(status)));

				}
				if(null != serviceId){
					Path<Object> rootWithService= root.get("cloudService");
					predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithService.get("id"), serviceId));
				}
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.notEqual(root.get("status"), ChangeManagementConfigStatus.ARCHIVED));
				if ( !StringUtils.isEmpty(activeFrom) && !StringUtils.isEmpty(activeTo)) {
					Expression<Date>  rootCategory = root.get("activeFrom");  
				    predicate = criteriaBuilder.and(predicate,criteriaBuilder.greaterThanOrEqualTo(rootCategory, DateFormatterUtility.formatDate(activeFrom)));		    
				    predicate = criteriaBuilder.and(predicate,criteriaBuilder.lessThanOrEqualTo(rootCategory, DateFormatterUtility.formatDate(activeTo)));
				}		
				criteriaQuery.where(predicate);					
		  		return predicate;
			}
		};
	 }
	 
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts persons in ascending order by using the last name.
	     * @return
	     */
	    public static Sort sortBydiscountSheetNameAsc() {
	        return new Sort(Sort.Direction.ASC, "discountSheetName");
	    }


}
