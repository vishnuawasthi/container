package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudRackspaceConfiguration;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudRackspaceConfigurationDAO extends AbstractJpaDAO<CloudRackspaceConfiguration> {
	@PersistenceContext
	EntityManager entityManager;

	
	public CloudRackspaceConfigurationDAO() {
		setClazz(CloudRackspaceConfiguration.class);
	}
	
	public List<CloudRackspaceConfiguration> readByService(Long serviceId) {
		
		TypedQuery<CloudRackspaceConfiguration> query =
				entityManager.createNamedQuery("RackspaceConfiguration.readByService", CloudRackspaceConfiguration.class).
							  setParameter("serviceId", serviceId);
		return query.getResultList();
		
	}
}
