package com.valuelabs.nephele.admin.data.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.api.DbsSyncStatus;
import com.valuelabs.nephele.admin.data.entity.CloudProductPlan;
import com.valuelabs.nephele.admin.data.entity.ProductPlanExternalSync;

public interface ProductPlanExternalSyncRepository
		extends TableRepository<ProductPlanExternalSync, Long>, JpaSpecificationExecutor<ProductPlanExternalSync> {
	
	@Query("FROM ProductPlanExternalSync where planCode= :planCode")
	public ProductPlanExternalSync getProductPlanByPlancode(@Param("planCode")String planCode);
	
	@Query("FROM ProductPlanExternalSync where status != :status")
	public List<ProductPlanExternalSync> getPlanRecordsByStatus(@Param("status") DbsSyncStatus status);
	
	@Query("FROM CloudProductPlan where planCode in :planCode")
	public List<CloudProductPlan> getMatchingRecords(@Param("planCode")Set<String> planCode);

}
