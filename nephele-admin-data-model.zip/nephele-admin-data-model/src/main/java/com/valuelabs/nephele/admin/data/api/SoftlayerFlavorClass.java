/**
 * 
 */
package com.valuelabs.nephele.admin.data.api;

/**
 * @author sbandarupalli
 *
 */

public enum SoftlayerFlavorClass {
	
	PublicLocal("PublicNode-LocalDisk"),
	PublicSAN("PublicNode-SANDisk"),
	PrivateLocal("PrivateNode-LocalDisk"),
	PrivateSAN("PrivateNode-SANDisk");
	
	
	private String value;

	SoftlayerFlavorClass(final String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return this.getValue();
    }

}
