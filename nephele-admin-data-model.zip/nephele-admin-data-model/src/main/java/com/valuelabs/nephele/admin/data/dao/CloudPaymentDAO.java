package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudPayment;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudPaymentDAO extends AbstractJpaDAO<CloudPayment>{

	
	public CloudPaymentDAO(){
		setClazz(CloudPayment.class);
	}
}
