package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.RackspaceServerConfiguration;

public interface RackspaceServerConfigurationRepository extends
TableRepository<RackspaceServerConfiguration, Long>,
		JpaSpecificationExecutor<RackspaceServerConfiguration> {

	@Query("SELECT sc FROM RackspaceServerConfiguration sc WHERE sc.cloudServer.id =:cloudServerId AND sc.status = :status") 
	public List<RackspaceServerConfiguration> getConfigurationByCloudServerIdNFlag(@Param("cloudServerId") Long cloudServerId, @Param("status") String status);
	
	/*@Query("SELECT sc FROM RackspaceServerConfiguration sc WHERE sc.cloudServer.id =:cloudServerId AND sc.lastLiveConfiguration = true ") 
	public List<RackspaceServerConfiguration> getLastLiveConfiguration(@Param("cloudServerId") Long cloudServerId);*/
	
	@Query("SELECT sc FROM RackspaceServerConfiguration sc WHERE sc.cloudServer.id =:cloudServerId AND sc.status != 'PUBLISHED'")
	public List<RackspaceServerConfiguration> getListOfUpgrades(@Param("cloudServerId") Long cloudServerId);
		
}
