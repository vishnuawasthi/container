/**
 * 
 */
package com.valuelabs.nephele.admin.data.api;

/**
 * @author rrsanepalle
 *
 */
public enum NomadeskVendorPlanCode {
	
	trial,
	monthly,
	yearly;

}
