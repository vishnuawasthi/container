package com.valuelabs.nephele.admin.data.entity;

import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@NamedQuery(name = "CustomerCompany.findByCode", query = " FROM CloudCustomerCompany rc where rc.customerCompanyCode = :customerCompanyCode")
@Getter
@Setter
@Builder
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "cloud_customer_company_seq", sequenceName = "cloud_customer_company_seq", initialValue = 1)
@Entity
@Table(name = "cloud_customer_company")
public class CloudCustomerCompany extends AbstractAuditEntity implements Serializable//extends CloudUserType
{
 
  private static final long serialVersionUID = 1370774753012643791L;

  @Id
  @GeneratedValue(generator = "cloud_customer_company_seq")
  @Column(name = "customer_company_id")
  private Long id;
  
  @Column(name = "customer_company_name")
  private String customerCompanyName;
  
  @Column(name="first_name")
  private String firstName;
  
  @Column(name="last_name")
  private String lastName;
  
  @Column(name="email")
  private String email;
  
  @Column(name="address_line1")
  private String addressLine1;
  
  @Column(name="address_line2")
  private String addressLine2;
  
  @Column(name="city")
  private String city;
  
  @Column(name="state")
  private String state;
  
  @Column(name="country")
  private String country;
  
  @Column(name="zipcode")
  private String zipcode;
  
  @Column(name = "isActive", nullable = true)
  private Boolean isActive;
  
  @Column(name="customer_company_code", unique= true , nullable = false)
  private String customerCompanyCode;

  @Column(name="business_contact_name")
  private String businessContactname;
  
  @Column(name="business_contact_email")
  private String businessContactEmail;
  
  @Column(name="abn_number")
  private String abnNumber;
  
  @Column(name="acn_number")
  private String acnNumber;
  
  @Column(name="phone_number")
  private String phoneNumber;
  
  @Column(name = "country_code_un")
  private String countryCodeUN;
  
  @Column(name = "country_code_iso")
  private String countryCodeISO;

  @ManyToOne
  @JoinColumn(name = "RESELLER_COMPANY_ID", nullable = true)
  private CloudResellerCompany cloudResellerCompany;

  @OneToMany(mappedBy = "cloudCustomerCompany")
  private Set<CloudCustomerUser> cloudCustomerUsers = new HashSet<CloudCustomerUser>();

  @OneToMany(mappedBy = "cloudCustomerCompany", fetch = FetchType.LAZY)
  private Set<CloudOrder> cloudOrders = new HashSet<CloudOrder>();

  @OneToMany(mappedBy = "cloudCustomerCompany")
  private Set<CloudResellerInvoice> cloudInvoiceSet = new HashSet<CloudResellerInvoice>();
  
  @OneToMany(mappedBy = "cloudCustomerCompany")
  private Set<CloudAccount> cloudAccount = new HashSet<CloudAccount>();

  
  @OneToMany(mappedBy="cloudCustomerCompany")
  private Set<NomadeskMeteringData> nomadeskMeteringData = new HashSet<NomadeskMeteringData>();

}