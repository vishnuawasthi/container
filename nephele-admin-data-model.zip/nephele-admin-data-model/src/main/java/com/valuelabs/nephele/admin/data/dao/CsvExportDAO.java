/**
 * 
 */
package com.valuelabs.nephele.admin.data.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudOperatingSystem;
import com.valuelabs.nephele.admin.data.entity.RackspaceComputePriceExportData;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;


/**
 * @author SivaNaresh Bandarupalli
 *
 */
@Repository
public class CsvExportDAO extends AbstractJpaDAO<CloudOperatingSystem> {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public CsvExportDAO() {
		setClazz(CloudOperatingSystem.class );
	}
	
	
	
	public List<RackspaceComputePriceExportData> csVExportFile(Long serviceId){
	
		TypedQuery<RackspaceComputePriceExportData> query =
				entityManager.createNamedQuery("OperatingSystem.getOSInfo", RackspaceComputePriceExportData.class).setParameter("serviceId", serviceId);
	
		return query.getResultList();	
	}
	
}
