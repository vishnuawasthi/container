package com.valuelabs.nephele.admin.data.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudRackspaceMeteringDataSubset;
import com.valuelabs.nephele.admin.data.entity.RackspaceMeteringData;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class RackspaceMeteringDataDAO extends AbstractJpaDAO<RackspaceMeteringData> {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public RackspaceMeteringDataDAO() {
		setClazz(RackspaceMeteringData.class);
	}
	
public List<CloudRackspaceMeteringDataSubset> getMeteringDataList(Long cycleId){
		
		TypedQuery<CloudRackspaceMeteringDataSubset> query =
				entityManager.createNamedQuery("RackspaceMeterData.ByUnits", CloudRackspaceMeteringDataSubset.class).setParameter("cycleId", cycleId);
		
		return query.getResultList();
		
	}
	
}
