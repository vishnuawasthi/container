package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudRackspacePriceUnitMeasure;

public interface CloudRackspacePriceUnitMeasureRepository  extends TableRepository<CloudRackspacePriceUnitMeasure, Long>, JpaSpecificationExecutor<CloudRackspacePriceUnitMeasure>  {
 
	@Query("SELECT um FROM  CloudRackspacePriceUnitMeasure um WHERE um.cloudRackspacePriceDetails.flavorId= :flavorId AND um.cloudRackspacePriceDetails.osType= :osType AND um.cloudRackspacePriceDetails.options= :options AND um.geo= :geo ")
	public List<CloudRackspacePriceUnitMeasure> getProductPlansByFlavor(@Param("flavorId") String flavorId, @Param("osType") String osType, @Param("options") String options, @Param("geo") String geo);

	
}
