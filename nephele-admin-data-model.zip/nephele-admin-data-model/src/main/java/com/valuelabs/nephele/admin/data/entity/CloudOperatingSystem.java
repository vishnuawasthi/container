package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.util.StringJsonUserType;

import lombok.*;
import lombok.experimental.Accessors;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@NamedQueries({@NamedQuery(name="OperatingSystem.getByService",
						   query="SELECT os FROM  CloudOperatingSystem os WHERE os.cloudService.id = :serviceId"),
			   @NamedQuery(name="OperatingSystem.getByServiceAndStatus",
			   			   query="SELECT os FROM  CloudOperatingSystem os WHERE os.cloudService.id = :serviceId AND os.status = :status"),
			   @NamedQuery(name = "OperatingSystem.getOSInfo", query = "Select NEW com.valuelabs.nephele.admin.data.entity.RackspaceComputePriceExportData(cos.cloudService.id as SERVICE_ID, cos.cloudService.name as SERVICE, "
			   														 + "cos.id as CLOUD_OPERATING_SYSTEM_ID, cos.imageId as VENDOR_IMAGE_ID, cos.name as VENDOR_IMAGE_NAME, "
			   														 + "crc.id as CLOUD_RACKSPACE_CONFIGURATION_ID, crc.flavorId as VENDOR_FLAVOR_ID, crc.flavor_class as VENDOR_FLAVOR_CLASS, "
			   														 + "crc.name as VENDOR_FLAVOR_NAME, crc.status as VENDOR_FLAVOR_STATUS, crc.ram as VENDOR_RAM, crc.price+cos.price as PRICE) "
			   														 + "FROM CloudOperatingSystem cos , CloudRackspaceConfiguration crc where cos.cloudService.id = :serviceId AND cos.cloudService.id = crc.cloudService.id "
			   														 + "AND crc.ram >= cos.minRam AND crc.disk >= cos.minDisk "
			   														 + "order by cos.id, cos.imageId, crc.id, crc.flavor_class, crc.flavorId"),
				@NamedQuery(name = "OperatingSystem.getOSNConfigByOSId", query = "Select NEW com.valuelabs.nephele.admin.data.entity.RackspaceComputePriceExportData(cos.cloudService.id as SERVICE_ID, cos.cloudService.name as SERVICE, "
																	 + "cos.id as CLOUD_OPERATING_SYSTEM_ID, cos.imageId as VENDOR_IMAGE_ID, cos.name as VENDOR_IMAGE_NAME, "
																	 + "crc.id as CLOUD_RACKSPACE_CONFIGURATION_ID, crc.flavorId as VENDOR_FLAVOR_ID, crc.flavor_class as VENDOR_FLAVOR_CLASS, "
																	 + "crc.name as VENDOR_FLAVOR_NAME, crc.status as VENDOR_FLAVOR_STATUS, crc.ram as VENDOR_RAM, crc.price+cos.price as PRICE) "
																	 + "FROM CloudOperatingSystem cos , CloudRackspaceConfiguration crc where cos.id = :osId AND cos.cloudService.id = crc.cloudService.id "
																	 + "AND crc.ram >= cos.minRam AND crc.disk >= cos.minDisk AND cos.status in ('STAGED', 'PUBLISHED') "
			   														 + "AND crc.status in ('STAGED', 'PUBLISHED') "
																	 + "order by cos.id, cos.imageId, crc.id, crc.flavor_class, crc.flavorId"),
			    @NamedQuery(name="OperatingSystem.findByStatus",
			   			   query="SELECT os FROM  CloudOperatingSystem os WHERE os.status = :status"),
			   
			   @NamedQuery(name = "CloudOperatingSystem.findOperatingSystemSummaryByServiceId", query = "SELECT status,count(status) FROM  CloudOperatingSystem cos"
			   					+" WHERE cos.cloudService.id= :serviceId GROUP BY status")		   

})
@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
@SequenceGenerator(name="cloud_operating_system_seq",sequenceName="cloud_operating_system_seq", initialValue=1)
@Entity
@Table(name="cloud_operating_system")
public class CloudOperatingSystem extends AbstractAuditEntity implements Serializable{
	

	private static final long serialVersionUID = -7446365051713237098L;

	@Id
	@GeneratedValue( generator="cloud_operating_system_seq")
    @Column(name = "cloud_operating_system_id", nullable = false)
	private Long id;
	
	@Column(name = "image_id", nullable = false)
	private String imageId;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "status", nullable = false)
	private String status;
	
	@Column(name = "minRam", nullable = false)
	private Long minRam;
	
	@Column(name = "minDisk", nullable = false)
	private Long minDisk;
	
	@Type(type = "StringJsonObject")
	@Column(name = "csp_resource", nullable = false)
	private String cspResource;
	
	@ManyToOne
    @JoinColumn(name = "cloud_service_id") 
    private CloudService cloudService; 
	
	@Column(name = "os_type", nullable = true)
	private String osType;
	
	@Column(name = "options", nullable = true)
	private String options;
	
	@Column(name = "price", nullable = true)
	private Double price;
	
	/*@OneToMany(mappedBy="cloudOperatingSystem")
    private Set<CloudRackspaceComputePrice> cloudComputePrices = new HashSet<CloudRackspaceComputePrice>();*/
	
	
	@OneToMany(mappedBy="cloudOperatingSystem")
    private Set<CloudProduct> cloudProducts = new HashSet<CloudProduct>();
	
	/*@OneToMany(mappedBy="cloudOperatingSystem")
	private Set<RackspaceServerConfiguration> rackspaceServerConfigurations=new HashSet<RackspaceServerConfiguration>();*/
	
/*	@OneToMany(mappedBy="cloudOperatingSystem")
	private Set<SoftlayerServerConfiguration> softlayerServerServerConfiguration=new HashSet<SoftlayerServerConfiguration>();
	
	@OneToMany(mappedBy="cloudOperatingSystem")
	private Set<AzureServerConfiguration> azureServerConfigurations=new HashSet<AzureServerConfiguration>();*/
	
}
