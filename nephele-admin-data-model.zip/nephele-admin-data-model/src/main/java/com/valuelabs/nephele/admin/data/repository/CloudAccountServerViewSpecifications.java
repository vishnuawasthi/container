package com.valuelabs.nephele.admin.data.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudAccountServerView;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

@Slf4j
public final class CloudAccountServerViewSpecifications  {
  
  
  public static Specification<CloudAccountServerView> findAccountServersByFilter(final Long customerCompanyId, final List<Long> customerCompanyIdList,final String status,final Long orderId, final Date fromDate, final Date toDate,final String description,
	final   List<Long> serviceIdListFromProvider,final List<Long> serviceIdListFromCategory,final Long orderIdFromOrderCode) {
	 
	  return new Specification<CloudAccountServerView>(){
		
		@Override
		public Predicate toPredicate(Root<CloudAccountServerView> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			Predicate predicate = criteriaBuilder.conjunction();
			
			predicate = criteriaBuilder.and(predicate, criteriaBuilder.notEqual(root.get("nepheleStatus"), "TERMINATED"));
			
			if(!StringUtils.isEmpty(customerCompanyId)) {
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("customerCompanyId"), customerCompanyId));
			}
			
			if(!CollectionUtils.isEmpty(customerCompanyIdList)){
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.in(root.get("customerCompanyId")).value(customerCompanyIdList));
			}
			
			if(!StringUtils.isEmpty(status)) {
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("nepheleStatus"), status));
			}
			
			if(!StringUtils.isEmpty(orderId)) {
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("cloudOrderId"), orderId));
			}
			
			if(!StringUtils.isEmpty(orderIdFromOrderCode)) {
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("cloudOrderId"), orderIdFromOrderCode));
			}
			
			
			if(!StringUtils.isEmpty(fromDate) &&  !StringUtils.isEmpty(toDate)) {
			  predicate = criteriaBuilder.and(predicate, criteriaBuilder.between(root.<Date>get("provisionDate"), fromDate,toDate));
			}
			
			if (!StringUtils.isEmpty(description)) {
				Expression<String> viewDescription = root.get("description");
				predicate = criteriaBuilder.and(predicate,criteriaBuilder.like(criteriaBuilder.lower(viewDescription), description.toLowerCase() + "%"));
			}
			
			if(!CollectionUtils.isEmpty(serviceIdListFromProvider) ) {
			  predicate = criteriaBuilder.and(predicate, criteriaBuilder.in(root.get("cloudServiceId")).value(serviceIdListFromProvider));
			}
			
			if(!CollectionUtils.isEmpty(serviceIdListFromCategory) ) {
			  predicate = criteriaBuilder.and(predicate, criteriaBuilder.in(root.get("cloudServiceId")).value(serviceIdListFromCategory));
			}
			
			
			
	  		return predicate;
		}
	};
}
  
	
	/* public static Specification<CloudAccountServerView> findAccountServersByFilter(final Long customerCompanyId, final List<Long> customerCompanyIdList) {
		 
		  return new Specification<CloudAccountServerView>(){
			
			@Override
			public Predicate toPredicate(Root<CloudAccountServerView> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();
				
				if(null != customerCompanyId && customerCompanyId != 0 ) {
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("customerCompanyId"), customerCompanyId));
				}
				
				if(!CollectionUtils.isEmpty(customerCompanyIdList)){
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.in(root.get("customerCompanyId")).value(customerCompanyIdList));
				}
				
		  		return predicate;
			}
		};
	 }*/
	 
  /*public static Specification<CloudServer> findServersByProviderAndCategory(final Long providerId, final Long categoryId ,final String externalResellerCode,final Long serviceId,final String description) {
	return new Specification<CloudServer>() {

	  @Override
	  public Predicate toPredicate(Root<CloudServer> root, CriteriaQuery<?> criteriaQuery,
		  CriteriaBuilder criteriaBuilder) {
		Predicate predicate = criteriaBuilder.conjunction();
		Join<CloudServer, CloudService> rootWithCloudService = root.join("cloudService");
		Path<Object> serviceProviderPath = rootWithCloudService.get("cloudServiceProvider");
		Path<Object> serviceCategoryPath = rootWithCloudService.get("serviceCategory");
		
		Join<CloudServer, CloudCustomerCompany> rootWithCustomerCompany= root.join("cloudCustomerCompany");
		
		 Path<Object> cloudResellerCompany = rootWithCustomerCompany.get("cloudResellerCompany");
		
		if (!StringUtils.isEmpty(serviceId)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(rootWithCloudService.get("id"), serviceId));
		}

		if (!StringUtils.isEmpty(providerId)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceProviderPath.get("id"), providerId));
		}
		
		if (!StringUtils.isEmpty(categoryId)) {
		  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(serviceCategoryPath.get("id"), categoryId));
		}
		
		if(!StringUtils.isEmpty(externalResellerCode)) {
		  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(cloudResellerCompany.get("resellerCompanyCode"), externalResellerCode));
		}
		if (!StringUtils.isEmpty(description)) {
			Expression<String>  rootDescription = root.get("description");
			  predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootDescription), "%" + description.toLowerCase() + "%"));
				  
		}
		
		return predicate;
	  }

	};

  }*/
	 
	 
	 
	 // STATUS Filter  for Reseller
	 public static Specification<CloudAccountServerView> findAccountServersStatusByFilter(final List <Long> customerCompanyIdList  ,final List <Long> serviceIdList,final Long serviceId,final Long customerCompanyId,final String status ) {
		 
		  return new Specification<CloudAccountServerView>(){
			
			@Override
			public Predicate toPredicate(Root<CloudAccountServerView> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Predicate predicate = criteriaBuilder.conjunction();
				predicate = criteriaBuilder.and(predicate, criteriaBuilder.notEqual(root.get("nepheleStatus"), "TERMINATED"));
				if(!CollectionUtils.isEmpty(serviceIdList) ) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.in(root.get("cloudServiceId")).value(serviceIdList));
				}
				
				if(!CollectionUtils.isEmpty(customerCompanyIdList)){
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.in(root.get("customerCompanyId")).value(customerCompanyIdList));
				}
				
				if (!StringUtils.isEmpty(serviceId)) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("cloudServiceId"), serviceId));
				}
				
				if (!StringUtils.isEmpty(customerCompanyId)) {
				  predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("customerCompanyId"), customerCompanyId));
				}
				
				if(!StringUtils.isEmpty(status)) {
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("nepheleStatus"), status));
				}
				
		  		return predicate;
			}
		};
	 }
	 
	 
	 
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "resourceId", "resourceType");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts persons in ascending order by using the last name.
	     * @return
	     */
	    public static Sort sortByLastNameAsc() {
	        return new Sort(Sort.Direction.ASC, "lastName");
	    }


}
