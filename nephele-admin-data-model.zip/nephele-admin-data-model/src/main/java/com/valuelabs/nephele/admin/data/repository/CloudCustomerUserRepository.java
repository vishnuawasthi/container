package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerUser;

public interface CloudCustomerUserRepository extends TableRepository<CloudCustomerUser, Long>, JpaSpecificationExecutor<CloudCustomerUser>{

}
