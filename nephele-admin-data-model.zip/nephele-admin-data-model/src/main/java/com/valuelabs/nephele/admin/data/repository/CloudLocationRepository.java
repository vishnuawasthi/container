package com.valuelabs.nephele.admin.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudLocation;

public interface CloudLocationRepository extends TableRepository<CloudLocation, Long>, JpaSpecificationExecutor<CloudLocation>{
	
	@Query("SELECT cl FROM  CloudLocation cl WHERE cl.status = :status") 
	public List<CloudLocation> findByStatus(@Param("status") String status);
	 
	@Query("SELECT cl FROM  CloudLocation cl WHERE cl.name = :name AND cl.status = :status") 
	public List<CloudLocation> findByNameNStatus(@Param("name") String name, @Param("status") String status);
	 
	@Query("SELECT status,count(status) FROM  CloudLocation cl"
				+" WHERE cl.cloudService.id= :serviceId GROUP BY status") 
	public List<Object[]> findLocationSummaryByServiceId(@Param("serviceId") Long serviceId);
	
	@Query("SELECT cl FROM  CloudLocation cl WHERE cl.cloudService.id = :serviceId AND cl.status = :status") 
	public List<CloudLocation> findByServiceAndStatus(@Param("serviceId") Long serviceId, @Param("status") String status);

	@Query("SELECT cl FROM  CloudLocation cl WHERE cl.cloudService.id = :serviceId")
	public List<CloudLocation> findByServiceId(@Param("serviceId") Long serviceId);
	
	@Query("SELECT cl FROM  CloudLocation cl WHERE cl.cloudService.id = :serviceId "
			+ "AND cl.locationCode = :locationCode AND cl.status = :status") 
	public List<CloudLocation> findByServiceLocationCodeAndStatus(@Param("serviceId") Long serviceId, @Param("locationCode") String locationCode, @Param("status") String status);
	
	@Query("SELECT cl FROM  CloudLocation cl WHERE cl.locationCode = :locationCode") 
	public CloudLocation findByLocationCode(@Param("locationCode") String locationCode);
	 
	 
}
