package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudCurrencyConversionRateAudit;

public interface CloudCurrencyConversionRateAuditRepository  extends TableRepository<CloudCurrencyConversionRateAudit, Long>, JpaSpecificationExecutor<CloudCurrencyConversionRateAudit>{

}
