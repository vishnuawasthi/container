package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudResellerUser;

public interface CloudResellerUserRepository extends TableRepository< CloudResellerUser, Long>, JpaSpecificationExecutor< CloudResellerUser> {
  
  @Query("SELECT cru FROM  CloudResellerUser cru WHERE resellerUserName = :resellerUserName")
  public CloudResellerUser findUserByUserName(@Param("resellerUserName")String resellerUserName) ;
}
