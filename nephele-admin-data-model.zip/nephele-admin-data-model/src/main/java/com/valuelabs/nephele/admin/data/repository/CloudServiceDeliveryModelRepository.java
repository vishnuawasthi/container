package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.CloudServiceDeliveryModel;

public interface CloudServiceDeliveryModelRepository extends TableRepository<CloudServiceDeliveryModel, Long>, JpaSpecificationExecutor<CloudServiceDeliveryModel> {

}
