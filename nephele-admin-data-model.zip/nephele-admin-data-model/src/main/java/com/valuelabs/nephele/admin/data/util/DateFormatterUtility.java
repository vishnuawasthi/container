package com.valuelabs.nephele.admin.data.util;

import lombok.extern.slf4j.Slf4j;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 * Created by SivaNaresh on 6/8/15.
 */
@Slf4j
public class DateFormatterUtility {

  /**
   * Method to check whether the passed object is Not empty or not.
   *
   * @param obj - to be checked.
   * @return - <code>true</code> if the object is not empty.
   */
  public static boolean isNotEmpty(final Object obj) {
    boolean returnVal = false;
    try {
      if (obj != null) {
        if (obj instanceof String) {
          String str = (String) obj;
          if (str.trim().length() > 0) {
            returnVal = true;
          }
        } else if (obj instanceof Collection) {
          Collection col = (Collection) obj;
          if (!col.isEmpty()) {
            returnVal = true;
          }
        } else if (obj instanceof Double) {
          Double dbl = (Double) obj;
          if (!dbl.equals(0d)) {
            returnVal = true;
          }
        }
      }
    } catch (Exception e) {
      log.error("=== Error from Utility.isNotEmpty() " + e.getMessage());
    }

    return returnVal;
  }

  public static Date getAfterDate(Date givenDate, Integer afterTimeInDay) {
    Date returnVal = null;
    try {
      SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
      String createdDate = df.format(givenDate);
      Date date = df.parse(createdDate);
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(date);
      calendar.add(Calendar.HOUR_OF_DAY, afterTimeInDay);
      calendar.add(Calendar.MINUTE, 59);
      calendar.add(Calendar.SECOND, 59);
      returnVal = calendar.getTime();
    } catch (Exception e) {
      log.error("Exception occurs while formatting date: ", e.getMessage());
    }
    return returnVal;
  }

  public static Date getDateWithoutTime(Date givenDate) {
    Date returnVal = null;
    try {
      SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
      String createdDate = df.format(givenDate);
      Date date = df.parse(createdDate);
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(date);
      returnVal = calendar.getTime();
    } catch (Exception e) {
      log.error("Exception occurs while formatting date: ", e.getMessage());
    }
    return returnVal;
  }

  public static Date formatDate(String givenDate) {
    Date returnVal = null;
    if (isNotEmpty(givenDate)) {
      try {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date date = df.parse(givenDate);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        returnVal = calendar.getTime();
      } catch (Exception e) {
        log.error("Exception occurs while formatting date: ", e.getMessage());
      }
    }
    return returnVal;
  }
  

  public static Date formatStringToDate(String givenDate) {
    Date returnVal = null;
    if (isNotEmpty(givenDate)) {
      try {
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        Date date = df.parse(givenDate);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        returnVal = calendar.getTime();        
      } catch (Exception e) {
        log.error("Exception occurs while formatStringTo date: ", e.getMessage());
      }
    }
    return returnVal;
  }
  
  public static Date formatStringToDateinSlashFormat(String givenDate) {
	    Date returnVal = null;
	    if (isNotEmpty(givenDate)) {
	      try {
	        SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	        Date date = df.parse(givenDate);
	        Calendar calendar = Calendar.getInstance();
	        calendar.setTime(date);
	        returnVal = calendar.getTime();        
	      } catch (Exception e) {
	        log.error("Exception occurs while formatStringTo date: ", e.getMessage());
	      }
	    }
	    return returnVal;
	  }
  
  public static Date formatStringToDateForAtomFeed(String givenDate) {
	    Date returnVal = null;
	    if (isNotEmpty(givenDate)) {
	      try {
	        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
	        Date date = df.parse(givenDate);
	        Calendar calendar = Calendar.getInstance();
	        calendar.setTime(date);
	        returnVal = calendar.getTime();        
	      } catch (Exception e) {
	        log.error("Exception occurs while formatStringTo date: ", e.getMessage());
	      }
	    }
	    return returnVal;
	  }
  
  public static Date getDateFromDay(int dayOfMonth){
	  
	    Calendar calendar = Calendar.getInstance();
	    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);	 
	    log.debug("DAY_OF_MONTH " + dayOfMonth + " = "
	        + calendar.getTime());
	    
	    SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
	    String date1 = format1.format(calendar.getTime());            
	    Date inActiveDate = null;
	    try {
	        inActiveDate = format1.parse(date1);
	    }catch(Exception ex){
	    	log.error("exception in getDateFromDay due to :"+ex.getMessage());
	    }
	    return inActiveDate;
  }
  
  public static Date getUTCDateFromDay(int dayOfMonth){
	  
	    Calendar calendar = Calendar.getInstance();
	    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);	 
	    log.debug("DAY_OF_MONTH " + dayOfMonth + " = "
	        + calendar.getTime());
	    
	    //SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
	    SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MMM-dd");
	    format1.setTimeZone(TimeZone.getTimeZone("UTC"));
	    
	    SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd");
	    
	    String date1 = format1.format(calendar.getTime());            
	    Date inActiveDate = null;
	    try {
	        inActiveDate = dateFormatLocal.parse(date1);
	    }catch(Exception ex){
	    	log.error("exception in getDateFromDay due to :"+ex.getMessage());
	    }
	    return inActiveDate;
  }
  
  public static Date getPreviousMonthUTCDateFromDay(int dayOfMonth){
	  
	  Calendar cal = Calendar.getInstance();
		int presentMonth = cal.get(Calendar.MONTH);
		int presentYear =  cal.get(Calendar.YEAR);
		cal.set(presentYear, presentMonth-1, dayOfMonth);
	    //DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MMM-dd");
	    format1.setTimeZone(TimeZone.getTimeZone("UTC"));
	    
	    SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd");
	    Date billingStartDate = null;
		try {
			billingStartDate = dateFormatLocal.parse(format1.format(cal.getTime()));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			log.error("exception in getPreviousMonthDateFromDay due to :"+e.getMessage());
		}
	    return billingStartDate;
  }
  
  public static Date getPreviousMonthDateFromDay(int dayOfMonth){
	  
	  Calendar cal = Calendar.getInstance();
		int presentMonth = cal.get(Calendar.MONTH);
		int presentYear =  cal.get(Calendar.YEAR);
		cal.set(presentYear, presentMonth-1, dayOfMonth);
	    DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
	    Date billingStartDate = null;
		try {
			billingStartDate = dateFormatter.parse(dateFormatter.format(cal.getTime()));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			log.error("exception in getPreviousMonthDateFromDay due to :"+e.getMessage());
		}
	    return billingStartDate;
  }

  public static Long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
	    Long diffInMillies = date2.getTime() - date1.getTime();
	    return timeUnit.convert(diffInMillies,TimeUnit.MILLISECONDS);
	}



	public static Date getLastMonthCurrentDate(Date givenDate) {
		Date returnVal = null;
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			String createdDate = df.format(givenDate);
			Date date = df.parse(createdDate);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.set(Calendar.MONTH, -1);
			returnVal = df.parse(df.format(calendar.getTime()));
		} catch (Exception e) {
			log.error("Exception occurs while formatting date: ",
					e.getMessage());
		}
		return returnVal;
	}
  public static Date getAfterDateInMinutes(Integer afterTimeInMinutes) {
    Date currentDate = new Date();
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(currentDate);
    calendar.add(Calendar.MINUTE, afterTimeInMinutes);
    return calendar.getTime();
  }

}
