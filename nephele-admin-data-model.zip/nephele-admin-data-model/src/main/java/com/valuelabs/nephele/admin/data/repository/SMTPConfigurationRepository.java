package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.valuelabs.nephele.admin.data.entity.SMTPConfiguration;
public interface SMTPConfigurationRepository  extends TableRepository<SMTPConfiguration, Long>,  JpaSpecificationExecutor<SMTPConfiguration> {

}
