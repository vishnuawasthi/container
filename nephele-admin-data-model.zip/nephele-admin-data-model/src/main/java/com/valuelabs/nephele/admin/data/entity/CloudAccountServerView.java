package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@Accessors(chain = true)
@Entity
@Table(name="CLOUD_ACCOUNT_SERVER_VIEW")
@IdClass(value=AccountServerPK.class)
public class CloudAccountServerView implements Serializable{
	
	private static final long serialVersionUID = -2125468165021724309L;

	@Id
	@Column(name = "resource_id", nullable = false)
	private Long resourceId;
	
	@Id
	@Column(name = "resource_type")
	private String resourceType;
	
	@Column(name = "resource_name")
	private String resourceName;
	
	@Column(name = "description", nullable = true)
	private String description;
		
	@Column(name = "customer_company_id")
	private Long customerCompanyId;
	
	@Column(name = "cloud_service_id")
	private Long cloudServiceId;
	
	@Column(name = "cloud_product_plan_id")
	private Long cloudProductPlanId;
	
	@Column(name = "cloud_order_id")
	private Long cloudOrderId;
	
	@Column(name = "vendor_status")
	private String vendorStatus;
	
	@Column(name = "nephele_status")
	private String nepheleStatus;
	
	@Column(name = "provision_date")
	private Date provisionDate;
	
	
}
