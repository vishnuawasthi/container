package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudLocationGeographiesMapping;

public interface CloudLocationGeographiesMappingRepository extends TableRepository<CloudLocationGeographiesMapping, Long>, JpaSpecificationExecutor<CloudLocationGeographiesMapping>{
	
	@Query("SELECT cgl FROM  CloudLocationGeographiesMapping cgl WHERE cgl.locationCode = :locationCode") 
	public CloudLocationGeographiesMapping findByLocationCode(@Param("locationCode") String locationCode);
	 
}
