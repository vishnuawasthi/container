package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Setter
@Getter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@NamedQuery(name = "PremiumGroupDiscountSheet.getBySheetName", query = "FROM PremiumGroupDiscountSheet ps where ps.premiumGroupDiscountConfig.discountSheetName =:sheetName")
@SequenceGenerator(name="cloud_premium_group_discount_sheet_seq",sequenceName="cloud_premium_group_discount_sheet_seq",initialValue=1)
@Entity
@Table(name="cloud_premium_group_discount_sheet")
public class PremiumGroupDiscountSheet extends AbstractAuditEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5964312760208441825L;
	
	@Id
    @GeneratedValue(generator="cloud_premium_group_discount_sheet_seq")
    @Column(name = "cloud_premium_group_discount_sheet_id", nullable = false)	
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="cloud_premium_group_discount_config_id")	
	private PremiumGroupDiscountConfig premiumGroupDiscountConfig;
	
	@ManyToOne
	@JoinColumn(name = "cloud_reseller_premium_group_id", nullable = false)
	private CloudResellerPremiumGroup premiumGroup;
	
	@Column(name = "start_range")	
	private Double startRange;

	@Column(name = "end_range")
	private Double endRange;

	@Column(name = "discount", nullable = false)
	private Double discount;

	
	
}
