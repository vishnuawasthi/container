package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.data.api.SubscriptionStatus;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
//@Data
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_license_seq",sequenceName="cloud_license_seq",initialValue=1)
@Entity
@Table(name="cloud_license")
public class CloudLicense extends AbstractAuditEntity implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = -7393005615546082737L;	
	@Id
    @GeneratedValue(generator="cloud_license_seq")
    @Column(name = "cloud_license_id", nullable = false)
	private Long id;
	
	
	@Column(name="vendor_license_id")
	private String licenseId;
	
	@OneToOne
	@JoinColumn(name="cloud_subscription_id")
	private CloudSubscription subscription;
	
	@Column(name = "status", nullable = true)
	@Enumerated(EnumType.STRING)
	private SubscriptionStatus status;
	
	@ManyToOne
	@JoinColumn(name="cloud_product_plan_id")
	private CloudProductPlan plan;
	
	@Column(name="license_provision_date")
	private Date licenseProvisionDate;	

	
	

}
