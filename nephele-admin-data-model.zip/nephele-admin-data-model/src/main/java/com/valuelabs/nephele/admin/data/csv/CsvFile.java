package com.valuelabs.nephele.admin.data.csv;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.stereotype.Component;

/**
 * An annotation to supply Class/CSV record metadata.
 * 
 * @author Srinivas Ch, ValueLabs
 * @version 1.0.0
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ java.lang.annotation.ElementType.TYPE })
@Component
public @interface CsvFile {

  /** The default delimiter. */
  String DEFAULT_DELIMITER = ",";

  /**
   * The file path.
   */
  String fileName();

  /**
   * The delimiter. The default is an empty string.
   */
  String delimiter() default DEFAULT_DELIMITER;

  /**
   * Whether the file has a header or not. The default is false.
   */
  boolean noHeader() default false;
}
