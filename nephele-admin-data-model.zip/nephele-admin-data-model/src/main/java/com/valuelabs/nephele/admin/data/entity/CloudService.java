package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.valuelabs.nephele.admin.data.api.NepheleTimeZone;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@NamedQueries({@NamedQuery(name="CloudService.findByName", query="SELECT cs FROM  CloudService cs WHERE cs.name = :name"),
			   @NamedQuery(name="CloudService.findByServiceCode", query="SELECT cs FROM  CloudService cs WHERE cs.serviceCode = :serviceCode"),
			   @NamedQuery(name="CloudService.findActiveServices", query=" FROM CloudService cs WHERE cs.isPublished = true"),
               @NamedQuery(name="CloudService.findActiveServicesCount", query=" SELECT count(isPublished) FROM CloudService WHERE isPublished = true")})

@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name="cloud_service_seq",sequenceName="cloud_service_seq",initialValue=1)
@Entity
@Table(name="cloud_service")
public class CloudService extends AbstractAuditEntity implements Serializable{
	
	private static final long serialVersionUID = 5044109968867766910L;

	@Id
    @GeneratedValue(generator="cloud_service_seq")
    @Column(name = "cloud_service_id", nullable = true)
	private Long id;
	
	@Column(name = "name", nullable = true,unique=true)
	private String name;
	
	@Column(name = "isPublished", nullable = true)
	private Boolean isPublished;
	
	@Column(name = "is_live", nullable = true)
	private Boolean isLive;
	
	@Column(name = "description", nullable = true, length = 1000)
	private String description;
	
	@Column(name = "integration_code", nullable = true,unique=true)
	private String integrationCode;
	
	@Column(name = "service_code", nullable = true,unique=true)
	private String serviceCode;
	
	@Column(name = "vendor_code", nullable = true,unique=true)
	private String vendorCode;

	@Column(name="billing_cycle",nullable=true)
	private String billingCycle;
	
	@Column(name="billing_day",nullable=true)
	private Integer billingDay;
	
	@Column(name="plan_prefix",nullable=true)
	private String planPrefix;
	
	@Column(name="subscription_name_prefix",nullable=true)
	private String subscriptionNamePrefix;
	
	@Column(name="vendor_currency")
	private String vendorCurrency;
		
	@Column(name = "time_zone")
	@Enumerated(EnumType.STRING)
	private NepheleTimeZone timeZone;
	
	@ManyToOne
    @JoinColumn(name = "cloud_service_provider_id", nullable = false) 
    private CloudServiceProvider cloudServiceProvider;
	
	@OneToOne(mappedBy="cloudService")
	private CloudServiceCredential cloudServiceCredential;
	
	
	@OneToMany(mappedBy="cloudService")
    private Set<CloudOperatingSystem> cloudOperatingSystems = new HashSet<CloudOperatingSystem>();
	
	@OneToMany(mappedBy="cloudService")
    private Set<CloudRackspaceConfiguration> cloudConfigurations = new HashSet<CloudRackspaceConfiguration>();

	@OneToMany(mappedBy = "cloudService")
	private Set<CloudLocation> cloudLocations = new HashSet<CloudLocation>();
	
	
	@OneToMany(mappedBy="cloudService")
    private Set<CloudProduct> cloudProducts = new HashSet<CloudProduct>();
	
	@OneToMany(mappedBy="cloudService")
	private Set<CloudServer> cloudServers=new HashSet<CloudServer>();

	@OneToMany(mappedBy = "cloudService")
	private Set<CloudAdditionalPrice> cloudAdditionalPrices=new HashSet<CloudAdditionalPrice>();
	
	@OneToMany(mappedBy="cloudService")
	private Set<CloudProductPriceManagementConfig> priceManagementConfig=new HashSet<CloudProductPriceManagementConfig>();

	@OneToMany(mappedBy = "cloudService")
	private Set<PremiumGroupDiscountConfig> groupDiscountConfig=new HashSet<PremiumGroupDiscountConfig>();
	
	@OneToMany(mappedBy="cloudService")
	private Set<CloudRackspaceBandwidthPrice> rackspaceBandwidthPriceSet = new HashSet<CloudRackspaceBandwidthPrice>();
	
	@OneToMany(mappedBy="cloudService")
	private Set<CloudBillingCycle> billingStatusSet = new HashSet<CloudBillingCycle>();
	
	@OneToMany(mappedBy="cloudService")
	private Set<CloudAccount> cloudAccounts = new HashSet<CloudAccount>();
	
	/*@OneToMany(mappedBy="cloudService")
	private Set<CloudResellerPremiumGroup> cloudResellerPremiumGroup = new HashSet<CloudResellerPremiumGroup>();
	*/	
	@ManyToOne
	@JoinColumn(name="service_industry_vertical_id")
	private ServiceIndustryVertical serviceIndustryVertical;
	
	@ManyToOne
	@JoinColumn(name="service_category_id")
	private ServiceCategory serviceCategory;
	
	@OneToMany(mappedBy="cloudService")
    private Set<NomadeskMeteringData> nomadeskMeteringData = new HashSet<NomadeskMeteringData>();
	
}
