package com.valuelabs.nephele.admin.data.api;

public enum ExternalProductStatus {
	PUBLISHED,
	SUSPENDED

}
