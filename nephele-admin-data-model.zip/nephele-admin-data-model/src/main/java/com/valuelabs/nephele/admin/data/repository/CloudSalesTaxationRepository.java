package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudSalesTaxation;
public interface CloudSalesTaxationRepository extends TableRepository<CloudSalesTaxation, Long>, JpaSpecificationExecutor<CloudSalesTaxation>  {
 
  @Query("SELECT cst FROM CloudSalesTaxation cst where cst.countryName = :countryName")
  public CloudSalesTaxation getByCountry(@Param("countryName")String countryName);
  
}
