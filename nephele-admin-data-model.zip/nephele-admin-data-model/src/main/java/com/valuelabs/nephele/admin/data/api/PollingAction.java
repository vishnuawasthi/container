package com.valuelabs.nephele.admin.data.api;

public enum PollingAction {
	CREATE,
	REBOOT,
	RESIZE,
	CONFIRM_RESIZE,
	DELETE,
	SYNC;
}
