package com.valuelabs.nephele.admin.data.api;

/**
 * This enum contains NepheleAccount statuses.
 * @author sbandarupalli
 * 
*/
public enum NepheleAccountStatus {
	ACTIVE,
	SUSPEND,
	CANCEL,
	PENDING_USER_ACTION;
}
