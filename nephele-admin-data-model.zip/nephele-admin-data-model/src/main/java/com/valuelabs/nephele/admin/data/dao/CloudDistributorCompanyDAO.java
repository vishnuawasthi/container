package com.valuelabs.nephele.admin.data.dao;

import org.springframework.stereotype.Repository;

import com.valuelabs.nephele.admin.data.entity.CloudDistributorCompany;
import com.valuelabs.nephele.admin.data.repository.AbstractJpaDAO;

@Repository
public class CloudDistributorCompanyDAO extends AbstractJpaDAO<CloudDistributorCompany> {

	public CloudDistributorCompanyDAO() {
		setClazz(CloudDistributorCompany.class);
	}
}
