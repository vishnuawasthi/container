package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import com.valuelabs.nephele.admin.data.api.ExternalProductStatus;
import com.valuelabs.nephele.admin.data.api.ExternalProductType;


@NoArgsConstructor
@AllArgsConstructor
@Builder
//@Data
@Getter
@Setter
@Accessors(chain = true)
//@EqualsAndHashCode(callSuper = false)
@SequenceGenerator(name = "external_product_seq", sequenceName = "external_product_seq", initialValue = 1)
@Entity
@Table(name = "external_product")
public class ExternalProduct extends AbstractAuditEntity implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	  @Id
	  @GeneratedValue(generator = "external_product_seq")
	  @Column(name = "external_product_id", nullable = false)
	  private Long id;
	  
	  @Column(name = "external_id")
	  private String externalId;

	  @Column(name = "product_name")
	  private String productName;
	  
	  @Column(name = "description")
	  private String description;

	  @Column(name = "brand_name")
	  private String brandName;
	  
	  @Column(name = "category_name")
	  private String categoryName;
	  
	  @Column(name="status")
	  @Enumerated(EnumType.STRING)
	  private ExternalProductStatus status;
	  
	  @Column(name ="type")
	  @Enumerated(EnumType.STRING)
	  private ExternalProductType type ;
	  
	  @OneToMany(mappedBy="externalProduct", fetch = FetchType.EAGER)
	  private Set<BundleExternalProduct> bundleExternalProducts = new HashSet<BundleExternalProduct>();


}
