package com.valuelabs.nephele.admin.data.entity;

import com.valuelabs.nephele.admin.data.api.InvoiceStatus;
import lombok.*;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by snagaboina on 30/11/15.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Accessors(chain = true)
@SequenceGenerator(name = "payment_gateway_transaction_log_seq", sequenceName = "payment_gateway_transaction_log_seq", initialValue = 1)
@Entity
@Table(name = "payment_gateway_transaction_log")
public class PaymentGatewayTransactionLog extends AbstractAuditEntity implements Serializable {

  private static final long serialVersionUID = 314276906679003689L;

  @Id
  @GeneratedValue(generator = "payment_gateway_transaction_log_seq")
  @Column(name = "id")
  private Long id;

  @Column(name = "pg_audit_id")
  private String pgAuditId;

  @Column(name = "transaction_status")
  @Enumerated(EnumType.STRING)
  private InvoiceStatus transactionStatus;

  @Column(name = "request_payload", length = 1024)
  private String requestPayload;

  @Column(name = "respone_payload", length = 1024)
  private String responsePayload;

  @Column(name = "respone_code", length = 1024)
  private String responseCode;

  @Column(name = "respone_message", length = 1024)
  private String responseMessage;


  @ManyToOne(cascade = {CascadeType.MERGE})
  @JoinColumn(name = "cloud_invoice_id")
  private CloudResellerInvoice cloudInvoice;
}
