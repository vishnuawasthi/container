package com.valuelabs.nephele.admin.data.util;

import java.text.DecimalFormat;

public class MemoryUnitConverterUtil {
	
	/**
	* Convert given size in MB into GB
	* @param megaBytes
	* @return
	*/
	public static double convertMegaBytesIntoGigaBytes(double megaBytes){
		double convBytes=megaBytes+'d';
		convBytes= megaBytes/1024;//gb
	
		return roundTwoDecimals(convBytes);
	}
	
	/**
	* Convert given size in Bytes into GB
	* @param megaBytes
	* @return
	*/
	public static double convertBytesIntoGigaBytes(double bytes){
		double convBytes=bytes+'d';
		convBytes= bytes/1073741824;//gb
		
		return convBytes;
	}

	/**
	* Decimal Format for the size
	* @param d
	* @return
	*/
	private static double roundTwoDecimals(double d) {
		DecimalFormat twoDForm = new DecimalFormat("#.#");
		return Double.valueOf(twoDForm.format(d));
	}

	

}
