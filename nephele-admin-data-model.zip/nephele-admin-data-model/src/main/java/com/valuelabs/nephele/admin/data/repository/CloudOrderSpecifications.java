package com.valuelabs.nephele.admin.data.repository;

import java.sql.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.valuelabs.nephele.admin.data.entity.CloudCustomerCompany;
import com.valuelabs.nephele.admin.data.entity.CloudOrder;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

@Slf4j
public final class CloudOrderSpecifications  {
	
	
	 /**
	 * This method filters the DB records according to the requsted parameters and also it gives total existing records 
	 * records in the DB without parameters.
	 * @param status
	 * @param orderId
	 * @param externalCustomerCode
	 * @param dateRangeStart
	 * @param dateRangeEnd
	 * @return
	 */
	 public static Specification<CloudOrder> findOrdersByStatusAndDateRange(final String status, final Long orderId, final String orderCode,
			 final String externalCustomerCode, final Date dateRangeStart, final Date dateRangeEnd, final String externalResellerCode) {
		 
		  return new Specification<CloudOrder>(){
			
			@Override
			public Predicate toPredicate(Root<CloudOrder> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
				
				Predicate predicate = criteriaBuilder.conjunction();	
				Join<CloudOrder, CloudCustomerCompany> rootWithCustomer = root.join("cloudCustomerCompany");				
				Path<Object> rootWithResellerCompany = rootWithCustomer.get("cloudResellerCompany");
				//List<Order> orderByList = new ArrayList<Order>();
				
				if (!StringUtils.isEmpty(status)) {
					Expression<String>  rootStatus = root.get("status");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootStatus), "%" + status.toLowerCase() + "%"));
				}
				if (!StringUtils.isEmpty(orderId)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("id"), orderId));
					  
				}
				if (!StringUtils.isEmpty(orderCode)) {
					Expression<String>  rootOrderCode = root.get("orderCode");
					predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(criteriaBuilder.lower(rootOrderCode), "%" + orderCode.toLowerCase() + "%"));
						  
				}
				if ( !StringUtils.isEmpty(externalCustomerCode)) {
				  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithCustomer.get("customerCompanyCode"), externalCustomerCode));
					  
				}
				if ( !StringUtils.isEmpty(externalResellerCode)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(rootWithResellerCompany.get("resellerCompanyCode"), externalResellerCode));
						  
					}
				if ( !StringUtils.isEmpty(dateRangeStart) && !StringUtils.isEmpty(dateRangeEnd)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.between(root.<Date>get("created"), dateRangeStart, 
							  DateFormatterUtility.getAfterDate(dateRangeEnd, 23)));
				}
				
				/*criteriaQuery.where(predicate);
				
				orderByList.add(criteriaBuilder.asc(root.get("id")));
				criteriaQuery.orderBy(orderByList);*/
		  		return predicate;
			}
		};
	 }
	 
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "id");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
}
