package com.valuelabs.nephele.admin.data.repository;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import com.google.common.base.Strings;
import com.valuelabs.nephele.admin.data.entity.CloudDistributorUser;
import com.valuelabs.nephele.admin.data.util.DateFormatterUtility;

@Slf4j
public final class CloudDistributorUserSpecifications  {
	
	 public static Specification<CloudDistributorUser> findUsers(final String firstName, final String lastName , final String email , final Boolean isEnabled , final Date createdDate){
		 
		  return new Specification<CloudDistributorUser>(){
			
			@Override
			public Predicate toPredicate(Root<CloudDistributorUser> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				 log.debug("findUser - START {}",isEnabled);				
				Predicate predicate = criteriaBuilder.conjunction();	
				
				if(!Strings.isNullOrEmpty(firstName)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("firstName"), firstName));
				}
				
				if(!Strings.isNullOrEmpty(lastName)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("lastName"), lastName));
				}
				
				if(!Strings.isNullOrEmpty(email)) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("email"), email));
				}
				
				if(null != isEnabled ){
					 predicate = criteriaBuilder.and(predicate,criteriaBuilder.equal(root.get("isEnabled"), isEnabled));
				}
			   
				if(null != createdDate) {
					  predicate = criteriaBuilder.and(predicate,criteriaBuilder.between(root.<Date>get("created"), getFormattedDate(createdDate), getFormattedDate(DateFormatterUtility.getAfterDate(createdDate, 23))));
							 /* criteriaBuilder.function("TO_CHAR",
						                String.class,root.get("created"), 
						                criteriaBuilder.literal("yyyy-MM-dd")), createdDate));		*/    
				}
				
				log.debug("findUser - END ");
		  		return predicate;
			}
		};
	 }
	 
	 public static Sort sortByIdAsc() {
	        return new Sort(Sort.Direction.ASC, "distributorId");
	 }
	 
	 /**
	  * Returns a new object which specifies the the wanted result page.
	  * @param pageIndex The index of the wanted result page
	  * @return
	  */
	 public static Pageable constructPageSpecification(int pageIndex, int pageSize, Sort sortingOrderSpec) {
	        Pageable pageSpecification = new PageRequest(pageIndex, pageSize, sortingOrderSpec);
	        return pageSpecification;
	 }
	 
	    /**
	     * Returns a Sort object which sorts persons in ascending order by using the last name.
	     * @return
	     */
	    public static Sort sortByLastNameAsc() {
	        return new Sort(Sort.Direction.ASC, "lastName");
	    }
	    
	    private static Date getFormattedDate(Date givenDate) {
	        Timestamp dateTimeValue = null;
	        try {
	          if (null != givenDate) {
	            SimpleDateFormat timeStampFormat = new SimpleDateFormat("yyyy-MM-DD HH:mm:ss z");
	            java.util.Date date = timeStampFormat.parse(timeStampFormat.format(givenDate));
	            dateTimeValue = new java.sql.Timestamp(date.getTime());
	          }
	        } catch (Exception e) {
	          e.printStackTrace();
	        }
	        return dateTimeValue;
	      }
}
