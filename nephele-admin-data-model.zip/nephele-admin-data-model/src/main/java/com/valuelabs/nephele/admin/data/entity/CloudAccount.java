package com.valuelabs.nephele.admin.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.valuelabs.nephele.admin.data.api.AccountStatus;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Setter
@Getter
@SequenceGenerator(name = "cloud_account_seq", sequenceName = "cloud_account_seq", initialValue = 1)
@Entity
@Table(name = "cloud_account")
public class CloudAccount extends AbstractAuditEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "account_id")
	@GeneratedValue(generator = "cloud_account_seq")
	private Long id;
	
	@Column(name = "name", nullable = true)
	private String name;
	
	@Column(name = "description", nullable = true, length = 1000)
	private String description;

	@Column(name = "vendor_account_id")
	private String vendorAccountId;

	@Column(name = "username")
	private String username;

	@Column(name = "password")
	private String password;

	@Enumerated(EnumType.STRING)
	@Column(name = "vendor_status")
	private AccountStatus vendorStatus;
	
	@Column(name = "nephele_status", nullable = true)
	private String nepheleStatus;

	@Column(name = "super_username")
	private String superUsername;

	@Column(name = "super_password")
	private String superPassword;

	@Column(name = "super_apikey")
	private String superAPIKey;

	@ManyToOne
	@JoinColumn(name = "customer_company_id")
	private CloudCustomerCompany cloudCustomerCompany;
	
	@OneToOne
	@JoinColumn(name = "cloud_order_id", unique = true)
	private CloudOrder cloudOrder;

	@ManyToOne
	@JoinColumn(name = "cloud_service_id")
	private CloudService cloudService;
	
	@ManyToOne
	@JoinColumn(name = "product_plan_id")
	private CloudProductPlan cloudProductPlan;

    @OneToMany(mappedBy = "cloudAccount")
	private Set<CloudSubscription> cloudSubscription = new HashSet<CloudSubscription>();

}
