package com.valuelabs.nephele.admin.data.api;

/**
 * Created by snagaboina on 28/12/15.
 */
public enum DbsSyncStatus {
  NEW,
  SYNC,
  DIRTY,
  FAILED
}
