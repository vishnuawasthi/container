package com.valuelabs.nephele.admin.data.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.valuelabs.nephele.admin.data.entity.CloudAccount;

public interface CloudAccountRepository  extends TableRepository<CloudAccount, Long>, JpaSpecificationExecutor<CloudAccount>{
	
	@Query("FROM CloudAccount ca where ca.cloudCustomerCompany.id = :customerId")
	CloudAccount getAccountByCustomerId(@Param("customerId")Long customerId);

	@Query("FROM CloudAccount ca where ca.vendorAccountId = :vendorAccountId")
	CloudAccount getAccountByVendorAccountId(@Param("vendorAccountId") String vendorAccountId);

	@Query("FROM CloudAccount ca where ca.cloudCustomerCompany.id = :customerId and ca.cloudService.id = :serviceId")
	CloudAccount getAccountByCustomerIdAndServiceId(@Param("customerId")Long customerId,@Param("serviceId")Long serviceId);

}
