package com.valuelabs.nephele.admin.data.api;

public enum RackspaceServerActionStatus {
	
	INITIATED,
	PICKED,
	PROCESSING,
	COMPLETED,
	FAILED;

}
