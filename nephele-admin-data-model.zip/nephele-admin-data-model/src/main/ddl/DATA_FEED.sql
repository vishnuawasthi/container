

INSERT INTO cloud_service_provider VALUES(nextval('cloud_service_provider_seq'), now(), now(), 'rackspace', 'Rackpace', 'RackSpaceDesc');
INSERT INTO cloud_service_provider VALUES(nextval('cloud_service_provider_seq'), now(), now(), 'softlayer', 'Softlayer', 'SoftlayerDesc');
INSERT INTO cloud_service_provider VALUES(nextval('cloud_service_provider_seq'), now(), now(), 'nomadesk', 'Nomadesk', 'NomadeskDesc');

Insert into service_category values(nextval('service_category_seq'),now(),null,'desc','IAAS');
Insert into service_industry_vertical values (nextval('service_industry_vertical_seq'),now(),null,'desc','test');

INSERT INTO cloud_service  VALUES(nextval('cloud_service_seq'), now(), now(),'Monthly',20, 'RackSpace Service Desc','rackspace',false,false, 'Rackspace','PLN','rackspace','RS','UTC','rackspace','AUD', 1,1,1);
INSERT INTO cloud_service  VALUES(nextval('cloud_service_seq'), now(), now(),'Monthly',20, 'Softlayer Service Desc','softlayer',false,false, 'Softlayer','SLPLN','softlayer','SL','UTC','softlayer','USD', 2,1,1);
INSERT INTO cloud_service  VALUES(nextval('cloud_service_seq'), now(), now(),'MONTHLY', 22, 'Nomadesk Business File Sharing & Synchronization', 'nomadesk', true, true, 'Nomadesk','NDPLN','nomadesk','ND','UTC','nomadesk', 'AUD', 3, 1, 1);

insert into cloud_service_credential values(nextval('cloud_service_credential_seq'), now(), now(), '86F3Vbg3FeW73vm79xC95LUjle83oPpdfAcbbOyzc5nJ6JqDBt/+y0bjVzljQd9Y', 'synnexsandbox',1);
insert into cloud_service_credential values(nextval('cloud_service_credential_seq'), now(), now(), 'UTLJEoV+y8yZr14C28JAEE980TIcTaRl4UnbTQdEAy9OK05fD12iTMNCFFu1AxxgymxOiFyws5ZN+V8VrT7bY8nomoMG3/7LRuNXOWNB31g=', 'SL775479',2);

INSERT INTO cloud_reseller_premium_group (id,  description, name) VALUES (nextval('cloud_reseller_premium_group_seq'), 'Default Group','DEFAULT');
INSERT INTO cloud_reseller_premium_group (id,  description, name) VALUES (nextVal('cloud_reseller_premium_group_seq'), 'Gold Group','GOLD');

INSERT INTO cloud_reseller_premium_group (id,  description, name) VALUES (nextVal('cloud_reseller_premium_group_seq'), 'Platinium Group','PLATINUM');
INSERT INTO cloud_reseller_discount_plan_type (id,  description,type_name) VALUES (nextval('cloud_reseller_discount_plan_type_seq'), 'Volume Based discount','VOLUME');
INSERT INTO cloud_reseller_discount_plan_type (id,  description, type_name) VALUES (nextval('cloud_reseller_discount_plan_type_seq'), 'Flat discount','FLAT');

INSERT INTO cloud_reseller_company VALUES (nextval('cloud_reseller_company_seq'), now(), now(),'123',true, '13 Vale St.','Malaga WA 6090','Malaga','Australia','AU','AUS',04,2030,'testToken','VISA','test@valuelabs.com','Synnex',true,'Australia Pvt Ltd','123456','SynnexReseller','test','WA','test','6090', 1);
INSERT INTO cloud_reseller_company VALUES (nextval('cloud_reseller_company_seq'), now(), now(),'123',true,'Plot No: 41','Hitech City Phase-II','Telangana','Australia','AU','AUS',04,2030,'testToken','VISA','test@valuelabs.com','Valuelabs Technologies',true,'LLP','789654123','ValueLabs','test','AP','test','500081', 1);


INSERT INTO cloud_customer_company VALUES (nextval('cloud_customer_company_seq'), now(), now(),1,1, 'Plot No: 41','Hitech City Phase-II','businessemail','businessname','Telangana','Australia','AU','AUS','123456','Valuelabs LLP','test@valuelabs.com','ValueLabs',true,'LLP',7888,'AP','500081', 1);
INSERT INTO cloud_customer_company VALUES (nextval('cloud_customer_company_seq'), now(), now(),1,1, 'Plot No: 41','Hitech City Phase-II','businessemail','businessname','Telangana','Australia','AU','AUS','789654123','Valuelabs LLP','test@valuelabs.com','ValueLabs',true,'LLP',5656,'AP','500081', 2);
INSERT INTO cloud_customer_company VALUES (nextval('cloud_customer_company_seq'), now(), now(),1,1 ,'Plot No: 41','Hitech City Phase-II','businessemail','businessname','Telangana','Australia','AU','AUS','8765434','Valuelabs Technologies','test@valuelabs.com','VLT',true,'Technologies',5454,'AP','500081', 2);

INSERT INTO cloud_product_category VALUES(1, now(), now(), 'Infrastructure as a Service', 'Infrastructure As a Service');
INSERT INTO cloud_product_category VALUES(2, now(), now(), 'Software as a Service', 'Software As a Service');

INSERT INTO CLOUD_USER_ROLE VALUES (nextval('CLOUD_USER_ROLE_seq'), now(), null, 'Administrator', 'ADMIN');
INSERT INTO CLOUD_USER_ROLE VALUES (nextval('CLOUD_USER_ROLE_seq'), now(), null, 'User', 'USER');

insert into cloud_distributor_user values (nextval('cloud_distributor_user_seq'), now(), null,null,null, 'srikanth.nagaboina@valuelabs.com','Srikanth',true,null,null,null,'YkzKq3m8fYux63zK4KYxgg==',null, null,1);
insert into cloud_distributor_user values (nextval('cloud_distributor_user_seq'), now(), null,null,null, 'rajamohan.sanepalle@valuelabs.com','Raj',true,null,null,null,'YkzKq3m8fYux63zK4KYxgg==',null, null,1);
insert into cloud_distributor_user values (nextval('cloud_distributor_user_seq'), now(), null,null,null, 'pothuluraiah.v@valuelabs.com','PV',true,null,null,null,'YkzKq3m8fYux63zK4KYxgg==',null, null,1);
insert into cloud_distributor_user values (nextval('cloud_distributor_user_seq'), now(), null,null,null, 'saranya.allu@valuelabs.com','Saranya',true,null,null,null,'YkzKq3m8fYux63zK4KYxgg==',null, null,2);
insert into cloud_distributor_user values (nextval('cloud_distributor_user_seq'), now(), null,null,null, 'bharath.todupunoori@valuelabs.com','Bharathsai',true,null,null,null,'YkzKq3m8fYux63zK4KYxgg==',null, null,1);

INSERT INTO cloud_manager_app_account VALUES (nextval('cloud_manager_app_account_seq'), now(), NULL, 'Reseller desc', 'Reseller');
INSERT INTO cloud_manager_app_account VALUES (nextval('cloud_manager_app_account_seq'), now(), NULL, 'Cloud Services desc', 'Cloud Services');
INSERT INTO cloud_manager_app_account VALUES (nextval('cloud_manager_app_account_seq'), now(), NULL, 'Invoices desc', 'Invoices');
INSERT INTO cloud_manager_app_account VALUES (nextval('cloud_manager_app_account_seq'), now(), NULL, 'Settings desc', 'Settings');
INSERT INTO cloud_manager_app_account VALUES (nextval('cloud_manager_app_account_seq'), now(), NULL, 'Reports desc', 'Reports');
INSERT INTO cloud_manager_app_account VALUES (nextval('cloud_manager_app_account_seq'), now(), NULL, 'Users desc', 'Users');
INSERT INTO cloud_manager_app_account VALUES (nextval('cloud_manager_app_account_seq'), now(), NULL, 'Bundles desc', 'Bundles');

INSERT INTO cloud_lifecycle_config values(nextval('cloud_lifecycle_config_seq'), now(), now(),5.0,'AUD','{"test":"test"}','INV',0,10.0,'ORD',10.0);


INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'ORDER_PREFIXDescription ', 'ORDER_PREFIX', 'CO');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'INVOICE_PREFIX', 'CI');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'AMEX_SURCHARGE', '');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'MASTER_SURCHARGE', '');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'VISA_SURCHARGE', '');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'CURRENCY', 'AUD');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'INVOICE_TERM', '0');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'GST', '10');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'DISTRIBUTOR_NAME', '{"companyName": "SYNNEX AUSTRALIA PTY LTD.","addressLine1": "14 PARRAMATTA RD","addressLine2": "","city": "LIDCOMBE","state": "NSW","country": "AUSTRALIA","zipCode": "2141","phone": "(02) 8756 8899","fax": "(02) 8756 8800","ABN": "40 052 285 882","ACN": "052 285 882"}');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'PAYMENT_GATEWAY_MERCHANT_ID', '962');
INSERT INTO cloud_business_rule  VALUES (nextval('cloud_business_rule_seq'), now(), now(), 'TEST Description', 'PAYMENT_GATEWAY_HASH_KEY', 'W65D4UL*s4kO$On6nRJa');

INSERT INTO cloud_geography VALUES (0, now(), now(), 'ND_GEO', 'Nomadesk Geography');
INSERT INTO cloud_geography VALUES(nextval('cloud_geography_seq'),now(),null,'AUS','Australia');
INSERT INTO cloud_geography VALUES(nextval('cloud_geography_seq'),now(),null,'USA','United States of America');
INSERT INTO cloud_geography VALUES(nextval('cloud_geography_seq'),now(),null,'APAC','Asia Pacific');

INSERT INTO cloud_loc_geo_mappings VALUES(nextval('cloud_loc_geo_mappings_seq'),now(),null,'AUS','SYD');
INSERT INTO cloud_loc_geo_mappings VALUES(nextval('cloud_loc_geo_mappings_seq'),now(),null,'APAC','HKG');
INSERT INTO cloud_loc_geo_mappings VALUES(nextval('cloud_loc_geo_mappings_seq'),now(),null,'USA','IAD');
INSERT INTO cloud_loc_geo_mappings VALUES(nextval('cloud_loc_geo_mappings_seq'),now(),null,'USA','DFW');
INSERT INTO cloud_loc_geo_mappings VALUES(nextval('cloud_loc_geo_mappings_seq'),now(),null,'USA','ORD');


 INSERT INTO cloud_operating_system VALUES (0, now(), null, '{"id":"nomadesk-1234"}', 'nomadesk-1234',  20, 512, 'nomadesk-OS', null, 'windows', 0.5, 'DISCOVERED', 3);


INSERT INTO cloud_product VALUES (0, now(), now(), 'Business File Sharing & Synchronization', true, false, false, 'Business File Sharing & Synchronization', 'DISCOVERED', 'storage', 0, 3);

INSERT INTO cloud_rackspace_configuration VALUES (0, now(), null, 1, '{}', 0, 0, 'nomadesk_class', 'Nomadesk Config', 0, 512,'DISCOVERED', 3);

INSERT INTO cloud_location VALUES (0, now(), now(), 'AUD', 'ND_LOC', 'Nomadesk Location', 'DISCOVERED', 0, 3);
INSERT INTO cloud_location VALUES (nextval('cloud_location_seq'), now(), now(), 'AU', 'syd01', 'syd01', 'DISCOVERED', 1, 2);


INSERT INTO cloud_product_plan VALUES (nextval('cloud_product_plan_seq'), now(), now(), 'Free trial Description', '{"operatingSystemId":0,"flavorId":0}', null, true, 'TRIAL_PLN', 'trial', 20, 'PER_LICENSE', 1, 'DISCOVERED', 'trial', 20, 0, 0, 3);

INSERT INTO cloud_product_plan VALUES (nextval('cloud_product_plan_seq'), now(), now(), 'Monthly plan Description', '{"operatingSystemId":0,"flavorId":0}', null, true, 'MONTHLY_PLN', 'Monthly', 50, 'PER_LICENSE', 2, 'DISCOVERED', 'monthly', 50, 0, 0, 3);

INSERT INTO cloud_product_plan VALUES (nextval('cloud_product_plan_seq'), now(), now(), 'Yearly plan Description', '{"operatingSystemId":0,"flavorId":0}', null, true, 'YEARLY_PLN', 'Yearly', 100, 'PER_LICENSE', 3, 'DISCOVERED', 'yearly', 100, 0, 0, 3);

INSERT INTO cloud_product VALUES (nextval('cloud_product_seq'), now(), now(), 'Softlayer Account Plan', false, false, false, 'Softlayer Account Plan','DISCOVERED', 'ACCOUNT', 0,  1, 2);

INSERT INTO cloud_product_plan VALUES (nextval('cloud_product_plan_seq'), now(), now(), 'Free trial Description', '{"operatingSystemId":0,"flavorId":0}', null, false, 'softlayer_cloud', 'softlayer cloud plan', 0, 'PER_UNIT', 1, 'DISCOVERED', null, 0, 1,(select cloud_product_id from cloud_product where name = 'Softlayer Account Plan'), 2);

drop table CLOUD_ACCOUNT_SERVER_VIEW;

create view CLOUD_ACCOUNT_SERVER_VIEW as
select cloud_server_id as resource_id, name as resource_name, description, customer_company_id, cloud_service_id, cloud_product_plan_id, cloud_order_id,
vendor_status, status as nephele_status, created as provision_date,'server' as resource_type from cloud_server
union all
select account_id as resource_id, name as resource_name, description, customer_company_id, cloud_service_id, product_plan_id, cloud_order_id,
null as vendor_status, status as nephele_status, created as provision_date, 'account' as resource_type  from cloud_account;

GRANT SELECT ON CLOUD_ACCOUNT_SERVER_VIEW TO NEPHELE;

insert into cloud_job_schedular values (nextval('cloud_job_schedular_seq'), now(), now(), 14 , 'INVENTORY',49, null, 'ACTIVE', 1 );
insert into cloud_job_schedular values (nextval('cloud_job_schedular_seq'), now(), now(), 14 , 'INVENTORY',51, null, 'ACTIVE', 2 );