package com.valuelabs.nephele.ui.controller;

import com.valuelabs.nephele.ui.data.SystemUtils;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

import java.io.File;
import java.io.FileReader;
import java.net.URL;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ManagerController {

	private final String DEFAULT_LANDING_PAGE = "index";
	@Value("${nephele.unixPath}")
    private String linuxDirectoryPath;
    @Value("${nephele.windowsPath}")
    private String windowsDirectoryPath;

    @RequestMapping(value = {"", "/manager/*", "/index"}, method = RequestMethod.GET)
    public ModelAndView index(ModelMap modelMap, HttpServletRequest httpServletRequest) {
        String urlToDirect = urlParameterConstruct(httpServletRequest);
        modelMap.put("pageLoadValue", StringUtils.isEmpty(urlToDirect) ? DEFAULT_LANDING_PAGE : urlToDirect);
        JSONObject jsonObj = getBaseURLS();
        modelMap.put("urlJson", jsonObj);
        return new ModelAndView(DEFAULT_LANDING_PAGE, modelMap);
    }

    @RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
    public ModelAndView resetPassword(ModelMap modelMap, HttpServletRequest httpServletRequest) {
        String resetKey = httpServletRequest.getParameter("_key");
        modelMap.put("resetKey", resetKey);
        modelMap.put("pageLoadValue", resetKey != null ? "resetPassword" : DEFAULT_LANDING_PAGE);
        return new ModelAndView(DEFAULT_LANDING_PAGE, modelMap);
    }

    private String urlParameterConstruct(HttpServletRequest httpServletRequest) {
        String path = DEFAULT_LANDING_PAGE;
        try {
            URL url = new URL(httpServletRequest.getRequestURL().toString());
            path = url.getPath();
            if (!StringUtils.isEmpty(path) && !path.equals(DEFAULT_LANDING_PAGE)) {
                path = path.substring(1, path.length()).replace("/", ".");
            }
            return path;
        } catch (Exception e) {
        	  log.error("Exception" + e);
        }
        return path;
    }

    private JSONObject getBaseURLS() {
        JSONObject returnVal = new JSONObject();
        String destPath = SystemUtils.IS_OS_UNIX ? linuxDirectoryPath : windowsDirectoryPath;
        File destinationFile = new File(destPath);
        if (destinationFile.exists()) {
            try {
                JSONParser parser = new JSONParser();
                Object obj = parser.parse(new FileReader(destPath));
                returnVal = (JSONObject) obj;
            }catch (ParseException e) {
                log.error("Json ParseException" + e);
             } catch (Exception e) {
               log.error("Exception" + e);
            }
        }
        return returnVal;
    }
}