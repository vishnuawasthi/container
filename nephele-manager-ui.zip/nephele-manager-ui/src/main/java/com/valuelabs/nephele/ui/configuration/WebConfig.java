package com.valuelabs.nephele.ui.configuration;

import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.ErrorPage;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.WebContentInterceptor;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration
@EnableWebMvc
public class WebConfig extends WebMvcConfigurerAdapter{
	
	private static final Integer RESOURCE_CACHE_PERIOD_SECONDS = new Integer(10);
	private static final String[] RESOURCE_LOCATIONS = {"classpath:/WEB-INF/jsp/"};
	
	@Bean
	public ViewResolver getViewResolver() {
		InternalResourceViewResolver internalResourceViewResolver = new InternalResourceViewResolver();
		internalResourceViewResolver.setViewClass(JstlView.class);
		internalResourceViewResolver.setPrefix("/resources/jsp/");
		internalResourceViewResolver.setSuffix(".jsp");
		return internalResourceViewResolver;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/").setCachePeriod(RESOURCE_CACHE_PERIOD_SECONDS);
		/*if (!registry.hasMappingForPattern("/**")) {
			registry.addResourceHandler("/**").addResourceLocations(RESOURCE_LOCATIONS);
		}*/
	}
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(getWebContentInterceptor());
	}
	@Bean
	public WebContentInterceptor getWebContentInterceptor() {
		WebContentInterceptor interceptor = new WebContentInterceptor();
		interceptor.setCacheSeconds(0);
		interceptor.setUseExpiresHeader(false);
		interceptor.setUseCacheControlHeader(false);
		interceptor.setUseCacheControlNoStore(false);
		/*interceptor.setAlwaysUseFullPath(true);		
		Properties mappings = new Properties();
		mappings.put("/", "2592000");
		mappings.put("css/**", "-1");
		mappings.put("/scripts/**", "-1");
		mappings.put("/images/**", "-1");
		interceptor.setCacheMappings(mappings);*/
		return interceptor;
	}
	
	
	@Bean public EmbeddedServletContainerCustomizer containerCustomizer() {
	    return new EmbeddedServletContainerCustomizer() {
	        public void customize(ConfigurableEmbeddedServletContainer container) {
	            ErrorPage error400Page = new ErrorPage(HttpStatus.BAD_REQUEST, "/resources/jsp/index.jsp");
	            ErrorPage error404Page = new ErrorPage(HttpStatus.NOT_FOUND,"/resources/jsp/index.jsp");
	           /* ErrorPage error500Page = new ErrorPage( HttpStatus.INTERNAL_SERVER_ERROR, "/resources/jsp/index.jsp");
	            ErrorPage error505Page = new ErrorPage(HttpStatus.HTTP_VERSION_NOT_SUPPORTED, "/resources/jsp/index.jsp");
	            ErrorPage error506Page = new ErrorPage(HttpStatus.METHOD_NOT_ALLOWED, "/resources/jsp/index.jsp");*/
	            container.addErrorPages(error400Page, error404Page);
	        }
	    };
	}


}