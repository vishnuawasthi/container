var app = angular.module('nepheleAdminApp', ['ngResource','ngCookies','ui.router','xeditable','ngTouch','ui.bootstrap','ngAnimate','ngIdle']);

// This used to store stateProvider in the variable on startup
app.constant('stateProviderConstant', { key: '' });
// This used to store all the constants in the variable on startup
app.constant('propertiesConfig', { details: [] });
//This used to store apiKey after login
//app.constant('apiKey', { key: '' });
// This is used to store the apiHeaders
app.constant('apiHeaders', { headers: {} });

// Config is used to load all the states object(navigation) and interceptor
app.config(['$locationProvider', '$stateProvider','$httpProvider','stateProviderConstant','IdleProvider',function ($locationProvider, $stateProvider,$httpProvider,stateProviderConstant,IdleProvider) {
	  IdleProvider.idle(1795);
	  IdleProvider.timeout(5);
	  $locationProvider.html5Mode(true);
	  stateProviderConstant.key = $stateProvider;
	  $httpProvider.interceptors.push('authHttpResponseInterceptor');
	  $httpProvider.interceptors.push('apiKeyInterceptor');
}]);

// This block is used to load all the states into stateProvider
app.run(['$state', '$http','onLoadPage','stateProviderConstant','propertiesConfig','$rootScope','$stateParams',
         			function ($state, $http,onLoadPage,stateProviderConstant,propertiesConfig,$rootScope,$stateParams){
	$http.get('resources/constants/restUrlConfig.txt').success(function(data,status,headers,config) {
		angular.extend(propertiesConfig.details, data);
	}).error(function(data,status,headers,config) {
		propertiesConfig.details = [];
	});
	$http.get('resources/constants/constants.txt').success(function(data,status,headers,config) {
		angular.extend(propertiesConfig.details, data);
	}).error(function(data,status,headers,config) {
		propertiesConfig.details = [];
	});
	$http.get("resources/constants/states.json").success(function(data,status,headers,config){
		angular.forEach(data, function (value, key){
			var state = {
				"url": value.url,
				"controller" : value.controller,
				"templateUrl": value.templateUrl,
				"params": {}
			};
			angular.forEach(value.params, function (value, keys){
				state.params = {
					keys : value
				};
			});
			stateProviderConstant.key.state(value.name, state);
		});
		var stateExists = $state.get(onLoadPage);
		onLoadPage = (stateExists!= null && stateExists!= undefined) ? onLoadPage: 'index';
		if(onLoadPage != 'index' && onLoadPage !=  'resetPassword'){
			$state.get('manager').params.navigate = onLoadPage;
			$state.go('manager');
		}else{
			$state.go(onLoadPage);
		}
	});
	
	$rootScope.$state = $state;
	$rootScope.$stateParams = $stateParams;
	$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){
		//console.log('testApp#run#stateChangeStart; from:', fromState.name, ' to:', toState.name,' onLoadPage:',onLoadPage);
		if(toState.name == propertiesConfig.details.manager){
			$state.go((fromState.name!= undefined && fromState.name != '')?fromState.name:onLoadPage);
		}
		// Need to write the back button disable logic
	});
}]);



// Interceptor is used for redirect to login page if response status code is 401
app.factory('authHttpResponseInterceptor',['$q','$location','$cookies','propertiesConfig',function($q,$location,$cookies,propertiesConfig){
	return {
		response: function(response){
			if (response.status === 401) {
				console.log("Response 401");
			}
			return response || $q.when(response);
		},
		responseError: function(rejection) {
			if (rejection.status === 401) {
				console.log("Response Error 401",rejection);
				$cookies.remove(propertiesConfig.details.apiKey);
				//apiKey.key='';
				$location.path(propertiesConfig.details.slashIndex);
				//$location.path('/login').search('returnTo', $location.path());
			}
			return $q.reject(rejection);
		}
	};
}]);

app.factory('apiKeyInterceptor',['$cookies','propertiesConfig',function($cookies,propertiesConfig){
    return {
    	'request': function(config) {
    			var apiKey = $cookies.get(propertiesConfig.details.apiKey);
    			if (apiKey!=null) {
          			 config.headers[propertiesConfig.details.apikeyServer] = apiKey;
    			} 
    		return config;
    	}
    };
}]);

// Application first controller to load necessary dependencies to the application (i.e constants, ...)
app.controller('appLoadController', ['$scope', 'propertiesConfig','urlPropertiesService','$state','$cookies','$rootScope','onLoadPage','Idle','sessionExpireService','responseMessageService','$timeout','factoryForRoleBasedFeature','roleFlagService',
	function($scope, propertiesConfig,urlPropertiesService,$state,$cookies,$rootScope,onLoadPage,Idle,sessionExpireService,responseMessageService,$timeout,factoryForRoleBasedFeature,roleFlagService ) {
	if(onLoadPage != propertiesConfig.details.index && onLoadPage != propertiesConfig.details.resetPassword){
		//apiKey.key=$cookies.get('apiKey');
		var urlJsonService =  urlPropertiesService.getProperties();
		if($scope.firstName === undefined){
			$scope.firstName = $cookies.get(propertiesConfig.details.firstName);
		}
		urlJsonService.success(function(data,status,headers,config) {
			if(data.indexOf(onLoadPage) >= 0){
				$state.get(onLoadPage).params.id = $cookies.get(propertiesConfig.details.id);
				$state.get(onLoadPage).params.name = $cookies.get(propertiesConfig.details.name);
				$state.get(onLoadPage).params.isPublished = $cookies.get(propertiesConfig.details.isPublished);
			}
		});
		urlJsonService.error(function(data,status,headers,config) {
			 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		});
	}	
	var roleBasedPermissions = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.roleBasedAll);
    roleFlagService.assignFlagToScope(roleBasedPermissions,$scope,propertiesConfig);
	Idle.watch();
	$rootScope.$on('IdleTimeout', function() { 
		  sessionExpireService.callExpire(propertiesConfig.details.sessionExpiredMsg);
	});
	$scope.firstName =  $cookies.get( propertiesConfig.details.firstName);
	$scope.loadingIcon = true;
	$scope.userProfileSettings = function(){
		$scope.firstName =  $cookies.get( propertiesConfig.details.firstName);
		$state.go('manager.profileSettings');
	};
	$scope.$on('updateFirstNameEvent', function(e) {
		$scope.firstName =  $cookies.get(propertiesConfig.details.firstName);
		$state.go('manager.profileSettings');
	 });
	var navigate =  $state.get(propertiesConfig.details.manager).params.navigate;
	 $state.go(navigate!= undefined ? navigate :'manager.dashBoard');
	  $scope.footerMessage = propertiesConfig.details.footerMessage;

}]);;
app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

;app.directive('datePicker', ['$compile','propertiesConfig',function($compile,propertiesConfig) {
	  var controllerName = 'dateEditCtrl';
	  return {
	      restrict: 'A',
	      require: '?ngModel',
	      scope: true,
	      link: function(scope, element) {
	          var wrapper = angular.element(
	              '<div class="input-group">' +
	                '<span class="input-group-btn">' +
	                  '<button type="button" class="btn btn-default" ng-click="' + controllerName + '.openPopup($event)"><i class="glyphicon glyphicon-calendar"></i></button>' +
	                '</span>' +
	              '</div>');

	          function setAttributeIfNotExists(name, value) {
	              var oldValue = element.attr(name);
	              if (!angular.isDefined(oldValue) || oldValue === false) {
	                  element.attr(name, value);
	              }
	          }
	          setAttributeIfNotExists('type', 'text');
	          setAttributeIfNotExists('is-open', controllerName + '.popupOpen');
	          setAttributeIfNotExists('show-weeks', propertiesConfig.details.falseStr);
	          setAttributeIfNotExists('date-formate', propertiesConfig.details.dateFormate);
	          setAttributeIfNotExists('datepicker-options' ,propertiesConfig.details.dateOptions);
	          setAttributeIfNotExists('datepicker-popup', propertiesConfig.details.dateFormate);
	          setAttributeIfNotExists('close-text', propertiesConfig.details.close);
	          setAttributeIfNotExists('clear-text', propertiesConfig.details.clear);
	          setAttributeIfNotExists('current-text', propertiesConfig.details.today);
	          element.addClass('form-control');
	          element.removeAttr('date-picker');
	        
	          element.after(wrapper);
	          wrapper.prepend(element);
	          $compile(wrapper)(scope);

	          scope.$on('$destroy', function () {
	              wrapper.after(element);
	              wrapper.remove();
	          });
	      },
	      controller: function($scope) {
	          this.popupOpen = false;
	          this.openPopup = function($event) {
	        	  if(!this.popupOpen){
	        		  $event.preventDefault();
                      $event.stopPropagation();
                      this.popupOpen = true;
                    }
	          };
	          $scope.format = propertiesConfig.details.dateFormate;
	          $scope.dateOptions = $scope.dateOptions || {
	              formatYear: 'yy',
	              startingDay: 1,
	              showWeeks: false
	          };
	      },
	      controllerAs: controllerName
	  };
	}]);
app.directive('dateFormat', ['dateFilter',function (dateFilter) {
	return {
		require:'^ngModel',
		restrict:'A',
		link:function (scope, elm, attrs, ctrl) {
			ctrl.$parsers.unshift(function (viewValue) {
				if(viewValue!=null){
					viewValue.toString = function() {
						return dateFilter(this, attrs.dateFormat);
					}
				}
				return viewValue;
			});
		}
	};
}]);
;
//Common Resource Factory to make rest call
app.factory('commonFactoryForRestCall', ['$resource',function ($resource) {
	 return {
        getURL: function(endpointURL,queryParams) {
       	 return $resource(endpointURL, {}, {
		    	get:{ method: 'GET',isArray: false},
		    	getQueryParam: { method: 'GET', params: queryParams, isArray: false},
		    	getWithTransform: { method: 'GET',isArray: false},
		        post:{ method: 'POST',isArray: false,headers: {'Content-Type': 'application/json'}},
		        postWithOutHeader:{ method: 'POST',headers: {'Content-Type': 'application/json'},isArray: false },
		        put: { method: 'PUT',isArray: false,headers: {'Content-Type': 'application/json'}},
		        del: { method: 'DELETE',params: {id: '@id'}}
       	 });
        }
	 };
}]);
// Common $http factory to make server call
app.factory('commonFactoryForHttp', ['$http',function ($http) {
	return {
		getURL: function(methodType,endpointURL,queryParams) {
			return $http({method: methodType, url: endpointURL,params:queryParams});
			//return $http({method: methodType, url: endpointURL,headers: {'api-key': apikey},params:queryParams});
		}
	};
}]);
//This factory  is used to load all the constants from the properties files
/*app.factory('configPropertiesService', function($http) {
	 var factory = {};
	 factory.getProperties= function() {
		 return $http.get('resources/constants/constants.txt');
	 };
	 return factory;
});*/

app.factory('urlPropertiesService', ['$http',function($http) {
	 var factory = {};
	 factory.getProperties= function() {
		 return $http.get('resources/constants/urlWithParamsData.json');
	 };
	 return factory;
}]);


app.factory('factoryForRoleBasedFeature', ['$cookies','propertiesConfig',function($cookies,propertiesConfig) {
	return {
		getPermissions: function(roleKey) {
			var roleBasedPermissions = $cookies.getObject(propertiesConfig.details.roleBasedPermissions);
			if(roleKey === propertiesConfig.details.roleBasedAll){
				return roleBasedPermissions;
			}
			var roleBasedData={};
            roleBasedData.isRead = false;
            roleBasedData.isWrite = false;
			for(var loop = 0; loop<roleBasedPermissions.length;loop++){
				if(roleKey == roleBasedPermissions[loop].accountName){
					roleBasedData.isRead = roleBasedPermissions[loop].isRead ;
					roleBasedData.isWrite = roleBasedPermissions[loop].isWrite ;
					return roleBasedData;
				}
			}
            return roleBasedData;
		}
	};
}]);

//This Method is to Generate Pdf Report
app.factory('reportGeneratorPdf', ['$http','$timeout','propertiesConfig','responseMessageService',
	function ($http,$timeout,propertiesConfig,responseMessageService) {
	return {
		downloadPdfFile: function (exportEndpointURL,currentScope) {
			return $http({url: exportEndpointURL,responseType: 'arraybuffer' }).success(function (response) {
				currentScope.loadingIcon = false;
				return response;
			}).error(function (response) {
				currentScope.loadingIcon = false;
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, currentScope, $timeout);
				return response;
			});
		}
	};
 }]);

app.factory('fileUpload', ['$http', function ($http,$scope) {
	 return {
	    uploadFileToUrl : function(file, uploadUrl){
	        var fd = new FormData();
	        fd.append('file', file);
	        return $http.post(uploadUrl, fd, {
	            transformRequest: angular.identity,
	            headers: {'Content-Type': undefined}
	        });
	    }
	 };
}]);
;
app.service('responseMessageService',function() {
    this.showResponseMsg = function (message, cssClass, currentScope, $timeout) {
        currentScope.responseClass = cssClass;
        currentScope.responseMsg = message;
        currentScope.responseMsgFlag = true;
        $timeout(function () {
            currentScope.responseMsgFlag = false;
            currentScope.responseMsg = '';
        }, 10000);
    };
});


app.service('moduleActiveService',['propertiesConfig','commonFactoryForRestCall',function(propertiesConfig,commonFactoryForRestCall) {
    this.getModulesData = function(currentScope){
        var endPointAdditionalURL = propertiesConfig.details.baseURL+propertiesConfig.details.servicesModules;
        var params = angular.extend({
            serviceId:currentScope.serviceId
        });
        currentScope.isEnablePublish=false;
        commonFactoryForRestCall.getURL(endPointAdditionalURL).get(params,undefined,function(data,status,headers,config) {
            currentScope.authentication = data.authentication;
            currentScope.products = data.pricing;
            currentScope.discount = data.discountPlan;
            currentScope.billingCycle= data.billingCycle;
            currentScope.serviceName = data.serviceName;
            currentScope.isPublished = data.servicePublished;
            currentScope.serviceLive = data.serviceLive;
            if(currentScope.serviceLive === true){
            	currentScope.showEditButton = false;
			 }
            if(currentScope.authentication  && currentScope.products && currentScope.discount && currentScope.billingCycle){
                currentScope.isEnablePublish=true;
            }
            currentScope.modulesActiveFlag = true;
            currentScope.$broadcast ('stopLoadingEvent');
        }, function(data,status,headers,config) {
            currentScope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;
            currentScope.modulesActiveFlag = true;
            currentScope.$broadcast ('stopLoadingEvent');
        });

    };
}]);

app.service('removeCookiesService',['$cookies',function($cookies) {
	this.removeAllCookies = function(){
		var cookies = $cookies.getAll();
		angular.forEach(cookies, function (cookie, key) {
		    $cookies.remove(key);
		 });
	};
}]);

app.service('searchToggleService', function(){
	this.toggleSearch = function(){
		$(".search_row").slideToggle();
		$(".c-toggle-arrow-i").toggleClass("toggle");
	}
});	

//session Expired Service
app.service('sessionExpireService', ['$state','propertiesConfig','onLoadPage','commonFactoryForRestCall','removeCookiesService',
	function($state,propertiesConfig,onLoadPage,commonFactoryForRestCall,removeCookiesService) {
	this.callExpire = function(message) {
		var baseURL = propertiesConfig.details.baseURL;
		var endpointURL = baseURL+propertiesConfig.details.logout;
	    commonFactoryForRestCall.getURL(endpointURL).get(undefined,undefined,function(data,status,headers,config) {
	    	removeCookiesService.removeAllCookies();
		}, function(data,status,headers,config) {
			removeCookiesService.removeAllCookies();
		});
		onLoadPage = '';
		$state.get(propertiesConfig.details.index).params.message = message;
		$state.go(propertiesConfig.details.index);
	};
}]);

app.service('roleFlagService',function(){
	this.assignFlagToScope = function(roleBasedPermissions,currentScope,propertiesConfig){
		for(var loop = 0; loop<roleBasedPermissions.length;loop++){
			if(propertiesConfig.details.cloudServicesForRole == roleBasedPermissions[loop].accountName){
				currentScope.servicesRoleFlag = roleBasedPermissions[loop].isRead ;
			}
			if(propertiesConfig.details.resellerForRole == roleBasedPermissions[loop].accountName){
				currentScope.resellersRoleFlag = roleBasedPermissions[loop].isRead ;
			}
			if(propertiesConfig.details.invoicesForRole == roleBasedPermissions[loop].accountName){
				currentScope.invoicesRoleFlag = roleBasedPermissions[loop].isRead ;
			}
			if(propertiesConfig.details.settingsForRole == roleBasedPermissions[loop].accountName){
				currentScope.settingsRoleFlag = roleBasedPermissions[loop].isRead ;
			}
			if(propertiesConfig.details.reportsRole == roleBasedPermissions[loop].accountName){
				currentScope.reportRoleFlag = roleBasedPermissions[loop].isRead;
			}
			if(propertiesConfig.details.usersForRole == roleBasedPermissions[loop].accountName){
				currentScope.usersRoleFlag = roleBasedPermissions[loop].isRead ;
			}
			if(propertiesConfig.details.bundlesForRole == roleBasedPermissions[loop].accountName){
      currentScope.bundlesRoleFlag = roleBasedPermissions[loop].isRead ;
      }

		}
	}
});
	

;// This service is useful for the graphs
app.service('graphsService',function() {
	this.drawPieWithDonutUsingNVD3 = function(params){
		nv.addGraph(function() {
			var chart = nv.models.pieChart()
			.x(function(d) { return d[params.xAxisDataColumn] })
			.y(function(d) { return d[params.yAxisDataColumn] })
			//.legendPosition("bottom")
			.color(params.colorRange)
			.labelType(params.labelType)
			.showLabels(params.showLabels)
			//.pieLabelsOutside(params.pieLabelsOutside)
			.labelThreshold(params.labelThreshold)
			.showLegend(params.showLegend)
			//.tooltips(params.tooltips)
			.noData(params.noData)
			.donut(params.donut)
			.donutRatio(params.donutRatio);
			d3.select("#" + params.container + " svg")
			.datum(params.data)
			.call(chart);
			nv.utils.windowResize(chart.update);
			return chart;
		});
	};
	
	this.drawBarUsingNVD3=function(params){
		nv.addGraph(function() {
			var chart = nv.models.discreteBarChart()
			.x(function(d) {return d[params.xAxisDataColumn]})
			.y(function(d) { return d[params.yAxisDataColumn] })
			.staggerLabels(params.staggerLabels)
			//.tooltips(params.tooltips)
			.showValues(params.showValues)
			.duration(params.transitionDuration)
			.color(params.color)
			.width(params.width)
			.noData(params.noData)
			.rightAlignYAxis(params.rightAlignYAxis)
			.showXAxis(params.showXAxis)
			.showYAxis(params.showYAxis);
			d3.select("#" + params.container + " svg")
			.datum([{values:params.data}])
			.call(chart);
			nv.utils.windowResize(chart.update);
			return chart;
		});
	};
	
	this.drawLineUsingNVD3 = function (params) {
		var chart = nv.models.lineChart()
		.showLegend(params.showLegend)
		.noData(params.noData)
		.showYAxis(params.showYAxis)
		.showXAxis(params.showXAxis)
		.interactive(params.interactive);
		chart.xAxis.axisLabel(params.xAxisLabel).ticks(params.xAxisTicks);
		if(params.xAxisLabelParamFromData) {
			chart.xAxis.tickFormat(function (d) {
				return  params.data[d]?params.data[d][params.xAxisLabelParamFromData]:'';
			});
		}else {
			chart.xAxis.tickFormat(d3.format(params.xAxisTickFormat));
			//chart.xAxis.tickFormat(d3.format(',r'));
		}
		chart.yAxis.axisLabel(params.yAxisLabel).ticks(params.yAxisTicks);
		chart.yAxis.tickFormat(d3.format('.02f'));
		d3.select("#" + params.container + " svg")
		.datum(params.dataToDisplay)
		.call(chart);
		nv.utils.windowResize(chart.update);
		return chart;
	};
	
});;// This service is useful for the pagination
app.service('paginationService',['propertiesConfig',function(propertiesConfig) {
	var self = this;
    this.pageRange = function(size,start, end) {
    	var pageNums = [];        
        if (size < end) {
            end = size;
            start = 0;
        }
        for (var i = start; i < end; i++) {
        	pageNums.push(i);
        }       
        return pageNums;
    };
    this.getPageData = function(currentScope,paginationParams,params,additionalParams) {
		if(currentScope.loadingIcon != undefined)
			currentScope.loadingIcon = true;
    	if(params == undefined){
	    	params = angular.extend({
	    		page: currentScope.currentPage,
	    		size:currentScope.noOfitems
	    	});
    	}
		if(additionalParams !=undefined){
			additionalParams.page = currentScope.currentPage;
			additionalParams.size = currentScope.noOfitems;
		}
    	paginationParams.commonFactoryForRestCall.getURL(paginationParams.baseURL,params).getQueryParam(additionalParams,function(data){
	 		currentScope.servicesDetails = data.content;
		    currentScope.itemsPerPage =  data.page.size;
		    currentScope.noOfPages  =  data.page.totalPages;
		    currentScope.resultsCount = data.page.totalElements;
		    currentScope.number=data.page.number;
		    self.loadPageItems(currentScope);
			if(currentScope.loadingIcon != undefined)
				currentScope.loadingIcon = false;
		    currentScope.range = self.pageRange(currentScope.noOfPages,currentScope.currentPage, currentScope.currentPage+currentScope.noOfPages);
    		}, function(data,status,headers,config) {
				currentScope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				if(currentScope.loadingIcon != undefined)
					currentScope.loadingIcon = false;
			}
    	);
    };
    this.postPageData = function(currentScope,paginationParams,params) {
    	if(params == undefined){
	    	params = angular.extend({
	    		page: currentScope.currentPage,
	    		size:currentScope.noOfitems
	    	});
    	}
    	paginationParams.commonFactoryForRestCall.getURL(paginationParams.baseURL,params).post(params,function(data,status,headers,config){
	 		currentScope.sheetDetails = data.content;	   	
		    currentScope.itemsPerPagePerSheet =  data.page.size;
		    currentScope.noOfPagesPerSheet  =  data.page.totalPages;
		    currentScope.resultsCountPerSheet = data.page.totalElements;
		    currentScope.numberPerSheet=data.page.number;
		    self.loadPageItems(currentScope);
		    currentScope.rangePerSheet = self.pageRange(currentScope.noOfPagesPerSheet,currentScope.currentPge, currentScope.currentPge+currentScope.noOfPagesPerSheet);
    		}, function(data,status,headers,config) { currentScope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;}
    	);
    	

    };
    this.nextPage = function($scope,paginationParams,params,additionalParams){
    	if ($scope.currentPage <= $scope.pagedItems.length - 1) {
            $scope.currentPage++;
            self.getPageData($scope,paginationParams,params,additionalParams);
        }
    };
    this.prevPage = function($scope,paginationParams,params,additionalParams){
    	if ($scope.currentPage > 0) {
            $scope.currentPage--;
            self.getPageData($scope,paginationParams,params,additionalParams);
        }
    };
    this.setPage = function($scope,paginationParams,passedReference,params,additionalParams){
    	 $scope.currentPage = passedReference.pageRange;
         self.getPageData($scope,paginationParams,params,additionalParams);
    };
    this.loadPageItems = function(currentScope){
    	if(currentScope.servicesDetails!=null){
     	    currentScope.pagedItems=[];
            for (var i = 0; i < currentScope.servicesDetails.length; i++) {
                if (i % currentScope.itemsPerPage === 0) {
                    currentScope.pagedItems[currentScope.number] = [ currentScope.servicesDetails[i] ];
                } else {
                    currentScope.pagedItems[currentScope.number].push(currentScope.servicesDetails[i]);
                }
            }
    	}
    };
    this.loadPageCounts = function(currentScope){
    	currentScope.pageSizes= JSON.parse(propertiesConfig.details.pageSize);
    	currentScope.noOfitems=currentScope.pageSizes[0];
    };
}]);;app.controller('billingCycleCtrl', ['$scope', 'commonFactoryForRestCall','propertiesConfig','$state','fileUpload','moduleActiveService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature',
	function ($scope, commonFactoryForRestCall,propertiesConfig,$state,fileUpload,moduleActiveService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature) {
	$scope.serviceError=false;
	$scope.showEditButton = true;
	var baseURL = propertiesConfig.details.baseURL;
	$scope.serviceId = $cookies.get(propertiesConfig.details.id);
	$scope.confirmationPopup=false;
	$scope.setBillingDay = true;
	$scope.loadingIcon = true;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var endpointURL = baseURL+propertiesConfig.details.serviceCatalog;
	var queryParams={};
	queryParams.id =  $scope.serviceId;
	moduleActiveService.getModulesData($scope);
	commonFactoryForRestCall.getURL(endpointURL).get(queryParams,undefined, function(data,status,headers,config) {
		$scope.billingDay= data.billingDay;
		if($scope.billingDay != null){
		    $scope.setBillingDay = false;
		}
		$scope.loadingIcon = false;
	}, function(data,status,headers,config) {
		if(data.status === 400){
			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.loadingIcon = false;
    });
	$scope.showConfirmationPopup = function(flag){
		$scope.confirmationPopup = flag;
	};
	$scope.editBillingDay = function(flag){
		$scope.setBillingDay = flag;
		$scope.newBillingDate = $scope.billingDay;
	};
	$scope.selectedDate = function(newBillingDate){
		$scope.newBillingDate = newBillingDate;
	};

	$scope.saveBillingDay = function(){
		$scope.confirmationPopup = true;
	};
	$scope.updateBillingDay = function(){
		$scope.loadingIcon = true;
		$scope.setBillingDay = true;
		$scope.confirmationPopup = false;
		var params = {};
		params.billingDay = $scope.newBillingDate;
		params.serviceId = $scope.serviceId;
		var endpointBillingURL = baseURL+propertiesConfig.details.updateBillingCycle;
		commonFactoryForRestCall.getURL(endpointBillingURL).put(undefined,params, function(data,status,headers,config) {
			$scope.billingDay = $scope.newBillingDate;
			$scope.setBillingDay = false;
			$scope.loadingIcon = false;
			responseMessageService.showResponseMsg(propertiesConfig.details.billingDayMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		}, function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			$scope.loadingIcon = false;
		});
	};
	$scope.uploadFile=function(myFile){
		$scope.loadingIcon = true;
		var importEndpointURL = baseURL + propertiesConfig.details.uploadMetering;
		$scope.exportSuccessMsg="";
		$scope.seviceErrorMsg="";
		var file = myFile;
		fileUpload.uploadFileToUrl(file, importEndpointURL).success(function(data, status, headers, config) {
			$scope.importSuccessMsg=propertiesConfig.details.importSuccessMsg;
			$scope.loadingIcon = false;
			responseMessageService.showResponseMsg(propertiesConfig.details.importSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		}).error(function(data, status, headers, config)  {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
		$scope.loadingIcon = false;
	};
	$scope.updateStatus = function(){
		var service ={};
		var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		endPointServiceURL = baseURL+ endPointServiceURL;
		service.serviceId= $scope.serviceId;
		service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;
		if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
				commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				$scope.isPublished = !$scope.isPublished;
				responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			},function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}else if($scope.isEnablePublish===false && service.isPublished==='true'){
			responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.statusConfirmationPopup = false;
	};
	$scope.statusConfirmationPopup = false;
	$scope.showStatusConfirmationPopup = function(flag){
		$scope.statusConfirmationPopup = flag;
		$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	};
}]);;app.controller('billingInvoiceCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall', 'paginationService', '$state','responseMessageService','$timeout','$cookies','searchToggleService','commonFactoryForHttp',
	function($scope, propertiesConfig, commonFactoryForRestCall, paginationService, $state,responseMessageService,$timeout,$cookies,searchToggleService,commonFactoryForHttp) {
	$scope.loadingIcon = true;
	$scope.servicesDetails = '';
	$scope.serviceError = false;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	var baseURL = propertiesConfig.details.baseReportingURL;
	baseURL += propertiesConfig.details.cloudInvoice;
	$scope.currentPage = 0;
	paginationService.loadPageCounts($scope);
	$scope.resultsCount = 0;
	var paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		baseURL: baseURL,
		propertiesConfig: propertiesConfig
		
	});
	paginationService.getPageData($scope, paginationParams);
	$scope.prevPage = function () {
		paginationService.prevPage($scope, paginationParams);
	};
	$scope.nextPage = function () {
		if($scope.currentPage < $scope.noOfPages-1 ){
			paginationService.nextPage($scope, paginationParams);
		} else {
			return false;
		}
	};
	$scope.setPage = function () {
		paginationService.setPage($scope, paginationParams, this);
	};

	$scope.pageSizeChange = function () {
		$scope.currentPage = 0;
		paginationService.getPageData($scope, paginationParams);
	};

	$scope.viewInvoiceDetails = function (invoice) {
	/*	var roleBasedData = roleBasedFeatureService.getPermissions('Invoice');
		$scope.isRead = roleBasedData.isRead;
		$scope.isWrite = roleBasedData.isWrite;*/
		$cookies.put('cloudInvoiceId',invoice.cloudInvoiceId);
		$state.go('manager.invoiceDetails');
	};
	$scope.searchToggle = function(){
		searchToggleService.toggleSearch();
	};
	$scope.populateInvoiceNoList = function(invoiceNoSelect){
        var listOfInvoiceNoEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.invoiceSearch;
        var invoiceSearchParams = angular.extend({
               invoiceNumber: invoiceNoSelect
        });
        commonFactoryForHttp.getURL('GET',listOfInvoiceNoEndPointURL,invoiceSearchParams).success(function(data, status, headers, config) {
               $scope.listofInvoiceNo =data;
        }).error( function(data, status, headers, config) {
               $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });

 };
 
	 $scope.populateCompanyNameList = function(companyNameSelect){
	     var listOfCompanyNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.invoiceSearch;
	     var invoiceSearchParams = angular.extend({
	            resellerCompanyName: companyNameSelect
	     });
	
	     commonFactoryForHttp.getURL('GET',listOfCompanyNameEndPointURL,invoiceSearchParams).success(function(data, status, headers, config) {
	            $scope.listofCompanyName =data;
	     }).error( function(data, status, headers, config) {
	            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	
	     });
	
	};

	$scope.populateStatusList = function(statusSelect){
	    var listOfStatusEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.invoiceSearch;
	    var invoiceSearchParams = angular.extend({
	           invoiceStatus: statusSelect
	    });
	    commonFactoryForHttp.getURL('GET',listOfStatusEndPointURL,invoiceSearchParams).success(function(data, status, headers, config) {
	           $scope.listofStatus =data;
	    }).error( function(data, status, headers, config) {
	           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	    });
	
	};

	$scope.searchReset = function(){
		$scope.companyNameSelect='';
		$scope.cloudResellerId='';
		$scope.emailSelect='';
	};

	$scope.searchRecords = function (){
		$scope.currentPage = 0;
		paginationService.loadPageCounts($scope);
		var paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
			baseURL : baseURL,
			propertiesConfig:propertiesConfig,
		});
		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
	};

	$scope.paginationParamsWithSearch = function(){
		return angular.extend({
			resellerCompanyName: $scope.companyNameSelect,
			cloudInvoiceId : $scope.cloudInvoiceId,
			invoiceNumber:$scope.invoiceNoSelect
		});
	};
	
}]);
app.filter('isPaid', function() {
	return function(input) {
	  return input === true ? 'Paid' : 'Pending' ;
	};
});;app.controller('dashBoardCtrl', ['$scope', 'propertiesConfig','commonFactoryForRestCall','graphsService','factoryForRoleBasedFeature','roleFlagService',
	function($scope, propertiesConfig,commonFactoryForRestCall,graphsService,factoryForRoleBasedFeature,roleFlagService) {
    $scope.loadingIcon = true;
    $scope.totalCloudServices = 0;
    $scope.totalNoOfResellers = 0;
    $scope.lastMonthRevenue = 0;
    $scope.topResellersDetails = [];
    $scope.invoicesDetails = [];

    $scope.servicesActiveFlag = false;
    $scope.resellersCountFlag = false;
    $scope.lastMonthRevenueFlag = false;
    $scope.reportResellersFlag = false;
    $scope.reportServicesFlag = false;
    $scope.lastYearRevenueForGraphFlag = false;
    
    var roleBasedPermissions = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.roleBasedAll);
    roleFlagService.assignFlagToScope(roleBasedPermissions,$scope,propertiesConfig);

	$scope.lastMonthRevenueFlag = !$scope.reportRoleFlag;
    $scope.reportResellersFlag = !$scope.reportRoleFlag;
    $scope.reportServicesFlag = !$scope.reportRoleFlag;
    $scope.lastYearRevenueForGraphFlag = !$scope.reportRoleFlag;
    $scope.servicesActiveFlag = !$scope.servicesRoleFlag;
    $scope.resellersCountFlag = !$scope.resellersRoleFlag;
    
    $scope.loadingIcon = ($scope.reportRoleFlag && $scope.servicesRoleFlag && $scope.resellersRoleFlag);
    
    $scope.date = new Date();
    var lastMonth = $scope.date.getMonth()-1;
    $scope.date.setMonth(lastMonth);
    var baseURL = propertiesConfig.details.baseURL;
    var baseReportingURL = propertiesConfig.details.baseReportingURL;
    var endPointURL = propertiesConfig.details.servicesActiveCount;
    if($scope.servicesRoleFlag){
	    commonFactoryForRestCall.getURL(baseURL + endPointURL).get(undefined, undefined, function(data, status, headers, config) {
	        $scope.servicesActiveFlag = true;
	    	$scope.totalCloudServices = data.services;
	        $scope.stopLoading();
	    }, function(data, status, headers, config){
	        $scope.servicesActiveFlag = true;
	        $scope.stopLoading();
	    });
    }

    if($scope.resellersRoleFlag){
	    endPointURL = propertiesConfig.details.resellersCount;
	    commonFactoryForRestCall.getURL(baseURL + endPointURL).get(undefined, undefined, function(data, status, headers, config) {
	    	$scope.totalNoOfResellers = data.total;
	        $scope.resellersCountFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	        $scope.resellersCountFlag = true;
	        $scope.stopLoading();
	    });
    }

    if($scope.reportRoleFlag){
	    var params = {
	        monthNumber: $scope.date.getMonth() + 1,
	        year: $scope.date.getFullYear()
	    };
	    endPointURL = propertiesConfig.details.lastMonthRevenue;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
	        if(data.content != undefined)
	        for(var loop =0; loop<data.content.length;loop++){
	            if(null != data.content[loop].amount) {
	                $scope.lastMonthRevenue = data.content[loop].amount;
	            break;
	            }
	        }
	        $scope.lastMonthRevenueFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	        $scope.lastMonthRevenueFlag = true;
	        $scope.stopLoading();
	    });
	    params = {
	        monthNumber: $scope.date.getMonth() + 1,
	        year: $scope.date.getFullYear(),
	        page:0,
	        size:5
	    };
	    endPointURL = propertiesConfig.details.reportReseller;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
	        var topResellerData = [];
	        for(var index in data.content) {
	            topResellerData.push({"amount" : data.content[index].amount, "name" : data.content[index].name,"id":data.content[index].userId});
	        }
			$scope.nodataClassForTopReseller = topResellerData.length>0 ?"":"svg-noData";
	        var params = angular.extend({
	            labelType: "amount",
	            showLabels:true,
	            pieLabelsOutside: true,
	            labelThreshold :.05,
	            showLegend : true,
	            tooltips : true,
	            donut : true,
	            donutRatio: 0.35,
	            colorRange: d3.scale.category10().range(),
	            container: "topFiveResellerDataDiv",
	            data: topResellerData,
	            xAxisDataColumn:'name',
	            yAxisDataColumn:'amount',
	            noData: "No data available"
	        });
	        graphsService.drawPieWithDonutUsingNVD3(params);
	        $scope.reportResellersFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config){
	        $scope.reportResellersFlag = true;
	        $scope.stopLoading();
	    });
	
	    endPointURL = propertiesConfig.details.topServices;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
	        var topServicesData = [];
	        for(var index in data.content) {
	            topServicesData.push({"amount" : data.content[index].amount, "name" : data.content[index].serviceName,"id":data.content[index].userId});
	        }
			$scope.nodataClassForTopServices = topServicesData.length>0 ?"":"svg-noData";
	        var params = angular.extend({
	            labelType: "amount",
	            showLabels:true,
	            pieLabelsOutside: true,
	            labelThreshold :.05,
	            showLegend : true,
	            tooltips : true,
	            donut : true,
	            donutRatio: 0.35,
	            colorRange: d3.scale.category10().range(),
	            container: "topFiveServicesDataDiv",
	            data: topServicesData,
	            xAxisDataColumn:'name',
	            yAxisDataColumn:'amount',
	            noData: "No data available"
	        });
	        graphsService.drawPieWithDonutUsingNVD3(params);
	        $scope.reportServicesFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	        $scope.reportServicesFlag = true;
	        $scope.stopLoading();
	    });
	    endPointURL = propertiesConfig.details.last12MonthsRevenue;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(undefined, undefined, function(data, status, headers, config) {
	    	var lastMonthRevenueData=[];
	        for(var index in data.content) {
		    	 lastMonthRevenueData.push({"month": data.content[index].month.substring(0, 3), "amount" : data.content[index].amount ? data.content[index].amount : 0, monthNumber: data.content[index].monthNumber});
		     }
	        var params = angular.extend({
		    	 showLegend:true,
		    	 showYAxis:true,
		    	 showXAxis:true,
		    	 interactive:50,
		    	 container:"chart",
				 xAxisLabel:'Month',
				 yAxisLabel:'Amount',
				 xAxisTicks:12,
				 yAxisTicks:5,
				 xAxisLabelParamFromData: 'month',
		         data:lastMonthRevenueData,
				 dataToDisplay : $scope.dataToDisplay(lastMonthRevenueData),
	             noData: "No data available"
		        });
	        graphsService.drawLineUsingNVD3(params);
	        $scope.lastYearRevenueForGraphFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	    	$scope.lastYearRevenueForGraphFlag = true;
	        $scope.stopLoading();
	    });
	    $scope.dataToDisplay = function(data) {
			var dataToDisplayArray = [];
			for (var i = 0; i < data.length; i++) {
				dataToDisplayArray.push({x: data[i].monthNumber, y: data[i].amount});
			}
			return [{values: dataToDisplayArray,key: 'Last 12 Months Revenue',color: '#FF0066'}];
		};
	}
    $scope.stopLoading = function(){
    	 $scope.loadingIcon = !($scope.servicesActiveFlag && $scope.resellersCountFlag && $scope.lastMonthRevenueFlag && $scope.reportResellersFlag && $scope.reportServicesFlag && $scope.lastYearRevenueForGraphFlag);
    };
}]);;app.controller('discountCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$stateParams','$state','moduleActiveService','$timeout','responseMessageService','$cookies','factoryForRoleBasedFeature','searchToggleService',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$stateParams,$state,moduleActiveService,$timeout,responseMessageService,$cookies,factoryForRoleBasedFeature,searchToggleService) {
    $scope.serviceError=false;
    var baseURL = propertiesConfig.details.baseURL;
    $scope.serviceId = $cookies.get(propertiesConfig.details.id);
	$scope.discountPlanPopUp = false;
	$scope.currentPage = 0;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.resultsCount = 0;
	$scope.viewSheet= false;
	var endPointURL = propertiesConfig.details.discountPremium; 
	endPointURL = baseURL + endPointURL
	$scope.loadDiscountTable = function(){
		$scope.loadingIcon = true;
		 paginationService.loadPageCounts($scope);
		 paginationParams = angular.extend({
		   commonFactoryForRestCall: commonFactoryForRestCall,
	       baseURL: endPointURL,
	       propertiesConfig:propertiesConfig
	       
	    });
		paginationService.getPageData($scope,paginationParams);
		getModulesActive();
	};
	
	var getModulesActive = function(){
		 moduleActiveService.getModulesData($scope);
		 $scope.loadingIcon = false;
	};
	
	$scope.prevPage = function () {
		paginationService.prevPage($scope,paginationParams);
    };
    $scope.nextPage = function () {
   	 if($scope.currentPage < $scope.noOfPages-1 ){
   	 paginationService.nextPage($scope,paginationParams);
   	 }else{
   		 return false;
   	 }
    };
    $scope.setPage = function () {
    	paginationService.setPage($scope,paginationParams,this);
    };
    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
    	paginationService.getPageData($scope,paginationParams);   
    };
    
    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
   };
		
/*	  $scope.savedetails = function (updatedValues,discounts) {
		var discount ={};
		discount.premiumGroupDiscountConfigId = discounts.premiumGroupDiscountConfigId;
		discount.discountSheetName = discounts.discountSheetName;
 		if($scope.editFlag){
	 		commonFactoryForRestCall.getURL(endPointURL,apiKey.key).put(JSON.stringify(discount),function(data) {
	 			 //$state.transitionTo($state.$current, $stateParams, {'reload':true});
	 			$scope.loadDiscountTable();
	 		 },function(data,status,headers,config) {
	 			  $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; 
	 			 $scope.editFlag = false;
	 		});
 		}else if($scope.createFlag){
 			commonFactoryForRestCall.getURL(baseURL,apiKey.key).post(JSON.stringify(discount),function(data) {
 				$scope.loadDiscountTable();
	 		 },function(data,status,headers,config) {
	 			  $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; 
	 			 $scope.createFlag = false;
	 		});
 		}
    };*/
    
    $scope.updateStatus = function(){
		 var service ={};
		 var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		 endPointServiceURL =baseURL+ endPointServiceURL;
		 service.serviceId= $scope.serviceId;
		 service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;	
		 if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			 commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				 $scope.isPublished = !$scope.isPublished;
				 responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 },function(data,status,headers,config) {
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			  });
		 }else if($scope.isEnablePublish===false && service.isPublished==='true'){
			 responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		 }
		 $scope.statusConfirmationPopup = false;
	 };
   
	  $scope.updateArchiveStatus = function (premiumGroupDiscountConfigId,status) {
		 /* var discountSheet ={};
		  discountSheet.premiumGroupDiscountConfigId= premiumGroupDiscountConfigId;
		  discountSheet.status=status;*/
		  commonFactoryForRestCall.getURL(endPointURL).del({id:premiumGroupDiscountConfigId},undefined,function(data,status,headers,config) {
			   $scope.loadDiscountTable();
			   responseMessageService.showResponseMsg(propertiesConfig.details.discountMsg+propertiesConfig.details.deletedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  }, function(data,status,headers,config) {
			  if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			  });
	  };
  
	  $scope.showSchedulePopup = function(flag,premiumGroupDiscountConfigId){
	    	$scope.schedulePopUp = flag;
	    	$scope.premiumGroupDiscountConfigId = premiumGroupDiscountConfigId;
	 };
	  $scope.scheduleUpdate = function (premiumGroupDiscountConfigId,status,eventType,comments) {
		  var discountSheet ={};
		  discountSheet.id=premiumGroupDiscountConfigId;
		  discountSheet.eventName=eventType;
		  discountSheet.comments=comments;
		  var scheduleEndPointURL = baseURL+propertiesConfig.details.discountPremiumSchedule;
		  commonFactoryForRestCall.getURL(scheduleEndPointURL).put(discountSheet,undefined,function(data) {
			   $scope.loadDiscountTable();
			   $scope.schedulePopUp = false;
			   responseMessageService.showResponseMsg(propertiesConfig.details.scheduledSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  }, function(data,status,headers,config) { 
			  $scope.schedulePopUp = false;
			  if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}});
	 };

	  $scope.goEditPlanSheet = function(sheetName,planType,premiumGroupDiscountConfigId,flag,sheetStatus){
		  $scope.viewSheet= flag;	
		/*  $state.get("nephele.discountSheet").params.viewSheet = $scope.viewSheet;
		  $state.get("nephele.discountSheet").params.sheetName = sheetName;
		  $state.get("nephele.discountSheet").params.planType = planType;*/
		  $cookies.put('premiumGroupDiscountConfigId',premiumGroupDiscountConfigId);
		  $cookies.put('sheetStatus',sheetStatus);
		  $cookies.put('viewSheet',$scope.viewSheet);
		  $state.go("manager.discountSheet");
	  };
	 
	  $scope.showDiscountPlanPopUp = function(flag){
	  	$scope.discountPlanPopUp = flag;
	  };
  
  $scope.planTypeCreate = function (planType) {
	  var planTypeParams ={};
	  planTypeParams.discountPlanType=planType;
	  planTypeParams.serviceId = $scope.serviceId;
	  var discountCreateEndPointURL = baseURL+propertiesConfig.details.discountPremium;
	  commonFactoryForRestCall.getURL(discountCreateEndPointURL).post(undefined,planTypeParams,function(data,status,headers,config) {
		  $scope.discountPlanPopUp = false;
		  $scope.viewSheet= false;
		  $scope.loadDiscountTable();
		/*$state.get("nephele.discountSheet").params.sheetName = data.discountSheetName;
		  $state.get("nephele.discountSheet").params.planType = $scope.planType;
		  $state.get("nephele.discountSheet").params.premiumGroupDiscountConfigId = data.premiumGroupDiscountConfigId;*/
		  $cookies.put('premiumGroupDiscountConfigId',data.premiumGroupDiscountConfigId);
		  $cookies.put('viewSheet',$scope.viewSheet);
		  $cookies.put('sheetStatus',"DRAFT");
		  $state.go("manager.discountSheet");
	  }, function(data,status,headers,config) { 
		  $scope.discountPlanPopUp = false;
		  if(data.status === 400){
			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}else{
			 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		} });
  };
  
  
  // Discount Sheet
  $scope.loadDiscountSheetDetails = function(){
	  $scope.loadingIcon = true;
	  /*$scope.planType = $state.get('nephele.discountSheet').params.planType;
	  $scope.sheetName = $state.get('nephele.discountSheet').params.sheetName;
	  $scope.viewSheet = $state.get("nephele.discountSheet").params.viewSheet;
 	  $scope.sheetStatus = $state.get("nephele.discountSheet").params.sheetStatus;
	  $scope.premiumGroupDiscountConfigId = $state.get('nephele.discountSheet').params.premiumGroupDiscountConfigId;*/
	  var discountSheetEndPointURL = baseURL+propertiesConfig.details.discountPremium;
	  $scope.premiumGroupDiscountConfigId = $cookies.get('premiumGroupDiscountConfigId');
	  $scope.viewSheet = $cookies.get('viewSheet');
	  $scope.sheetStatus = $cookies.get('sheetStatus');
	  commonFactoryForRestCall.getURL(discountSheetEndPointURL).get({id:$scope.premiumGroupDiscountConfigId},undefined,function(data,status,headers,config) {
		  $scope.sheetName = data.discountSheetName;
		  $scope.planType = data.discountPlanType;
		  $scope.sheetName = data.discountSheetName;
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		 });
	  
	  
	  var endPointsPremiumURL = baseURL +propertiesConfig.details.premiumGroupsList;
		 commonFactoryForRestCall.getURL(endPointsPremiumURL).get(undefined,undefined,function(data,status,headers,config) {
			 $scope.premiumGroupList= data.content;
			 if($scope.premiumGroupList.length>0){
				 $scope.premiumGroupIdwithName =$scope.premiumGroupList[0].premiumGroupid+" "+$scope.premiumGroupList[0].name;
				 $scope.premiumGroupId = $scope.premiumGroupList[0].premiumGroupid;
				 $scope.premiumGroupName=$scope.premiumGroupList[0].name;
			 }
			 $scope.getDiscountSheetDetails();
			 getModulesActive();
			// $scope.loadingIcon = false;
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		 	$scope.loadingIcon = false;
		 });
	};
	
	$scope.selectedPremium = function(premiumGroupIdwithName){
		$scope.premiumGroupId = premiumGroupIdwithName.split(" ")[0];
		$scope.premiumGroupName = premiumGroupIdwithName.split(" ")[1];
		$scope.getDiscountSheetDetails();
	};
	$scope.getDiscountSheetDetails = function(){
		var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
		 commonFactoryForRestCall.getURL(endPointsheetURL).get({groupName:$scope.premiumGroupName,sheetId:$scope.premiumGroupDiscountConfigId},undefined,function(data,status,headers,config) {
			 $scope.discountDetails= data.content;
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; });
	};
		
  
	  $scope.saveDiscountSheetdetails = function (updatedValues,discounts) {
		  $scope.loadingIcon = true;
		  var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
		var discount ={};
		discount.premiumGroupDiscountConfigId= $scope.premiumGroupDiscountConfigId;
		discount.discountRuleId = discounts.discountRuleId;
		discount.startRange=updatedValues.startRange;
		discount.endRange=updatedValues.endRange;
		discount.discount=updatedValues.discount;
			discount.premiumGroupId = $scope.premiumGroupId;
			discount.serviceId = $scope.serviceId;
				if($scope.editFlag){
			 		commonFactoryForRestCall.getURL(endPointsheetURL).put(JSON.stringify(discount),function(data,status,headers,config) {
			 			$scope.getDiscountSheetDetails();
			 			 $scope.editFlag = false;
			 			 responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 			$scope.loadingIcon = false;
			 		 },function(data,status,headers,config) {
						$scope.getDiscountSheetDetails();
			 			if(data.status === 400){
							responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}else{
							 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}
			 			 $scope.editFlag = false;
			 			$scope.loadingIcon = false;
			 		});
				}else if($scope.createFlag){
					commonFactoryForRestCall.getURL(endPointsheetURL).post(JSON.stringify(discount),function(data,status,headers,config) {
		 			// $state.transitionTo($state.$current, $stateParams, {'reload':true});
						$scope.getDiscountSheetDetails();
						 $scope.createFlag = false;
						 responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
						 $scope.loadingIcon = false;
		 		 },function(data,status,headers,config) {
		 			$scope.getDiscountSheetDetails();
						$scope.getDiscountSheetDetails();
		 			if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					} else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
		 			 $scope.createFlag = false;
		 			$scope.loadingIcon = false;
		 		});
				}
	};
	  
	
	$scope.editFlag = false;
	$scope.createFlag = false;
	
	$scope.updateDiscount = function(showForm){
		  if(!$scope.editFlag && !$scope.createFlag){
			  $scope.editFlag = true;
			  showForm.$show();
		  }else{
			  alert("Please save already initiated discount");
		  }
	};
	
		$scope.addRule = function() {
			if($scope.premiumGroupId === null){
				alert("Please select valid Premium Group");
			}else{
			  if(!$scope.editFlag && !$scope.createFlag){
				  $scope.createFlag=true;
				  $scope.inserted = {
					      id:'',
					      activeFrom:'',
					      activeTo:'',
					      discount:'',
					      premiumGroupId:'',
					      serviceId:$scope.serviceId ,
					      premiumGroupDiscountConfigId:''
					    };
					    $scope.discountDetails.push($scope.inserted);
			  }else{
					alert("Please save already initiated groups");
			  }
			}
			};
		
		$scope.removeFlag= function(rowform,index){
			  if($scope.createFlag){
				  $scope.createFlag = false;
				  $scope.discountDetails.splice(index, 1);
			  }
			  $scope.editFlag= false;
			  rowform.$cancel();
		};
		
		$scope.removeDiscount = function (discountId,index) {
		if(discountId != null){
			  var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
			commonFactoryForRestCall.getURL(endPointsheetURL).del({id:discountId},function(data,status,headers,config) {
				$scope.loadDiscountSheetDetails();
				responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg + propertiesConfig.details.deletedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			}, function(data,status,headers,config) { 
				if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			} else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}});
		}else{
			  $scope.discountDetails.splice(index, 1);
			 // $state.transitionTo($state.$current, $stateParams, {'reload':true});
		}
		};

		
		$scope.setEditFlag = function(flag){
			if($scope.premiumGroupId === null){
				alert("Please select valid Premium Group");
			}else{
				$scope.showEditSheetName = flag;
			}
		};
		
		 $scope.saveSheetName = function (sheetName) {
			  var discountSheet ={};
			  discountSheet.premiumGroupDiscountConfigId=$scope.premiumGroupDiscountConfigId;
			  discountSheet.discountSheetName=sheetName;
		 	  commonFactoryForRestCall.getURL(endPointURL).put(undefined,discountSheet,function(data,status,headers,config) {
		 		  var queryParams = {};
		 		 queryParams.premiumGroupDiscountConfigId=$scope.premiumGroupDiscountConfigId
		 		 commonFactoryForRestCall.getURL(endPointURL).get(queryParams,undefined,function(data,status,headers,config) {
				 },function(data,status,headers,config) { });
				 $scope.showEditSheetName = false;
				 responseMessageService.showResponseMsg(propertiesConfig.details.sheetNameMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			  },function(data,status,headers,config) {
				  if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				   $scope.editFlag = false;
			  });
		  };
		 
		  $scope.statusConfirmationPopup = false;
			 $scope.showStatusConfirmationPopup = function(flag){
			    	$scope.statusConfirmationPopup = flag;
			    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
			    };
  
}]);;// Forgot Password Controller to send request with email
 app.controller('forgotPasswordCtrl',  ['$scope', 'commonFactoryForRestCall','propertiesConfig','$state','responseMessageService','$timeout',
	 function ($scope, commonFactoryForRestCall,propertiesConfig,$state,responseMessageService,$timeout) {
	 $scope.validateEmail = function(emailId){
		 var baseURL = propertiesConfig.details.baseURL;
		 var endPointURL = propertiesConfig.details.forgetPassword;
		 endPointURL =baseURL+ endPointURL;
			 var service = { email :emailId};
			 commonFactoryForRestCall.getURL(endPointURL).post(JSON.stringify(service),function(data,status,headers,config) {
				 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
				 $state.go(propertiesConfig.details.index);
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				 
			 });
	 };
	 $scope.cancel= function(){
		 $state.go(propertiesConfig.details.index);
	 };
	 
 }]);
 
 //Reset Password Controller 
 app.controller('resetPasswordCtrl',  ['$scope', 'commonFactoryForRestCall','propertiesConfig','resetPasswordKey','$state','responseMessageService','$timeout',
     function ($scope, commonFactoryForRestCall,propertiesConfig,resetPasswordKey,$state,responseMessageService,$timeout) {
	 $scope.resetPassword= function(newPasswrd,confirmPassword){
		 var baseURL = propertiesConfig.details.baseURL;
		 var endPointURL = propertiesConfig.details.resetPassword;
		 endPointURL =baseURL+ endPointURL;
			 var service = { resetPasswordToken :resetPasswordKey,newPassword:newPasswrd,confirmPassword:confirmPassword};
			 commonFactoryForRestCall.getURL(endPointURL).post(JSON.stringify(service),function(data,status) {
				 var responsestatus = status;
				 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
				 $state.go(propertiesConfig.details.index);
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			 });
	 };
	 $scope.cancel= function(){
		 $state.go(propertiesConfig.details.index);
	 };
	 
	 
 }]);;app.controller('headerWithLogOutCtrl', ['$scope','propertiesConfig','sessionExpireService',function($scope,propertiesConfig,sessionExpireService) {
	$scope.callLogOut = function(){
		sessionExpireService.callExpire(propertiesConfig.details.logoutMsg);
	}
}]);
;//This contrroler is for Inventory the details and change the statuses
app.controller('inventoryController', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','fileUpload','commonFactoryForHttp','moduleActiveService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,fileUpload,commonFactoryForHttp,moduleActiveService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature) {
	$scope.showSearchContent =true;
	var  baseURL = propertiesConfig.details.baseURL;
	var endPointURL = baseURL+propertiesConfig.details.productPlan;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.resultsCount = 0;
	$scope.currentPage = 0;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var path = null;
	$scope.status = null;
	$scope.showBlukPrice = false;
	$scope.masterCheckBox = false;
	$scope.inventoryCountActiveFlag = false;
	$scope.modulesActiveFlag = false;
	$scope.locationSearchActiveFlag = true;
	$scope.osSearchActiveFlag = true;
	$scope.configSearchActiveFlag = true;
	$scope.loadAdditionalDataActiveFlag = true;
	$scope.stopLoading = function(){
		$scope.loadingIcon = !($scope.inventoryCountActiveFlag && $scope.modulesActiveFlag  && $scope.loadAdditionalDataActiveFlag);
	};
	$scope.$on('stopLoadingEvent', function(e) {
		$scope.stopLoading();
	});
	$scope.loadInventoryDetails = function(status,statePath){
		$scope.loadingIcon = true;
		path = statePath ;
		$scope.status = status;
		$scope.serviceId = $cookies.get(propertiesConfig.details.id);
		var planCountEndpointURL=baseURL+propertiesConfig.details.planCount;
		
		getInventoryCount(planCountEndpointURL);
		$scope.discoverCount = 0;
		$scope.stageCount = 0;
		$scope.publishCount = 0;
		$scope.suspendCount = 0;
		$scope.archiveCount = 0;
		moduleActiveService.getModulesData($scope);
		paginationService.loadPageCounts($scope);
		var paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
			baseURL: endPointURL,
			propertiesConfig:propertiesConfig
			
		});
		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		$scope.prevPage = function () {
			$scope.masterCheckBox = false;
			$scope.selection = [];
			paginationService.prevPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		};
		$scope.nextPage = function () {
			$scope.masterCheckBox = false;
			$scope.selection = [];
			if($scope.currentPage < $scope.noOfPages-1 ){
				paginationService.nextPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
			}else{
				return false;
			}
		};
		$scope.setPage = function () {
			$scope.masterCheckBox = false;
			$scope.selection = [];
			paginationService.setPage($scope,paginationParams,this,undefined,$scope.paginationParamsWithSearch());
		};
		$scope.pageSizeChange = function () {
			$scope.currentPage = 0;
			$scope.masterCheckBox = false;
			$scope.selection = [];
			paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		};

		if(status === 'STAGED' || status === 'PUBLISHED'){
			$scope.loadAdditionalDataActiveFlag = false;
			loadAdditionalData(status);
		}
		
	};

		$scope.populateLocationList = function(locationSelect){
			var listOfLocationEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.locationSearch;
			var serviceSearchParams = angular.extend({
				locationName: locationSelect
			});
			commonFactoryForHttp.getURL('GET',listOfLocationEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
				$scope.listofLocations =data;
			}).error( function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			});
		};
		$scope.populateOperatingSystemList = function(operatingSystemSelect){
			var listOfOsEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.osSearch;
			var serviceSearchParams = angular.extend({
				name: operatingSystemSelect
			});
			commonFactoryForHttp.getURL('GET',listOfOsEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
				$scope.listofOperatingSystems =data;
			}).error( function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			});
		};
		$scope.populateConfigurationList = function(configurationSelect){
			var listOfConfigurationEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.cofigurationSearch;
			var serviceSearchParams = angular.extend({
				flavorClass:configurationSelect
			});
			commonFactoryForHttp.getURL('GET',listOfConfigurationEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
				$scope.listofConfigurations =data;
			}).error( function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			});
		};

		$scope.locationsChange = function (locationSelect) {
			if(locationSelect == null){
				$scope.locationName = propertiesConfig.details.chooseLocation;
				$scope.locationId = '';
			}else {
				$scope.locationId = locationSelect.split(",")[0];
				$scope.locationName = locationSelect.split(",")[1];
				$scope.locationSelect =  locationSelect.split(",")[1];
			}
		};
		
		$scope.operatingSystemChange = function (operatingSystemSelect) {
			if(operatingSystemSelect == null){
				$scope.operatingSystemName = propertiesConfig.details.chooseOperatingSystem;
				$scope.operatingSystemId = '';
			}else {
				$scope.operatingSystemId = operatingSystemSelect.split(",")[0];
				$scope.operatingSystemName = operatingSystemSelect.split(",")[1];
				$scope.operatingSystemSelect = operatingSystemSelect.split(",")[1];
			}
		};
		 $scope.clearlocationData = function(){
			 $scope.locationId ='';
		 };
		 $scope.clearOsData = function(){
			 $scope.operatingSystemId ='';
		 };
		 $scope.clearConfigurationData = function(){
			 $scope.rackSpaceConfigurationId ='';
		 };

		
		$scope.rackSpaceConfigurationChange = function (configurationSelect) {
			if(configurationSelect == null){
				$scope.rackSpaceConfigurationName = propertiesConfig.details.chooseConfiguration;
				$scope.rackSpaceConfigurationId = null;
			}else {
				$scope.flavourCategory = configurationSelect.split(",")[1];
				$scope.configurationSelect = configurationSelect.split(",")[1];
			}
		};
	
		/*commonFactoryForRestCall.getURL(baseURL + listOfLocationEndPointURL).get(planParams, undefined, function(data, status, headers, config) {
		$scope.listOfLocations = data.planLocations;
		$scope.locationSearchActiveFlag = true;
		$scope.stopLoading();
	}, function(data, status, headers, config) {
		$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		$scope.locationSearchActiveFlag = true;
		$scope.stopLoading();
	});
*/
		/*$scope.operatingSystemName = propertiesConfig.details.chooseOperatingSystem;
		$scope.operatingSystemId = '';
		var listOfOperatingSystemEndPointURL = propertiesConfig.details.listOfOperatingSystems;
		var planParams = angular.extend({
			status: $scope.status,
			serviceId:$scope.serviceId
		});
		commonFactoryForRestCall.getURL(baseURL + listOfOperatingSystemEndPointURL).get(planParams, undefined, function(data, status, headers, config) {
			var operatingSystems = [];
			$scope.listofOperatingSystems =data.planOperatingSystems;
			$scope.osSearchActiveFlag = true;
			$scope.stopLoading();
		}, function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			$scope.osSearchActiveFlag = true;
			$scope.stopLoading();
		});
		*/
		/*$scope.rackSpaceConfigurationName = propertiesConfig.details.chooseConfiguration;
		$scope.rackSpaceConfigurationId = '';
		var rackSpaceConfigurationEndPointURL =  propertiesConfig.details.rackSpaceConfiguration;
		commonFactoryForRestCall.getURL(baseURL + rackSpaceConfigurationEndPointURL)
			.get(planParams, undefined, function(data, status, headers, config) {
				$scope.listofrackSpaceConfiguration = data.planCategories;
				$scope.configSearchActiveFlag = true;
				$scope.stopLoading();
			}, function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				$scope.configSearchActiveFlag = true;
				$scope.stopLoading();
			});*/


	

	$scope.searchReset = function(){
		$scope.rackSpaceConfigurationName = propertiesConfig.details.chooseConfiguration;
		$scope.rackSpaceConfigurationId = null;
		$scope.locationName = propertiesConfig.details.chooseLocation;
		$scope.locationId = '';
		$scope.operatingSystemName = propertiesConfig.details.chooseOperatingSystem;
		$scope.operatingSystemId = '';
	};

	$scope.searchRecords = function (){
		$scope.currentPage = 0;
		paginationService.loadPageCounts($scope);
		var paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
			baseURL: endPointURL,
			propertiesConfig:propertiesConfig
			/*apiKey: apiKey.key*/
		});
		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
	};

	$scope.inventorySync= function (){
		$scope.loadingIcon = true;
		var endpointURL = baseURL+propertiesConfig.details.inventorySync;
		commonFactoryForRestCall.getURL(endpointURL).get(undefined,undefined, function(data,status,headers,config) {
			$scope.loadingIcon = false;
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
	    });
	};
	var loadAdditionalData = function(status){
		var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
		var additionalParams = angular.extend({
			serviceId:$scope.serviceId,
			status:status
		});
		commonFactoryForRestCall.getURL(endPointAdditionalURL).get(additionalParams,undefined,function(data,status,headers,config) {
			$scope.additionalDetails = data.content;
			$scope.loadAdditionalDataActiveFlag = true;
			$scope.stopLoading();
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadAdditionalDataActiveFlag = true;
			$scope.stopLoading();
		});
	};

	//Get Inventory Count
	var getInventoryCount = function(endPointURL){
		commonFactoryForRestCall.getURL(endPointURL).get({serviceId:$scope.serviceId},function(data,status,headers,config) {
				$scope.discoverCount += data.summary.DISCOVERED;
				$scope.stageCount += data.summary.STAGED;
				$scope.publishCount += data.summary.PUBLISHED ;
				$scope.suspendCount += data.summary.WITHDRAWN ;
				$scope.archiveCount += data.summary.ARCHIVED ;
				$scope.inventoryCountActiveFlag = true;
				$scope.stopLoading();
			}, function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.inventoryCountActiveFlag = true;
				$scope.stopLoading();}
		);
	};

	//Change Status
	$scope.selection = [];
	$scope.plansToggleSelection = function(planId,masterCheckboxCheck) {
		var idx = $scope.selection.indexOf(planId);
		if (idx > -1) {
			$scope.selection.splice(idx, 1);
		}else {
			if(masterCheckboxCheck == undefined || masterCheckboxCheck)
				$scope.selection.push(planId);
		}
	};
	$scope.plansChangeStatus = function(changeStatus){
		var plans = [];
		var planChanges = $scope.selection;
		for(var i=0;i<planChanges.length;i++){
			var plan = {};
			plan.status = changeStatus;
			plan.planId = planChanges[i];
			plans.push(plan);
		}
		var statusUpdated =changeStatus;
		if(changeStatus==="DISCOVERED" && $scope.status === "STAGED" ){
			var statusUpdated = "UNSTAGED";
		}
		var paramsData = {"productPlans":plans};
		commonFactoryForRestCall.getURL(endPointURL).put(paramsData,function(data, status, headers, config) {
			$scope.loadInventoryDetails($scope.status,path);
			responseMessageService.showResponseMsg(propertiesConfig.details.plansMsg+statusUpdated+propertiesConfig.details.successfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		},function(data, status, headers, config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
		});
		$scope.masterCheckBox = false;
		$scope.selection = [];

	};

	$scope.plansAdditionalChange = function(status,additionalData){
		if(additionalData.price !== '0.0'){
			var plan = {};
			plan.status = status;
			plan.additionalPriceId = additionalData.additionalPriceId;
			plan.price = additionalData.price ;
			var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
			commonFactoryForRestCall.getURL(endPointAdditionalURL).put(undefined,plan,function(data, status, headers, config) {
				loadAdditionalData('STAGED');
				responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			},function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}else{
			alert("Please update valid Price");
		}
	};

	$scope.savedetails = function (updatedValues,inventoryData) {
		var inventorylist=[];
		var inventory ={};
		inventory.planId= inventoryData.planId;
		inventory.price=updatedValues.price;
		inventorylist.push(inventory);
		var paramsData = {"productPlans":inventorylist};
		commonFactoryForRestCall.getURL(endPointURL).put(undefined,paramsData,function(data,status,headers,config) {
			$scope.loadInventoryDetails("STAGED","manager.staged");
			responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		},function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.editFlag = false;
		});
	};

	//Export and Import excel files
	var exportEndpointURL = baseURL + propertiesConfig.details.exportExcel;
	$scope.exportExcel=function(){
		$scope.loadingIcon = true;
		$scope.importSuccessMsg="";
		$scope.seviceErrorMsg="";
		commonFactoryForHttp.getURL('GET',exportEndpointURL).success(function(data, status, headers, config) {
			$scope.loadingIcon = false;
			var a = document.createElement('a');
			a.href = 'data:attachment/csv;charset=utf-8,' + encodeURI(data);
			a.target = '_blank';
			a.download = 'RackspacePriceSheet.csv';
			document.body.appendChild(a);
			$scope.exportSuccessMsg=propertiesConfig.details.exportSuccessMsg;
			a.click();
			responseMessageService.showResponseMsg(propertiesConfig.details.downloadSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		}).
			error(function(data, status, headers, config) {
				$scope.loadingIcon = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
	};

	var importEndpointURL = baseURL + propertiesConfig.details.importExcel;
	$scope.uploadfile=function(myFile){
		$scope.exportSuccessMsg="";
		$scope.seviceErrorMsg="";
		$scope.loadingIcon = true;
		var file = myFile;
		fileUpload.uploadFileToUrl(file, importEndpointURL).success(function(data, status, headers, config) {
			$scope.loadInventoryDetails("STAGED","manager.staged");
			$scope.showBulkPrice(false);
			responseMessageService.showResponseMsg(propertiesConfig.details.importSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			$scope.loadingIcon = false;
		}).error(function(data, status, headers, config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
		$scope.loadingIcon = false;
	};

	
	$scope.showBulkPrice = function(flag){
		$scope.showBlukPrice = flag;
	};
	$scope.selectAll = function(pageData){
		if($scope.masterCheckBox){
			$scope.selection = [];
		}
		for(var loop=0;loop<pageData.length;loop++){
			$scope.plansToggleSelection(pageData[loop].planId,$scope.masterCheckBox);
		}
	};

	$scope.updateStatus = function(){
		var service ={};
		var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		endPointServiceURL =baseURL+ endPointServiceURL;
		service.serviceId= $scope.serviceId;
		service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;
		if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				$scope.isPublished = !$scope.isPublished;
				responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			},function(data, status, headers, config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}else if($scope.isEnablePublish===false && service.isPublished==='true'){
			responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.statusConfirmationPopup = false;
	};

	$scope.paginationParamsWithSearch = function(){
		return angular.extend({
			status: $scope.status,
			serviceId:$scope.serviceId,
			operatingSystemId: $scope.operatingSystemId,
			flavorCategory :$scope.configurationSelect,
			locationId : $scope.locationId
		});
	};
	$scope.statusConfirmationPopup = false;
	 $scope.showStatusConfirmationPopup = function(flag){
	    	$scope.statusConfirmationPopup = flag;
	    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	    };
}]);;app.controller('InventoryPriceSheetCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','paginationService','moduleActiveService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature','searchToggleService',
	function($scope,propertiesConfig,commonFactoryForRestCall,$state,paginationService,moduleActiveService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature,searchToggleService) {
	 $scope.serviceId = $cookies.get(propertiesConfig.details.id);
	 var baseURL = propertiesConfig.details.baseURL;
	 var endPointURL = baseURL+propertiesConfig.details.priceManagement;
	 $scope.resultsfound = propertiesConfig.details.resultsFound;
	 $scope.resultsCount = 0;
	 $scope.currentPage = 0;
	 $scope.viewSheet= false;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	 $scope.isInnerPriceCtrl = $cookies.get('isInnerPriceCtrl');
	 var viewFlag=$cookies.get('viewPriceSheet');
	 var sheetName=$cookies.get('priceSheetName');
	 $scope.loadPriceSheetDetails = function(){
		 $scope.loadingIcon = true;
		 moduleActiveService.getModulesData($scope);
			paginationService.loadPageCounts($scope);
			 var paginationParams = angular.extend({
				commonFactoryForRestCall: commonFactoryForRestCall,
		       baseURL: endPointURL,
		       propertiesConfig:propertiesConfig
		      /* apiKey: apiKey.key*/
		    });
			paginationService.getPageData($scope,paginationParams);
			
			$scope.prevPage = function () {
				paginationService.prevPage($scope,paginationParams);
		    };
		    $scope.nextPage = function () {
		   	 if($scope.currentPage < $scope.noOfPages-1 ){
		   	 paginationService.nextPage($scope,paginationParams);
		   	 }else{
		   		 return false;
		   	 }
		    };
		    $scope.setPage = function () {
		    	paginationService.setPage($scope,paginationParams,this);
		    };
		    $scope.pageSizeChange = function () {
		    	$scope.currentPage = 0;
		    	paginationService.getPageData($scope,paginationParams);   
		    };
	 };
	
	  $scope.updateArchiveStatus = function (productPriceMgmtConfigId,status) {
			 /* var priceSheet ={};
			  priceSheet.productPriceMgmtConfigId= productPriceMgmtConfigId;
			  priceSheet.status=status;*/
			  commonFactoryForRestCall.getURL(endPointURL).del({id:productPriceMgmtConfigId},undefined,function(data,status,headers,config) {
				   $scope.loadPriceSheetDetails();
				   responseMessageService.showResponseMsg(propertiesConfig.details.deletedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			  }, function(data,status,headers,config) {
				  	if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			});
	  };
	  
	  $scope.scheduleUpdate = function (productPriceMgmtConfigId,status,eventType,comments) {
		  var priceSheet ={};
		  priceSheet.id=productPriceMgmtConfigId;
		  //priceSheet.status=status;
		  priceSheet.eventName=eventType;
		  priceSheet.comments=comments;
		  var scheduleEndPointURL = baseURL+propertiesConfig.details.priceManagementSchedule;
		  commonFactoryForRestCall.getURL(scheduleEndPointURL).put(priceSheet,undefined,function(data,status,headers,config) {
			   $scope.loadPriceSheetDetails();
			   $scope.showSchedulePopup(false);
			   responseMessageService.showResponseMsg(propertiesConfig.details.scheduledSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  }, function(data,status,headers,config) {
			  $scope.showSchedulePopup(false);
			   if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			  });
 		 };
  
	 $scope.showPriceSheetPopUp = function(flag){
	    	$scope.priceSheetPopUp = flag;
	    	$scope.viewSheet= false;	    	
	    	 $scope.$broadcast ('createEvent');
	 };
	 
	 $scope.showSchedulePopup = function(flag,productPriceMgmtConfigId){
	    	$scope.schedulePopUp = flag;
	    	$scope.productPriceMgmtConfigId = productPriceMgmtConfigId;
	 };
	 $scope.showViewPriceSheetPopUp= function(priceSheetName,flag,id){
		 $scope.sheetName = priceSheetName;
		 $scope.priceSheetPopUp = true;
		 $scope.viewSheet= flag;	
		 $scope.productPriceMgmtConfigId = id;
		 $scope.$broadcast ('getPlanDetailsEvent');
	 };
	 $scope.updateStatus = function(){
		 var service ={};
		 var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		 endPointServiceURL =baseURL+ endPointServiceURL;
		 service.serviceId= $scope.serviceId;
		 service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;	
		 if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			 commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				 $scope.isPublished = !$scope.isPublished;
				 responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 },function(data,status,headers,config) {
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			  });
		 }else if($scope.isEnablePublish===false && service.isPublished==='true'){
			 responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		 }
		 $scope.statusConfirmationPopup = false;
	 };
	 $scope.statusConfirmationPopup = false;
	 $scope.showStatusConfirmationPopup = function(flag){
	    	$scope.statusConfirmationPopup = flag;
	    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	    };
	    $scope.searchToggle = function(){
	    	searchToggleService.toggleSearch();
		};	
	   
}]);

app.controller('innerPriceSheetCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','paginationService','commonFactoryForHttp','fileUpload','responseMessageService','$timeout','$cookies',
    function($scope,propertiesConfig,commonFactoryForRestCall,$state,paginationService,commonFactoryForHttp,fileUpload,responseMessageService,$timeout,$cookies ) {
	 var baseURL = propertiesConfig.details.baseURL;
	 var priceSheetEndPointURL = baseURL+propertiesConfig.details.priceSheetData;
	 var endPointURL = baseURL+propertiesConfig.details.priceManagement;
	 $scope.showEditSheetName=false;
	 $scope.isInnerPriceCtrl = true;
	 
	 $scope.$on('createEvent', function(e) {  
		 $scope.loadPricePopupDetails();
	 });
	 $scope.$on('getPlanDetailsEvent', function(e) {
		 $scope.loadSheetDetails($scope.$parent.sheetName);
	 });
	 $scope.loadPricePopupDetails = function(){
		 $scope.$parent.loadingIcon = true;
	    	var priceSheetEndPointURL = baseURL+propertiesConfig.details.priceManagement;
	    	var paramsData = angular.extend({		 		
				serviceId:$scope.serviceId
	    	});
	    	commonFactoryForRestCall.getURL(priceSheetEndPointURL).post(undefined,paramsData,function(data, status, headers, config) {
					$scope.osSuccessMsg = propertiesConfig.details.updateSuccessMessage;
					$scope.productPriceMgmtConfigId = data.productPriceMgmtConfigId;
					$scope.sheetName = data.priceSheetName;
					$scope.loadSheetDetails($scope.sheetName);
					$scope.$parent.loadPriceSheetDetails();
					responseMessageService.showResponseMsg(propertiesConfig.details.priceSheetMsg+propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
					$scope.$parent.loadingIcon = false;
				},function(data,status,headers,config) {
					$scope.$parent.loadingIcon = false;
					$scope.showPriceSheetPopUp(false);
					 if(data.status === 400){
						 responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope.$parent, $timeout);
						}else{
							responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope.$parent, $timeout);
						}
				});
		 };
	 
	 $scope.showPriceSheetPopUp = function(flag){
		 $scope.$parent.priceSheetPopUp = flag;
	 };
	
	 $scope.loadSheetDetails = function(sheetName){
		 $scope.$parent.loadingIcon = true;
		 $scope.sheetName =sheetName;
		 $cookies.put('priceSheetName',$scope.sheetName);
		 var params = angular.extend({
			 	sheetName: sheetName,
				serviceId:$scope.serviceId
			});
			paginationService.loadPageCounts($scope);
			 
			 paginationParams = angular.extend({
				commonFactoryForRestCall: commonFactoryForRestCall,
		       baseURL: priceSheetEndPointURL,
		       propertiesConfig:propertiesConfig
		    });
			 
			paginationService.getPageData($scope,paginationParams,undefined,params);
			
			$scope.prevPage = function () {
				//params.page = this.currentPage-1;
				paginationService.prevPage($scope,paginationParams,undefined,params);
		    };
		    $scope.nextPage = function () {
		    	paginationParams.baseURL = priceSheetEndPointURL;
		   	 if($scope.currentPage < $scope.noOfPages-1 ){
		   		//params.page = this.currentPage+1;
		   		 paginationService.nextPage($scope,paginationParams,undefined,params);
		   	 }else{
		   		 return false;
		   	 }
		    };
		    $scope.setPage = function () {
		    	paginationParams.baseURL = priceSheetEndPointURL;
		    	//params.page = this.pageRange;
		    	paginationService.setPage($scope,paginationParams,this,undefined,params);
		    };
		    $scope.pageSizeChange = function () {
		    	$scope.currentPage = 0;
		    	//params.page = this.currentPage;
		    	//params.size= this.noOfitems;
		    	paginationParams.baseURL = priceSheetEndPointURL;
		    	paginationService.getPageData($scope,paginationParams,undefined,params);   
		    };
		    loadAdditionalData('PUBLISHED');
		    $scope.$parent.loadingIcon = false;
	 };
	 
	 var loadAdditionalData = function(status){
			var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
			var additionalParams = angular.extend({				
				serviceId:$scope.serviceId,
				status:status
			});
			commonFactoryForRestCall.getURL(endPointAdditionalURL).get(additionalParams,undefined,function(data,status,headers,config) {
				$scope.additionalDetails = data.content;
			}, function(data,status,headers,config) {
				$scope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;
			
			});
	};
	 
	 $scope.savePriceSheetDetails = function ($data, priceSheetData) {
		 $scope.loadingIcon = true;
		 var priceSheetPutEndPointURL = baseURL+propertiesConfig.details.priceSheetPut;
		 params = {productPriceManagementSheetId:priceSheetData.productPriceManagementSheetId, price:$data.price};
	 	  commonFactoryForRestCall.getURL(priceSheetPutEndPointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
			 $scope.loadSheetDetails($scope.sheetName);
			 responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 $scope.loadingIcon = false;
		  },function(data,status,headers,config) {
			  $scope.loadingIcon = false;
			  if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			   $scope.editFlag = false;
		  });
	  };
	  
	  $scope.saveSheetName = function (sheetName,productPriceMgmtConfigId) {
		  var priceSheet ={};
		  priceSheet.productPriceMgmtConfigId=productPriceMgmtConfigId;
		  priceSheet.priceSheetName=sheetName;
	 	  commonFactoryForRestCall.getURL(endPointURL).put(undefined,priceSheet,function(data,status,headers,config) {
			 $scope.$parent.loadPriceSheetDetails();
			 $scope.showEditSheetName = false;
			 responseMessageService.showResponseMsg(propertiesConfig.details.sheetNameMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  },function(data,status,headers,config) {
			  if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			   $scope.editFlag = false;
		  });
	  };
	 
	 $scope.showBulkPriceSheetPopUp = function(flag){
	    $scope.bulkPriceSheetPopUp = flag;
	 };
	
		//Export and Import excel files
		var exportEndpointURL = baseURL + propertiesConfig.details.exportPriceExcel;
		$scope.exportExcel=function(){
			$scope.loadingIcon = true;
			$scope.importSuccessMsg="";
			$scope.seviceErrorMsg="";
			sheetDetails={};
			sheetDetails.serviceId = $scope.serviceId ;
			sheetDetails.sheetName = $scope.sheetName;
			commonFactoryForHttp.getURL('GET',exportEndpointURL,sheetDetails).success(function(data, status, headers, config) {
			var a = document.createElement('a');
				a.href = 'data:attachment/csv;charset=utf-8,' + encodeURI(data);
				a.target = '_blank';
				a.download = 'RackspacePriceSheet.csv';
				document.body.appendChild(a);
				$scope.exportSuccessMsg=propertiesConfig.details.exportSuccessMsg;
				a.click();
				$scope.loadingIcon = false;
				responseMessageService.showResponseMsg(propertiesConfig.details.downloadSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			}).
			error(function(data, status, headers, config) {
				$scope.loadingIcon = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		};

		var importEndpointURL = baseURL + propertiesConfig.details.importPriceExcel;
		$scope.uploadfile=function(){
			$scope.loadingIcon = true;
			$scope.exportSuccessMsg="";
			$scope.seviceErrorMsg="";
			var file = $scope.myFile;
			fileUpload.uploadFileToUrl(file, importEndpointURL).success(function(data, status, headers, config) {	
				$scope.bulkPriceSheetPopUp = false;
				$scope.loadPriceSheetDetails();
				$scope.loadSheetDetails($scope.sheetName);
				  $scope.importSuccessMsg=propertiesConfig.details.importSuccessMsg;
				  $scope.loadingIcon = false;
				  responseMessageService.showResponseMsg(propertiesConfig.details.importSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			}).error(function(data, status, headers, config) {
				$scope.bulkPriceSheetPopUp = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
				});
		};
		
		$scope.saveAdditionalPrice = function(additionalPrice,additionalData){
				if(additionalPrice !== '0.0'){
					var plan = {};
					plan.additionalPriceId = additionalData.additionalPriceId;
					plan.price = additionalPrice ;
					var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
					$scope.showEditAdditionalPrice = false;
					commonFactoryForRestCall.getURL(endPointAdditionalURL).put(undefined,plan,function(data, status, headers, config) {
						 loadAdditionalData('PUBLISHED');
						 responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
					},function(data,status,headers,config) {
						if(data.status === 400){
							responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}else{
							responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}
					});
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.validPriceMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			};
			
			$scope.setEditFlag = function(flag){
				$scope.showEditSheetName = flag;
			};
			$scope.showUpdateAdditionalPrice = function(flag){
				$scope.showEditAdditionalPrice = flag;
				if(flag){
					$scope.additionalDetails.$original = angular.copy($scope.additionalDetails);
				}
			};
			$scope.cancelAdditionalPrice= function(additionalDetails){
				angular.copy($scope.additionalDetails.$original, additionalDetails);
				$scope.showUpdateAdditionalPrice(false);
				
			};
			$scope.showUpdatePrice = function(flag){
				$scope.showEditPrice = flag;
			};
}]);;app.controller('invoiceDetailsCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall', 'paginationService', '$state', 'responseMessageService', '$timeout','$cookies','reportGeneratorPdf','factoryForRoleBasedFeature',
	function($scope, propertiesConfig, commonFactoryForRestCall, paginationService, $state, responseMessageService, $timeout,$cookies,reportGeneratorPdf,factoryForRoleBasedFeature) {
	$scope.master = {};
	$scope.invoiceId = $cookies.get('cloudInvoiceId');
	$scope.instrumentTypes = propertiesConfig.details.instrumentType;
	var baseURL = propertiesConfig.details.baseReportingURL;
	$scope.invoice = null;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.invoicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var endPointURL = propertiesConfig.details.cloudInvoiceDetails;
	$scope.loadPage = function (endPointURL) {
		$scope.loadingIcon = true;
		commonFactoryForRestCall.getURL(baseURL + endPointURL)
			.get({id:$scope.invoiceId}, undefined,function(data, status, headers, config) {
				$scope.invoice = data;
				$scope.billingStatus =($scope.invoice.status ==='PAID');
				$scope.loadingIcon = false;
			}, function(data, status, headers, config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
			}
		);
	};

	if($scope.instrumentTypes && $scope.instrumentTypes.length > 0) {
		$scope.instrumentType = $scope.instrumentTypes[0];
		$scope.instrument = $scope.instrumentTypes[0];
	}
	$scope.loadPage(endPointURL);

	$scope.downloadPDF = function(invoiceId) {
		if(invoiceId == undefined){
			$cookies.remove(propertiesConfig.details.apiKey);
			$state.go(propertiesConfig.details.index);
		}
		$scope.loadingIcon = true;
		var baseURL = propertiesConfig.details.baseReportingURL;
		var endPointURL = propertiesConfig.details.cloudInvoicePDFDownload;
		var exportEndpointURL = baseURL+endPointURL+"/"+invoiceId;
		var fileName = invoiceId + ".pdf";
		var a = document.createElement("a");
		document.body.appendChild(a);
		a.style = "display: none";
		reportGeneratorPdf.downloadPdfFile(exportEndpointURL,$scope).then(function (result) {
			var file = new Blob([result.data], {type: 'application/pdf'});
			var fileURL = window.URL.createObjectURL(file);
			a.href = fileURL;
			a.download = fileName;
			a.click();
			$scope.loadingIcon = false;
		});
	};
	$scope.instrumentTypeChange = function(type) {
		$scope.instrument = type;
		$scope.instrumentType = type;
	};
	$scope.invoicePay = function(paymentDetails) {
		$scope.loadingIcon = true;
		var endPointURL = propertiesConfig.details.cloudBillPay;
		commonFactoryForRestCall.getURL(baseURL + endPointURL)
			.post(undefined, paymentDetails,
			function(data, status, headers, config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.paymentMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadPage(propertiesConfig.details.cloudInvoiceDetails);
				$scope.loadingIcon = false;
			}
			, function(data, status, headers, config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				} else {
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
			}
		);
	}

}]);;app.controller('loginController',['$scope','propertiesConfig','commonFactoryForRestCall','$state','$cookies','$document','removeCookiesService' ,
	function($scope,propertiesConfig,commonFactoryForRestCall,$state,$cookies,$document,removeCookiesService) {
	$scope.loadingIcon = false;
	 $scope.message = $state.get(propertiesConfig.details.index).params.message;
	$scope.footerMessage =propertiesConfig.details.footerMessage;
	 $scope.username;
	 $scope.password;
	$scope.authenticate=function(){
		$scope.message = null;
		$scope.seviceErrorMsg= null;
		var baseURL = propertiesConfig.details.baseURL;
		var params = angular.extend({
			email: $scope.username,
			password:$scope.password
		});
		var endpointURL = baseURL + propertiesConfig.details.login;
		var apiHeaders = {
			'Accept': 'application/json'
		};
		$scope.loadingIcon = true;
		removeCookiesService.removeAllCookies();
		commonFactoryForRestCall.getURL(endpointURL,apiHeaders).post(params,function(data,status,headers,config) {
			//apiKey.key=data.apiKey;
			$cookies.put(propertiesConfig.details.apiKey,data.apiKey);
			$cookies.put(propertiesConfig.details.firstName,data.firstName);
			$cookies.put(propertiesConfig.details.distributorId,data.distributorId);
			$cookies.put(propertiesConfig.details.userRoleId,data.userRoleId);
			$cookies.putObject(propertiesConfig.details.roleBasedPermissions,data.permissions);
			$document[0].title = propertiesConfig.details.title;
			$state.go(propertiesConfig.details.manager);
		}, function(data,status,headers,config) {
			if(data.status === 401 ||data.status === 400){
				$scope.seviceErrorMsg = data.data.errorMessages[0];
			}else{
				$scope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;;
			}
			$scope.loadingIcon = false;
		});
	};
}]);;//This controller is to view the data of roles
app.controller('manageRoleCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall', 'paginationService', '$timeout','$cookies', 'responseMessageService','factoryForRoleBasedFeature',
	function($scope, propertiesConfig, commonFactoryForRestCall, paginationService, $timeout,$cookies, responseMessageService,factoryForRoleBasedFeature) {
    $scope.loadingIcon = true;
    $scope.responseMsgFlag = false;
    $scope.responseClass = propertiesConfig.details.successMsgClass;
    var paginationParams;
    var baseURL = propertiesConfig.details.baseURL;
    var endPointURL = propertiesConfig.details.userRoles;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.usersForRole);
    $scope.isRead = roleBasedData.isRead;
    $scope.isWrite = roleBasedData.isWrite;
    $scope.showCreateRolePopUP = false;
    $scope.showEditRolePopUP = false;
    $scope.currentPage = 0;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    paginationService.loadPageCounts($scope);

    paginationParams = angular.extend({
      commonFactoryForRestCall: commonFactoryForRestCall,
      baseURL: baseURL + endPointURL,
      propertiesConfig: propertiesConfig
      /*apiKey: apiKey.key*/
    });

	  paginationService.getPageData($scope, paginationParams);

	  $scope.prevPage = function () {
		  paginationService.prevPage($scope, paginationParams);
    };

    $scope.nextPage = function () {
   	  if($scope.currentPage < $scope.noOfPages-1 ){
   	    paginationService.nextPage($scope, paginationParams);
   	  } else {
   		  return false;
   	  }
    };

    $scope.setPage = function () {
    	paginationService.setPage($scope, paginationParams,this);
    };

    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
    	paginationService.getPageData($scope, paginationParams);
    };
    
    $scope.showCreateRolePopUPFn = function(flag){
      $scope.showCreateRolePopUP = flag;
      $scope.role = null;
    	if(flag){
    		  var getUserAccountsURL= baseURL +propertiesConfig.details.userAccounts;
    		  $scope.loadingIcon = true;
		 	    commonFactoryForRestCall.getURL(getUserAccountsURL).get(undefined,undefined,function(data,status,headers,config) {
		 	    	$scope.roleAccountsData = data.content;
		 	    	for(var loop =0 ; loop<$scope.roleAccountsData.length;loop++){
		 	    		$scope.roleAccountsData[loop].isRead=false;
		 	    		$scope.roleAccountsData[loop].isWrite=false;
		 	    	}
		 	        $scope.loadingIcon = false;
				}, function(data, status, headers, config) {
					if(data.status === 400){
						  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					} else {
						responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
					$scope.loadingIcon = false;
				});
    	} 	    
    };


    $scope.createRole = function (roleAccountsData,newRoleName) {
      $scope.loadingIcon = true;
      var paramsData = {
                         "roleName" : newRoleName,
                         "permissions" : $scope.roleAccountsData
                       };
      commonFactoryForRestCall.getURL(baseURL + endPointURL).post(undefined, paramsData, function(data, status, headers, config) {
         $scope.showCreateRolePopUP = false;
         paginationService.getPageData($scope, paginationParams);
         responseMessageService.showResponseMsg(propertiesConfig.details.role + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
         $scope.loadingIcon = false;
      }, function(data, status, headers, config) {
         $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
         if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			   } else {
           responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
         }
         $scope.loadingIcon = false;
      });
    };

    $scope.showEditRolePopUPFn = function(flag, roleId){
        $scope.showEditRolePopUP = flag;
        if(flag && roleId != undefined){
          if(flag){
        	  $scope.loadingIcon = true;
	          	var getUserPermissionsURL= baseURL +propertiesConfig.details.userPermissions;
	          	 var queryParams={};
	       	    queryParams.roleId =  roleId; 
	       	    commonFactoryForRestCall.getURL(getUserPermissionsURL).get(queryParams,undefined, function(data,status,headers,config) {
	       	    	$scope.roleId = data.roleId;
	       	    	$scope.roleName = data.roleName;
	       	    	$scope.rolePermissions = data.permissions;
	       	     $scope.loadingIcon = false;
	  			}, function(data, status, headers, config) {
	  				if(data.status === 400){
	  					  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	  				} else {
	  					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	  				}
	  				$scope.loadingIcon = false;
	  			});
          }
        }
      };
    $scope.updateRolePermissions = function (roleName) {
	     var updateRolesURL = baseURL+propertiesConfig.details.updateUserRolePermissions;
	      $scope.loadingIcon = true;
	      var paramsData = {"roleName": roleName, "permissions" : $scope.rolePermissions};
	       commonFactoryForRestCall.getURL(updateRolesURL).put(undefined, paramsData, function(data, status, headers, config) {
		        $scope.showEditRolePopUP = false;
		        responseMessageService.showResponseMsg(propertiesConfig.details.role + propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		    	var getUserPermissionsURL= baseURL +propertiesConfig.details.userPermissions;
	          	var queryParams={};
	       	    queryParams.roleId =  $scope.roleId; 
	       	    if( $cookies.get(propertiesConfig.details.userRoleId) === $scope.roleId){
		       	    commonFactoryForRestCall.getURL(getUserPermissionsURL).get(queryParams,undefined, function(data,status,headers,config) {
		       	    	$cookies.putObject(propertiesConfig.details.roleBasedPermissions,data.permissions);
		       	    	$scope.loadingIcon = false;
		  			}, function(data, status, headers, config) {
		  				if(data.status === 400){
		  					  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		  				} else {
		  					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		  				} 				
		  				$scope.loadingIcon = false;
		  			});
	       	    }else{
	       	    	$scope.loadingIcon = false;
	       	    }
	      }, function(data, status, headers, config) {
	         $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	         $scope.showEditRolePopUP = false;
	        
	         if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			 }else {
	             responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	         }
         $scope.loadingIcon = false;
      });
    };
    
    $scope.searchRole = function () {
        paginationParams = angular.extend({
          commonFactoryForRestCall: commonFactoryForRestCall,
          baseURL: baseURL + endPointURL,
          propertiesConfig: propertiesConfig
        });
    	paginationService.getPageData($scope, paginationParams,undefined,$scope.paginationParamsWithSearch());
    };
    $scope.paginationParamsWithSearch = function(){
		return angular.extend({
			roleName: $scope.searchRoleName
		});
	};

}]);;//This controller is to view the data of users
app.controller('manageUserCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall','paginationService','$timeout','responseMessageService','factoryForRoleBasedFeature','searchToggleService','$state','commonFactoryForHttp',
    function($scope, propertiesConfig, commonFactoryForRestCall,paginationService,$timeout,responseMessageService,factoryForRoleBasedFeature,searchToggleService,$state,commonFactoryForHttp) {
    $scope.loadingIcon = true;
    $scope.responseMsgFlag = false;
    $scope.responseClass = propertiesConfig.details.successMsgClass;
    var baseURL = propertiesConfig.details.baseURL;
	var searchURL = propertiesConfig.details.searchURL;
    var endPointURL = propertiesConfig.details.userRoles;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.usersForRole);
    $scope.isRead = roleBasedData.isRead;
    $scope.isWrite = roleBasedData.isWrite;
    $scope.userRoleId = '';
    commonFactoryForRestCall.getURL(baseURL + endPointURL)
        .get(undefined, undefined, function(data, status, headers, config) {
            $scope.userRoles = data.content;
            if($scope.userRoles && $scope.userRoles.length > 0){
                $scope.userRole = $scope.userRoles[0].roleId + "," + $scope.userRoles[0].roleName;
                $scope.userRoleId = $scope.userRoles[0].roleId;
                $scope.userRoleName = $scope.userRoles[0].roleName;
            }
        }, function(data, status, headers, config) {
            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });

    endPointURL = propertiesConfig.details.manageUser;
    $scope.showCreateUserPopUP = false;
    $scope.showEditUserPopUP = false;
    var paginationParams;

    $scope.currentPage = 0;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    paginationService.loadPageCounts($scope);

    paginationParams = angular.extend({
        commonFactoryForRestCall: commonFactoryForRestCall,
        baseURL: baseURL + endPointURL,
        propertiesConfig:propertiesConfig
        
    });

    paginationService.getPageData($scope, paginationParams);

    $scope.prevPage = function () {
        paginationService.prevPage($scope, paginationParams);
    };

    $scope.nextPage = function () {
        if($scope.currentPage < $scope.noOfPages-1 ){
            paginationService.nextPage($scope, paginationParams);
        } else {
            return false;
        }
    };

    $scope.setPage = function () {
        paginationService.setPage($scope, paginationParams,this);
    };

    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
        paginationService.getPageData($scope, paginationParams);
    };

    $scope.showCreateUserPopUPFn = function(flag){
        $scope.showCreateUserPopUP = flag;
          $scope.user ={};

    };
    
    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
   };
    
    $scope.showEditUserPopUPFn = function(flag, user){
        $scope.showEditUserPopUP = flag;
        $scope.updatedUser = {};
        if(flag && user != undefined){
            $scope.updatedUser.email = user.email;
            $scope.updatedUser.firstName = user.firstName;
            $scope.updatedUser.lastName = user.lastName;
            $scope.updatedUser.userRoleId = user.userRoleId;
            $scope.updatedUser.isEnabled = user.isEnabled;
            if($scope.userRoles && $scope.userRoles.length > 0){
                for(var i=0; i<$scope.userRoles.length; i++) {
                    if ($scope.userRoles[i].roleId == $scope.updatedUser.userRoleId) {
                        $scope.userRole = $scope.userRoles[i].roleId + "," + $scope.userRoles[i].roleName;
                        $scope.userRoleId = $scope.userRoles[i].roleId;
                        $scope.userRoleName = $scope.userRoles[i].roleName;
                        break;
                    }
                }
            }
            $scope.updatedUser.distributorId = user.distributorId;
        }
    };

    $scope.viewManagerRole = function(){
    	$state.go("manager.manageRole");
    }
    $scope.createUser = function (user) {
        $scope.loadingIcon = true;
        endPointURL = propertiesConfig.details.manageUser;
        var paramsData = {
            "email": user.email? user.email.toLowerCase() : "", "firstName" : user.firstName
            , "lastName" : user.lastName, "userRoleId" : parseInt($scope.userRoleId)
        };
        commonFactoryForRestCall.getURL(baseURL + endPointURL)
            .post(undefined, paramsData, function(data, status, headers, config) {
                $scope.showCreateUserPopUP = false;
                paginationService.getPageData($scope, paginationParams);
                responseMessageService.showResponseMsg(propertiesConfig.details.user + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
                $scope.loadingIcon = false;
            }, function(data, status, headers, config) {
            	if(data.status === 400){
            	  var errorMessage;
                if(data.data.message) {
                  errorMessage = data.data.message;
                } else if (data.data.errorMessages[0]){
                  errorMessage = data.data.errorMessages[0];
                }
    				    responseMessageService.showResponseMsg(errorMessage, propertiesConfig.details.errorMsgClass, $scope, $timeout);
    			    } else {
                responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
              }
              $scope.showCreateUserPopUP = false;
              paginationService.getPageData($scope, paginationParams);
              $scope.loadingIcon = false;

            });
    };

    $scope.userRoleChange = function (role) {
        $scope.userRoleId = role.split(",")[0];
        $scope.userRoleName = role.split(",")[1];
    };

    $scope.changeUserStatus = function (service) {
        service.isEnabled = !service.isEnabled;
        $scope.updateUser(service);
    };

    $scope.updateUser = function (user) {
        $scope.loadingIcon = true;
        var paramsData = {
            "email": user.email, "firstName" : user.firstName, "lastName" : user.lastName,
            "userRoleId" : parseInt($scope.userRoleId), "isEnabled" : user.isEnabled, "distributorId" : user.distributorId
        };
        endPointURL = propertiesConfig.details.manageUser;
        commonFactoryForRestCall.getURL(baseURL + endPointURL)
            .put(undefined, paramsData, function(data, status, headers, config) {
                $scope.showEditUserPopUP = false;
                paginationService.getPageData($scope, paginationParams);
                responseMessageService.showResponseMsg(propertiesConfig.details.user + propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
                $scope.loadingIcon = false;
            }, function(data, status, headers, config) {
            	 $scope.showEditUserPopUP = false;
            	if(data.status === 400){
            	  var errorMessage;
            	  if(data.data.message) {
            	    errorMessage = data.data.message;
            	  } else if (data.data.errorMessages[0]){
            	    errorMessage = data.data.errorMessages[0];
            	  }
    				    responseMessageService.showResponseMsg(errorMessage, propertiesConfig.details.errorMsgClass, $scope, $timeout);
    			    } else {
    			      responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
    			    }
    			    paginationService.getPageData($scope, paginationParams);
              $scope.loadingIcon = false;
            });
    };
  $scope.populateEmailList = function(emailSelect){
        var listOfEmailEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.distributorsSearch;
        var distributorSearchParams = angular.extend({
               email: emailSelect
        });
        commonFactoryForHttp.getURL('GET',listOfEmailEndPointURL,distributorSearchParams).success(function(data, status, headers, config) {
               $scope.listofEmails =data;
        }).error( function(data, status, headers, config) {
               $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });
   };
 
	 $scope.populateFirstNameList = function(firstNameSelect){
	     var listOfFirstNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.distributorsSearch;
	     var firstNameSearchParams = angular.extend({
	    	 firstName: firstNameSelect
	     });
	     commonFactoryForHttp.getURL('GET',listOfFirstNameEndPointURL,firstNameSearchParams).success(function(data, status, headers, config) {
	            $scope.listofFirstNames =data;
	     }).error( function(data, status, headers, config) {
	            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	     });
	};

	$scope.populateLastNameList = function(lastNameSelect){
	    var listOfLastNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.distributorsSearch;
	    var lastNameSearchParams = angular.extend({
	   	 lastName: lastNameSelect
	    });
	    commonFactoryForHttp.getURL('GET',listOfLastNameEndPointURL,lastNameSearchParams).success(function(data, status, headers, config) {
	           $scope.listofLastNames =data;
	    }).error( function(data, status, headers, config) {
	           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	    });
	};

$scope.searchReset = function(){
	$scope.emailSelect='';
	$scope.distributorId='';
	$scope.firstNameSelect='';
	$scope.lastNameSelect='';
};

$scope.searchRecords = function (){
	$scope.currentPage = 0;
	paginationService.loadPageCounts($scope);
	var paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		endPointURL : propertiesConfig.details.manageUser,
		baseURL:baseURL+endPointURL,
		propertiesConfig:propertiesConfig
	});
	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
};

$scope.paginationParamsWithSearch = function(){
	return angular.extend({
		email:$scope.emailSelect,
		distributorId:$scope.distributorId,
		firstName:$scope.firstNameSelect,
		lastName:$scope.lastNameSelect
	});
};

}]);
;app.controller('overAllReportCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','graphsService',
    function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,graphsService) {
    $scope.loadingIcon = true;
    var baseReportingURL = propertiesConfig.details.baseReportingURL;
    var endPointURL = propertiesConfig.details.lastMonthRevenue;
    var params = angular.extend({
        year: new Date().getFullYear()
    });
    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
        var lastMonthRevenueData=[];
        for(var index in data.content) {
            lastMonthRevenueData.push({"month": data.content[index].month, "amount" : data.content[index].amount ? data.content[index].amount : 0, monthNumber: data.content[index].monthNumber});
        }
        var params = angular.extend({
            showLegend:false,
            showYAxis:true,
            showXAxis:true,
            interactive:50,
            container:"chart",
            xAxisLabel:'Month',
            yAxisLabel:'Amount',
            xAxisTicks:12,
            yAxisTicks:10,
            xAxisLabelParamFromData: 'month',
            data:lastMonthRevenueData,
            dataToDisplay : $scope.dataToDisplay(lastMonthRevenueData),
            noData: "No data available"
        });
        graphsService.drawLineUsingNVD3(params);
        $scope.loadingIcon = false;
    }, function(data, status, headers, config) {
    	 $scope.loadingIcon = false;
    });
    $scope.dataToDisplay = function(data) {
        var dataToDisplayArray = [];
        for (var i = 0; i < data.length; i++) {
            dataToDisplayArray.push({x: data[i].monthNumber, y: data[i].amount});
        }
        return [{values: dataToDisplayArray,key: 'Last Month Revenue',color: '#FF0066'}];
    };
}]);;app.controller('premiumGroupsCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$stateParams','$state','paginationService','responseMessageService','$timeout','factoryForRoleBasedFeature','searchToggleService',
    function($scope,propertiesConfig,commonFactoryForRestCall,$stateParams,$state,paginationService,responseMessageService,$timeout,factoryForRoleBasedFeature,searchToggleService) {
    $scope.loadingIcon = false;
    $scope.createPremiumGroupPopUp = false;
    $scope.currentPage = 0;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.resellerForRole);
    $scope.isRead = roleBasedData.isRead;
    $scope.isWrite = roleBasedData.isWrite;
    $scope.servicesDetails = '';
    $scope.showPremiumGroupPopUp = function(flag){
        $scope.createPremiumGroupPopUp = flag;
    };
    var baseURL = propertiesConfig.details.baseURL;
    var endPointURL = baseURL+propertiesConfig.details.premiumGroupsList;

    paginationService.loadPageCounts($scope);
    var paginationParams = angular.extend({
        commonFactoryForRestCall: commonFactoryForRestCall,
        baseURL: endPointURL,
        propertiesConfig:propertiesConfig
       
    });
    paginationService.getPageData($scope,paginationParams);

    $scope.prevPage = function () {
        paginationService.prevPage($scope,paginationParams);
    };
    $scope.nextPage = function () {
        if($scope.currentPage < $scope.noOfPages-1 ){
            paginationService.nextPage($scope,paginationParams);
        }else{
            return false;
        }
    };
    $scope.setPage = function () {
        paginationService.setPage($scope,paginationParams,this);
    };
    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
        paginationService.getPageData($scope,paginationParams);
    };

    $scope.changeStatus = function(premiumGroup){
        var params = angular.extend({
        	premiumGroupid: premiumGroup.premiumGroupid,
            status:'ACTIVE'
        });
        commonFactoryForRestCall.getURL(endPointURL).put(undefined,params,function(data, status, headers, config) {
            paginationService.getPageData($scope,paginationParams);
            responseMessageService.showResponseMsg(propertiesConfig.details.statusChangeMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
        },function(data, status, headers, config){
        	if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
        });
    };
    $scope.createPremiumGroupFn = function(createPremiumGroup){
        endPointURL = baseURL+propertiesConfig.details.premiumGroupsList;
        var params = angular.extend({
            name: createPremiumGroup.name,
            description: createPremiumGroup.description
        });
        commonFactoryForRestCall.getURL(endPointURL).post(undefined,params,function(data, status, headers, config) {
            $scope.showPremiumGroupPopUp(false);
            paginationService.getPageData($scope,paginationParams);
            responseMessageService.showResponseMsg(propertiesConfig.details.premiumGroup + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
        },function(data, status, headers, config){
        	if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
        });
    };
    
    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
   };
   
    
}]);;app.controller('resellerCompanyCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','responseMessageService','$timeout','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,responseMessageService,$timeout,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
	$scope.loadingIcon = false;
	$scope.servicesDetails = '';
	$scope.serviceError=false;
	var paginationParams ;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.resellerForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var baseURL = propertiesConfig.details.baseURL;
	var searchURL = propertiesConfig.details.searchURL;
	var cloudResellerCompany  = baseURL+propertiesConfig.details.cloudResellerCompany;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.currentPage = 0;
	 $scope.resultsCount = 0;
	paginationService.loadPageCounts($scope);
	paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		baseURL: cloudResellerCompany,
		propertiesConfig:propertiesConfig
		
	});
	paginationService.getPageData($scope,paginationParams);
	$scope.prevPage = function () {
		paginationService.prevPage($scope,paginationParams);
	};
	$scope.nextPage = function () {
		if($scope.currentPage < $scope.noOfPages-1 ){
			paginationService.nextPage($scope,paginationParams);
		}else{
			return false;
		}
	};
	  $scope.searchToggle = function(){
		  searchToggleService.toggleSearch();
      };
	
	$scope.setPage = function () {
		paginationService.setPage($scope,paginationParams,this);
	};
	$scope.pageSizeChange = function () {
		$scope.currentPage = 0;
		paginationService.getPageData($scope,paginationParams);
	};
	$scope.viewResellerCompanyDetails = function (reseller) {

	};
	

		
	$scope.premiumGroupsId = undefined;
	$scope.changePremiumGroupFn = function(flag,resellerCompanies){
		$scope.premiumGroupsId = undefined;
		if(flag){
			$scope.resellerCompanyName = resellerCompanies.resellerCompanyName;
			$scope.resellerCompanyId = resellerCompanies.resellerCompanyId;
			var baseURL = propertiesConfig.details.baseURL;
			var premiumGroupsList = baseURL+propertiesConfig.details.premiumGroupsList;
			var params = angular.extend({
				status: 'ACTIVE'
			});
			commonFactoryForRestCall.getURL(premiumGroupsList).get(params,undefined,function(data, status, headers, config) {
				$scope.premiumgroupDetails = data.content;
				if($scope.premiumgroupDetails && $scope.premiumgroupDetails.length > 0){
					for(var loop=0; loop<$scope.premiumgroupDetails.length;loop++){
						if($scope.premiumgroupDetails[loop].premiumGroupid === resellerCompanies.resellerPremiumGroupId){
							$scope.premiumGroupId = $scope.premiumgroupDetails[loop].premiumGroupid+" "+$scope.premiumgroupDetails[loop].name;
							$scope.premiumGroupsId = $scope.premiumgroupDetails[loop].premiumGroupid;
							$scope.premiumGroupName = $scope.premiumgroupDetails[loop].name;
							break;
						}
					}
				}
			},function(data, status, headers, config){
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}
		$scope.changePremiumGroup = flag;
	};
	$scope.premiumGroupChanged = function(premiumGroupId){
		$scope.premiumGroupsId = premiumGroupId.split(" ")[0];
		$scope.premiumGroupName = premiumGroupId.split(" ")[1];
	};
	$scope.updateDetails = function(){

		var baseURL = propertiesConfig.details.baseURL;
		var premiumGroupChangeURL = baseURL+propertiesConfig.details.updateResellerPremiumGroup;
		var params = angular.extend({
			resellerCompanyId: $scope.resellerCompanyId,
			resellerPremiumGroupId : $scope.premiumGroupsId,
			comments:$scope.comments
		});
		commonFactoryForRestCall.getURL(premiumGroupChangeURL).put(undefined,params,function(data, status, headers, config) {
			paginationService.getPageData($scope,paginationParams);
			$scope.changePremiumGroupFn(false);
			responseMessageService.showResponseMsg(propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		},function(data, status, headers, config){
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
		});
	};
	
	$scope.populateEmailList = function(emailSelect){
        var listOfEmailEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.resellersSearch;
        var resellerSearchParams = angular.extend({
               email: emailSelect
        });

        commonFactoryForHttp.getURL('GET',listOfEmailEndPointURL,resellerSearchParams).success(function(data, status, headers, config) {
               $scope.listofEmails =data;
        }).error( function(data, status, headers, config) {
               $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });
 };
 
 
 $scope.populateCompanyNameList = function(companyNameSelect){
     var listOfCompanyNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.resellersSearch;
     var resellerSearchParams = angular.extend({
    	 companyName: companyNameSelect
     });

     commonFactoryForHttp.getURL('GET',listOfCompanyNameEndPointURL,resellerSearchParams).success(function(data, status, headers, config) {
            $scope.listofCompanyName =data;
     }).error( function(data, status, headers, config) {
            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
     });
};

$scope.premiumGroupList = function(premiumGroupSelect){
    var listOfPremiumGroupEndPointURL = propertiesConfig.details.premiumGroupsList;
    var premiumGroupSearchParams = angular.extend({
    	resellerPremiumGroupName: premiumGroupSelect
    });

    commonFactoryForHttp.getURL('GET',listOfPremiumGroupEndPointURL,premiumGroupSearchParams).success(function(data, status, headers, config) {
           $scope.listofPremiumGroup =data;
    }).error( function(data, status, headers, config) {
    	$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
    });
};
 
 $scope.searchReset = function(){
		$scope.companyNameSelect='';
		$scope.cloudResellerId='';
		$scope.emailSelect='';
		//$scope.resellerPremiumGroupName='';
 };

 $scope.searchRecords = function (){
 	$scope.currentPage = 0;
 	paginationService.loadPageCounts($scope);
 	var paginationParams = angular.extend({
 		commonFactoryForRestCall: commonFactoryForRestCall,
 		baseURL:cloudResellerCompany,
 		propertiesConfig:propertiesConfig,
 	});
 	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
 };
 
 $scope.paginationParamsWithSearch = function(){
		return angular.extend({
			companyName: $scope.companyNameSelect,
			email:$scope.emailSelect,
			created:$scope.created,
			cloudResellerId : $scope.resellerCompanyId,
			resellerPremiumGroupName:$scope.premiumGroupSelect
		});
	};

     	
}]);;app.controller('resellerPriceCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','$stateParams','responseMessageService','$timeout',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,$stateParams,responseMessageService,$timeout) {
	 $scope.servicesDetails = '';
	    var baseURL;
	    $scope.serviceError=false;
	    var paginationParams ;
	    baseURL = propertiesConfig.details.baseURL;
		var endPointURL = propertiesConfig.details.cloudResellerPrice; 
		baseURL += endPointURL;
		$scope.currentPage = 0;
		 paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
	        baseURL: baseURL,
	        propertiesConfig:propertiesConfig
	      
	    });
		 
		 //Get Price Group Details 
		 $scope.loadPriceGroupDetails=function(){
			paginationService.getPageData($scope,paginationParams);   
		 	 $scope.prevPage = function () {
		 		paginationService.prevPage($scope,paginationParams);
		     };
		     $scope.nextPage = function () {
		    	 if($scope.currentPage < $scope.noOfPages-1 ){
		    	 paginationService.nextPage($scope,paginationParams);
		    	 }else{
		    		 return false;
		    	 }
		     };
		     $scope.setPage = function () {
		    	 paginationService.setPage($scope,paginationParams,this);
		     };
		 };
	     
	     //Save Price Group Details
	     $scope.savedetails = function (updatedValues,reseller) {
    		 var priceGroup ={};
    		 priceGroup.distributorPriceGroupId= reseller.distributorPriceGroupId;
    		 priceGroup.name=updatedValues.name;
		 		commonFactoryForRestCall.getURL(baseURL).put(JSON.stringify(priceGroup),function(data,status,headers,config) {
		 			// $state.transitionTo($state.$current, $stateParams, {'reload':true});
		 			$scope.loadPriceGroupDetails();
		 			$scope.editFlag = false;
		 		 },function(data,status,headers,config) {
		 			if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
		 			 $scope.editFlag = false;
		 		});
	     };
	     
	     //Create New Group Name
	     $scope.creategroup = function (groupname) {
	    	var groupDetails = { name :groupname }
			 commonFactoryForRestCall.getURL(baseURL).post(JSON.stringify(groupDetails),function(data,status,headers,config) {
				 //$state.transitionTo($state.$current, $stateParams, {'reload':true});
				 $scope.loadPriceGroupDetails();
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			 });
	     }
	     
	     $scope.editFlag = false;
		  
		  //update edit flag when cancel the action
		  $scope.updatePriceGroup = function(showForm){
			  if(!$scope.editFlag){
				  $scope.editFlag = true;
				  showForm.$show();
			  }else{
				  alert("Please save already initiated PriceGroup");
			  }
		  };
		
		  //Remove all flags when cancel the action
		  $scope.removeFlag= function(rowform,index){
			  $scope.editFlag= false;
			  rowform.$cancel()
		  }
	  
		  //remove price group record
		  $scope.removePrice = function (groupId) {
			  if(groupId != null){
				commonFactoryForRestCall.getURL(baseURL).del({id:groupId},function(data,status,headers,config) {
					//$state.transitionTo($state.$current, $stateParams, {'reload':true});
					$scope.loadPriceGroupDetails();
				}, function(data,status,headers,config) {
					if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				});
			  }else{
				  $scope.discountDetails.splice(index, 1);
				// $state.transitionTo($state.$current, $stateParams, {'reload':true});
			  }
		}
	     
}]);;app.controller('resellerReportCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService) {
	$scope.loadingIcon = false;
	$scope.servicesDetails = '';
	$scope.serviceError=false;
	$scope.monthsArray = propertiesConfig.details.months;
	$scope.date = new Date();
	$scope.month = $scope.date.getMonth();
	$scope.monthName = '';
	$scope.year = $scope.date.getFullYear();
	for(var loop =0 ; loop<$scope.monthsArray.length;loop++){
		if($scope.month == $scope.monthsArray[loop].number){
			$scope.months = $scope.monthsArray[loop].number+' '+$scope.monthsArray[loop].monthName;
			$scope.monthNames = $scope.monthsArray[loop].monthName;
			break;
		}
	}
	var baseURL = propertiesConfig.details.baseReportingURL;
	baseURL +=  propertiesConfig.details.reportReseller;
	$scope.currentPage = 0;
	$scope.resultsCount = 0;
	$scope.resultsFound = propertiesConfig.details.resultsFound;
	paginationService.loadPageCounts($scope);
	var paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		baseURL: baseURL,
		propertiesConfig:propertiesConfig
		
	});
	var params = {
		monthNumber: $scope.month,
		year: $scope.year,
		page: $scope.currentPage,
		size:$scope.noOfitems
	};

	$scope.onMonthChange = function(months) {
		$scope.month = months.split(" ")[0];
		$scope.monthNames = months.split(" ")[1];
		params = {
			monthNumber: $scope.month,
			year: $scope.year
		};
		paginationService.getPageData($scope,paginationParams,undefined,params);
	};

	paginationService.getPageData($scope,paginationParams,undefined,params);

	$scope.prevPage = function () {
		paginationService.prevPage($scope,paginationParams,undefined,params);
	};

	$scope.nextPage = function () {
		if($scope.currentPage < $scope.noOfPages-1 ){
			paginationService.nextPage($scope,paginationParams,undefined,params);
		} else{
			return false;
		}
	};

	$scope.setPage = function () {
		paginationService.setPage($scope,paginationParams,this,undefined,params);
	};

	$scope.pageSizeChange = function () {
		$scope.currentPage = 0;
		paginationService.getPageData($scope, paginationParams,undefined,params);
	};
}]);;// Config credentials Controller to create,update,delete operations from database
 app.controller('serviceAuthCredentialsCtrl',  ['$scope', '$stateParams', 'commonFactoryForRestCall', 'propertiesConfig', '$state', 'moduleActiveService', 'responseMessageService', '$timeout', '$cookies', 'factoryForRoleBasedFeature',
	 function ($scope, $stateParams, commonFactoryForRestCall, propertiesConfig, $state, moduleActiveService, responseMessageService, $timeout, $cookies, factoryForRoleBasedFeature) {
	$scope.master = {};
	$scope.serviceId =  $cookies.get(propertiesConfig.details.id);
	var baseURL = propertiesConfig.details.baseURL;
	$scope.isExists=false;
	$scope.isExistsFlag=false;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var endPointURL = propertiesConfig.details.serviceCredential;
	endPointURL = baseURL+ endPointURL;
	$scope.loadingIcon = true;
	$scope.loadSetUpCredentials = function(){
		moduleActiveService.getModulesData($scope);
		commonFactoryForRestCall.getURL(endPointURL).get({id:$scope.serviceId},function(data,status,headers,config) {
			$scope.service.apiKey= data.apiKey;
			$scope.service.username=data.username;
			$scope.service.serviceCredentialId=data.serviceCredentialId;
			if($scope.service.apiKey!=null){
				$scope.isExists=true;
				$scope.isExistsFlag=!$scope.isExistsFlag;
			}
			$scope.loadingIcon = false;
		}, function(data,status,headers,config) {
			$scope.loadingIcon = false;});
	};

	$scope.reset = function() {
		$scope.service = angular.copy($scope.master);
	};
	$scope.cancel = function() {
		$scope.loadSetUpCredentials();
	};

	$scope.showUpdateView=function() {
		$scope.isExistsFlag=!$scope.isExistsFlag;
	};
	
	$scope.checkAndCreate = function(service){
		$scope.loadingIcon = true;
		var params = {};
		if(!$scope.isExists){
			params = { apiKey :service.apiKey, username:service.username,serviceId:$scope.serviceId};
				commonFactoryForRestCall.getURL(endPointURL).post(JSON.stringify(params),function(data,status,headers,config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.setUpMsg+propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
				$scope.loadSetUpCredentials();
			}, function(data,status,headers,config) {
				$scope.loadSetUpCredentials();
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;});
		}else{
			params = { apiKey :service.apiKey, username:service.username, serviceId:$scope.serviceId,serviceCredentialId:service.serviceCredentialId};
			commonFactoryForRestCall.getURL(endPointURL).put(JSON.stringify(params),function(data,status,headers,config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.setUpMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
				$scope.loadSetUpCredentials();
			}, function(data,status,headers,config) { 
				$scope.loadSetUpCredentials();
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				} else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
				});
		}
	};
	$scope.updateStatus = function(){
		$scope.loadingIcon = true;
		var service ={};
		var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		endPointServiceURL =baseURL+ endPointServiceURL;
		service.serviceId= $scope.serviceId;
		service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;
		if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				$scope.isPublished = !$scope.isPublished;
				$scope.loadingIcon = false;
				 responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			},function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
			});
		}else if($scope.isEnablePublish===false && service.isPublished==='true'){
			 $scope.loadingIcon = false;
			 responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.statusConfirmationPopup = false;
	};
	/*$scope.gotoPathWithParams = function(path){
		$state.get(path).params.id = $scope.serviceId;
		$state.get(path).params.serviceName = $scope.serviceName;
		$state.get(path).params.isPublished = $scope.isPublished;
		$state.go(path);
	};*/
	$scope.statusConfirmationPopup = false;
	 $scope.showStatusConfirmationPopup = function(flag){
	    	$scope.statusConfirmationPopup = flag;
	    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	    };
	    
}]);
;//This controller is to view data of service Catalogs
app.controller('serviceCatalogCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','paginationService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
	function($scope,propertiesConfig,commonFactoryForRestCall,$state,paginationService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
	$scope.loadingIcon = false;
    $scope.servicesDetails = '';
    $scope.serviceError=false;
    var paginationParams ;
    var baseURL = propertiesConfig.details.baseURL;
	var endPointURL = propertiesConfig.details.serviceCatalog; 
	endPointURL=baseURL+endPointURL;
	$scope.currentPage = 0;
	$scope.resultsCount = 0;
	$scope.createServicePopUP = false;
	$scope.editServicePopUP = false;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.loadServiceDetails = function(){
		 paginationService.loadPageCounts($scope);
		 paginationParams = angular.extend({
		   commonFactoryForRestCall: commonFactoryForRestCall,
	       baseURL: endPointURL,
	       propertiesConfig:propertiesConfig,
	      // apiKey: apiKey.key 
	    });
		paginationService.getPageData($scope,paginationParams);
	};
		$scope.prevPage = function () {
			paginationService.prevPage($scope,paginationParams);
	    };
	    $scope.nextPage = function () {
	   	 if($scope.currentPage < $scope.noOfPages-1 ){
	   	 paginationService.nextPage($scope,paginationParams);
	   	 }else{
	   		 return false;
	   	 }
	    };
	    $scope.setPage = function () {
	    	paginationService.setPage($scope,paginationParams,this);
	    };
	    $scope.pageSizeChange = function () {
	    	$scope.currentPage = 0;
	    	paginationService.getPageData($scope,paginationParams);
	    };

	    $scope.viewResellerCompanyDetails = function (cloudServices) {

		};
	    
    $scope.configCredentials = function (services) {
		$cookies.put(propertiesConfig.details.id,services.serviceId);
    	$state.go('manager.setupcredentials');

    };

    $scope.showCreateServicePopUP = function(flag){
    	$scope.createServicePopUP = flag;
    	$scope.service={};
    };

    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
    };



    $scope.showEditServicePopUP = function(flag,services){
    	$scope.editServicePopUP = flag;
    	 $scope.updateService ={};
    	if(flag && services!= undefined){
    	 $scope.updateService.name= services.name;
		 $scope.updateService.brandName=services.brandName;
		 $scope.updateService.serviceCode=services.serviceCode;
		 $scope.updateService.vendorCode=services.vendorCode;
		 $scope.updateService.serviceId =services.serviceId;
		 $scope.updateService.serviceProviderId=services.serviceProviderId;
		 //$scope.updateService.brandCode=services.brandCode;
		 $scope.updateService.planPrefix=services.planPrefix;
		 $scope.updateService.subscriptionNamePrefix=services.subscriptionNamePrefix;
    	}
    };
    
    $scope.createNewService = function(service){
    	$scope.loadingIcon = true;
		 var params = {};
		 var endPointprovidertURL = baseURL+propertiesConfig.details.serviceProvider;
		 var endPointServiceURL = baseURL+propertiesConfig.details.serviceCatalog;
		 params = { brandName:service.brandName,brandCode:service.brandCode};
		 commonFactoryForRestCall.getURL(endPointprovidertURL).post(undefined,JSON.stringify(params),function(data,status,headers,config) {
			 serviceParams = { brandName:service.brandName,name:service.name,serviceCode:service.serviceCode,serviceProviderId:data.serviceProviderId,planPrefix:service.planPrefix,subscriptionNamePrefix:service.subscriptionNamePrefix};
			 commonFactoryForRestCall.getURL(endPointServiceURL).post(undefined,JSON.stringify(serviceParams),function(data,status,headers,config) {
				 $scope.createServicePopUP = false;
				 $scope.loadServiceDetails();
				 $scope.loadingIcon = false;
			 }, function(data,status,headers,config) {
				 	$scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			 		$scope.loadingIcon = false;
			 	});
			 responseMessageService.showResponseMsg(propertiesConfig.details.cloudServiceMsg+propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		 }, function(data,status,headers,config) {

			 if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
				  $scope.createServicePopUP = true;
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			 $scope.loadingIcon = false;
			});
	 };
	 $scope.updateCloudService = function(service){
		 var params = {};
		 $scope.loadingIcon = true;
		 var endPointprovidertURL = baseURL+propertiesConfig.details.serviceProvider;
		 params = {serviceProviderId:service.serviceProviderId, brandName:service.brandName};
		 commonFactoryForRestCall.getURL(endPointprovidertURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
			 var endPointServiceURL = baseURL+propertiesConfig.details.serviceCatalog; 
			 serviceParams = {serviceId:service.serviceId,brandName:service.brandName,name:service.name,planPrefix:service.planPrefix,subscriptionNamePrefix:service.subscriptionNamePrefix,vendorCode:service.vendorCode,serviceCode:service.serviceCode};
			 commonFactoryForRestCall.getURL(endPointServiceURL).put(undefined,JSON.stringify(serviceParams),function(data,status,headers,config) {
				 $scope.editServicePopUP = false;
				 $scope.loadServiceDetails();
				 $scope.loadingIcon = false; 
			 }, function(data,status,headers,config) {
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				 	$scope.loadingIcon = false; 
			 	});
			 responseMessageService.showResponseMsg(propertiesConfig.details.cloudServiceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		 }, function(data,status,headers,config) { 
			 $scope.editServicePopUP = false;
			 if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
		 		$scope.loadingIcon = false;
		 });
	};
	

	$scope.populateBrandNameList = function(brandNameSelect){
		var listOfBranEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.serviceProvidersSearch;
		var serviceProviderSearchParams = angular.extend({
			name: brandNameSelect
		});
		commonFactoryForHttp.getURL('GET',listOfBranEndPointURL,serviceProviderSearchParams).success(function(data, status, headers, config) {
			$scope.listofBrandNames =data;
		}).error( function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		});
	};
	$scope.populateServiceNameList = function(serviceNameSelect){
		var listOfServiceEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.serviceSearch;
		var serviceSearchParams = angular.extend({
			name: serviceNameSelect
		});
		commonFactoryForHttp.getURL('GET',listOfServiceEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
			$scope.listofServiceNames =data;
		}).error( function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		});
	};
	
	 $scope.searchReset = function(){
			$scope.brandNameSelect='';
			$scope.serviceNameSelect='';
	 };
	
	 $scope.searchRecords = function (){
		 	$scope.currentPage = 0;
		 	paginationService.loadPageCounts($scope);
		 	var paginationParams = angular.extend({
		 		commonFactoryForRestCall: commonFactoryForRestCall,
		 		baseURL:endPointURL,
		 		propertiesConfig:propertiesConfig,
		 	});
		 	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		 };
		 
		 $scope.paginationParamsWithSearch = function(){
				return angular.extend({
					brandName: $scope.brandNameSelect,
					name:$scope.serviceNameSelect,
				});
			};
}]);

app.filter('isPublish', function() {
	return function(input) {
	  return input === true ? 'Enabled' : 'Disabled' ;
	};
});

app.filter('isPublishOpp', function() {
	return function(input) {
	  return input === true ? 'Disable' : 'Enable' ;
	};
});


;app.controller('servicesReportCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService',
    function($scope,propertiesConfig,commonFactoryForRestCall,paginationService) {
    $scope.loadingIcon = false;
    $scope.servicesDetails = '';
    $scope.serviceError=false;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    $scope.monthsArray = propertiesConfig.details.months;
    $scope.date = new Date();
    $scope.month = $scope.date.getMonth();
    $scope.monthName = '';
    $scope.year = $scope.date.getFullYear();
    for(var loop =0 ; loop<$scope.monthsArray.length;loop++){
        if($scope.month == $scope.monthsArray[loop].number){
            $scope.months = $scope.monthsArray[loop].number+' '+$scope.monthsArray[loop].monthName;
            $scope.monthNames = $scope.monthsArray[loop].monthName;
            break;
        }
    }
    var baseReportingURL = propertiesConfig.details.baseReportingURL;
    var endPointURL = propertiesConfig.details.topServices;
    endPointURL = baseReportingURL+endPointURL;
    $scope.currentPage = 0;
    paginationService.loadPageCounts($scope);
    var paginationParams = angular.extend({
        commonFactoryForRestCall: commonFactoryForRestCall,
        baseURL: endPointURL,
        propertiesConfig:propertiesConfig
       
    });

    var params = angular.extend({
        page: $scope.currentPage,
        size:$scope.noOfitems,
        monthNumber: $scope.month,
        year: $scope.date.getFullYear()
    });
    $scope.onMonthChange = function(months) {
        $scope.month = months.split(" ")[0];
        $scope.monthNames = months.split(" ")[1];
        params = {
            monthNumber: $scope.month,
            year: $scope.year,
            page: $scope.currentPage,
            size:$scope.noOfitems
        };
        paginationService.getPageData($scope,paginationParams,params);
    };
    paginationService.getPageData($scope,paginationParams,params);

    $scope.prevPage = function () {
        paginationService.prevPage($scope,paginationParams,params);
    };

    $scope.nextPage = function () {
        if($scope.currentPage < $scope.noOfPages-1 ){
            paginationService.nextPage($scope,paginationParams,params);
        } else{
            return false;
        }
    };

    $scope.setPage = function () {
        paginationService.setPage($scope,paginationParams,this,params);
    };

    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
        paginationService.getPageData($scope, paginationParams,params);
    };
}]);;app.controller('settingsCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','responseMessageService','$timeout','factoryForRoleBasedFeature',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,responseMessageService,$timeout,factoryForRoleBasedFeature) {
    $scope.showTaxEditMode = false;
    $scope.showConfigEditMode = false;
    $scope.showSurchargeEditMode = false;
    $scope.showDistributorEditMode = false;
    $scope.taxPercentage = 10;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.settingsForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
    //Tax Settings
    $scope.showTaxEditModeView = function(flag){
    	if(flag){
    		$scope.taxDetails.$original =  angular.copy($scope.taxDetails);
    	}
        $scope.showTaxEditMode = flag;
    };
    $scope.cancelTaxDetails= function(taxDetails){
    	angular.copy($scope.taxDetails.$original, taxDetails);
    	$scope.showTaxEditModeView(false);
    };
    
    //Config Settings
    $scope.showConfigEditModeView = function(flag){
    	if(flag){
    		$scope.orderPrefixDetails.$original = angular.copy($scope.orderPrefixDetails);
    		$scope.invoicePrefixDetails.$original =  angular.copy($scope.invoicePrefixDetails);
    		$scope.currencyDetails.$original =  angular.copy($scope.currencyDetails);
    	}
        $scope.showConfigEditMode = flag;
    };    
    $scope.cancelConfigDetails= function(orderPrefixDetails,invoicePrefixDetails,currencyDetails){
    	angular.copy($scope.orderPrefixDetails.$original, orderPrefixDetails);
    	angular.copy($scope.invoicePrefixDetails.$original, invoicePrefixDetails);
    	angular.copy($scope.currencyDetails.$original, currencyDetails);
    	$scope.showConfigEditModeView(false);
    };
    $scope.reset = function() {
        $scope.configDetails.orderPrefix = "";
        $scope.configDetails.invoicePrefix = "";
    };
    
    //Surcharge settings
    $scope.showSurchargeEditModeView = function(flag){
    	if(flag){
    		$scope.amexSurcharge.$original = angular.copy($scope.amexSurcharge);
    		$scope.masterSurcharge.$original = angular.copy($scope.masterSurcharge);
    		$scope.visaSurcharge.$original = angular.copy($scope.visaSurcharge);
    	}
        $scope.showSurchargeEditMode = flag;
    };    
    $scope.cancelSurchargeDetails= function(amexSurcharge,masterSurcharge,visaSurcharge){
    	angular.copy($scope.amexSurcharge.$original, amexSurcharge);
    	angular.copy($scope.masterSurcharge.$original, masterSurcharge);
    	angular.copy($scope.visaSurcharge.$original, visaSurcharge);
    	$scope.showSurchargeEditModeView(false);
    };
    $scope.reset = function() {
        $scope.amexSurcharge = "";
        $scope.masterSurcharge = "";
        $scope.visaSurcharge = "";
    };
    
    //Distributor company settings
    $scope.showDistributorEditModeView = function(flag){
    	if(flag){
    		$scope.distributorDetails.$original = angular.copy($scope.distributorDetails);
  	}
        $scope.showDistributorEditMode = flag;
    };    
    $scope.cancelDistributorDetails= function(distributorDetails){
    	angular.copy($scope.distributorDetails.$original, distributorDetails);
    	$scope.showDistributorEditModeView(false);
    };
    $scope.reset = function() {
        $scope.distributorDetails.data = "";
    };
    
    var baseURL = propertiesConfig.details.baseURL;
    var endPointURL = baseURL+propertiesConfig.details.businessRules;
    
    $scope.loadDetails = function(){
	    commonFactoryForRestCall.getURL(endPointURL).get(undefined,undefined, function(data,status,headers,config) {
	    	$scope.taxDetails = {};
	    	$scope.orderPrefixDetails = {};
	    	$scope.invoicePrefixDetails = {};
	    	$scope.currencyDetails = {};
	    	$scope.amexSurcharge = {};
	    	$scope.masterSurcharge = {};
	    	$scope.visaSurcharge = {};
	    	$scope.distributorDetails = {};
	    	
	    	angular.forEach(data.content, function(content) {
	    	    if(content.ruleName === 'GST'){
	    	    	  $scope.taxDetails.countryName = 'Australia';
	    	    	  $scope.taxDetails.value=content.ruleValue;
	    	    	  $scope.taxDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'ORDER_PREFIX'){
	    	    	$scope.orderPrefixDetails.value=content.ruleValue;
	    	    	$scope.orderPrefixDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'INVOICE_PREFIX'){
	    	    	$scope.invoicePrefixDetails.value=content.ruleValue;
	    	    	$scope.invoicePrefixDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'CURRENCY'){
	    	    	$scope.currencyDetails.value=content.ruleValue;
	    	    	$scope.currencyDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'AMEX_SURCHARGE'){
	    	    	$scope.amexSurcharge.value=content.ruleValue;
	    	    	$scope.amexSurcharge.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'MASTER_SURCHARGE'){
	    	    	$scope.masterSurcharge.value=content.ruleValue;
	    	    	$scope.masterSurcharge.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'VISA_SURCHARGE'){
	    	    	$scope.visaSurcharge.value=content.ruleValue;
	    	    	$scope.visaSurcharge.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'DISTRIBUTOR_NAME'){
	    	    	$scope.distributorDetails.data=content.resource;
	    	    	$scope.distributorDetails.id=content.ruleId;
	    	    }
	    	});
	    	
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; });
    };
   
    var updateBusinessRule = function(id,value,callLoadDetailsFlag,configType,type){
    	 var params ={};
    	if(type==='DISTRIBUTOR_NAME'){
    		 params= {ruleId :id,  resource:value};
    	}else{
    		params= {ruleId :id,  ruleValue:value};
    	}
		 commonFactoryForRestCall.getURL(endPointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
			 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
			 if(callLoadDetailsFlag){
				 $scope.loadDetails();
			 }
			 responseMessageService.showResponseMsg(configType + propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		 }, function(data,status,headers,config) { 
			 if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			 });
    };
    $scope.updateTaxGST = function(taxDetails) {
   	 delete $scope.taxDetails.$original;
   	var configType = propertiesConfig.details.taxSettingsMsg;
   	updateBusinessRule(taxDetails.id,taxDetails.value,true,configType);
    $scope.showTaxEditModeView(false); 
	
   };
    
    $scope.saveOrderInvoiceConfig = function(orderPrefixDetails,invoicePrefixDetails,currencyDetails) {
    	var configType = propertiesConfig.details.configSettingsMsg;
    	 delete $scope.orderPrefixDetails.$original;
    	 delete $scope.invoicePrefixDetails.$original;
    	 delete $scope.currencyDetails.$original;
    	 updateBusinessRule(orderPrefixDetails.id,orderPrefixDetails.value,false,configType);
    	 updateBusinessRule(invoicePrefixDetails.id,invoicePrefixDetails.value,false,configType);
    	 updateBusinessRule(currencyDetails.id,currencyDetails.value,true,configType);
    	 $scope.showConfigEditModeView(false);
		 
    };
    $scope.updateSurchageDetails = function(amexSurcharge,masterSurcharge,visaSurcharge){
    	var configType = propertiesConfig.details.surchargeSettingsMsg;
	   	 delete $scope.amexSurcharge.$original;
	   	 delete $scope.masterSurcharge.$original;
	   	 delete $scope.visaSurcharge.$original;
	     updateBusinessRule(amexSurcharge.id,amexSurcharge.value,false,configType);
	     updateBusinessRule(masterSurcharge.id,masterSurcharge.value,false,configType);
	     updateBusinessRule(visaSurcharge.id,visaSurcharge.value,true,configType);
	     $scope.showSurchargeEditModeView(false);
   };
   
   $scope.updateDistributor = function(distributorDetails){
	   var configType = propertiesConfig.details.distributorSettingsMsg;
	   	 delete $scope.distributorDetails.$original;
	     updateBusinessRule(distributorDetails.id,distributorDetails.data,false,configType,"DISTRIBUTOR_NAME");
	     $scope.showDistributorEditModeView(false);
		
 };
}]);
;app.controller('userProfileCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','responseMessageService','$timeout','$cookies'
	,function($scope,propertiesConfig,commonFactoryForRestCall,$state,responseMessageService,$timeout,$cookies) {
	var baseURL = propertiesConfig.details.baseURL;
	$scope.loadingIcon = false;
	var endpointURL = baseURL + propertiesConfig.details.login;
	$scope.distributorId = $cookies.get(propertiesConfig.details.distributorId);
	var endpointGetURL = baseURL + propertiesConfig.details.userDetails;
	commonFactoryForRestCall.getURL(endpointGetURL).get({id:$scope.distributorId},undefined,function(data,status,headers,config) {
		$scope.firstName = data.firstName;
		$scope.lastName =  data.lastName;
		$scope.email = data.email;
		$scope.userRoleName =  data.userRoleName;
		$scope.password = data.password;
	}, function(error) {
		$scope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;
	});
	
	
	  $scope.reset = function() {
	        $scope.firstName = "";
	        $scope.lastName = "";
	    };
	    
	    $scope.resetChangePassword = function() {
	        $scope.oldPassword = "";
	        $scope.newPassword = "";
	        $scope.confirmPassword = "";
	    };
	    
	    $scope.saveNameChanges = function() {
	    	$scope.loadingIcon = true;
	    	var endpointURL = baseURL + propertiesConfig.details.userDetails;
	    	var params = { firstName : $scope.firstName, lastName: $scope.lastName,distributorId:$scope.distributorId,email:$scope.email};
			 commonFactoryForRestCall.getURL(endpointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
				 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
				 commonFactoryForRestCall.getURL(endpointURL).get({id:$scope.distributorId},function(data,status,headers,config) {
					 $scope.firstName = data.firstName;
					 $scope.lastName =  data.lastName;
					 $cookies.put(propertiesConfig.details.firstName,$scope.firstName);
					 $scope.loadingIcon = false;
					 $scope.$emit('updateFirstNameEvent');
				 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				 $scope.loadingIcon = false;});
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			 $scope.loadingIcon = false;});
	    };
	    
	    
	   $scope.saveChangePassword = function() {
	    	var endpointURL = baseURL + propertiesConfig.details.changePassword;
	    	var params = { oldPassword : $scope.oldPassword, newPassword: $scope.newPassword, confirmPassword:$scope.confirmPassword,distributorId:$scope.distributorId};
			 commonFactoryForRestCall.getURL(endpointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
				 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
				 $scope.resetChangePassword();
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				 });
	    };
	    
}]);