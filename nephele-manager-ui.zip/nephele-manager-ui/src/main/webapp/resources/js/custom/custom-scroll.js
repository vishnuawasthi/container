 $(document).ready(function(){
    $("html").niceScroll({cursorcolor:"#0f365e"});
	// $(".scroll-pane-content").niceScroll();
    $(".scroll-pane-content").niceScroll({cursorcolor:"#000"});
 });