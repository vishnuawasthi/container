app.directive('datePicker', ['$compile','propertiesConfig',function($compile,propertiesConfig) {
	  var controllerName = 'dateEditCtrl';
	  return {
	      restrict: 'A',
	      require: '?ngModel',
	      scope: true,
	      link: function(scope, element) {
	          var wrapper = angular.element(
	              '<div class="input-group">' +
	                '<span class="input-group-btn">' +
	                  '<button type="button" class="btn btn-default" ng-click="' + controllerName + '.openPopup($event)"><i class="glyphicon glyphicon-calendar"></i></button>' +
	                '</span>' +
	              '</div>');

	          function setAttributeIfNotExists(name, value) {
	              var oldValue = element.attr(name);
	              if (!angular.isDefined(oldValue) || oldValue === false) {
	                  element.attr(name, value);
	              }
	          }
	          setAttributeIfNotExists('type', 'text');
	          setAttributeIfNotExists('is-open', controllerName + '.popupOpen');
	          setAttributeIfNotExists('show-weeks', propertiesConfig.details.falseStr);
	          setAttributeIfNotExists('date-formate', propertiesConfig.details.dateFormate);
	          setAttributeIfNotExists('datepicker-options' ,propertiesConfig.details.dateOptions);
	          setAttributeIfNotExists('datepicker-popup', propertiesConfig.details.dateFormate);
	          setAttributeIfNotExists('close-text', propertiesConfig.details.close);
	          setAttributeIfNotExists('clear-text', propertiesConfig.details.clear);
	          setAttributeIfNotExists('current-text', propertiesConfig.details.today);
	          element.addClass('form-control');
	          element.removeAttr('date-picker');
	        
	          element.after(wrapper);
	          wrapper.prepend(element);
	          $compile(wrapper)(scope);

	          scope.$on('$destroy', function () {
	              wrapper.after(element);
	              wrapper.remove();
	          });
	      },
	      controller: function($scope) {
	          this.popupOpen = false;
	          this.openPopup = function($event) {
	        	  if(!this.popupOpen){
	        		  $event.preventDefault();
                      $event.stopPropagation();
                      this.popupOpen = true;
                    }
	          };
	          $scope.format = propertiesConfig.details.dateFormate;
	          $scope.dateOptions = $scope.dateOptions || {
	              formatYear: 'yy',
	              startingDay: 1,
	              showWeeks: false
	          };
	      },
	      controllerAs: controllerName
	  };
	}]);
app.directive('dateFormat', ['dateFilter',function (dateFilter) {
	return {
		require:'^ngModel',
		restrict:'A',
		link:function (scope, elm, attrs, ctrl) {
			ctrl.$parsers.unshift(function (viewValue) {
				if(viewValue!=null){
					viewValue.toString = function() {
						return dateFilter(this, attrs.dateFormat);
					}
				}
				return viewValue;
			});
		}
	};
}]);
