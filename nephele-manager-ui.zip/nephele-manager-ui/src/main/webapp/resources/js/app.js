var app = angular.module('nepheleAdminApp', ['ngResource','ngCookies','ui.router','xeditable','ngTouch','ui.bootstrap','ngAnimate','ngIdle']);

// This used to store stateProvider in the variable on startup
app.constant('stateProviderConstant', { key: '' });
// This used to store all the constants in the variable on startup
app.constant('propertiesConfig', { details: [] });
//This used to store apiKey after login
//app.constant('apiKey', { key: '' });
// This is used to store the apiHeaders
app.constant('apiHeaders', { headers: {} });

// Config is used to load all the states object(navigation) and interceptor
app.config(['$locationProvider', '$stateProvider','$httpProvider','stateProviderConstant','IdleProvider',function ($locationProvider, $stateProvider,$httpProvider,stateProviderConstant,IdleProvider) {
	  IdleProvider.idle(1795);
	  IdleProvider.timeout(5);
	  $locationProvider.html5Mode(true);
	  stateProviderConstant.key = $stateProvider;
	  $httpProvider.interceptors.push('authHttpResponseInterceptor');
	  $httpProvider.interceptors.push('apiKeyInterceptor');
	}]);

// This block is used to load all the states into stateProvider
app.run(['$state', '$http','onLoadPage','stateProviderConstant','propertiesConfig','$rootScope','$stateParams','urlJson','$cookies',
         			function ($state, $http,onLoadPage,stateProviderConstant,propertiesConfig,$rootScope,$stateParams,urlJson,$cookies){


	$http.get('resources/constants/restUrlConfig.txt').success(function(data,status,headers,config) {
		angular.extend(propertiesConfig.details, data);
	}).error(function(data,status,headers,config) {
		propertiesConfig.details = [];
	});
	$http.get('resources/constants/constants.txt').success(function(data,status,headers,config) {
		angular.extend(propertiesConfig.details, data);
	}).error(function(data,status,headers,config) {
	});

	$http.get("resources/constants/states.json").success(function(data,status,headers,config){
		angular.forEach(data, function (value, key){
			var state = {
				"url": value.url,
				"controller" : value.controller,
				"templateUrl": value.templateUrl,
				"params": {}
			};
			angular.forEach(value.params, function (value, keys){
				state.params = {
					keys : value
				};
			});
			stateProviderConstant.key.state(value.name, state);
		});
		if((urlJson != null && urlJson != undefined) && urlJson !='notNull'){
			var jsonObj = JSON.parse(urlJson);
			for(var keyName in jsonObj){
				propertiesConfig.details[keyName] = jsonObj[keyName];
			}
		}else{
			$state.get(propertiesConfig.details.index).params.message = propertiesConfig.details.fileMissingMsg;
			$state.get(propertiesConfig.details.index).params.urlJsonMissing = true;
			$state.go(propertiesConfig.details.index);
		}
		var stateExists = $state.get(onLoadPage);
		onLoadPage = (stateExists!= null && stateExists!= undefined) ? onLoadPage: 'index';
		if(onLoadPage != 'index' && onLoadPage !=  'resetPassword'){
			$state.get('manager').params.navigate = onLoadPage;
			$state.go('manager');
		}else{
			$state.go(onLoadPage);
		}
	});
	$rootScope.$state = $state;
	$rootScope.$stateParams = $stateParams;
	$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){
		//console.log('testApp#run#stateChangeStart; from:', fromState.name, ' to:', toState.name,' onLoadPage:',onLoadPage);
		if(toState.name == propertiesConfig.details.manager){
			$state.go((fromState.name!= undefined && fromState.name != '')?fromState.name:onLoadPage);
		}
		// Need to write the back button disable logic
	});
}]);



// Interceptor is used for redirect to login page if response status code is 401
app.factory('authHttpResponseInterceptor',['$q','$location','$cookies','propertiesConfig','removeCookiesService','onLoadPage',function($q,$location,$cookies,propertiesConfig,removeCookiesService,onLoadPage){
	return {
		response: function(response){
			if (response.status === 401) {
				console.log("Response 401");
			}
			return response || $q.when(response);
		},
		responseError: function(rejection) {
			if (rejection.status === 401) {
				console.log("Response Error 401",rejection);
				$cookies.remove(propertiesConfig.details.apiKey);
				removeCookiesService.removeAllCookies();
				$location.path(propertiesConfig.details.slashIndex);
				 onLoadPage = '';
			}
			return $q.reject(rejection);
		}
	};
}]);
// Below block is used for to send api key for all the apis after login
app.factory('apiKeyInterceptor',['$cookies','propertiesConfig',function($cookies,propertiesConfig){
    return {
    	'request': function(config) {
    			var apiKey = $cookies.get(propertiesConfig.details.apiKey);
    			if (apiKey!=null) {
          			 config.headers[propertiesConfig.details.apikeyServer] = apiKey;
    			} 
    		return config;
    	}
    };
}]);

// Application first controller to load necessary dependencies to the application (i.e constants, ...)
app.controller('appLoadController', ['$scope', 'propertiesConfig','urlPropertiesService','$state','$cookies','$rootScope','onLoadPage','Idle','sessionExpireService','responseMessageService','$timeout','factoryForRoleBasedFeature','roleFlagService','platformCurrencyService',
	function($scope, propertiesConfig,urlPropertiesService,$state,$cookies,$rootScope,onLoadPage,Idle,sessionExpireService,responseMessageService,$timeout,factoryForRoleBasedFeature,roleFlagService,platformCurrencyService ) {
	var idExistFlag = false;
	if(onLoadPage != propertiesConfig.details.index && onLoadPage != propertiesConfig.details.resetPassword){
		//apiKey.key=$cookies.get('apiKey');
		var urlJsonService =  urlPropertiesService.getProperties();
		if($scope.firstName === undefined){
			$scope.firstName = $cookies.get(propertiesConfig.details.firstName);
		}
		urlJsonService.success(function(data,status,headers,config) {
			if(data.indexOf(onLoadPage) >= 0){
				$state.get(onLoadPage).params.id = $cookies.get(propertiesConfig.details.id);
				$state.get(onLoadPage).params.name = $cookies.get(propertiesConfig.details.name);
				$state.get(onLoadPage).params.isPublished = $cookies.get(propertiesConfig.details.isPublished);
				if($cookies.get(propertiesConfig.details.id)){
					idExistFlag = true;
				}
			}
		});
		urlJsonService.error(function(data,status,headers,config) {
			 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		});
	}	
	if(($cookies.get( propertiesConfig.details.salesCurrency) == undefined )||($cookies.get( propertiesConfig.details.salesCurrency) == '' )){
		platformCurrencyService.getCurrencyCode($scope);
	}
	var roleBasedPermissions = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.roleBasedAll);
    roleFlagService.assignFlagToScope(roleBasedPermissions,$scope,propertiesConfig);
	Idle.watch();
	$rootScope.$on('IdleTimeout', function() { 
		  sessionExpireService.callExpire(propertiesConfig.details.sessionExpiredMsg);
	});
	$scope.firstName =  $cookies.get( propertiesConfig.details.firstName);
	$scope.loadingIcon = true;
	$scope.userProfileSettings = function(){
		$scope.firstName =  $cookies.get( propertiesConfig.details.firstName);
		$state.go('manager.profileSettings');
	};
	$scope.$on('updateFirstNameEvent', function(e) {
		$scope.firstName =  $cookies.get(propertiesConfig.details.firstName);
		$state.go('manager.profileSettings');
	 });
	var navigate =  $state.get(propertiesConfig.details.manager).params.navigate;
	 $state.go((navigate!= undefined ) ? navigate :'manager.dashBoard');
	  $scope.footerMessage = propertiesConfig.details.footerMessage;
	  //&& idExistFlag

}]);
