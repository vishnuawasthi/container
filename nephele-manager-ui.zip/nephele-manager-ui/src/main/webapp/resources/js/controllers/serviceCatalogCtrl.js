//This controller is to view data of service Catalogs
app.controller('serviceCatalogCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','paginationService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
	function($scope,propertiesConfig,commonFactoryForRestCall,$state,paginationService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
	$scope.loadingIcon = false;
    $scope.servicesDetails = '';
    $scope.serviceError=false;
	$scope.serviceForm = {};
	$scope.updateForm = {};
    var paginationParams ;
    $scope.vendorCurrencyOptions = ['AUD', 'USD'];
    var baseURL = propertiesConfig.details.baseURL;
	var endPointURL = propertiesConfig.details.serviceCatalog; 
	endPointURL=baseURL+endPointURL;
	$scope.currentPage = 0;
	$scope.resultsCount = 0;
	$scope.createServicePopUP = false;
	$scope.editServicePopUP = false;
	$scope.categoryTextFlag = false;
	$scope.verticalTextFlag = false;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.timeZone = 'UTC';
	
	
	$scope.loadServiceDetails = function(){
		$scope.getServiceCategoryList();
		$scope.getIndustryVerticalList();
		$scope.getPageData();
	};
	 $scope.getPageData = function(){
			paginationService.loadPageCounts($scope);
			 paginationParams = angular.extend({
			   commonFactoryForRestCall: commonFactoryForRestCall,
		      baseURL: endPointURL,
		      propertiesConfig:propertiesConfig,
		   });
			paginationService.getPageData($scope,paginationParams);
	 }
		$scope.prevPage = function () {
			paginationService.prevPage($scope,paginationParams);
	    };
	    $scope.nextPage = function () {
	   	 if($scope.currentPage < $scope.noOfPages-1 ){
	   	 paginationService.nextPage($scope,paginationParams);
	   	 }else{
	   		 return false;
	   	 }
	    };
	    $scope.setPage = function () {
	    	paginationService.setPage($scope,paginationParams,this);
	    };
	    $scope.pageSizeChange = function () {
	    	$scope.currentPage = 0;
	    	paginationService.getPageData($scope,paginationParams);
	    };

    $scope.configCredentials = function (services) {
    	if(services.vendorCurrency != undefined){
			$cookies.put(propertiesConfig.details.vendorCurrency,services.vendorCurrency);
		}
		if(services.integrationCode != undefined){
        	$cookies.put(propertiesConfig.details.integrationCode,services.integrationCode);
        }
		if(services.name != undefined){
        	$cookies.put(propertiesConfig.details.serviceName,services.name);
        }
		$cookies.put(propertiesConfig.details.id,services.serviceId);
    	$state.go('manager.setupcredentials');
    };


	var serviceCategoryURL =baseURL+ propertiesConfig.details.serviceCategory; 
	
	$scope.getServiceCategoryList = function(){
			commonFactoryForRestCall.getURL(serviceCategoryURL).get(undefined,undefined, function(data,status,headers,config) {
				$scope.serviceCategoryList = [];
				$scope.serviceCategory={};
				$scope.serviceCategory.categoryId = '0';
				$scope.serviceCategory.name = propertiesConfig.details.createNew;
			$scope.serviceCategoryList.push($scope.serviceCategory);
				for(var loop = 0; loop<data.content.length;loop++){
					$scope.serviceCategoryList.push(data.content[loop]);
				}
					$scope.loadingIcon = false;
				}, function(data,status,headers,config) {
					if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
					$scope.loadingIcon = false;
			    });
	}
	
	var industryVerticalURL = baseURL + propertiesConfig.details.industryVertical; 
	
	$scope.getIndustryVerticalList = function(){
		commonFactoryForRestCall.getURL(industryVerticalURL).get(undefined,undefined, function(data,status,headers,config) {
			$scope.industrialVerticalList=[];
			$scope.industrialVertical = {};
			$scope.industrialVertical.verticalsId = '0';
			$scope.industrialVertical.name = propertiesConfig.details.createNew;
			$scope.industrialVerticalList.push($scope.industrialVertical);
			for(var loop = 0; loop<data.content.length;loop++){
				$scope.industrialVerticalList.push(data.content[loop]);
			}
			$scope.loadingIcon = false;
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
	    });
	}
	$scope.serviceCategoryChange = function(serviceCategory){
		$scope.serviceCategory = {};
		if($scope.editServicePopUP == true){
			$scope.updateService.serviceCategory = serviceCategory.split(",")[1];
		}else{
			$scope.service.serviceCategory = serviceCategory.split(",")[1];
		}
		$scope.categoryName = serviceCategory.split(",")[1];
		$scope.categoryTextFlag= (serviceCategory.split(",")[1] == propertiesConfig.details.createNew)?true: false;
		$scope.categoryID = serviceCategory.split(",")[0];
	};

	$scope.industryVerticalChange = function(industryVertical){
		$scope.industryVertical = {};
		if($scope.editServicePopUP == true){
			$scope.updateService.industryVertical = industryVertical.split(",")[1];
		}else{
			$scope.service.industryVertical = industryVertical.split(",")[1];
		}
		$scope.verticalTextFlag= (industryVertical.split(",")[1]== propertiesConfig.details.createNew)?true: false;
		$scope.verticalsID = industryVertical.split(",")[0];
		$scope.verticalName = industryVertical.split(",")[1];
	};

    $scope.showCreateServicePopUP = function(flag){
    	$scope.createServicePopUP = flag;
    	$scope.categoryTextFlag=false;
    	$scope.verticalTextFlag=false;
    	$scope.service={};
    	$scope.invalidSubmitAttempt = false;
    	 $scope.service.vendorCurrency = 'AUD';
    	 if(!flag){
    		 $scope.service.serviceCategory = '';
    		 $scope.service.industryVertical = '';
    		 $scope.categoryTextFlag = false;
    		 $scope.verticalTextFlag = false;
    		 $scope.serviceForm.submitted = false;
    	 }
    };

    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
    };

    $scope.showEditServicePopUP = function(flag,services){
    	$scope.editServicePopUP = flag;
    	$scope.updateForm.submitted= false;
    	 $scope.updateService ={};
    	if(flag && services!= undefined){
    	 $scope.updateService.name= services.name;
		 $scope.updateService.brandName=services.brandName;
		 $scope.updateService.serviceCode=services.serviceCode;
		 $scope.updateService.integrationCode=services.integrationCode;
		 $scope.updateService.vendorCode=services.vendorCode;
		 $scope.updateService.vendorCurrency=services.vendorCurrency;
		
		 $scope.updateService.serviceId =services.serviceId;
		 $scope.updateService.serviceProviderId=services.serviceProviderId;
		 //$scope.updateService.brandCode=services.brandCode;
		 $scope.updateService.planPrefix=services.planPrefix;
		 $scope.updateService.subscriptionNamePrefix=services.subscriptionNamePrefix;
		 	if($scope.serviceCategoryList != undefined){
	          for(var loop = 0; loop<$scope.serviceCategoryList.length;loop++){
	        	  if(services.serviceCategoryId == $scope.serviceCategoryList[loop].categoryId){
						 $scope.updateService.serviceCategory = $scope.serviceCategoryList[loop].name;
					 }
     		   	   }
     		   }
	     if($scope.industrialVerticalList != undefined){
   	          for(var loop = 0; loop<$scope.industrialVerticalList.length;loop++){
   	        	 if(services.serviceIndustryVerticalId == $scope.industrialVerticalList[loop].verticalsId){
    				 $scope.updateService.industryVertical = $scope.industrialVerticalList[loop].name;
    			 }
        		   	   }
        		   }
	    	}
    	
    	if(!flag){
    		 $scope.updateService.serviceCategory = '';
    		 $scope.updateService.industryVertical = '';
    		 $scope.categoryTextFlag = false;
    		 $scope.verticalTextFlag = false;
    	}
    };
    
    $scope.createNewService = function(service, serviceForm){
    //Form validations
        if(serviceForm.$invalid) {
          $scope.invalidSubmitAttempt = true;
          return;
        }
    	$scope.loadingIcon = true;
		 var params = {};
		 var endPointprovidertURL = baseURL+propertiesConfig.details.serviceProvider;
		
		 params = { brandName:service.brandName,brandCode:service.brandCode};
		 var verticalParams = {};
		 var categoryParams ={};
		 var postCategory =false;
		 var postVertical =false;
		 commonFactoryForRestCall.getURL(endPointprovidertURL).post(undefined,JSON.stringify(params),function(data,status,headers,config) {
				$scope.newServiceProviderId =  data.serviceProviderId;
			if($scope.categoryID  == '0'){
				 categoryParams = {
						  name:service.serviceCategorytxt
				 }
				 commonFactoryForRestCall.getURL(serviceCategoryURL).post(undefined,JSON.stringify(categoryParams),function(data,status,headers,config) {
						$scope.categoryID = data.categoryId;
						 postCategory = true;
						 $scope.createService(postCategory,postVertical,service);
						 $scope.getServiceCategoryList();
				 }, function(data,status,headers,config) {
					 	$scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				 		$scope.loadingIcon = false;
				 	});
				 
			}else{
				postCategory = true;
			};
				
			if( $scope.verticalsID =='0'){
				 verticalParams = {
						 name :service.industryVerticaltxt
				 };
				 commonFactoryForRestCall.getURL(industryVerticalURL).post(undefined,JSON.stringify(verticalParams),function(data,status,headers,config) {
					$scope.verticalsID = data.verticalsId;
					postVertical = true;
					$scope.getIndustryVerticalList();
					 $scope.createService(postCategory,postVertical,service);
				 }, function(data,status,headers,config) {
					 	$scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				 		$scope.loadingIcon = false;
				 	});
			}else{
				postVertical = true;
			};
			 $scope.createService(postCategory,postVertical,service);
			 
		 }, function(data,status,headers,config) {
			 if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
				  $scope.createServicePopUP = true;
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			 $scope.loadingIcon = false;
			});
	 };
	 
	 $scope.createService = function(postCategory,postVertical,service){
		 var endPointServiceURL = baseURL+propertiesConfig.details.serviceCatalog;
		 if( postCategory== true && postVertical == true){
			 serviceParams = { brandName:service.brandName,name:service.name,serviceCode:service.serviceCode,integrationCode:service.integrationCode,vendorCode:service.vendorCode,vendorCurrency:service.vendorCurrency,serviceProviderId:$scope.newServiceProviderId,planPrefix:service.planPrefix,subscriptionNamePrefix:service.subscriptionNamePrefix,serviceCategoryId: $scope.categoryID , serviceIndustryVerticalId: $scope.verticalsID,timeZone:$scope.timeZone};
			 commonFactoryForRestCall.getURL(endPointServiceURL).post(undefined,JSON.stringify(serviceParams),function(data,status,headers,config) {
				 $scope.createServicePopUP = false;
				 $scope.getPageData();
				 $scope.loadingIcon = false;
				 responseMessageService.showResponseMsg(propertiesConfig.details.cloudServiceMsg+propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 }, function(data,status,headers,config) {
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else if(data.status === 500){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
					  $scope.createServicePopUP = true;
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			 		$scope.loadingIcon = false;
			 	});
		 }
	 };
	 
	 $scope.updateCloudService = function(service){
		 var postCategory =false;
		 var postVertical =false;
		 var params = {};
		 $scope.loadingIcon = true;
		 if($scope.categoryID  == '0'){
			 categoryParams = {
					  name:service.serviceCategorytxt
			 }
			 commonFactoryForRestCall.getURL(serviceCategoryURL).post(undefined,JSON.stringify(categoryParams),function(data,status,headers,config) {
					$scope.categoryID = data.categoryId;
					 postCategory = true;
					 $scope.updateServices(postCategory,postVertical,service);
					 $scope.getServiceCategoryList();
			 }, function(data,status,headers,config) {
				 	$scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			 		$scope.loadingIcon = false;
			 	});
		}else{postCategory = true; }
			
		if( $scope.verticalsID =='0'){
			 verticalParams = {
					 name :service.industryVerticaltxt
			 };
			 commonFactoryForRestCall.getURL(industryVerticalURL).post(undefined,JSON.stringify(verticalParams),function(data,status,headers,config) {
				$scope.verticalsID = data.verticalsId;
				postVertical = true;
				$scope.getIndustryVerticalList();
				 $scope.updateServices(postCategory,postVertical,service);
			 }, function(data,status,headers,config) {
				 	$scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			 		$scope.loadingIcon = false;
			});
		}else{ postVertical = true; }
		$scope.updateServices(postCategory,postVertical,service);
	};
	
	$scope.updateServices = function(postCategory,postVertical,service){
		 if(postCategory== true && postVertical == true){
			 var endPointprovidertURL = baseURL+propertiesConfig.details.serviceProvider;
			 params = {serviceProviderId:service.serviceProviderId, brandName:service.brandName};
			 commonFactoryForRestCall.getURL(endPointprovidertURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
				 var endPointServiceURL = baseURL+propertiesConfig.details.serviceCatalog; 
				 serviceParams = {serviceId:service.serviceId,brandName:service.brandName,name:service.name,planPrefix:service.planPrefix,subscriptionNamePrefix:service.subscriptionNamePrefix,vendorCode:service.vendorCode,vendorCurrency:service.vendorCurrency,integrationCode:service.integrationCode,serviceCode:service.serviceCode,serviceCategoryId: $scope.categoryID , serviceIndustryVerticalId: $scope.verticalsID};
				 commonFactoryForRestCall.getURL(endPointServiceURL).put(undefined,JSON.stringify(serviceParams),function(data,status,headers,config) {
					 $scope.editServicePopUP = false;
					 $scope.getPageData();
					 $scope.loadingIcon = false; 
				 }, function(data,status,headers,config) {
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					 	$scope.loadingIcon = false; 
				 	});
				 responseMessageService.showResponseMsg(propertiesConfig.details.cloudServiceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 }, function(data,status,headers,config) { 
				 $scope.editServicePopUP = false;
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else if(data.status === 500){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			 		$scope.loadingIcon = false;
			 });
		 }
	}
	

	$scope.populateBrandNameList = function(brandNameSelect){
		var listOfBranEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.serviceProvidersSearch;
		var serviceProviderSearchParams = angular.extend({
			brandName: brandNameSelect
		});
		commonFactoryForHttp.getURL('GET',listOfBranEndPointURL,serviceProviderSearchParams).success(function(data, status, headers, config) {
			$scope.listofBrandNames =data;
		}).error( function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		});
	};
	$scope.populateServiceNameList = function(serviceNameSelect){
		var listOfServiceEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.serviceSearch;
		var serviceSearchParams = angular.extend({
			serviceName: serviceNameSelect
		});
		commonFactoryForHttp.getURL('GET',listOfServiceEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
			$scope.listofServiceNames =data;
		}).error( function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		});
	};
	
	 $scope.searchReset = function(){
			$scope.brandNameSelect='';
			$scope.serviceNameSelect='';
	 };
	
	 $scope.searchRecords = function (){
		 	$scope.currentPage = 0;
		 	paginationService.loadPageCounts($scope);
		 	var paginationParams = angular.extend({
		 		commonFactoryForRestCall: commonFactoryForRestCall,
		 		baseURL:endPointURL,
		 		propertiesConfig:propertiesConfig,
		 	});
		 	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		 };
		 
		 $scope.paginationParamsWithSearch = function(){
				return angular.extend({
					brandName: $scope.brandNameSelect,
					serviceName:$scope.serviceNameSelect,
				});
			};
}]);

app.filter('isPublish', function() {
	return function(input) {
	  return input === true ? 'Enabled' : 'Disabled' ;
	};
});

app.filter('isPublishOpp', function() {
	return function(input) {
	  return input === true ? 'Disable' : 'Enable' ;
	};
});


