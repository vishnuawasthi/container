app.controller('billingCycleCtrl', ['$scope', 'commonFactoryForRestCall','propertiesConfig','$state','fileUpload','moduleActiveService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature',
	function ($scope, commonFactoryForRestCall,propertiesConfig,$state,fileUpload,moduleActiveService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature) {
	$scope.serviceError=false;
	$scope.showEditButton = true;
	var baseURL = propertiesConfig.details.baseURL;
	$scope.serviceId = $cookies.get(propertiesConfig.details.id);
	$scope.integrationCode= $cookies.get(propertiesConfig.details.integrationCode);
	$scope.serviceName= $cookies.get(propertiesConfig.details.serviceName);
	$scope.confirmationPopup=false;
	$scope.setBillingDay = true;
	$scope.loadingIcon = true;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var endpointURL = baseURL+propertiesConfig.details.serviceCatalog;
	var queryParams={};
	queryParams.id =  $scope.serviceId;
	moduleActiveService.getModulesData($scope);
	commonFactoryForRestCall.getURL(endpointURL).get(queryParams,undefined, function(data,status,headers,config) {
		$scope.billingDay= data.billingDay;
		$scope.timeZone=data.timeZone;
		if($scope.billingDay != null){
		    $scope.setBillingDay = false;
		}
		$scope.loadingIcon = false;
	}, function(data,status,headers,config) {
		if(data.status === 400){
			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.loadingIcon = false;
    });
	$scope.showConfirmationPopup = function(flag){
		$scope.confirmationPopup = flag;
	};
	$scope.editBillingDay = function(flag){
		$scope.setBillingDay = flag;
		$scope.newBillingDate = $scope.billingDay;
	};
	$scope.selectedDate = function(newBillingDate){
		$scope.newBillingDate = newBillingDate;
	};

	$scope.saveBillingDay = function(){
		$scope.confirmationPopup = true;
	};
	$scope.updateBillingDay = function(){
		$scope.loadingIcon = true;
		$scope.setBillingDay = true;
		$scope.confirmationPopup = false;
		var params = {};
		params.billingDay = $scope.newBillingDate;
		params.serviceId = $scope.serviceId;
		var endpointBillingURL = baseURL+propertiesConfig.details.updateBillingCycle;
		commonFactoryForRestCall.getURL(endpointBillingURL).put(undefined,params, function(data,status,headers,config) {
			$scope.billingDay = $scope.newBillingDate;
			$scope.setBillingDay = false;
			$scope.loadingIcon = false;
			responseMessageService.showResponseMsg(propertiesConfig.details.billingDayMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		}, function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			$scope.loadingIcon = false;
		});
	};
	$scope.uploadFile=function(myFile){
		$scope.loadingIcon = true;
		var importEndpointURL = baseURL + propertiesConfig.details.uploadMetering;
		$scope.exportSuccessMsg="";
		$scope.seviceErrorMsg="";
		var file = myFile;
		fileUpload.uploadFileToUrl(file, importEndpointURL).success(function(data, status, headers, config) {
			$scope.importSuccessMsg=propertiesConfig.details.importSuccessMsg;
			$scope.loadingIcon = false;
			responseMessageService.showResponseMsg(propertiesConfig.details.importSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		}).error(function(data, status, headers, config)  {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
		$scope.loadingIcon = false;
	};
	$scope.updateStatus = function(){
		$scope.loadingIcon = true;
		var service ={};
		var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		endPointServiceURL = baseURL+ endPointServiceURL;
		service.serviceId= $scope.serviceId;
		service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;
		if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
				commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				$scope.isPublished = !$scope.isPublished;
				responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
			},function(data,status,headers,config) {
				$scope.loadingIcon = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}else if($scope.isEnablePublish===false && service.isPublished==='true'){
			responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			$scope.loadingIcon = false;
		}
		$scope.statusConfirmationPopup = false;
	};
	$scope.statusConfirmationPopup = false;
	$scope.showStatusConfirmationPopup = function(flag){
		$scope.statusConfirmationPopup = flag;
		$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	};
}]);