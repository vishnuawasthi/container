app.controller('loginController',['$scope','propertiesConfig','commonFactoryForRestCall','$state','$cookies','$document','removeCookiesService' ,'onLoadPage',
	function($scope,propertiesConfig,commonFactoryForRestCall,$state,$cookies,$document,removeCookiesService,onLoadPage) {
	$scope.loadingIcon = false;
	 $scope.message = $state.get(propertiesConfig.details.index).params.message;
	 $scope.urlJsonMissing = $state.get(propertiesConfig.details.index).params.urlJsonMissing;
	$scope.footerMessage =propertiesConfig.details.footerMessage;
	$scope.authenticate=function(){
        if($scope.loginForm.$invalid) {
            $scope.invalidSubmitAttempt = true;
            return;
        }
		$scope.message = null;
		$scope.seviceErrorMsg= null;
		var baseURL = propertiesConfig.details.baseURL;
		var params = angular.extend({
			email: $scope.username,
			password:$scope.password
		});
		var endpointURL = baseURL + propertiesConfig.details.login;
		var apiHeaders = {
			'Accept': 'application/json'
		};
		$scope.loadingIcon = true;
		removeCookiesService.removeAllCookies();
		commonFactoryForRestCall.getURL(endpointURL,apiHeaders).post(params,function(data,status,headers,config) {
			//apiKey.key=data.apiKey;
			if($cookies.get( propertiesConfig.details.apiKey) == undefined ||$cookies.get( propertiesConfig.details.apiKey) ==''){
				onLoadPage = 'manager.dashBoard';
			}
			$cookies.put(propertiesConfig.details.apiKey,data.apiKey);
			$cookies.put(propertiesConfig.details.firstName,data.firstName);
			$cookies.put(propertiesConfig.details.distributorId,data.distributorId);
			$cookies.put(propertiesConfig.details.userRoleId,data.userRoleId);
			$cookies.putObject(propertiesConfig.details.roleBasedPermissions,data.permissions);
			$document[0].title = propertiesConfig.details.title;
			
			$state.go(propertiesConfig.details.manager);
		}, function(data,status,headers,config) {
			if(data.status === 401 ||data.status === 400){
				$scope.seviceErrorMsg = data.data.errorMessages[0];
			}else if(data.status === 500){
				$scope.seviceErrorMsg = (data.message!=null && undefined != data.message)?data.message:propertiesConfig.details.seviceErrorMsg;
			}else{
				$scope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;;
			}
			$scope.password='';
			$scope.loadingIcon = false;
		});
		
		
	};
}]);