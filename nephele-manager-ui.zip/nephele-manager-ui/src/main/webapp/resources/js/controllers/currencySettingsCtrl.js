app.controller('currencySettingsCtrl', ['$scope', 'commonFactoryForRestCall','propertiesConfig','$state','fileUpload','moduleActiveService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature','searchToggleService',
	function ($scope, commonFactoryForRestCall,propertiesConfig,$state,fileUpload,moduleActiveService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature,searchToggleService) {
	$scope.loadingIcon = true;
	$scope.serviceError=false;
	$scope.showEditButton = true;
	var baseURL = propertiesConfig.details.baseURL;
	$scope.loadingIcon = true;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var endpointURL = baseURL+propertiesConfig.details.currencyConversionRate;
    var auditLogURL = baseURL+propertiesConfig.details.auditLog;
	var currencyListURL = baseURL+propertiesConfig.details.currencyList;
	
	commonFactoryForRestCall.getURL(currencyListURL).get(undefined,undefined,function(data,status,headers,config){
		$scope.CurrencyList= data.currencyList;
		if(data != undefined){
					$scope.currencyList = data[0];
		}
	 });

	commonFactoryForRestCall.getURL(endpointURL).get(undefined,undefined, function(data,status,headers,config) {
		$scope.currencyData = data.content;
		$scope.loadingIcon = false;
	}, function(data,status,headers,config) {
		if(data.status === 400){
			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.loadingIcon = false;
	});

	$scope.addCurrencyConversion = function(){
	 if($scope.sourceCurrency==undefined || $scope.targetCurrency==undefined ||($scope.sourceCurrency==$scope.targetCurrency)){
    	   return false;
    	 }
    $scope.loadingIcon = true;
		var params={
			  sourceCurrency: $scope.sourceCurrency,
			  targetCurrency: $scope.targetCurrency
		};
		commonFactoryForRestCall.getURL(endpointURL).post(undefined,params, function(data,status,headers,config) {
			responseMessageService.showResponseMsg(propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			$scope.loadingIcon = false;
			$scope.reload();
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
	};

	 $scope.searchToggle = function(){
	    	searchToggleService.toggleSearch();
	    };

	$scope.resetCurrencyConversion = function(){
		$scope.sourceCurrency='';
		$scope.targetCurrency = '';
	};

	$scope.showHistoryPopup = function(flag){
		$scope.historyFlag= flag;
				commonFactoryForRestCall.getURL(auditLogURL).get(undefined,undefined, function(data,status,headers,config) {
					$scope.auditList = data.content;

					$scope.loadingIcon = false;
				}, function(data,status,headers,config) {
					if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
					$scope.loadingIcon = false;
				});
		}

	$scope.saveConversionRate = function($data,currency,conversionRate){
		var params={
			conversionRateId: currency.conversionRateId,
			conversionRate: $data.conversionRate
		};
		commonFactoryForRestCall.getURL(endpointURL).put(undefined,params, function(data,status,headers,config) {
			responseMessageService.showResponseMsg(propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			$scope.loadingIcon = false;
			$scope.showEditCurrencyConversion = false;
               		$scope.reload();
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
	};

	$scope.showUpdateCurrencyConversion = function(flag){
		$scope.showEditCurrencyConversion = flag;
		if(flag){
			$scope.currencyData.$original = angular.copy($scope.currencyData);
		}
	};
	$scope.cancelConversionRateUpdate= function(currencyData){
		angular.copy($scope.currencyData.$original, currencyData);
		$scope.showUpdateCurrencyConversion(false);

	};


	$scope.reload=function(){
		commonFactoryForRestCall.getURL(endpointURL).get(undefined,undefined, function(data,status,headers,config) {
			$scope.currencyData = data.content;
			$scope.loadingIcon = false;
			}, function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			$scope.loadingIcon = false;
		});
	};


}]);