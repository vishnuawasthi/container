app.controller('discountCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$stateParams','$state','moduleActiveService','$timeout','responseMessageService','$cookies','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$stateParams,$state,moduleActiveService,$timeout,responseMessageService,$cookies,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
    $scope.serviceError=false;
     $scope.planError=false;
	//$scope.loadingIcon = true;
	 $scope.percentage=/^(100(?:\.0{1,2})?|0*?\.\d{1,2}|\d{1,2}(?:\.\d{1,2})?)$/;
	 $scope.onlyNumbers = /^\-?\d+((\.|\,)\d+)?$/;
    var baseURL = propertiesConfig.details.baseURL;
    $scope.serviceId = $cookies.get(propertiesConfig.details.id);
    $scope.integrationCode= $cookies.get(propertiesConfig.details.integrationCode);
	$scope.serviceName= $cookies.get(propertiesConfig.details.serviceName);
	$scope.discountPlanPopUp = false;
	$scope.currentPage = 0;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.resultsCount = 0;
	$scope.showEditDiscount=false;
	$scope.viewSheet= false;
	$scope.search ={};
	$scope.custom ={};
	$scope.activation={};
	 $scope.showEditView = false;
	 $scope.listofStatus=['DRAFT','ACTIVE','SCHEDULED','INACTIVE','ARCHIVED'];
	var endPointURL = propertiesConfig.details.discountPremium; 
	endPointURL = baseURL + endPointURL
	$scope.loadDiscountTable = function(){
		$scope.loadingIcon = true;
		 paginationService.loadPageCounts($scope);
		 paginationParams = angular.extend({
		   commonFactoryForRestCall: commonFactoryForRestCall,
	       baseURL: endPointURL,
	       propertiesConfig:propertiesConfig
	       
	    });
		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		getModulesActive();
	};
	
	var getModulesActive = function(){
		 moduleActiveService.getModulesData($scope);
		 //$scope.loadingIcon = false;
	};
	
	$scope.prevPage = function () {
		paginationService.prevPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
    };
    $scope.nextPage = function () {
   	 if($scope.currentPage < $scope.noOfPages-1 ){
   	 paginationService.nextPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
   	 }else{
   		 return false;
   	 }
    };
    $scope.setPage = function () {
    	paginationService.setPage($scope,paginationParams,this,undefined,$scope.paginationParamsWithSearch());
    };
    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
    	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());   
    };
    
    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
   };
		
/*	  $scope.savedetails = function (updatedValues,discounts) {
		var discount ={};
		discount.premiumGroupDiscountConfigId = discounts.premiumGroupDiscountConfigId;
		discount.discountSheetName = discounts.discountSheetName;
 		if($scope.editFlag){
	 		commonFactoryForRestCall.getURL(endPointURL,apiKey.key).put(JSON.stringify(discount),function(data) {
	 			 //$state.transitionTo($state.$current, $stateParams, {'reload':true});
	 			$scope.loadDiscountTable();
	 		 },function(data,status,headers,config) {
	 			  $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; 
	 			 $scope.editFlag = false;
	 		});
 		}else if($scope.createFlag){
 			commonFactoryForRestCall.getURL(baseURL,apiKey.key).post(JSON.stringify(discount),function(data) {
 				$scope.loadDiscountTable();
	 		 },function(data,status,headers,config) {
	 			  $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; 
	 			 $scope.createFlag = false;
	 		});
 		}
    };*/
    
   $scope.showDateField= function(flag){
		 $scope.dateFalg = flag;
	 };
   $scope.populateSheetNameList = function(sheetNameSelect){
       var listOfDiscountSheetEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.discountSheetSearch;
       var discountSheetSearchParams = angular.extend({
    	   sheetName: sheetNameSelect
       });
       commonFactoryForHttp.getURL('GET',listOfDiscountSheetEndPointURL,discountSheetSearchParams).success(function(data, status, headers, config) {
              $scope.listofSheetNames =data;
       }).error( function(data, status, headers, config) {
       	$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
       });
   };
   
  /* $scope.populateStatusList = function(statusSelect){
	    var listOfStatusEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.discountSheetSearch;
	    var premiumSearchParams = angular.extend({
	           status: statusSelect
	    });
	    commonFactoryForHttp.getURL('GET',listOfStatusEndPointURL,premiumSearchParams).success(function(data, status, headers, config) {
	           $scope.listofStatus =data;
	    }).error( function(data, status, headers, config) {
	           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	    });
	};*/
	  $scope.searchReset = function(){
	   		$scope.statusSelect='';
	   		$scope.sheetNameSelect='';
	   		$scope.errMessage = '';
	   		$scope.search.activeFromDt = null;
			$scope.search.activeToDt = null;
	    };
	    $scope.searchRecords = function (){
	    	 $scope.errMessage = '';
	     	$scope.currentPage = 0;
	     	paginationService.loadPageCounts($scope);
	     	var paginationParams = angular.extend({
	     		commonFactoryForRestCall: commonFactoryForRestCall,
	     		baseURL:endPointURL,
	     		propertiesConfig:propertiesConfig,
	     	});
	     	$scope.formattedFromDate = null;
			$scope.formattedToDate = null;
			var errorFlag = false;
			var errorSet = false;
			if(!$scope.search.activeFromDt  && !$scope.search.activeToDt){
				errorSet = true;
			}
			if((!$scope.search.activeFromDt && $scope.search.activeToDt)||($scope.search.activeFromDt  && !$scope.search.activeToDt)){
				$scope.errMessage = propertiesConfig.details.validDateMsg;
				errorFlag = true;
			}
			if($scope.search.activeFromDt ){
				var fromDate = new Date($scope.search.activeFromDt);
				$scope.formattedFromDate =  fromDate.getFullYear()+"-"+(fromDate.getMonth()+1) + "-"+fromDate.getDate();
			}
	     	if($scope.search.activeToDt){
	     		var toDate = new Date($scope.search.activeToDt);
	     		$scope.formattedToDate = toDate.getFullYear()+"-"+(toDate.getMonth()+1) + "-"+toDate.getDate();
	     	}
	     	if((($scope.search.activeFromDt) >= $scope.search.activeToDt ) && !errorFlag && !errorSet){
	              $scope.errMessage = propertiesConfig.details.EndDateValidationMsg;
	              errorFlag = true;
	           }else if(!errorFlag){
	        	   paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
	           }
	     };
	     
	     $scope.paginationParamsWithSearch = function(){
	    		return angular.extend({
	    			sheetName: $scope.sheetNameSelect,
	    			status:$scope.statusSelect,
	    			activeFrom:$scope.formattedFromDate,
	    			activeTo:$scope.formattedToDate,
	    			serviceId:$scope.serviceId
	    		});
	    };
   
    $scope.updateStatus = function(){
    	$scope.loadingIcon = true;
		 var service ={};
		 var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		 endPointServiceURL =baseURL+ endPointServiceURL;
		 service.serviceId= $scope.serviceId;
		 service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;	
		 if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			 commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				 $scope.isPublished = !$scope.isPublished;
				 responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				 $scope.loadingIcon = false;
			 },function(data,status,headers,config) {
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				 $scope.loadingIcon = false;
			  });
		 }else if($scope.isEnablePublish===false && service.isPublished==='true'){
			 responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			 $scope.loadingIcon = false;
		 }
		 $scope.statusConfirmationPopup = false;
	 };
   
	  $scope.updateArchiveStatus = function (premiumGroupDiscountConfigId,status) {
		 /* var discountSheet ={};
		  discountSheet.premiumGroupDiscountConfigId= premiumGroupDiscountConfigId;
		  discountSheet.status=status;*/
		  commonFactoryForRestCall.getURL(endPointURL).del({id:premiumGroupDiscountConfigId},undefined,function(data,status,headers,config) {
			   $scope.loadDiscountTable();
			   responseMessageService.showResponseMsg(propertiesConfig.details.discountMsg+propertiesConfig.details.deletedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  }, function(data,status,headers,config) {
			  if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			  });
	  };
  
	  $scope.showSchedulePopup = function(flag,premiumGroupDiscountConfigId){
	    	$scope.schedulePopUp = flag;
	    	$scope.premiumGroupDiscountConfigId = premiumGroupDiscountConfigId;
	    	if(!flag){
	    		$scope.activation={};
		    	$scope.custom.scheduleDt = '';
		    	$scope.dateFalg = false;
	    	}
	 };
	  $scope.scheduleUpdate = function (premiumGroupDiscountConfigId,status,eventType,comments) {
		  var discountSheet ={};
		  discountSheet.id=premiumGroupDiscountConfigId;
		  discountSheet.eventName=eventType;
		  discountSheet.comments=comments;
		  if(eventType === 'CUSTOM'){
			  var scheduleDate = new Date( $scope.custom.scheduleDt);
			  $scope.formattedScheduleDate =  scheduleDate.getFullYear()+"-"+(scheduleDate.getMonth()+1) + "-"+scheduleDate.getDate();
			  discountSheet.customDate=  $scope.formattedScheduleDate;
		  }
		  var scheduleEndPointURL = baseURL+propertiesConfig.details.discountPremiumSchedule;
		  commonFactoryForRestCall.getURL(scheduleEndPointURL).put(discountSheet,undefined,function(data) {
			   $scope.loadDiscountTable();
			   $scope.schedulePopUp = false;
			   responseMessageService.showResponseMsg(data.message, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  }, function(data,status,headers,config) { 
			  $scope.schedulePopUp = false;
			  if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}});
	 };

	  $scope.goEditPlanSheet = function(sheetName,planType,premiumGroupDiscountConfigId,flag,sheetStatus){
		  $scope.viewSheet= flag;
		/*  $state.get("nephele.discountSheet").params.viewSheet = $scope.viewSheet;
		  $state.get("nephele.discountSheet").params.sheetName = sheetName;
		  $state.get("nephele.discountSheet").params.planType = planType;*/
		  $cookies.put('premiumGroupDiscountConfigId',premiumGroupDiscountConfigId);
		  $cookies.put('sheetStatus',sheetStatus);
		  $cookies.put('viewSheet',$scope.viewSheet);
		  $state.go("manager.discountSheet");
	  };
	 
	  $scope.showDiscountPlanPopUp = function(flag){
	  	 $scope.discountPlanPopUp = flag;
	  	 $scope.planError=false;
	     $scope.planType ='';
	  };
  
  $scope.planTypeCreate = function (planType) {
	   if(!planType){
		   $scope.planError=true;
		   return false;
	   };
	  $scope.loadingIcon = true;
	  $scope.planError=false;
	  var planTypeParams ={};
	  planTypeParams.discountPlanType=planType;
	  planTypeParams.serviceId = $scope.serviceId;
	  var discountCreateEndPointURL = baseURL+propertiesConfig.details.discountPremium;
	  commonFactoryForRestCall.getURL(discountCreateEndPointURL).post(undefined,planTypeParams,function(data,status,headers,config) {
		  $scope.discountPlanPopUp = false;
		  $scope.viewSheet= false;
		  $scope.loadDiscountTable();
		  $scope.showEditSheetName = false;
		/*$state.get("nephele.discountSheet").params.sheetName = data.discountSheetName;
		  $state.get("nephele.discountSheet").params.planType = $scope.planType;
		  $state.get("nephele.discountSheet").params.premiumGroupDiscountConfigId = data.premiumGroupDiscountConfigId;*/
		  $cookies.put('premiumGroupDiscountConfigId',data.premiumGroupDiscountConfigId);
		  $cookies.put('viewSheet',$scope.viewSheet);
		  $cookies.put('sheetStatus',"DRAFT");
		  $state.go("manager.discountSheet");
		  $scope.loadingIcon = false;
	  }, function(data,status,headers,config) { 
		  $scope.discountPlanPopUp = false;
		  if(data.status === 400){
			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}else{
			 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		  $scope.loadingIcon = false;
		  });
  };
  
  
  // Discount Sheet
  $scope.loadDiscountSheetDetails = function(){
	  $scope.loadingIcon = true;
	  /*$scope.planType = $state.get('nephele.discountSheet').params.planType;
	  $scope.sheetName = $state.get('nephele.discountSheet').params.sheetName;
	  $scope.viewSheet = $state.get("nephele.discountSheet").params.viewSheet;
 	  $scope.sheetStatus = $state.get("nephele.discountSheet").params.sheetStatus;
	  $scope.premiumGroupDiscountConfigId = $state.get('nephele.discountSheet').params.premiumGroupDiscountConfigId;*/
	  var discountSheetEndPointURL = baseURL+propertiesConfig.details.discountPremium;
	  $scope.premiumGroupDiscountConfigId = $cookies.get('premiumGroupDiscountConfigId');
	  $scope.viewSheet = $cookies.get('viewSheet');
	  $scope.sheetStatus = $cookies.get('sheetStatus');
	  commonFactoryForRestCall.getURL(discountSheetEndPointURL).get({id:$scope.premiumGroupDiscountConfigId},undefined,function(data,status,headers,config) {
		  $scope.sheetName = data.discountSheetName;
		  $scope.planType = data.discountPlanType;
		  $scope.sheetName = data.discountSheetName;
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		 	$scope.loadingIcon = false;
		 });
	  
	  
	  var endPointsPremiumURL = baseURL +propertiesConfig.details.premiumGroupsList;
		 commonFactoryForRestCall.getURL(endPointsPremiumURL).get(undefined,undefined,function(data,status,headers,config) {
			 $scope.premiumGroupList= data.content;
			 if($scope.premiumGroupList.length>0){
				 $scope.premiumGroupIdwithName =$scope.premiumGroupList[0].premiumGroupid+" "+$scope.premiumGroupList[0].name;
				 $scope.premiumGroupId = $scope.premiumGroupList[0].premiumGroupid;
				 $scope.premiumGroupName=$scope.premiumGroupList[0].name;
			 }
			 $scope.getDiscountSheetDetails();
			 getModulesActive();
			 $scope.loadingIcon = false;
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		 	$scope.loadingIcon = false;
		 });
	};
	
	$scope.selectedPremium = function(premiumGroupIdwithName){
		$scope.premiumGroupId = premiumGroupIdwithName.split(" ")[0];
		$scope.premiumGroupName = premiumGroupIdwithName.split(" ")[1];
		$scope.getDiscountSheetDetails();
	};
	$scope.getDiscountSheetDetails = function(){
		var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
		 commonFactoryForRestCall.getURL(endPointsheetURL).get({groupName:$scope.premiumGroupName,sheetId:$scope.premiumGroupDiscountConfigId},undefined,function(data,status,headers,config) {
			 $scope.discountDetails= data.content;
			 $scope.deleteFlag = ( $scope.discountDetails !=undefined||$scope.discountDetails !=null)? true:false;
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; });
	};
		
	$scope.saveDiscountSheetdetails = function (updatedValues,discounts) {
		  $scope.loadingIcon = true;
		  var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
		var discount ={};
		discount.premiumGroupDiscountConfigId= $scope.premiumGroupDiscountConfigId;
		discount.discountRuleId = discounts.discountRuleId;
		discount.startRange=updatedValues.startRange;
		discount.endRange=updatedValues.endRange;
		discount.discount=updatedValues.discount;
			discount.premiumGroupId = $scope.premiumGroupId;
			discount.serviceId = $scope.serviceId;
				if($scope.editFlag){
			 		commonFactoryForRestCall.getURL(endPointsheetURL).put(JSON.stringify(discount),function(data,status,headers,config) {
			 			$scope.getDiscountSheetDetails();
			 			 $scope.editFlag = false;
			 			 responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 			$scope.loadingIcon = false;
			 		 },function(data,status,headers,config) {
						$scope.getDiscountSheetDetails();
			 			if(data.status === 400){
							responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}else{
							 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}
			 			 $scope.editFlag = false;
			 			$scope.loadingIcon = false;
			 		});
				}else if($scope.createFlag){
					commonFactoryForRestCall.getURL(endPointsheetURL).post(JSON.stringify(discount),function(data,status,headers,config) {
		 			// $state.transitionTo($state.$current, $stateParams, {'reload':true});
						$scope.getDiscountSheetDetails();
						 $scope.createFlag = false;
						 responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
						 $scope.loadingIcon = false;
		 		 },function(data,status,headers,config) {
						$scope.getDiscountSheetDetails();
		 			if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					} else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
		 			 $scope.createFlag = false;
		 			$scope.loadingIcon = false;
		 		});
				}
	};
	
	$scope.saveDiscountSheetRules = function (discounts) {
		  $scope.loadingIcon = true;
		  var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
		
		var discountArray = [];
		for(var i = 0; i < discounts.length; i++){
			var discount ={};
			discount.premiumGroupDiscountConfigId= $scope.premiumGroupDiscountConfigId;
			discount.startRange=discounts[i].startRange;
			discount.endRange=discounts[i].endRange;
			if(i==discounts.length-1){
			  if(discounts[i].endRange == undefined ||discounts[i].endRange== ""){
			    delete discount.endRange;
			  }
			}
			discount.discount=discounts[i].discount;
			discount.premiumGroupId = $scope.premiumGroupId;
			discount.serviceId = $scope.serviceId;
			discountArray.push(discount);
		}
		discount = {"rules":discountArray};
			commonFactoryForRestCall.getURL(endPointsheetURL).put(JSON.stringify(discount),function(data,status,headers,config) {
					$scope.getDiscountSheetDetails();
					 responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
					 $scope.loadingIcon = false;
					 $scope.showEditView = false;
	 		 },function(data,status,headers,config) {
	 			 $scope.showEditView = false;
	 			 	$scope.getDiscountSheetDetails();
	 			if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				} else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
	 			$scope.loadingIcon = false;
	 		});
	};
	
	$scope.cancelRules= function (discounts) {
		$scope.showEditView = false;
		for(var i=0; i<discounts.length;i++){
			if(discounts[i] != undefined && (discounts[i].startRange == '' ||discounts[i].startRange== undefined)){
				$scope.discountDetails.splice(i, discounts.length);
			}
		}
	};
	$scope.removeDiscountRule= function (discounts,index) {
		if(discounts[index] != undefined){
			$scope.discountDetails.splice(index, 1);
			$scope.showEditView = true;
		}else{
			responseMessageService.showResponseMsg(propertiesConfig.details.CannotRemoveMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			
		}
	}
	  $scope.saveDiscountPercent = function (discountPer) {
		  $scope.loadingIcon = true;
		  var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
		  var discountArray = [];
		 var discount ={};
		 discount.premiumGroupDiscountConfigId= $scope.premiumGroupDiscountConfigId;
		 discount.discount=discountPer;
			discount.premiumGroupId = $scope.premiumGroupId;
			discount.serviceId = $scope.serviceId;
			discountArray.push(discount);
			discount = {"rules":discountArray};
	 		commonFactoryForRestCall.getURL(endPointsheetURL).put(JSON.stringify(discount),function(data,status,headers,config) {
	 			$scope.getDiscountSheetDetails();
	 			$scope.editFlag = false;
	 			responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
	 			$scope.loadingIcon = false;
	 			$scope.showEditDiscount = false;
	 		 },function(data,status,headers,config) {
				$scope.getDiscountSheetDetails();
	 			if(data.status === 400){
					 responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
	 			 $scope.editFlag = false;
	 			$scope.loadingIcon = false;
	 		});
	};
	  
	$scope.cancelDiscountPercent = function (discount){
		$scope.getDiscountSheetDetails();
	}
	
	$scope.editFlag = false;
	$scope.createFlag = false;
	
	$scope.updateDiscount = function(showForm){
		  if(!$scope.editFlag && !$scope.createFlag){
			  $scope.editFlag = true;
			  showForm.$show();
		  }else{
			  alert("Please save already initiated discount");
		  }
	};
	
		$scope.addRule = function() {
			if($scope.premiumGroupId === null){
				alert("Please select valid Premium Group");
			}else{
			 /* if(!$scope.editFlag && !$scope.createFlag){*/
				  $scope.createFlag=true;
				  $scope.inserted = {
					      id:'',
					      startRange:'',
					      endRange:'',
					      discount:'',
					      premiumGroupId:'',
					      serviceId:$scope.serviceId ,
					      premiumGroupDiscountConfigId:''
					    };
				 $scope.discountDetails.push($scope.inserted);
				 $scope.showEditView = true;
				 $scope.discountForm.submitted=false;
			 /* }else{
					alert("Please save already initiated groups");
			  }*/
			}
			};
		
		$scope.removeFlag= function(rowform,index){
			  if($scope.createFlag){
				  $scope.createFlag = false;
				  $scope.discountDetails.splice(index, 1);
			  }
			  $scope.editFlag= false;
			  rowform.$cancel();
		};
		
		$scope.removeDiscount = function (discountId,index) {
		if(discountId != null){
			  var endPointsheetURL = baseURL +propertiesConfig.details.discount; 
			commonFactoryForRestCall.getURL(endPointsheetURL).del({id:discountId},function(data,status,headers,config) {
				$scope.loadDiscountSheetDetails();
				responseMessageService.showResponseMsg(propertiesConfig.details.discountRuleMsg + propertiesConfig.details.deletedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			}, function(data,status,headers,config) { 
				if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			} else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}});
		}else{
			  $scope.discountDetails.splice(index, 1);
			 // $state.transitionTo($state.$current, $stateParams, {'reload':true});
		}
		};

		
		$scope.setEditFlag = function(flag){
				$scope.showEditSheetName = flag;
		};
		
		$scope.setDiscountEditFlag = function(flag){
			$scope.showEditDiscount = flag;
		};
		
		 $scope.saveSheetName = function (sheetName) {
			  var discountSheet ={};
			  discountSheet.premiumGroupDiscountConfigId=$scope.premiumGroupDiscountConfigId;
			  discountSheet.discountSheetName=sheetName;
		 	  commonFactoryForRestCall.getURL(endPointURL).put(undefined,discountSheet,function(data,status,headers,config) {
		 		  var queryParams = {};
		 		 queryParams.premiumGroupDiscountConfigId=$scope.premiumGroupDiscountConfigId
		 		 commonFactoryForRestCall.getURL(endPointURL).get(queryParams,undefined,function(data,status,headers,config) {
				 },function(data,status,headers,config) { });
				 $scope.showEditSheetName = false;
				 responseMessageService.showResponseMsg(propertiesConfig.details.sheetNameMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			  },function(data,status,headers,config) {
				  if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				   $scope.editFlag = false;
			  });
		  };
		 
		  $scope.statusConfirmationPopup = false;
			 $scope.showStatusConfirmationPopup = function(flag){
			    	$scope.statusConfirmationPopup = flag;
			    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
			    };



}]);
