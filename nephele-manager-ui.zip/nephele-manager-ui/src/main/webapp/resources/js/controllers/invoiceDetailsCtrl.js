app.controller('invoiceDetailsCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall', 'paginationService', '$state', 'responseMessageService', '$timeout','$cookies','reportGeneratorPdf','factoryForRoleBasedFeature',
	function($scope, propertiesConfig, commonFactoryForRestCall, paginationService, $state, responseMessageService, $timeout,$cookies,reportGeneratorPdf,factoryForRoleBasedFeature) {
	$scope.master = {};
	$scope.invoiceId = $cookies.get('cloudInvoiceId');
	$scope.instrumentTypes = propertiesConfig.details.instrumentType;
	var baseURL = propertiesConfig.details.baseReportingURL;
	$scope.invoice = null;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.invoicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var endPointURL = propertiesConfig.details.cloudInvoiceDetails;
	$scope.loadPage = function (endPointURL) {
		$scope.loadingIcon = true;
		commonFactoryForRestCall.getURL(baseURL + endPointURL)
			.get({id:$scope.invoiceId}, undefined,function(data, status, headers, config) {
				$scope.invoice = data;
				$scope.billingStatus =($scope.invoice.status ==='PAID');
				$scope.loadingIcon = false;
			}, function(data, status, headers, config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
			}
		);
	};

	if($scope.instrumentTypes && $scope.instrumentTypes.length > 0) {
		$scope.instrumentType = $scope.instrumentTypes[0];
		$scope.instrument = $scope.instrumentTypes[0];
	}
	$scope.loadPage(endPointURL);

	$scope.downloadPDF = function(invoiceId) {
		if(invoiceId == undefined){
			$cookies.remove(propertiesConfig.details.apiKey);
			$state.go(propertiesConfig.details.index);
		}
		$scope.loadingIcon = true;
		var baseURL = propertiesConfig.details.baseReportingURL;
		var endPointURL = propertiesConfig.details.cloudInvoicePDFDownload;
		var exportEndpointURL = baseURL+endPointURL+"/"+invoiceId;
		var fileName = invoiceId + ".pdf";
		var a = document.createElement("a");
		document.body.appendChild(a);
		a.style = "display: none";
		reportGeneratorPdf.downloadPdfFile(exportEndpointURL,$scope).then(function (result) {
			var file = new Blob([result.data], {type: 'application/pdf'});
			var fileURL = window.URL.createObjectURL(file);
			a.href = fileURL;
			a.download = fileName;
			a.click();
			$scope.loadingIcon = false;
		});
	};
	$scope.instrumentTypeChange = function(type) {
		$scope.instrument = type;
		$scope.instrumentType = type;
	};
	$scope.invoicePay = function(paymentDetails) {
		$scope.loadingIcon = true;
		var endPointURL = propertiesConfig.details.cloudBillPay;
		commonFactoryForRestCall.getURL(baseURL + endPointURL)
			.post(undefined, paymentDetails,
			function(data, status, headers, config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.paymentMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadPage(propertiesConfig.details.cloudInvoiceDetails);
				$scope.loadingIcon = false;
			}
			, function(data, status, headers, config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				} else {
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
			}
		);
	}

}]);