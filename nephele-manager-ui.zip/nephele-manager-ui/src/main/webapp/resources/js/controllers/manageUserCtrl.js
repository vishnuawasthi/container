//This controller is to view the data of users
app.controller('manageUserCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall','paginationService','$timeout','responseMessageService','factoryForRoleBasedFeature','searchToggleService','$state','commonFactoryForHttp',
    function($scope, propertiesConfig, commonFactoryForRestCall,paginationService,$timeout,responseMessageService,factoryForRoleBasedFeature,searchToggleService,$state,commonFactoryForHttp) {
    $scope.loadingIcon = true;
    $scope.responseMsgFlag = false;
    $scope.responseClass = propertiesConfig.details.successMsgClass;
    var baseURL = propertiesConfig.details.baseURL;
	var searchURL = propertiesConfig.details.searchURL;
    var endPointURL = propertiesConfig.details.userRoles;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.usersForRole);
    $scope.isRead = roleBasedData.isRead;
    $scope.isWrite = roleBasedData.isWrite;
    $scope.userRoleId = '';
    $scope.search ={};
    commonFactoryForRestCall.getURL(baseURL + endPointURL)
        .get(undefined, undefined, function(data, status, headers, config) {
            $scope.userRoles = data.content;
            if($scope.userRoles && $scope.userRoles.length > 0){
                $scope.userRole = $scope.userRoles[0].roleId + "," + $scope.userRoles[0].roleName;
                $scope.userRoleId = $scope.userRoles[0].roleId;
                $scope.userRoleName = $scope.userRoles[0].roleName;
            }
        }, function(data, status, headers, config) {
            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });

    endPointURL = propertiesConfig.details.manageUser;
    $scope.showCreateUserPopUP = false;
    $scope.showEditUserPopUP = false;
    var paginationParams;

    $scope.currentPage = 0;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    paginationService.loadPageCounts($scope);

    paginationParams = angular.extend({
        commonFactoryForRestCall: commonFactoryForRestCall,
        baseURL: baseURL + endPointURL,
        propertiesConfig:propertiesConfig
        
    });

    paginationService.getPageData($scope, paginationParams);

    $scope.prevPage = function () {
        paginationService.prevPage($scope, paginationParams);
    };

    $scope.nextPage = function () {
        if($scope.currentPage < $scope.noOfPages-1 ){
            paginationService.nextPage($scope, paginationParams);
        } else {
            return false;
        }
    };

    $scope.setPage = function () {
        paginationService.setPage($scope, paginationParams,this);
    };

    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
        paginationService.getPageData($scope, paginationParams);
    };

    $scope.showCreateUserPopUPFn = function(flag,createForm){
        $scope.showCreateUserPopUP = flag;
          $scope.user ={};
          $scope.user.email= '';
          $scope.user.firstName= '';
          $scope.user.lastName= '';
          if( createForm != undefined ||createForm == ''){
        	 createForm.submitted = false;
          }
    };
    
    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
   };
    
    $scope.showEditUserPopUPFn = function(flag, user){
        $scope.showEditUserPopUP = flag;
        $scope.updatedUser = {};
        if(flag && user != undefined){
            $scope.updatedUser.email = user.email;
            $scope.updatedUser.firstName = user.firstName;
            $scope.updatedUser.lastName = user.lastName;
            $scope.updatedUser.userRoleId = user.userRoleId;
            $scope.updatedUser.isEnabled = user.isEnabled;
            if($scope.userRoles && $scope.userRoles.length > 0){
                for(var i=0; i<$scope.userRoles.length; i++) {
                    if ($scope.userRoles[i].roleId == $scope.updatedUser.userRoleId) {
                        $scope.userRole = $scope.userRoles[i].roleId + "," + $scope.userRoles[i].roleName;
                        $scope.userRoleId = $scope.userRoles[i].roleId;
                        $scope.userRoleName = $scope.userRoles[i].roleName;
                        break;
                    }
                }
            }
            $scope.updatedUser.distributorId = user.distributorId;
        }
    };

    $scope.viewManagerRole = function(){
    	$state.go("manager.manageRole");
    }
    $scope.createUser = function (user) {
        $scope.loadingIcon = true;
        endPointURL = propertiesConfig.details.manageUser;
        var paramsData = {
            "email": user.email? user.email.toLowerCase() : "", "firstName" : user.firstName
            , "lastName" : user.lastName, "userRoleId" : parseInt($scope.userRoleId)
        };
        commonFactoryForRestCall.getURL(baseURL + endPointURL)
            .post(undefined, paramsData, function(data, status, headers, config) {
                $scope.showCreateUserPopUP = false;
                paginationService.getPageData($scope, paginationParams);
                responseMessageService.showResponseMsg(propertiesConfig.details.user + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
                $scope.loadingIcon = false;
            }, function(data, status, headers, config) {
            	if(data.status === 400){
            	  var errorMessage;
                if(data.data.message) {
                  errorMessage = data.data.message;
                } else if (data.data.errorMessages[0]){
                  errorMessage = data.data.errorMessages[0];
                }
    				    responseMessageService.showResponseMsg(errorMessage, propertiesConfig.details.errorMsgClass, $scope, $timeout);
    			    } else {
                responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
              }
              $scope.showCreateUserPopUP = false;
              paginationService.getPageData($scope, paginationParams);
              $scope.loadingIcon = false;

            });
    };

    $scope.userRoleChange = function (role) {
        $scope.userRoleId = role.split(",")[0];
        $scope.userRoleName = role.split(",")[1];
    };

    $scope.changeUserStatus = function (service) {
        service.isEnabled = !service.isEnabled;
        $scope.updateUser(service);
    };

    $scope.updateUser = function (user) {
        $scope.loadingIcon = true;
        var paramsData = {
            "email": user.email, "firstName" : user.firstName, "lastName" : user.lastName,
            "userRoleId" : parseInt($scope.userRoleId), "isEnabled" : user.isEnabled, "distributorId" : user.distributorId
        };
        endPointURL = propertiesConfig.details.manageUser;
        commonFactoryForRestCall.getURL(baseURL + endPointURL)
            .put(undefined, paramsData, function(data, status, headers, config) {
                $scope.showEditUserPopUP = false;
                paginationService.getPageData($scope, paginationParams);
                responseMessageService.showResponseMsg(propertiesConfig.details.user + propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
                $scope.loadingIcon = false;
            }, function(data, status, headers, config) {
            	 $scope.showEditUserPopUP = false;
            	if(data.status === 400){
            	  var errorMessage;
            	  if(data.data.message) {
            	    errorMessage = data.data.message;
            	  } else if (data.data.errorMessages[0]){
            	    errorMessage = data.data.errorMessages[0];
            	  }
    				    responseMessageService.showResponseMsg(errorMessage, propertiesConfig.details.errorMsgClass, $scope, $timeout);
    			    } else {
    			      responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
    			    }
    			    paginationService.getPageData($scope, paginationParams);
              $scope.loadingIcon = false;
            });
    };
  $scope.populateEmailList = function(emailSelect){
        var listOfEmailEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.distributorsSearch;
        var distributorSearchParams = angular.extend({
               email: emailSelect
        });
        commonFactoryForHttp.getURL('GET',listOfEmailEndPointURL,distributorSearchParams).success(function(data, status, headers, config) {
               $scope.listofEmails =data;
        }).error( function(data, status, headers, config) {
               $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });
   };
 
	 $scope.populateFirstNameList = function(firstNameSelect){
	     var listOfFirstNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.distributorsSearch;
	     var firstNameSearchParams = angular.extend({
	    	 firstName: firstNameSelect
	     });
	     commonFactoryForHttp.getURL('GET',listOfFirstNameEndPointURL,firstNameSearchParams).success(function(data, status, headers, config) {
	            $scope.listofFirstNames =data;
	     }).error( function(data, status, headers, config) {
	            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	     });
	};

	$scope.populateLastNameList = function(lastNameSelect){
	    var listOfLastNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.distributorsSearch;
	    var lastNameSearchParams = angular.extend({
	   	 lastName: lastNameSelect
	    });
	    commonFactoryForHttp.getURL('GET',listOfLastNameEndPointURL,lastNameSearchParams).success(function(data, status, headers, config) {
	           $scope.listofLastNames =data;
	    }).error( function(data, status, headers, config) {
	           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	    });
	};

	/* $scope.populateStatusList = function(statusSelect){
		    var listOfStatusEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.distributorsSearch;
		    var statusSearchParams = angular.extend({
		           status: statusSelect
		    });
		    commonFactoryForHttp.getURL('GET',listOfStatusEndPointURL,statusSearchParams).success(function(data, status, headers, config) {
		           $scope.listofStatus =data;
		    }).error( function(data, status, headers, config) {
		           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		    });
		};*/
$scope.searchReset = function(){
	$scope.emailSelect='';
	$scope.distributorId='';
	$scope.firstNameSelect='';
	$scope.lastNameSelect='';
	$scope.statusSelect='';
	$scope.search.createdDt='';
};

$scope.searchRecords = function (){
	$scope.currentPage = 0;
	var searchUserURL = propertiesConfig.details.manageUserSearch;
	paginationService.loadPageCounts($scope);
	var paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		baseURL:baseURL+searchUserURL,
		propertiesConfig:propertiesConfig
	});
	$scope.formattedCreatedDt = null;
	if($scope.search.createdDt != undefined || $scope.search.createdDt != null){
		var createdDate = new Date($scope.search.createdDt);
	 	$scope.formattedCreatedDt =  createdDate.getFullYear()+"-"+(createdDate.getMonth()+1) + "-"+createdDate.getDate();
	}
	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
};

$scope.paginationParamsWithSearch = function(){
	return angular.extend({
		email:$scope.emailSelect,
		distributorId:$scope.distributorId,
		firstName:$scope.firstNameSelect,
		lastName:$scope.lastNameSelect,
		createdDate:$scope.formattedCreatedDt,
		status:($scope.statusSelect =='Active')?true:false
	});
};

}]);
