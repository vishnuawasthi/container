app.controller('settingsCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','responseMessageService','$timeout','factoryForRoleBasedFeature','$cookies',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,responseMessageService,$timeout,factoryForRoleBasedFeature,$cookies) {
    $scope.showTaxEditMode = false;
    $scope.showConfigEditMode = false;
    $scope.showSurchargeEditMode = false;
    $scope.showDistributorEditMode = false;
	$scope.loadingIcon = true;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.settingsForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	$scope.text = {};
	$scope.taxDetails = {};
    //Tax Settings
	$scope.textFlagSet = function(flag){
		$scope.textFlag = flag;
	};
    $scope.showTaxEditModeView = function(flag){
    	if(flag){
    		$scope.taxDetails.$original =  angular.copy($scope.taxDetails);
    	}
        $scope.showTaxEditMode = flag;
    };
    $scope.cancelTaxDetails= function(taxDetails){
    	angular.copy($scope.taxDetails.$original, taxDetails);
    	$scope.showTaxEditModeView(false);
    };
    
    //Config Settings
    $scope.showConfigEditModeView = function(flag){
    	if(flag){
    		$scope.orderPrefixDetails.$original = angular.copy($scope.orderPrefixDetails);
    		$scope.invoicePrefixDetails.$original =  angular.copy($scope.invoicePrefixDetails);
    		$scope.currencyDetails.$original =  angular.copy($scope.currencyDetails);
    		$scope.invoiceTermDetails.$original =  angular.copy($scope.invoiceTermDetails);
    		$scope.text.noOfDays=$scope.noOfDays
    	}
        $scope.showConfigEditMode = flag;
    };    
    $scope.cancelConfigDetails= function(orderPrefixDetails,invoicePrefixDetails,currencyDetails,invoiceTermDetails){
    	angular.copy($scope.orderPrefixDetails.$original, orderPrefixDetails);
    	angular.copy($scope.invoicePrefixDetails.$original, invoicePrefixDetails);
    	angular.copy($scope.currencyDetails.$original, currencyDetails);
    	angular.copy($scope.invoiceTermDetails.$original, invoiceTermDetails);
    	$scope.orderInvoiceForm.submitted=false;
    	$scope.showConfigEditModeView(false);
    	//$scope.textFlag = false;
    };
    $scope.reset = function() {
        $scope.configDetails.orderPrefix = "";
        $scope.configDetails.invoicePrefix = "";
    };
    
    //Surcharge settings
    $scope.showSurchargeEditModeView = function(flag){
    	if(flag){
    		$scope.amexSurcharge.$original = angular.copy($scope.amexSurcharge);
    		$scope.masterSurcharge.$original = angular.copy($scope.masterSurcharge);
    		$scope.visaSurcharge.$original = angular.copy($scope.visaSurcharge);
    	}
        $scope.showSurchargeEditMode = flag;
    };    
    $scope.cancelSurchargeDetails= function(amexSurcharge,masterSurcharge,visaSurcharge){
    	angular.copy($scope.amexSurcharge.$original, amexSurcharge);
    	angular.copy($scope.masterSurcharge.$original, masterSurcharge);
    	angular.copy($scope.visaSurcharge.$original, visaSurcharge);
    	$scope.showSurchargeEditModeView(false);
    };
    $scope.reset = function() {
        $scope.amexSurcharge = "";
        $scope.masterSurcharge = "";
        $scope.visaSurcharge = "";
    };
    
    //Distributor company settings
    $scope.showDistributorEditModeView = function(flag){
    	if(flag){
    		$scope.distributorDetails.$original = angular.copy($scope.distributorDetails);
  	}
        $scope.showDistributorEditMode = flag;
    };    
    $scope.cancelDistributorDetails= function(distributorDetails){
    	angular.copy($scope.distributorDetails.$original, distributorDetails);
    	$scope.showDistributorEditModeView(false);
    	$scope.distributorForm.submitted=false;
    };
    $scope.reset = function() {
        $scope.distributorDetails.data = "";
    };
    //Payment Gateway settings
    $scope.showPaymentEditModeView = function(flag){
    	if(flag){
    		$scope.paymentMerchantId.$original = angular.copy($scope.paymentMerchantId);
    		$scope.paymentMerchantKey.$original =  angular.copy($scope.paymentMerchantKey);
    	}
        $scope.showPaymentEditMode = flag;
    };    
    $scope.cancelPaymentDetails= function(paymentMerchantId,paymentMerchantKey){
    	angular.copy($scope.paymentMerchantId.$original, paymentMerchantId);
    	angular.copy($scope.paymentMerchantKey.$original, paymentMerchantKey);
    	$scope.showPaymentEditModeView(false);
    };
    $scope.reset = function() {
        $scope.paymentMerchantId = "";
        $scope.paymentMerchantKey = "";
    };
    
    //load all details
    var baseURL = propertiesConfig.details.baseURL;
    var endPointURL = baseURL+propertiesConfig.details.businessRules;
    
    $scope.loadDetails = function(){
    	$scope.loadingIcon = true;
	    commonFactoryForRestCall.getURL(endPointURL).get(undefined,undefined, function(data,status,headers,config) {
	    	$scope.taxDetails = {};
	    	$scope.orderPrefixDetails = {};
	    	$scope.invoicePrefixDetails = {};
	    	$scope.currencyDetails = {};
	    	$scope.invoiceTermDetails={};
	    	$scope.amexSurcharge = {};
	    	$scope.masterSurcharge = {};
	    	$scope.visaSurcharge = {};
	    	$scope.distributorDetails = {};
	    	$scope.paymentMerchantId = {};
	    	$scope.paymentMerchantKey = {};
	    	
	    	angular.forEach(data.content, function(content) {
	    	    if(content.ruleName === 'GST'){
	    	    	  $scope.taxDetails.countryName = 'Australia';
	    	    	  $scope.taxDetails.value=Number(content.ruleValue);
	    	    	  $scope.taxDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'ORDER_PREFIX'){
	    	    	$scope.orderPrefixDetails.value=content.ruleValue;
	    	    	$scope.orderPrefixDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'INVOICE_PREFIX'){
	    	    	$scope.invoicePrefixDetails.value=content.ruleValue;
	    	    	$scope.invoicePrefixDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'CURRENCY'){
	    	    	$scope.currencyDetails.value=content.ruleValue;
	    	    	$scope.currencyDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'INVOICE_TERM'){
	    	    	$scope.invoiceTermDetails.value= content.ruleValue;
	    	    	$scope.noOfDays=Number ((content.ruleValue == 0) ?'':content.ruleValue);
	    	    	$scope.text.noOfDays=$scope.noOfDays;
	    	    	$scope.invoiceTermDetails.constant= (content.ruleValue == 0) ? 'On Receipt' : 'Net '+content.ruleValue;
	    	    	$scope.textFlagSet(!(content.ruleValue == 0));
	    	    	$scope.invoiceTermDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'AMEX_SURCHARGE'){
	    	    	$scope.amexSurcharge.value=Number(content.ruleValue);
	    	    	$scope.amexSurcharge.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'MASTER_SURCHARGE'){
	    	    	$scope.masterSurcharge.value=Number(content.ruleValue);
	    	    	$scope.masterSurcharge.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'VISA_SURCHARGE'){
	    	    	$scope.visaSurcharge.value=Number(content.ruleValue);
	    	    	$scope.visaSurcharge.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'DISTRIBUTOR_NAME'){
	    	    	$scope.distributorDetails.data=content.resource;
	    	    	$scope.distributorDetails.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'AMEX_SURCHARGE'){
	    	    	$scope.amexSurcharge.value=Number(content.ruleValue);
	    	    	$scope.amexSurcharge.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'PAYMENT_GATEWAY_MERCHANT_ID'){
	    	    	$scope.paymentMerchantId.value=content.ruleValue;
	    	    	$scope.paymentMerchantId.id=content.ruleId;
	    	    }
	    	    if(content.ruleName === 'PAYMENT_GATEWAY_HASH_KEY'){
	    	    	$scope.paymentMerchantKey.value=content.ruleValue;
	    	    	$scope.paymentMerchantKey.id=content.ruleId;
	    	    }
	    	});
	    	$scope.loadingIcon = false;
		 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		 $scope.loadingIcon = false;});
    };
   
    var updateBusinessRule = function(id,value,callLoadDetailsFlag,configType,type){
    	$scope.loadingIcon = true;
    	var params ={};
    	if(type==='DISTRIBUTOR_NAME'){
    		 params= {ruleId :id,  resource:value};
    	}else{
    		params= {ruleId :id,  ruleValue:value};
    	}
		 commonFactoryForRestCall.getURL(endPointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
			 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
			 if(callLoadDetailsFlag){
				 $scope.loadDetails();
			 }
			 $scope.loadingIcon = false;
			 responseMessageService.showResponseMsg(configType + propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		 }, function(data,status,headers,config) { 
			 if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			 $scope.loadingIcon = false;
		 });
    };
    $scope.updateTaxGST = function(taxDetails) {
   	 delete $scope.taxDetails.$original;
   	var configType = propertiesConfig.details.taxSettingsMsg;
   	updateBusinessRule(taxDetails.id,taxDetails.value,true,configType);
    $scope.showTaxEditModeView(false); 
	
   };
    
    $scope.saveOrderInvoiceConfig = function(orderPrefixDetails,invoicePrefixDetails,currencyDetails,invoiceTermDetails) {
    	if($scope.textFlag){
    		$scope.noOfDays=$scope.text.noOfDays;
    		invoiceTermDetails.value=$scope.noOfDays;
    	}
    	var configType = propertiesConfig.details.configSettingsMsg;
    	 delete $scope.orderPrefixDetails.$original;
    	 delete $scope.invoicePrefixDetails.$original;
    	 delete $scope.currencyDetails.$original;
    	 delete $scope.invoiceTermDetails.$original;
    	 $cookies.put(propertiesConfig.details.currency,currencyDetails.value);
    	 updateBusinessRule(orderPrefixDetails.id,orderPrefixDetails.value,false,configType);
    	 updateBusinessRule(invoicePrefixDetails.id,invoicePrefixDetails.value,false,configType);
    	 updateBusinessRule(currencyDetails.id,currencyDetails.value,true,configType);
    	 updateBusinessRule(invoiceTermDetails.id,invoiceTermDetails.value,true,configType);
    	 $scope.showConfigEditModeView(false);
    };
    $scope.updateSurchageDetails = function(amexSurcharge,masterSurcharge,visaSurcharge){
    	var configType = propertiesConfig.details.surchargeSettingsMsg;
	   	 delete $scope.amexSurcharge.$original;
	   	 delete $scope.masterSurcharge.$original;
	   	 delete $scope.visaSurcharge.$original;
	     updateBusinessRule(amexSurcharge.id,amexSurcharge.value,false,configType);
	     updateBusinessRule(masterSurcharge.id,masterSurcharge.value,false,configType);
	     updateBusinessRule(visaSurcharge.id,visaSurcharge.value,true,configType);
	     $scope.showSurchargeEditModeView(false);
   };
   
   $scope.updateDistributor = function(distributorDetails){
	   var configType = propertiesConfig.details.distributorSettingsMsg;
	   	 delete $scope.distributorDetails.$original;
	     updateBusinessRule(distributorDetails.id,distributorDetails.data,false,configType,"DISTRIBUTOR_NAME");
	     $scope.showDistributorEditModeView(false);
   };
 
	 $scope.updatePaymentSettings= function(paymentMerchantId,paymentMerchantKey){
		   	var configType = propertiesConfig.details.paymentSettingsMsg;
	    	 delete $scope.paymentMerchantKey.$original;
	    	 delete $scope.invoicePrefixDetails.$original;
	    	 updateBusinessRule(paymentMerchantKey.id,paymentMerchantKey.value,true,configType);
	    	 updateBusinessRule(paymentMerchantId.id,paymentMerchantId.value,true,configType);
	    	 $scope.showPaymentEditModeView(false);
	 }
}]);
