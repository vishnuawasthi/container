app.controller('newProductsCtrl',  ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','moduleActiveService','responseMessageService','$cookies','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
       	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,moduleActiveService,responseMessageService,$cookies,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
       	$scope.showSearchContent =true;
       	$scope.loadingIcon = true;
       	var  baseURL = propertiesConfig.details.baseURL;
       	var endPointURL = baseURL+propertiesConfig.details.products;
        $scope.serviceId = $cookies.get(propertiesConfig.details.id);
        $scope.integrationCode= $cookies.get(propertiesConfig.details.integrationCode);
    	$scope.serviceName= $cookies.get(propertiesConfig.details.serviceName);
       	$scope.resultsfound = propertiesConfig.details.resultsFound;
       	$scope.resultsCount = 0;
       	$scope.currentPage = 0;
       	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
       	$scope.isRead = roleBasedData.isRead;
       	$scope.isWrite = roleBasedData.isWrite;
       	$scope.listofStatus=['DISCOVERED','PUBLISHED','SUSPENDED'];
       	var planCountEndpointURL=baseURL+propertiesConfig.details.planCount;
       	$scope.loadProductDetails = function(){
    		$scope.loadingIcon = true;
    		getInventoryCount(planCountEndpointURL);
    		 paginationService.loadPageCounts($scope);
    		 paginationParams = angular.extend({
    		   commonFactoryForRestCall: commonFactoryForRestCall,
    	       baseURL: endPointURL,
    	       propertiesConfig:propertiesConfig
    	    });
    		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
    		getModulesActive();
    	};
    	
    	//Get Inventory Count
    	var getInventoryCount = function(endPointURL){
    		$scope.discoverCount = 0;
    		$scope.loadingIcon = true;
    		commonFactoryForRestCall.getURL(endPointURL).get({serviceId:$scope.serviceId},function(data,status,headers,config) {
    				$scope.discoverCount += data.summary.DISCOVERED; 
    			}, function(data,status,headers,config) {
    				if(data.status === 400){
    					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
    				}
    				$scope.loadingIcon = false;
    				}
    		);
    	};

    	
    	var getModulesActive = function(){
    		 moduleActiveService.getModulesData($scope);
    		 //$scope.loadingIcon = false;
    	};
    	
    	$scope.prevPage = function () {
    		paginationService.prevPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
        };
        $scope.nextPage = function () {
       	 if($scope.currentPage < $scope.noOfPages-1 ){
       	 paginationService.nextPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
       	 }else{
       		 return false;
       	 }
        };
        $scope.setPage = function () {
        	paginationService.setPage($scope,paginationParams,this,undefined,$scope.paginationParamsWithSearch());
        };
        $scope.pageSizeChange = function () {
        	$scope.currentPage = 0;
        	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());   
        };
        
        $scope.searchToggle = function(){
        	searchToggleService.toggleSearch();
       };
       $scope.paginationParamsWithSearch = function(){
   		return angular.extend({   			
   			serviceId:$scope.serviceId   			
   		});
   	};
       
       $scope.editProduct = function(products){
    	   $scope.productsList = [];
    	   $scope.productsList.push(products);
    	   $cookies.putObject("products",$scope.productsList);
    	   $state.go("manager.editProduct");
       };
       $scope.populateProductList = function(searchProduct){
 		  var listOfProductsURL = propertiesConfig.details.searchURL+propertiesConfig.details.productsSearch;
 		  var searchParams = angular.extend({
 			  productName: searchProduct
 			});
 	   		commonFactoryForHttp.getURL('GET',listOfProductsURL,searchParams).success(function(data, status, headers, config) {
 	   			$scope.listofCloudProducts = data;
 	   		}).error(function(data, status, headers, config) {
 	   			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
 	   		});
 	}; 
 	
 	$scope.searchReset = function(){
		 $scope.statusSelect ='';
		 $scope.searchCloudProduct ='';
		 $scope.featuredFlag ='';
		 $scope.RelatedProductsFlag ='';
    };

$scope.searchRecords = function (){
	$scope.currentPage = 0;
	paginationService.loadPageCounts($scope);
	var paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		baseURL: endPointURL,
		propertiesConfig:propertiesConfig
	});
	paginationService.getPageData($scope,paginationParams,undefined,$scope.ParamsWithSearch());
};
$scope.ParamsWithSearch = function(){
	return angular.extend({
		status: $scope.statusSelect,
		serviceId:$scope.serviceId,
		productName:$scope.searchCloudProduct,
		isFeatured:$scope.convertBoolean($scope.featuredFlag),
		hasRelatedProducts:$scope.convertBoolean($scope.RelatedProductsFlag)
	});
};
$scope.convertBoolean = function(input){
	return input === 'Yes' ? true : false ;
}

}]);
app.filter('flagChange', function() {
		return function(input) {
		  return input === true ? 'Yes' : 'No' ;
		};
   });