app.controller('createBundleCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','$cookies','responseMessageService','$timeout','commonFactoryForHttp',
                                   	                            	function($scope,propertiesConfig,commonFactoryForRestCall,$state,$cookies,responseMessageService,$timeout,commonFactoryForHttp) {
       	$scope.loadingIcon = true;
       	var baseURL = propertiesConfig.details.baseURL;
        var externaldeleteURL=	baseURL +  propertiesConfig.details.bundleexternaldelete;
        var clouddeleteURL=	baseURL +  propertiesConfig.details.bundleclouddelete;
        var bundlecreationURL=baseURL+ propertiesConfig.details.bindlelist;
        var getbundledata=baseURL+ propertiesConfig.details.bundlebyid;
       	$scope.bundleFlag=$cookies.get('bundleFlag');
       	$scope.bundleId = $cookies.get('bundleId');
       	$scope.bundleform={};
       	   
   	   $scope.loadBundleProducts = function () {
   		$scope.loadingIcon = true;
       	    if($scope.bundleFlag=='View'||$scope.bundleFlag=='Edit'||($scope.bundleFlag=='Create' &&($scope.bundleform.cloudProductList != undefined ||$scope.bundleform.externalProductList!= undefined ))){
       	       commonFactoryForRestCall.getURL(getbundledata).get({id:$scope.bundleId},function(data,status,headers,config) {
       	    	   if(data.content != undefined ){
       	    		 $scope.bundleform=data.content;
       	    	   }else{
                      $scope.bundleform=data;
       	    	   }
                     $scope.status=$scope.bundleform.status;
                  	$scope.loadingIcon = false;
			     }, function(data,status,headers,config) {
					if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				 	$scope.loadingIcon = false;
				});
       	    }else{
       	      $scope.bundleFlag="Create";
              $scope.status="DRAFT";
              $scope.bundleform={};
          	$scope.loadingIcon = false;
       	    }
   	    };

       	$scope.deleteExternalProduct = function (externalproductId,index) {
			if($scope.bundleform.externalProductList!=undefined){
				$scope.bundleform.externalProductList.splice(index, 1);
				responseMessageService.showResponseMsg(propertiesConfig.details.removedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			};
      };

       $scope.deleteCloudProduct = function (cloudproductId,index) {
		   if($scope.bundleform.cloudProductList!=undefined){
			   $scope.bundleform.cloudProductList.splice(index, 1);
			    responseMessageService.showResponseMsg(propertiesConfig.details.removedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		   }
      };

   $scope.createBundle = function (bundleform) {
	   $scope.loadingIcon = true;
	   var cloudproductslist =[];
	   var externalproductlist=[]
	  	  if(bundleform.cloudProductList != undefined){
		   	   for(var loop = 0; loop<bundleform.cloudProductList.length;loop++){
		   		   cloudproductslist.push(bundleform.cloudProductList[loop].cloudProductId);
		   	   }
		   }
	        if(bundleform.externalProductList != undefined){
		       for(var loop1 = 0; loop1<bundleform.externalProductList.length;loop1++){
		            externalproductlist.push(bundleform.externalProductList[loop1].externalProductId);
		        }
	       }
	        var bundleparms = {
	        		  name: bundleform.name,
				      description: bundleform.description,
				      status: $scope.status,
				      logoCode: bundleform.logoCode,
				      cloudproducts:cloudproductslist,
				      externalproducts:externalproductlist,
				      bundleId:$scope.bundleId
	         	};
	         if(bundleform.cloudProductList == undefined ||bundleform.cloudProductList.length==0){
	        	 responseMessageService.showResponseMsg(propertiesConfig.details.selecteCloudProductsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	        	 $scope.loadingIcon = false;
	         }else if(bundleform.externalProductList == undefined||bundleform.externalProductList.length==0){
	        	 responseMessageService.showResponseMsg(propertiesConfig.details.selecteHardwareProductsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	        	 $scope.loadingIcon = false;
	         } else{
	        	 commonFactoryForRestCall.getURL(bundlecreationURL).post(undefined,bundleparms, function(data,status,headers,config) {
						$scope.loadingIcon = false;
						responseMessageService.showResponseMsg(propertiesConfig.details.bundlesMsg +propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
						 $scope.bundleId = data.bundleId;
						$state.go('manager.bundleList');
					}, function(data,status,headers,config) {
						if(data.status === 400){
							responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}
					});
	            }
	   
    };

	   $scope.cancelCreation = function () {
			 if($scope.bundleFlag == 'Create'){
			   $scope.bundleform={};
			   if($scope.bundleform !=undefined){
				   $scope.bundleForm.submitted=false;
			   }
		   }
		   $scope.loadBundleProducts();
	   };
       
     $scope.populateProductList = function(searchProduct){
		  var listOfOsEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.productsPublishSearch;
		  var searchRolesParams = angular.extend({
			  productName: searchProduct
   			});
   		commonFactoryForHttp.getURL('GET',listOfOsEndPointURL,searchRolesParams).success(function(data, status, headers, config) {
   			$scope.listofCloudProducts = data;
   		}).error(function(data, status, headers, config) {
   			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
   		});
   	};
   	$scope.populateExternalProductList = function(searchProduct){
   		 var listOfOsEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.externalProductsSearch;
   		 var searchRolesParams = angular.extend({
   			  extProductName: searchProduct
 	   		});
  		commonFactoryForHttp.getURL('GET',listOfOsEndPointURL,searchRolesParams).success(function(data, status, headers, config) {
  			$scope.listofExternalProducts = data;
  		}).error(function(data, status, headers, config) {
  			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
  		});
	};
	$scope.addProduct = function(searchProduct,productType){
   if(searchProduct==undefined || searchProduct==""){
    responseMessageService.showResponseMsg("Required String parameter 'productName' is not present", propertiesConfig.details.errorMsgClass, $scope, $timeout);
   }else{
		var addProductURL ='';
		if(productType =='external'){
			addProductURL = baseURL +  propertiesConfig.details.addSearchExternalProduct;
		}else{
			addProductURL = baseURL +  propertiesConfig.details.addSearchProduct;
		}
		params = {
					productName:searchProduct
				};
		var cloudProductExists= false;
		var relatedProductExists = false;
		commonFactoryForRestCall.getURL(addProductURL).get(params,undefined,function(data,status,headers,config) {
			$scope.cloudData = {};
			$scope.externalData = {};
			if(productType =='external'){
				if($scope.bundleform.externalProductList == undefined){
					$scope.bundleform.externalProductList=[];
				}
				for(var loop=0;loop<$scope.bundleform.externalProductList.length;loop++){
					if($scope.bundleform.externalProductList[loop].externalProductId == data.externalProductId){
						responseMessageService.showResponseMsg(propertiesConfig.details.productExistsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						relatedProductExists = true;
					}
				}
				if(!relatedProductExists){
					$scope.externalData.externalProductId=data.externalProductId;
					$scope.externalData.brandName=data.brandName;
					$scope.externalData.productName=data.productName;
					$scope.externalData.status=data.status;
					if(data.externalProductId != undefined){
						$scope.bundleform.externalProductList.push($scope.externalData);
					}
				}
				$scope.searchExternalProduct ='';
			}else{
				if($scope.bundleform.cloudProductList == undefined){
					$scope.bundleform.cloudProductList=[];
				}
				for(var loop=0;loop<$scope.bundleform.cloudProductList.length;loop++){
					if($scope.bundleform.cloudProductList[loop].cloudProductId == data.productId){
						responseMessageService.showResponseMsg(propertiesConfig.details.productExistsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						cloudProductExists = true;
					}
				}
				if(!cloudProductExists){
					$scope.cloudData.cloudProductId =data.productId;
					$scope.cloudData.serviceName =data.serviceName;
					$scope.cloudData.name =data.name;
					$scope.cloudData.status =data.status;
					if(data.productId != undefined){
						$scope.bundleform.cloudProductList.push($scope.cloudData);
					}
				}
				$scope.searchCloudProduct='';
			}
	     }, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
		});
		}
	};

}]);