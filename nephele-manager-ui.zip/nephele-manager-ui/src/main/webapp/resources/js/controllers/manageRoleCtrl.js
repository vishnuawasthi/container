//This controller is to view the data of roles
app.controller('manageRoleCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall', 'paginationService', '$timeout','$cookies', 'responseMessageService','factoryForRoleBasedFeature','commonFactoryForHttp',
	function($scope, propertiesConfig, commonFactoryForRestCall, paginationService, $timeout,$cookies, responseMessageService,factoryForRoleBasedFeature,commonFactoryForHttp) {
    $scope.loadingIcon = true;
    $scope.responseMsgFlag = false;
    $scope.responseClass = propertiesConfig.details.successMsgClass;
    var paginationParams;
    var baseURL = propertiesConfig.details.baseURL;
    var endPointURL = propertiesConfig.details.userRoles;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.usersForRole);
    $scope.isRead = roleBasedData.isRead;
    $scope.isWrite = roleBasedData.isWrite;
    $scope.showCreateRolePopUP = false;
    $scope.showEditRolePopUP = false;
    $scope.currentPage = 0;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    paginationService.loadPageCounts($scope);

    paginationParams = angular.extend({
      commonFactoryForRestCall: commonFactoryForRestCall,
      baseURL: baseURL + endPointURL,
      propertiesConfig: propertiesConfig
      /*apiKey: apiKey.key*/
    });

	  paginationService.getPageData($scope, paginationParams);

	  $scope.prevPage = function () {
		  paginationService.prevPage($scope, paginationParams);
    };

    $scope.nextPage = function () {
   	  if($scope.currentPage < $scope.noOfPages-1 ){
   	    paginationService.nextPage($scope, paginationParams);
   	  } else {
   		  return false;
   	  }
    };

    $scope.setPage = function () {
    	paginationService.setPage($scope, paginationParams,this);
    };

    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
    	paginationService.getPageData($scope, paginationParams);
    };
    
    $scope.showCreateRolePopUPFn = function(flag,manageRoleForm){
      $scope.showCreateRolePopUP = flag;
      $scope.role = null;
      if(manageRoleForm !=undefined){
    	  manageRoleForm.submitted=false;
      }
    	if(flag){
    		  var getUserAccountsURL= baseURL +propertiesConfig.details.userAccounts;
    		  $scope.loadingIcon = true;
		 	    commonFactoryForRestCall.getURL(getUserAccountsURL).get(undefined,undefined,function(data,status,headers,config) {
		 	    	$scope.roleAccountsData = data.content;
		 	    	for(var loop =0 ; loop<$scope.roleAccountsData.length;loop++){
		 	    		$scope.roleAccountsData[loop].isRead=false;
		 	    		$scope.roleAccountsData[loop].isWrite=false;
		 	    	}
		 	        $scope.loadingIcon = false;
				}, function(data, status, headers, config) {
					if(data.status === 400){
						  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					} else {
						responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
					$scope.loadingIcon = false;
				});
    	} 	    
    };

	$scope.populateRoleNameList = function(searchRoleName){
		var listOfOsEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.roleNameSearch;
		var searchRolesParams = angular.extend({
			roleName: searchRoleName
		});
		commonFactoryForHttp.getURL('GET',listOfOsEndPointURL,searchRolesParams).success(function(data, status, headers, config) {
			$scope.listofRoleNames = data;
		}).error(function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		});
	};

    $scope.createRole = function (roleAccountsData,newRoleName) {
      $scope.loadingIcon = true;
      var paramsData = {
                         "roleName" : newRoleName,
                         "permissions" :$scope.roleAccountsData
                       };
      commonFactoryForRestCall.getURL(baseURL + endPointURL).post(undefined, paramsData, function(data, status, headers, config) {
         $scope.showCreateRolePopUP = false;
         paginationService.getPageData($scope, paginationParams);
         responseMessageService.showResponseMsg(propertiesConfig.details.role + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
         $scope.loadingIcon = false;
      }, function(data, status, headers, config) {
         $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
         if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			   } else {
           responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
         }
         $scope.loadingIcon = false;
      });
    };

    $scope.showEditRolePopUPFn = function(flag, roleId){
        $scope.showEditRolePopUP = flag;
        if(flag && roleId != undefined){
          if(flag){
        	  $scope.loadingIcon = true;
	          	var getUserPermissionsURL= baseURL +propertiesConfig.details.userPermissions;
	          	 var queryParams={};
	       	    queryParams.roleId =  roleId; 
	       	    commonFactoryForRestCall.getURL(getUserPermissionsURL).get(queryParams,undefined, function(data,status,headers,config) {
	       	    	$scope.roleId = data.roleId;
	       	    	$scope.roleName = data.roleName;
	       	    	$scope.rolePermissions = data.permissions;
	       	     $scope.loadingIcon = false;
	  			}, function(data, status, headers, config) {
	  				if(data.status === 400){
	  					  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	  				} else {
	  					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	  				}
	  				$scope.loadingIcon = false;
	  			});
          }
        }
      };
    $scope.updateRolePermissions = function (roleName) {
	     var updateRolesURL = baseURL+propertiesConfig.details.updateUserRolePermissions;
	      $scope.loadingIcon = true;
	      var paramsData = {"roleName": roleName, "permissions" : $scope.rolePermissions};
	       commonFactoryForRestCall.getURL(updateRolesURL).put(undefined, paramsData, function(data, status, headers, config) {
		        $scope.showEditRolePopUP = false;
		        responseMessageService.showResponseMsg(propertiesConfig.details.role + propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		    	var getUserPermissionsURL= baseURL +propertiesConfig.details.userPermissions;
	          	var queryParams={};
	       	    queryParams.roleId =  $scope.roleId; 
	       	    if( $cookies.get(propertiesConfig.details.userRoleId) === $scope.roleId){
		       	    commonFactoryForRestCall.getURL(getUserPermissionsURL).get(queryParams,undefined, function(data,status,headers,config) {
		       	    	$cookies.putObject(propertiesConfig.details.roleBasedPermissions,data.permissions);
		       	    	$scope.loadingIcon = false;
		  			}, function(data, status, headers, config) {
		  				if(data.status === 400){
		  					  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		  				} else {
		  					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		  				} 				
		  				$scope.loadingIcon = false;
		  			});
	       	    }else{
	       	    	$scope.loadingIcon = false;
	       	    }
	      }, function(data, status, headers, config) {
	         $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	         $scope.showEditRolePopUP = false;
	        
	         if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			 }else {
	             responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	         }
         $scope.loadingIcon = false;
      });
    };
    
    $scope.searchRole = function () {
        paginationParams = angular.extend({
          commonFactoryForRestCall: commonFactoryForRestCall,
          baseURL: baseURL + endPointURL,
          propertiesConfig: propertiesConfig
        });
    	paginationService.getPageData($scope, paginationParams,undefined,$scope.paginationParamsWithSearch());
    };
    $scope.paginationParamsWithSearch = function(){
		return angular.extend({
			roleName: $scope.searchRoleName
		});
	};

}]);