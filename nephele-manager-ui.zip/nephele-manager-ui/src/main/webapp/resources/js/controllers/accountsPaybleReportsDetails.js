app.controller('accountsPaybleReportsDetailsCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','$cookies',
                                                    	                            	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,$cookies) {
	           $scope.loadingIcon = true;
               var baseURL = propertiesConfig.details.baseReportingURL;
               var invoiceReportURL=	baseURL +  propertiesConfig.details.cloudInvoiceForResellers;
               $scope.currentPage = 0;
               $scope.resultsCount = 0;
          	paginationService.loadPageCounts($scope);
          	var paginationParams = angular.extend({
          		commonFactoryForRestCall: commonFactoryForRestCall,
          		baseURL: invoiceReportURL,
          		propertiesConfig:propertiesConfig
          	});
          $scope.apreport=$cookies.getObject('apfullreport');

          var params= {
          	   serviceId: $scope.apreport.cloudServiceId,
               billingStartDate: $scope.apreport.fromDate,
               billingEndDate: $scope.apreport.toDate,
               page: $scope.currentPage,
               size:$scope.noOfitems
               };

             paginationService.getPageData($scope,paginationParams,undefined,params);

             $scope.prevPage1 = function () {
          		paginationService.prevPage($scope,paginationParams,undefined,params);
          	};

          	$scope.nextPage1 = function () {
          		if($scope.currentPage < $scope.noOfPages-1 ){
          			paginationService.nextPage($scope,paginationParams,undefined,params);
          		} else{
          			return false;
          		}
          	};

          	$scope.setPage1 = function () {
          		paginationService.setPage($scope,paginationParams,this,undefined,params);
          	};

          	$scope.pageSizeChange1 = function () {
          		$scope.currentPage = 0;
          		paginationService.getPageData($scope, paginationParams,undefined,params);
          	};
          	$scope.viewInvoiceReportDetails = function (invoicenumber) {
                $cookies.remove("cloudInvoiceId");
             		$cookies.put('cloudInvoiceId',invoicenumber);
            		$state.go('manager.invoiceDetails');
            	};
}]);