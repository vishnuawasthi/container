app.controller('premiumGroupsCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$stateParams','$state','paginationService','responseMessageService','$timeout','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
    function($scope,propertiesConfig,commonFactoryForRestCall,$stateParams,$state,paginationService,responseMessageService,$timeout,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
    $scope.loadingIcon = false;
    $scope.createPremiumGroupPopUp = false;
    $scope.currentPage = 0;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.resellerForRole);
    $scope.isRead = roleBasedData.isRead;
    $scope.isWrite = roleBasedData.isWrite;
    $scope.servicesDetails = '';
    $scope.createPremiumGroupForm = {};
    $scope.showPremiumGroupPopUp = function(flag,createPremiumGroupForm){
        $scope.createPremiumGroupPopUp = flag;
        if(createPremiumGroupForm != undefined){
        	createPremiumGroupForm.submitted =false;
        }
    };
    var baseURL = propertiesConfig.details.baseURL;
    var endPointURL = baseURL+propertiesConfig.details.premiumGroupsList;

    paginationService.loadPageCounts($scope);
    var paginationParams = angular.extend({
        commonFactoryForRestCall: commonFactoryForRestCall,
        baseURL: endPointURL,
        propertiesConfig:propertiesConfig
       
    });
    paginationService.getPageData($scope,paginationParams);

    $scope.prevPage = function () {
        paginationService.prevPage($scope,paginationParams);
    };
    $scope.nextPage = function () {
        if($scope.currentPage < $scope.noOfPages-1 ){
            paginationService.nextPage($scope,paginationParams);
        }else{
            return false;
        }
    };
    $scope.setPage = function () {
        paginationService.setPage($scope,paginationParams,this);
    };
    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
        paginationService.getPageData($scope,paginationParams);
    };

    $scope.changeStatus = function(premiumGroup){
        var params = angular.extend({
        	premiumGroupid: premiumGroup.premiumGroupid,
            status:'ACTIVE'
        });
        commonFactoryForRestCall.getURL(endPointURL).put(undefined,params,function(data, status, headers, config) {
            paginationService.getPageData($scope,paginationParams);
            responseMessageService.showResponseMsg(propertiesConfig.details.statusChangeMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
        },function(data, status, headers, config){
        	if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
        });
    };
    $scope.populatePremiumGroupList = function(premiumGroupSelect){
        var listOfPremiumGroupEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.premiumGroupsSearch;
        var premiumGroupSearchParams = angular.extend({
        	groupName: premiumGroupSelect
        });
        commonFactoryForHttp.getURL('GET',listOfPremiumGroupEndPointURL,premiumGroupSearchParams).success(function(data, status, headers, config) {
               $scope.listofPremiumGroups =data;
        }).error( function(data, status, headers, config) {
        	$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });
    };
    
    $scope.searchReset = function(){
   		$scope.premiumGroupSelect='';
    };
    $scope.searchRecords = function (){
     	$scope.currentPage = 0;
     	paginationService.loadPageCounts($scope);
     	var paginationParams = angular.extend({
     		commonFactoryForRestCall: commonFactoryForRestCall,
     		baseURL:endPointURL,
     		propertiesConfig:propertiesConfig,
     	});
     	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
     };
     
     $scope.paginationParamsWithSearch = function(){
    		return angular.extend({
    			groupName: $scope.premiumGroupSelect
    		});
    	};
/*	$scope.populateStatusList = function(statusSelect){
	    var listOfStatusEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.invoiceSearch;
	    var premiumSearchParams = angular.extend({
	           status: statusSelect
	    });
	    commonFactoryForHttp.getURL('GET',listOfStatusEndPointURL,premiumSearchParams).success(function(data, status, headers, config) {
	           $scope.listofStatus =data;
	    }).error( function(data, status, headers, config) {
	           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	    });
	};*/
    $scope.createPremiumGroupFn = function(createPremiumGroup){
        endPointURL = baseURL+propertiesConfig.details.premiumGroupsList;
        var params = angular.extend({
            name: createPremiumGroup.name,
            description: createPremiumGroup.description
        });
        commonFactoryForRestCall.getURL(endPointURL).post(undefined,params,function(data, status, headers, config) {
            $scope.showPremiumGroupPopUp(false);
            paginationService.getPageData($scope,paginationParams);
            responseMessageService.showResponseMsg(propertiesConfig.details.premiumGroup + propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
        },function(data, status, headers, config){
        	if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
        });
    };
    
    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
   };
   
    
}]);