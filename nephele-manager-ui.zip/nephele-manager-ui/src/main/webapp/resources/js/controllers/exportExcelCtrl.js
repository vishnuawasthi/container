app.controller('exportExcelCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall',  '$state','responseMessageService','$timeout','commonFactoryForHttp',
	function($scope, propertiesConfig, commonFactoryForRestCall, $state,responseMessageService,$timeout,commonFactoryForHttp) {
	 $scope.search ={};
	$scope.getProductPlanData = function(){
		var baseURL = propertiesConfig.details.baseURL;
		var productExportURL = baseURL + propertiesConfig.details.PlansDbs;
		var fileName="ProductPlanData";
		 $scope.exportExcel(productExportURL,undefined)
	}
	$scope.loadingIcon = false;
	$scope.getInvoiceData = function(){
		$scope.loadingIcon = true;
		$scope.errInvoiceMessage ='';
		var baseURL = propertiesConfig.details.baseReportingURL;
		var invoiceExportURL = baseURL + propertiesConfig.details.invoiceDbs;
		$scope.formattedFromDate = null;
		$scope.formattedToDate = null;
		var errorFlag = false;
		var errorSet = false;
		if(!$scope.search.invoiceFromDt  && !$scope.search.invoiceToDt){
			$scope.errInvoiceMessage = propertiesConfig.details.validDateMsg;
			errorSet = true;
		}
		if((!$scope.search.invoiceFromDt  && $scope.search.invoiceToDt)||($scope.search.invoiceFromDt && !$scope.search.invoiceToDt)){
			$scope.errInvoiceMessage = propertiesConfig.details.validDateMsg;
			errorFlag = true;
		}
		if($scope.search.invoiceFromDt){
			var fromDate = new Date($scope.search.invoiceFromDt);
			$scope.formattedFromDate =  fromDate.getFullYear()+"-"+(fromDate.getMonth()+1) + "-"+fromDate.getDate();
		}
     	if($scope.search.invoiceToDt){
     		var toDate = new Date($scope.search.invoiceToDt);
     		$scope.formattedToDate = toDate.getFullYear()+"-"+(toDate.getMonth()+1) + "-"+toDate.getDate();
     	}
     	  if(($scope.search.invoiceFromDt) >= ($scope.search.invoiceToDt) && !errorFlag && !errorSet){
              $scope.errInvoiceMessage = propertiesConfig.details.EndDateValidationMsg;
              errorFlag = true;
          }else if(!errorFlag  && !errorSet){
        	   var serviceparms = angular.extend({
        		   startInvoiceDate: $scope.formattedFromDate,
        		   endInvoiceDate:$scope.formattedToDate
        	   });
        	   var fileName="InvoiceData";
      		 	$scope.exportExcel(invoiceExportURL,serviceparms,fileName)
          };
          $scope.loadingIcon = false;
	}
	$scope.getPaymentData = function(){
		$scope.loadingIcon = true;
		$scope.formattedPaymentFromDate = null;
		$scope.formattedPaymentToDate = null;
		var errorFlag = false;
		var errorSet = false;
		$scope.errPaymentMessage ='';
		var baseURL = propertiesConfig.details.baseReportingURL;
		var paymentExportURL = baseURL + propertiesConfig.details.paymentDbs;
		if(!$scope.search.paymentFromDt  && !$scope.search.paymentToDt){
			$scope.errPaymentMessage = propertiesConfig.details.validDateMsg;
			errorSet = true;
		}
		if((!$scope.search.paymentFromDt  && $scope.search.paymentToDt)||($scope.search.invoiceFromDt && !$scope.search.paymentToDt)){
			$scope.errPaymentMessage = propertiesConfig.details.validDateMsg;
			errorFlag = true;
		}
		if($scope.search.paymentFromDt){
			var fromDate = new Date($scope.search.paymentFromDt);
			$scope.formattedPaymentFromDate =  fromDate.getFullYear()+"-"+(fromDate.getMonth()+1) + "-"+fromDate.getDate();
		}
     	if($scope.search.paymentToDt){
     		var toDate = new Date($scope.search.paymentToDt);
     		$scope.formattedPaymentToDate = toDate.getFullYear()+"-"+(toDate.getMonth()+1) + "-"+toDate.getDate();
     	}
     	  if(($scope.search.paymentFromDt) >= ($scope.search.paymentToDt) && !errorFlag && !errorSet){
              $scope.errPaymentMessage = propertiesConfig.details.EndDateValidationMsg;
              errorFlag = true;
          }else if(!errorFlag  && !errorSet){
        	  var serviceparms = angular.extend({
        		  fromDate: $scope.formattedPaymentFromDate,
       		   toDate:$scope.formattedPaymentToDate
           });
     		 var fileName="PaymentData";
     		 $scope.exportExcel(paymentExportURL,serviceparms,fileName)
          };
          $scope.loadingIcon = false;
	}
	
	
	$scope.exportExcel=function(exportEndpointURL,serviceparms,fileName){
		$scope.loadingIcon = true;
		$scope.importSuccessMsg="";
		$scope.seviceErrorMsg="";
		commonFactoryForHttp.getURL('GET',exportEndpointURL,serviceparms).success(function(data, status, headers, config) {
			
			 fileName = fileName+ ".xml";
			var a = document.createElement('a');
			a.href = 'data:attachment/xml;charset=utf-8,' + encodeURI(data);
			a.target = '_blank';
			a.download = fileName;
			document.body.appendChild(a);
			$scope.exportSuccessMsg=propertiesConfig.details.exportSuccessMsg;
			a.click();
			$scope.loadingIcon = false;
			responseMessageService.showResponseMsg(propertiesConfig.details.downloadSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			
		}).error(function(data, status, headers, config) {
				$scope.loadingIcon = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
	};
}]);
