app.controller('userProfileCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','responseMessageService','$timeout','$cookies'
	,function($scope,propertiesConfig,commonFactoryForRestCall,$state,responseMessageService,$timeout,$cookies) {
	var baseURL = propertiesConfig.details.baseURL;
	$scope.loadingIcon = false;
	var endpointURL = baseURL + propertiesConfig.details.login;
	$scope.distributorId = $cookies.get(propertiesConfig.details.distributorId);
	var endpointGetURL = baseURL + propertiesConfig.details.userDetails;
	commonFactoryForRestCall.getURL(endpointGetURL).get({id:$scope.distributorId},undefined,function(data,status,headers,config) {
		$scope.firstName = data.firstName;
		$scope.lastName =  data.lastName;
		$scope.email = data.email;
		$scope.userRoleName =  data.userRoleName;
		$scope.password = data.password;
	}, function(error) {
		$scope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;
	});
	
	
	  $scope.reset = function() {
	        $scope.firstName = "";
	        $scope.lastName = "";
	        $scope.changeForm.submitted=false;
	    };
	    
	    $scope.resetChangePassword = function() {
	        $scope.oldPassword = "";
	        $scope.newPassword = "";
	        $scope.confirmPassword = "";
	        $scope.passwordForm.submitted=false;
	    };
	    
	    $scope.saveNameChanges = function() {
	    	$scope.loadingIcon = true;
	    	var endpointURL = baseURL + propertiesConfig.details.userDetails;
	    	var params = { firstName : $scope.firstName, lastName: $scope.lastName,distributorId:$scope.distributorId,email:$scope.email};
			 commonFactoryForRestCall.getURL(endpointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
				 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
				 commonFactoryForRestCall.getURL(endpointURL).get({id:$scope.distributorId},function(data,status,headers,config) {
					 $scope.firstName = data.firstName;
					 $scope.lastName =  data.lastName;
					 $cookies.put(propertiesConfig.details.firstName,$scope.firstName);
					 $scope.loadingIcon = false;
					 $scope.$emit('updateFirstNameEvent');
				 }, function(data,status,headers,config) { $scope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				 $scope.loadingIcon = false;});
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			 $scope.loadingIcon = false;});
	    };
	    
	    
	   $scope.saveChangePassword = function() {
	    	var endpointURL = baseURL + propertiesConfig.details.changePassword;
	    	var params = { oldPassword : $scope.oldPassword, newPassword: $scope.newPassword, confirmPassword:$scope.confirmPassword,distributorId:$scope.distributorId};
			 commonFactoryForRestCall.getURL(endpointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
				 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;
				 $scope.resetChangePassword();
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				 });
	    };
	    
}]);