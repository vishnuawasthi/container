app.controller('billingInvoiceCtrl', ['$scope', 'propertiesConfig', 'commonFactoryForRestCall', 'paginationService', '$state','responseMessageService','$timeout','$cookies','searchToggleService','commonFactoryForHttp',
	function($scope, propertiesConfig, commonFactoryForRestCall, paginationService, $state,responseMessageService,$timeout,$cookies,searchToggleService,commonFactoryForHttp) {
	$scope.loadingIcon = true;
	$scope.servicesDetails = '';
	$scope.serviceError = false;
	$scope.integrationCode = 'softlayer';
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	var baseURL = propertiesConfig.details.baseReportingURL;
	baseURL += propertiesConfig.details.cloudInvoice;
	$scope.currentPage = 0;
	paginationService.loadPageCounts($scope);
	$scope.resultsCount = 0;
	$scope.search ={};
	$scope.listofStatus=['PAID','OUTSTANDING','OVERDUE'];
	var paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		baseURL: baseURL,
		propertiesConfig: propertiesConfig
		
	});
	paginationService.getPageData($scope, paginationParams);
	$scope.prevPage = function () {
		paginationService.prevPage($scope, paginationParams);
	};
	$scope.nextPage = function () {
		if($scope.currentPage < $scope.noOfPages-1 ){
			paginationService.nextPage($scope, paginationParams);
		} else {
			return false;
		}
	};
	$scope.setPage = function () {
		paginationService.setPage($scope, paginationParams, this);
	};

	$scope.pageSizeChange = function () {
		$scope.currentPage = 0;
		paginationService.getPageData($scope, paginationParams);
	};

	$scope.viewInvoiceDetails = function (invoice) {
	/*	var roleBasedData = roleBasedFeatureService.getPermissions('Invoice');
		$scope.isRead = roleBasedData.isRead;
		$scope.isWrite = roleBasedData.isWrite;*/
		$cookies.put('cloudInvoiceId',invoice.cloudInvoiceId);
		$state.go('manager.invoiceDetails');
	};
	$scope.searchToggle = function(){
		searchToggleService.toggleSearch();
	};
	$scope.populateInvoiceNoList = function(invoiceNoSelect){
        var listOfInvoiceNoEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.invoiceSearch;
        var invoiceSearchParams = angular.extend({
               invoiceNumber: invoiceNoSelect
        });
        commonFactoryForHttp.getURL('GET',listOfInvoiceNoEndPointURL,invoiceSearchParams).success(function(data, status, headers, config) {
               $scope.listofInvoiceNo =data;
        }).error( function(data, status, headers, config) {
               $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });

 };
 
	 $scope.populateCompanyNameList = function(companyNameSelect){
	     var listOfCompanyNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.invoiceSearch;
	     var invoiceSearchParams = angular.extend({
	            resellerCompanyName: companyNameSelect
	     });
	
	     commonFactoryForHttp.getURL('GET',listOfCompanyNameEndPointURL,invoiceSearchParams).success(function(data, status, headers, config) {
	            $scope.listofCompanyName =data;
	     }).error( function(data, status, headers, config) {
	            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	
	     });
	
	};

	$scope.populateStatusList = function(statusSelect){
	    var listOfStatusEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.invoiceSearch;
	    var invoiceSearchParams = angular.extend({
	           invoiceStatus: statusSelect
	    });
	    commonFactoryForHttp.getURL('GET',listOfStatusEndPointURL,invoiceSearchParams).success(function(data, status, headers, config) {
	           $scope.listofStatus =data;
	    }).error( function(data, status, headers, config) {
	           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	    });
	
	};

	$scope.searchReset = function(){
		$scope.companyNameSelect='';
		$scope.cloudResellerId='';
		$scope.invoiceNoSelect='';
		$scope.statusSelect = '';
		$scope.search.invoiceFromDt = null;
		$scope.search.invoiceToDt = null;
		$scope.search.dueFromDt = null;
		$scope.search.dueToDt = null;
		$scope.errInvoiceMessage = '';
		$scope.errDueMessage = '';
		$scope.formattedInvoiceFromDt = null;
		$scope.formattedInvoiceToDate = null;
		$scope.formattedDueFromDt = null;
		$scope.formattedDueToDate = null;
	};

	$scope.searchRecords = function (){
		
		$scope.errInvoiceMessage = '';
		 $scope.errDueMessage = '';
		$scope.currentPage = 0;
		paginationService.loadPageCounts($scope);
		var paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
			baseURL : baseURL,
			propertiesConfig:propertiesConfig,
		});
		$scope.formattedInvoiceFromDt = null;
		$scope.formattedInvoiceToDate = null;
		$scope.formattedDueFromDt = null;
		$scope.formattedDueToDate = null;
		var errorInvoiceFlag = false;
		var errorDueFlag = false;
		var errorInvoiceSet = false;
		var errorDueSet = false;
		 if(!$scope.search.invoiceFromDt && !$scope.search.invoiceToDt ){
			errorInvoiceSet = true;
		}if(!$scope.search.dueFromDt  && !$scope.search.dueToDt){
			errorDueSet = true;
		}
		
		if((!$scope.search.invoiceFromDt && $scope.search.invoiceToDt )|| ( $scope.search.invoiceFromDt  && !$scope.search.invoiceToDt )){
			$scope.errInvoiceMessage = propertiesConfig.details.validDateMsg;
			errorInvoiceFlag = true;
		}
		if((!$scope.search.dueFromDt  && $scope.search.dueToDt)||($scope.search.dueFromDt && !$scope.search.dueToDt )){
			$scope.errDueMessage = propertiesConfig.details.validDateMsg;
			errorDueFlag = true;
		}
		if($scope.search.invoiceFromDt){
			var invoiceFromDate = new Date($scope.search.invoiceFromDt);
			$scope.formattedInvoiceFromDt =  invoiceFromDate.getFullYear()+"-"+(invoiceFromDate.getMonth()+1) + "-"+invoiceFromDate.getDate();
		}
		if($scope.search.invoiceToDt ){
			var invoiceToDate = new Date($scope.search.invoiceToDt);     
			$scope.formattedInvoiceToDate = invoiceToDate.getFullYear()+"-"+(invoiceToDate.getMonth()+1) + "-"+invoiceToDate.getDate();
		}
     	if($scope.search.dueFromDt){
     		var dueFromDate = new Date($scope.search.dueFromDt);
     		$scope.formattedDueFromDt =  dueFromDate.getFullYear()+"-"+(dueFromDate.getMonth()+1) + "-"+dueFromDate.getDate();
     	}
     	if($scope.search.dueToDt ){
     		var dueToDate = new Date($scope.search.dueToDt);
     		$scope.formattedDueToDate = dueToDate.getFullYear()+"-"+(dueToDate.getMonth()+1) + "-"+dueToDate.getDate();
     	}
     	if((($scope.search.invoiceFromDt ) >=($scope.search.invoiceToDt)) && !errorInvoiceFlag && !errorInvoiceSet){
     			$scope.errInvoiceMessage = propertiesConfig.details.EndDateValidationMsg;
     			errorInvoiceFlag = true;
         }
     	if((($scope.search.dueFromDt) >= ($scope.search.dueToDt)) && !errorDueFlag && !errorDueSet){
        	 $scope.errDueMessage = propertiesConfig.details.EndDateValidationMsg;
        	 errorDueFlag = true;
         }
     	if(!errorInvoiceFlag && !errorDueFlag ){
     		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
     	}
	};

	$scope.paginationParamsWithSearch = function(){
		return angular.extend({
			resellerName: $scope.companyNameSelect,
			cloudInvoiceId : $scope.cloudInvoiceId,
			invoiceNumber:$scope.invoiceNoSelect,
			startInvoiceDate:$scope.formattedInvoiceFromDt,
			endInvoiceDate:$scope.formattedInvoiceToDate,
			startDueDate:$scope.formattedDueFromDt,
			endDueDate:$scope.formattedDueToDate,
			status:$scope.statusSelect
		});
	};
	
}]);
app.filter('isPaid', function() {
	return function(input) {
	  return input === true ? 'Paid' : 'Pending' ;
	};
});
