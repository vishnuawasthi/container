// Config credentials Controller to create,update,delete operations from database
 app.controller('serviceAuthCredentialsCtrl',  ['$scope', '$stateParams', 'commonFactoryForRestCall', 'propertiesConfig', '$state', 'moduleActiveService', 'responseMessageService', '$timeout', '$cookies', 'factoryForRoleBasedFeature',
	 function ($scope, $stateParams, commonFactoryForRestCall, propertiesConfig, $state, moduleActiveService, responseMessageService, $timeout, $cookies, factoryForRoleBasedFeature) {
	$scope.master = {};
	$scope.serviceId =  $cookies.get(propertiesConfig.details.id);
	$scope.integrationCode= $cookies.get(propertiesConfig.details.integrationCode);
	$scope.serviceName= $cookies.get(propertiesConfig.details.serviceName);
		$scope.cloudCredentials={};
		$scope.cloudCredentials.submitted=false;
	var baseURL = propertiesConfig.details.baseURL;
	$scope.isExists=false;
	$scope.isExistsFlag=false;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var endPointURL = propertiesConfig.details.serviceCredential;
	endPointURL = baseURL+ endPointURL;
	$scope.loadingIcon = true;
	$scope.loadSetUpCredentials = function(){
		   var params = angular.extend({
	            serviceId:$scope.serviceId
	        });
		moduleActiveService.getModulesData($scope);
		commonFactoryForRestCall.getURL(endPointURL).get(params,undefined,function(data,status,headers,config) {
			if(data.content[0] != undefined){
				$scope.service.apiKey= data.content[0].apiKey;
				$scope.service.username=data.content[0].username;
				$scope.service.accountNumber=data.content[0].accountNumber;
				$scope.service.password=data.content[0].password;
				$scope.service.serviceCredentialId=data.content[0].serviceCredentialId;
				if(data.content[0].username!=null && data.content[0].username!=''){
					$scope.isExists=true;
					$scope.isExistsFlag=!$scope.isExistsFlag;
				}
			}
			$scope.loadingIcon = false;
		}, function(data,status,headers,config) {
			$scope.loadingIcon = false;});
	};

	$scope.reset = function() {
		$scope.service = angular.copy($scope.master);
			$scope.cloudCredentials.submitted=false;
	};
	$scope.cancel = function() {
		$scope.loadSetUpCredentials();
	};

	$scope.showUpdateView=function() {
		$scope.isExistsFlag=!$scope.isExistsFlag;
	};
	
	$scope.checkAndCreate = function(service){
		$scope.loadingIcon = true;
		var params = {};
		if(!$scope.isExists){
			params = { apiKey :service.apiKey, username:service.username,serviceId:$scope.serviceId,accountNumber:service.accountNumber,password:service.password};
				commonFactoryForRestCall.getURL(endPointURL).post(JSON.stringify(params),function(data,status,headers,config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.setUpMsg+propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
				$scope.loadSetUpCredentials();
			}, function(data,status,headers,config) {
				$scope.loadSetUpCredentials();
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;});
		}else{
			params = { apiKey :service.apiKey, username:service.username, serviceId:$scope.serviceId,serviceCredentialId:service.serviceCredentialId,accountNumber:service.accountNumber,password:service.password};
			commonFactoryForRestCall.getURL(endPointURL).put(JSON.stringify(params),function(data,status,headers,config) {
				responseMessageService.showResponseMsg(propertiesConfig.details.setUpMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
				$scope.loadSetUpCredentials();
			}, function(data,status,headers,config) { 
				$scope.loadSetUpCredentials();
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				} else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
				});
		}
	};
	$scope.updateStatus = function(){
		$scope.loadingIcon = true;
		var service ={};
		var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		endPointServiceURL =baseURL+ endPointServiceURL;
		service.serviceId= $scope.serviceId;
		service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;
		if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				$scope.isPublished = !$scope.isPublished;
				$scope.loadingIcon = false;
				 responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			},function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
			});
		}else if($scope.isEnablePublish===false && service.isPublished==='true'){
			 $scope.loadingIcon = false;
			 responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.statusConfirmationPopup = false;
	};
	/*$scope.gotoPathWithParams = function(path){
		$state.get(path).params.id = $scope.serviceId;
		$state.get(path).params.serviceName = $scope.serviceName;
		$state.get(path).params.isPublished = $scope.isPublished;
		$state.go(path);
	};*/
	$scope.statusConfirmationPopup = false;
	 $scope.showStatusConfirmationPopup = function(flag){
	    	$scope.statusConfirmationPopup = flag;
	    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	    };
	    
}]);
