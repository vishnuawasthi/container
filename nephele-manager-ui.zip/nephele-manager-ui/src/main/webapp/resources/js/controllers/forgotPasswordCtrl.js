// Forgot Password Controller to send request with email
 app.controller('forgotPasswordCtrl',  ['$scope', 'commonFactoryForRestCall','propertiesConfig','$state','responseMessageService','$timeout',
	 function ($scope, commonFactoryForRestCall,propertiesConfig,$state,responseMessageService,$timeout) {
	 $scope.validateEmail = function(emailId){
		 var baseURL = propertiesConfig.details.baseURL;
		 var endPointURL = propertiesConfig.details.forgetPassword;
		 endPointURL =baseURL+ endPointURL;
			 var service = { email :emailId};
			 commonFactoryForRestCall.getURL(endPointURL).post(JSON.stringify(service),function(data,status,headers,config) {
				 $scope.updateSuccessMessage=propertiesConfig.details.updateSuccessMessage;

				$timeout(function(){
                  		 $state.go(propertiesConfig.details.index);
                }, 5000);
			 }, function(data,status,headers,config) {
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				 
			 });
	 };
	 $scope.cancel= function(){
		 $state.go(propertiesConfig.details.index);
	 };
	 
 }]);
 
 //Reset Password Controller 
 app.controller('resetPasswordCtrl',  ['$scope', 'commonFactoryForRestCall','propertiesConfig','resetPasswordKey','$state','responseMessageService','$timeout',
     function ($scope, commonFactoryForRestCall,propertiesConfig,resetPasswordKey,$state,responseMessageService,$timeout) {
	 $scope.resetPassword= function(newPasswrd,confirmPassword){
		 var baseURL = propertiesConfig.details.baseURL;
		 var endPointURL = propertiesConfig.details.resetPassword;
		 endPointURL =baseURL+ endPointURL;
			 var service = { resetPasswordToken :resetPasswordKey,newPassword:newPasswrd,confirmPassword:confirmPassword};
			 commonFactoryForRestCall.getURL(endPointURL).post(JSON.stringify(service),function(data,status) {
				 var responsestatus = status;
				// responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.successMsgClass, $scope, $timeout);
				 $state.go(propertiesConfig.details.index);
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			 });
	 };
	 $scope.cancel= function(){
		 $state.go(propertiesConfig.details.index);
	 };
 }]);
    app.directive('compareTo', function() {
      return {
        require: "ngModel",
        scope: {
          otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {

          ngModel.$validators.compareTo = function(modelValue) {
            return modelValue == scope.otherModelValue;
          };

          scope.$watch("otherModelValue", function() {
            ngModel.$validate();
          });
        }
      };
    });

