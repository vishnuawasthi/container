app.controller('servicesReportCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService',
    function($scope,propertiesConfig,commonFactoryForRestCall,paginationService) {
    $scope.loadingIcon = false;
    $scope.servicesDetails = '';
    $scope.serviceError=false;
    $scope.resultsCount = 0;
    $scope.resultsFound = propertiesConfig.details.resultsFound;
    $scope.monthsArray = propertiesConfig.details.months;
    $scope.date = new Date();
    $scope.month = $scope.date.getMonth();
    $scope.monthName = '';
    $scope.year = $scope.date.getFullYear();
    for(var loop =0 ; loop<$scope.monthsArray.length;loop++){
        if($scope.month == $scope.monthsArray[loop].number){
            $scope.months = $scope.monthsArray[loop].number+' '+$scope.monthsArray[loop].monthName;
            $scope.monthNames = $scope.monthsArray[loop].monthName;
            break;
        }
    }
    var baseReportingURL = propertiesConfig.details.baseReportingURL;
    var endPointURL = propertiesConfig.details.topServices;
    endPointURL = baseReportingURL+endPointURL;
    $scope.currentPage = 0;
    paginationService.loadPageCounts($scope);
    var paginationParams = angular.extend({
        commonFactoryForRestCall: commonFactoryForRestCall,
        baseURL: endPointURL,
        propertiesConfig:propertiesConfig
       
    });

    var params = angular.extend({
        page: $scope.currentPage,
        size:$scope.noOfitems,
        monthNumber: $scope.month,
        year: $scope.date.getFullYear()
    });
    $scope.onMonthChange = function(months) {
        $scope.month = months.split(" ")[0];
        $scope.monthNames = months.split(" ")[1];
        params = {
            monthNumber: $scope.month,
            year: $scope.year,
            page: $scope.currentPage,
            size:$scope.noOfitems
        };
        paginationService.getPageData($scope,paginationParams,params);
    };
    paginationService.getPageData($scope,paginationParams,params);

    $scope.prevPage = function () {
        paginationService.prevPage($scope,paginationParams,params);
    };

    $scope.nextPage = function () {
        if($scope.currentPage < $scope.noOfPages-1 ){
            paginationService.nextPage($scope,paginationParams,params);
        } else{
            return false;
        }
    };

    $scope.setPage = function () {
        paginationService.setPage($scope,paginationParams,this,params);
    };

    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
        paginationService.getPageData($scope, paginationParams,params);
    };
}]);