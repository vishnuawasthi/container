app.controller('dashBoardCtrl', ['$scope', 'propertiesConfig','commonFactoryForRestCall','graphsService','factoryForRoleBasedFeature','roleFlagService',
	function($scope, propertiesConfig,commonFactoryForRestCall,graphsService,factoryForRoleBasedFeature,roleFlagService) {
    $scope.loadingIcon = true;
    $scope.totalCloudServices = 0;
    $scope.totalNoOfResellers = 0;
    $scope.lastMonthRevenue = 0;
    $scope.topResellersDetails = [];
    $scope.invoicesDetails = [];

    $scope.servicesActiveFlag = false;
    $scope.resellersCountFlag = false;
    $scope.lastMonthRevenueFlag = false;
    $scope.reportResellersFlag = false;
    $scope.reportServicesFlag = false;
    $scope.lastYearRevenueForGraphFlag = false;
    
    var roleBasedPermissions = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.roleBasedAll);
    roleFlagService.assignFlagToScope(roleBasedPermissions,$scope,propertiesConfig);

	$scope.lastMonthRevenueFlag = !$scope.reportRoleFlag;
    $scope.reportResellersFlag = !$scope.reportRoleFlag;
    $scope.reportServicesFlag = !$scope.reportRoleFlag;
    $scope.lastYearRevenueForGraphFlag = !$scope.reportRoleFlag;
    $scope.servicesActiveFlag = !$scope.servicesRoleFlag;
    $scope.resellersCountFlag = !$scope.resellersRoleFlag;
    
    $scope.loadingIcon = ($scope.reportRoleFlag && $scope.servicesRoleFlag && $scope.resellersRoleFlag);
    
    $scope.date = new Date();
    var lastMonth = $scope.date.getMonth()-1;
    $scope.date.setMonth(lastMonth);
    var baseURL = propertiesConfig.details.baseURL;
    var baseReportingURL = propertiesConfig.details.baseReportingURL;
    var endPointURL = propertiesConfig.details.servicesActiveCount;
    if($scope.servicesRoleFlag){
	    commonFactoryForRestCall.getURL(baseURL + endPointURL).get(undefined, undefined, function(data, status, headers, config) {
	        $scope.servicesActiveFlag = true;
	    	$scope.totalCloudServices = data.services;
	        $scope.stopLoading();
	    }, function(data, status, headers, config){
	        $scope.servicesActiveFlag = true;
	        $scope.stopLoading();
	    });
    }

    if($scope.resellersRoleFlag){
	    endPointURL = propertiesConfig.details.resellersCount;
	    commonFactoryForRestCall.getURL(baseURL + endPointURL).get(undefined, undefined, function(data, status, headers, config) {
	    	$scope.totalNoOfResellers = data.total;
	        $scope.resellersCountFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	        $scope.resellersCountFlag = true;
	        $scope.stopLoading();
	    });
    }

    if($scope.reportRoleFlag){
	    var params = {
	        monthNumber: $scope.date.getMonth() + 1,
	        year: $scope.date.getFullYear()
	    };
	    endPointURL = propertiesConfig.details.lastMonthRevenue;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
	        if(data.content != undefined)
	        for(var loop =0; loop<data.content.length;loop++){
	            if(null != data.content[loop].amount) {
	                $scope.lastMonthRevenue = data.content[loop].amount;
	            break;
	            }
	        }
	        $scope.lastMonthRevenueFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	        $scope.lastMonthRevenueFlag = true;
	        $scope.stopLoading();
	    });
	    params = {
	        monthNumber: $scope.date.getMonth() + 1,
	        year: $scope.date.getFullYear(),
	        page:0,
	        size:5
	    };
	    endPointURL = propertiesConfig.details.reportReseller;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
	        var topResellerData = [];
	        for(var index in data.content) {
	            topResellerData.push({"amount" : data.content[index].amount, "name" : data.content[index].name,"id":data.content[index].userId});
	        }
			$scope.nodataClassForTopReseller = topResellerData.length>0 ?"":"svg-noData";
	        var params = angular.extend({
	            labelType: "amount",
	            showLabels:true,
	            pieLabelsOutside: true,
	            labelThreshold :.05,
	            showLegend : true,
	            tooltips : true,
	            donut : true,
	            donutRatio: 0.35,
	            colorRange: d3.scale.category10().range(),
	            container: "topFiveResellerDataDiv",
	            data: topResellerData,
	            xAxisDataColumn:'name',
	            yAxisDataColumn:'amount',
	            noData: "No data available"
	        });
	        graphsService.drawPieWithDonutUsingNVD3(params);
	        $scope.reportResellersFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config){
	        $scope.reportResellersFlag = true;
	        $scope.stopLoading();
	    });
	
	    endPointURL = propertiesConfig.details.topServices;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
	        var topServicesData = [];
	        for(var index in data.content) {
	            topServicesData.push({"amount" : data.content[index].amount, "name" : data.content[index].serviceName,"id":data.content[index].userId});
	        }
			$scope.nodataClassForTopServices = topServicesData.length>0 ?"":"svg-noData";
	        var params = angular.extend({
	            labelType: "amount",
	            showLabels:true,
	            pieLabelsOutside: true,
	            labelThreshold :.05,
	            showLegend : true,
	            tooltips : true,
	            donut : true,
	            donutRatio: 0.35,
	            colorRange: d3.scale.category10().range(),
	            container: "topFiveServicesDataDiv",
	            data: topServicesData,
	            xAxisDataColumn:'name',
	            yAxisDataColumn:'amount',
	            noData: "No data available"
	        });
	        graphsService.drawPieWithDonutUsingNVD3(params);
	        $scope.reportServicesFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	        $scope.reportServicesFlag = true;
	        $scope.stopLoading();
	    });
	    endPointURL = propertiesConfig.details.last12MonthsRevenue;
	    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(undefined, undefined, function(data, status, headers, config) {
	    	var lastMonthRevenueData=[];
	        for(var index in data.content) {
		    	 lastMonthRevenueData.push({"month": data.content[index].month.substring(0, 3), "amount" : data.content[index].amount ? data.content[index].amount : 0, monthNumber: data.content[index].monthNumber});
		     }
	        var params = angular.extend({
		    	 showLegend:true,
		    	 showYAxis:true,
		    	 showXAxis:true,
		    	 interactive:50,
		    	 container:"chart",
				 xAxisLabel:'Month',
				 yAxisLabel:'Amount',
				 xAxisTicks:12,
				 yAxisTicks:5,
				 xAxisLabelParamFromData: 'month',
		         data:lastMonthRevenueData,
				 dataToDisplay : $scope.dataToDisplay(lastMonthRevenueData),
	             noData: "No data available"
		        });
	        graphsService.drawLineUsingNVD3(params);
	        $scope.lastYearRevenueForGraphFlag = true;
	        $scope.stopLoading();
	    }, function(data, status, headers, config) {
	    	$scope.lastYearRevenueForGraphFlag = true;
	        $scope.stopLoading();
	    });
	    $scope.dataToDisplay = function(data) {
			var dataToDisplayArray = [];
			for (var i = 0; i < data.length; i++) {
				dataToDisplayArray.push({x: data[i].monthNumber, y: data[i].amount});
			}
			return [{values: dataToDisplayArray,key: 'Last 12 Months Revenue',color: '#FF0066'}];
		};
	}
    $scope.stopLoading = function(){
    	 $scope.loadingIcon = !($scope.servicesActiveFlag && $scope.resellersCountFlag && $scope.lastMonthRevenueFlag && $scope.reportResellersFlag && $scope.reportServicesFlag && $scope.lastYearRevenueForGraphFlag);
    };
}]);