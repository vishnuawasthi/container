app.controller('headerWithLogOutCtrl', ['$scope','propertiesConfig','sessionExpireService',function($scope,propertiesConfig,sessionExpireService) {
	$scope.callLogOut = function(){
		sessionExpireService.callExpire(propertiesConfig.details.logoutMsg);
	}
}]);
