app.controller('editProductCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','moduleActiveService','responseMessageService','$cookies','factoryForRoleBasedFeature','$timeout','commonFactoryForHttp',
                                           	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,moduleActiveService,responseMessageService,$cookies,factoryForRoleBasedFeature,$timeout,commonFactoryForHttp) {
   	$scope.showSearchContent = true;
	$scope.loadingIcon = true;
   	var  baseURL = propertiesConfig.details.baseURL;
   	var products = $cookies.getObject("products");
   	$scope.integrationCode= $cookies.get(propertiesConfig.details.integrationCode);
	$scope.serviceName= $cookies.get(propertiesConfig.details.serviceName);
	if(products){
		for(var loop = 0; loop<products.length;loop++){
				$scope.relativeProductID = products[loop].productId ;
				$scope.name = products[loop].name ;
				$scope.serviceName = products[loop].serviceName ;
				$scope.isFeatured = products[loop].isFeatured ;
				$scope.hasRelatedProducts = products[loop].hasRelatedProducts ;
		};
	}
   	var cloudEndPointURL = baseURL+propertiesConfig.details.relatedCloudProduct;
   	var externalEndPointURL = baseURL+propertiesConfig.details.relatedexternalproducts;
    $scope.serviceId = $cookies.get(propertiesConfig.details.id);
   	$scope.resultsfound = propertiesConfig.details.resultsFound;
   	$scope.resultsCount = 0;
   	$scope.currentPage = 0;
   	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
   	$scope.isRead = roleBasedData.isRead;
   	$scope.isWrite = roleBasedData.isWrite;
   	$scope.cloudflag = false;
   	$scope.externalFlag = false;
   	$scope.modulesActiveFlag = false;
   	
   	$scope.stopLoading = function(){
		$scope.loadingIcon = !($scope.cloudflag && $scope.modulesActiveFlag  && $scope.externalFlag);
	};
   	$scope.loadProductDetails = function(){
		$scope.loadingIcon = true;
		commonFactoryForRestCall.getURL(cloudEndPointURL).get({cloudproductId:$scope.relativeProductID}, function(data,status,headers,config) {
			$scope.cloudProductList = data.content;
			$scope.cloudflag = true;
			$scope.stopLoading();
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
		commonFactoryForRestCall.getURL(externalEndPointURL).get({cloudproductId:$scope.relativeProductID}, function(data,status,headers,config) {
			$scope.externalProductList = data.content;
		 	$scope.externalFlag = true;
		 	$scope.stopLoading();
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
		getModulesActive();
	};
	
	var getModulesActive = function(){
		 moduleActiveService.getModulesData($scope);
		 $scope.modulesActiveFlag = true;
			$scope.stopLoading();
	};
	
	$scope.prevPage = function () {
		paginationService.prevPage($scope,paginationParams);
    };
    $scope.nextPage = function () {
	   	 if($scope.currentPage < $scope.noOfPages-1 ){
	   		 paginationService.nextPage($scope,paginationParams);
	   	 }else{
	   		 return false;
	   	 }
    };
    $scope.setPage = function () {
    	paginationService.setPage($scope,paginationParams,this);
    };
    $scope.pageSizeChange = function () {
    	$scope.currentPage = 0;
    	paginationService.getPageData($scope,paginationParams);   
    };
    
    $scope.searchToggle = function(){
    	searchToggleService.toggleSearch();
    };
   
   $scope.removeCloudProduct = function(cloudProducts,index){
	   if($scope.cloudProductList!=undefined){
				$scope.cloudProductList.splice(index, 1);
				responseMessageService.showResponseMsg(propertiesConfig.details.removedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		};
   };
   $scope.removeExternalProduct = function(externalProducts,index){
	   if($scope.externalProductList!=undefined){
				$scope.externalProductList.splice(index, 1);
				responseMessageService.showResponseMsg(propertiesConfig.details.removedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		};
   };
   $scope.selectedCheck = function(){
	   var hasRelatedProductURL = baseURL+propertiesConfig.details.hasRelatedProduct;
	   var params = {
			   productId:$scope.relativeProductID ,
			   isFeatured: $scope.isFeatured,
			   hasRelatedProducts : $scope.hasRelatedProducts}
	   commonFactoryForRestCall.getURL(hasRelatedProductURL).put(undefined,params, function(data,status,headers,config) {
			$scope.loadingIcon = false;
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
		});
   }
   
   $scope.saveProducts  = function(){
	   $scope.loadingIcon = true;
	   var cloudEndPointURL = baseURL+propertiesConfig.details.relatedCloudProductDel;
	   var externalEndPointURL = baseURL+propertiesConfig.details.relatedexternalproductsDel;
	   var cloudproductID = $scope.relativeProductID//$scope.cloudProductList[0].cloudproductId;
	   var relatedCloudproducts = [];
	   if(($scope.cloudProductList == '' && $scope.externalProductList == '')||($scope.cloudProductList == undefined && $scope.externalProductList == undefined)){
      	 	responseMessageService.showResponseMsg(propertiesConfig.details.selecteProductsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
      	 	$scope.loadingIcon = false;
       }else{
    	   if($scope.cloudProductList != undefined ){
			   for(var loop = 0; loop<$scope.cloudProductList.length;loop++){
				   relatedCloudproducts.push($scope.cloudProductList[loop].relatedCloudproductId);
			   }
    	   }
		   var cloudParams = { cloudproductId:cloudproductID ,
				   				relatedCloudproducts: relatedCloudproducts};
		   var externalProducts = [];
		   if( $scope.externalProductList != undefined){
			   for(var loop = 0; loop<$scope.externalProductList.length;loop++){
				   externalProducts.push($scope.externalProductList[loop].externalProductId);
			   }
		   }
		   var externalParams = { cloudproductId:cloudproductID ,
				   				  externalProducts: externalProducts};
		   if($scope.cloudProductList == undefined ||$scope.cloudProductList.length==0){
	        	 responseMessageService.showResponseMsg(propertiesConfig.details.selecteCloudProductsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	        	 $scope.loadingIcon = false;
	       }else if($scope.externalProductList == undefined||$scope.externalProductList.length==0){
	        	 responseMessageService.showResponseMsg(propertiesConfig.details.selecteHardwareProductsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
	        	 $scope.loadingIcon = false;
	       } else{
				   commonFactoryForRestCall.getURL(cloudEndPointURL).post(undefined,cloudParams, function(data,status,headers,config) {
					   commonFactoryForRestCall.getURL(externalEndPointURL).post(undefined,externalParams, function(data,status,headers,config) {
							$scope.loadProductDetails();
							$state.go("manager.newProducts");
							$scope.loadingIcon = false;
							responseMessageService.showResponseMsg(propertiesConfig.details.productsMsg +propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
						}, function(data,status,headers,config) {
							if(data.status === 400){
								responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
							}
							$scope.loadingIcon = false;
						});
					}, function(data,status,headers,config) {
						if(data.status === 400){
							responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}
						$scope.loadingIcon = false;
					});
	         }
       }
   };
   
   $scope.cancel = function () {
	    $scope.loadProductDetails();
	    $state.go("manager.newProducts");
   };
   
   $scope.populateProductList = function(searchProduct){
		  var listOfOsEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.productsPublishSearch;
		  var searchRolesParams = angular.extend({
			  productName: searchProduct
			});
	   		commonFactoryForHttp.getURL('GET',listOfOsEndPointURL,searchRolesParams).success(function(data, status, headers, config) {
	   			$scope.listofCloudProducts = data;
	   		}).error(function(data, status, headers, config) {
	   			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	   		});
	};
	$scope.populateExternalProductList = function(searchProduct){
		 var listOfOsEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.externalProductsSearch;
		 var searchRolesParams = angular.extend({
			  extProductName: searchProduct
	   		});
		commonFactoryForHttp.getURL('GET',listOfOsEndPointURL,searchRolesParams).success(function(data, status, headers, config) {
			$scope.listofExternalProducts = data;
		}).error(function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		});
	};
	
	$scope.addProduct = function(searchProduct,productType){
		var addProductURL ='';
		if(productType =='external'){
			addProductURL = baseURL +  propertiesConfig.details.addSearchExternalProduct;
		}else{
			addProductURL = baseURL +  propertiesConfig.details.addSearchProduct;
		}
		var params = {
				productName:searchProduct
		};
	commonFactoryForRestCall.getURL(addProductURL).get(params,undefined,function(data,status,headers,config) {
		$scope.cloudData = {};
		$scope.externalData = {};
		var cloudProductExists= false;
		var relatedProductExists = false;
		if(productType =='external'){
			if($scope.externalProductList == undefined){
				$scope.externalProductList=[];
			}
			for(var loop=0;loop<$scope.externalProductList.length;loop++){
				if($scope.externalProductList[loop].externalProductId == data.externalProductId){
					responseMessageService.showResponseMsg(propertiesConfig.details.productExistsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					relatedProductExists = true;
				}
			}
			if(!relatedProductExists){
				$scope.externalData.externalProductId=data.externalProductId;
				$scope.externalData.serviceName=data.brandName;
				$scope.externalData.externalProductName=data.productName;
				$scope.externalData.status=data.status;
				if(data.externalProductId != undefined){
					$scope.externalProductList.push($scope.externalData);
				}
			}
			$scope.searchExternalProduct='';
		}else{
			if($scope.cloudProductList == undefined){
				$scope.cloudProductList=[];
			}
			for(var loop=0;loop<$scope.cloudProductList.length;loop++){
				if($scope.cloudProductList[loop].relatedCloudproductId == data.productId){
					responseMessageService.showResponseMsg(propertiesConfig.details.productExistsMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					cloudProductExists = true;
				}
			}
			if(!cloudProductExists){
				$scope.cloudData.relatedCloudproductId =data.productId;
				$scope.cloudData.serviceName =data.serviceName;
				$scope.cloudData.relatedProductName =data.name;
				$scope.cloudData.status =data.status;
				if(data.productId != undefined){
					$scope.cloudProductList.push($scope.cloudData);
				}
			}
			$scope.searchCloudProduct='';
		}
     }, function(data,status,headers,config) {
		if(data.status === 400){
			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
	});
};
  
}]);