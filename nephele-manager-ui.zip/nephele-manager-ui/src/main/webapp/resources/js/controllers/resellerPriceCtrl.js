app.controller('resellerPriceCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','$stateParams','responseMessageService','$timeout',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,$stateParams,responseMessageService,$timeout) {
	 $scope.servicesDetails = '';
	    var baseURL;
	    $scope.serviceError=false;
	    var paginationParams ;
	    baseURL = propertiesConfig.details.baseURL;
		var endPointURL = propertiesConfig.details.cloudResellerPrice; 
		baseURL += endPointURL;
		$scope.currentPage = 0;
		 paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
	        baseURL: baseURL,
	        propertiesConfig:propertiesConfig
	      
	    });
		 
		 //Get Price Group Details 
		 $scope.loadPriceGroupDetails=function(){
			paginationService.getPageData($scope,paginationParams);   
		 	 $scope.prevPage = function () {
		 		paginationService.prevPage($scope,paginationParams);
		     };
		     $scope.nextPage = function () {
		    	 if($scope.currentPage < $scope.noOfPages-1 ){
		    	 paginationService.nextPage($scope,paginationParams);
		    	 }else{
		    		 return false;
		    	 }
		     };
		     $scope.setPage = function () {
		    	 paginationService.setPage($scope,paginationParams,this);
		     };
		 };
	     
	     //Save Price Group Details
	     $scope.savedetails = function (updatedValues,reseller) {
    		 var priceGroup ={};
    		 priceGroup.distributorPriceGroupId= reseller.distributorPriceGroupId;
    		 priceGroup.name=updatedValues.name;
		 		commonFactoryForRestCall.getURL(baseURL).put(JSON.stringify(priceGroup),function(data,status,headers,config) {
		 			// $state.transitionTo($state.$current, $stateParams, {'reload':true});
		 			$scope.loadPriceGroupDetails();
		 			$scope.editFlag = false;
		 		 },function(data,status,headers,config) {
		 			if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
		 			 $scope.editFlag = false;
		 		});
	     };
	     
	     //Create New Group Name
	     $scope.creategroup = function (groupname) {
	    	var groupDetails = { name :groupname }
			 commonFactoryForRestCall.getURL(baseURL).post(JSON.stringify(groupDetails),function(data,status,headers,config) {
				 //$state.transitionTo($state.$current, $stateParams, {'reload':true});
				 $scope.loadPriceGroupDetails();
			 }, function(data,status,headers,config) { 
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			 });
	     }
	     
	     $scope.editFlag = false;
		  
		  //update edit flag when cancel the action
		  $scope.updatePriceGroup = function(showForm){
			  if(!$scope.editFlag){
				  $scope.editFlag = true;
				  showForm.$show();
			  }else{
				  alert("Please save already initiated PriceGroup");
			  }
		  };
		
		  //Remove all flags when cancel the action
		  $scope.removeFlag= function(rowform,index){
			  $scope.editFlag= false;
			  rowform.$cancel()
		  }
	  
		  //remove price group record
		  $scope.removePrice = function (groupId) {
			  if(groupId != null){
				commonFactoryForRestCall.getURL(baseURL).del({id:groupId},function(data,status,headers,config) {
					//$state.transitionTo($state.$current, $stateParams, {'reload':true});
					$scope.loadPriceGroupDetails();
				}, function(data,status,headers,config) {
					if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
				});
			  }else{
				  $scope.discountDetails.splice(index, 1);
				// $state.transitionTo($state.$current, $stateParams, {'reload':true});
			  }
		}
	     
}]);