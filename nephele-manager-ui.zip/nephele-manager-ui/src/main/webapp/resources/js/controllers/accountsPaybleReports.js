app.controller('accountsPaybleReportsCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','$cookies',
	                            	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,$cookies) {
        	$scope.loadingIcon = true;
        	$scope.servicesDetails = '';
        	$scope.serviceError=false;
        	$scope.date = new Date();
        	$scope.year = $scope.date.getFullYear();
        	$scope.serviceCode = '';
        	$scope.servicesList = [];
        	var baseURL = propertiesConfig.details.baseReportingURL;
        	var apReportURL=baseURL + propertiesConfig.details.reportAP;
        	$scope.currentPage = 0;
        	$scope.resultsCount = 0;
        	$scope.resultsFound = propertiesConfig.details.resultsFound;
        	
        	paginationService.loadPageCounts($scope);
        	var paginationParams = angular.extend({
        		commonFactoryForRestCall: commonFactoryForRestCall,
        		baseURL: apReportURL,
        		propertiesConfig:propertiesConfig
        		
        	});
        	var params ={};
        	serviceEndpointURL = propertiesConfig.details.baseURL+ propertiesConfig.details.serviceCatalog;
         	var yearEndpointURL = baseURL+ propertiesConfig.details.invoiceYearList;
        	commonFactoryForRestCall.getURL(serviceEndpointURL).get(undefined,undefined, function(data,status,headers,config) {
        		$scope.servicesList =data.content;
        		if(data.content != undefined){
        			$scope.serviceCode = data.content[0].serviceCode;
        			$scope.serviceCodeSelect =$scope.serviceCode+','+ data.content[0].name;
        			$scope.serviceName =  data.content[0].name;
        		 	commonFactoryForRestCall.getURL(yearEndpointURL).get(undefined,undefined, function(data,status,headers,config) {
                		$scope.yearList= data.years;
                		$scope.loadingIcon = false;
                		$scope.year = $scope.yearList[0];
                		if($scope.year == undefined ||$scope.year == ''){
                			$scope.year = new Date().getFullYear();
                		}
                		 params = {
                        		serviceCode: $scope.serviceCode,
                        		year: $scope.year,
                        		page: $scope.currentPage,
                        		size:$scope.noOfitems
                        	};
                		paginationService.getPageData($scope,paginationParams,undefined,params);
                	}, function(data,status,headers,config) {
                		if(data.status === 400){
                			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
                		}
                		$scope.loadingIcon = false;
                    });
        		}
        		$scope.loadingIcon = false;
        	}, function(data,status,headers,config) {
        		if(data.status === 400){
        			responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
        		}
        		$scope.loadingIcon = false;
            });
       
        	 params = {
            		serviceCode: $scope.serviceCode,
            		year: $scope.year,
            		page: $scope.currentPage,
            		size:$scope.noOfitems
            	};
        
        	$scope.onServiceChange = function(serviceCodeSelect) {
        		$scope.loadingIcon = true;
        		$scope.serviceCode = serviceCodeSelect.split(",")[0];
				$scope.serviceName = serviceCodeSelect.split(",")[1];
        			params = {
        			serviceCode:  $scope.serviceCode,
        			year: $scope.year
        		};
        		paginationService.getPageData($scope,paginationParams,undefined,params);
        	};

        	$scope.onYearChange = function(year){
        		$scope.loadingIcon = true;
        		params = {
            			serviceCode: $scope.serviceCode,
            			year: $scope.year
            		};
            		paginationService.getPageData($scope,paginationParams,undefined,params);
        	}
        	$scope.prevPage = function () {
        		paginationService.prevPage($scope,paginationParams,undefined,params);
        	};

        	$scope.nextPage = function () {
        		if($scope.currentPage < $scope.noOfPages-1 ){
        			paginationService.nextPage($scope,paginationParams,undefined,params);
        		} else{
        			return false;
        		}
        	};

        	$scope.setPage = function () {
        		paginationService.setPage($scope,paginationParams,this,undefined,params);
        	};

        	$scope.pageSizeChange = function () {
        		$scope.currentPage = 0;
        		paginationService.getPageData($scope, paginationParams,undefined,params);
        	};

        	 $scope.viewApFullReport = function (services) {
                  	$scope.apservices=services;
                  	 $cookies.putObject('apfullreport',	$scope.apservices);
                   	$state.go('manager.accountsPaybleReportsDetails');

            };

        }]);
