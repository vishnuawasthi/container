app.controller('resellerCompanyCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','responseMessageService','$timeout','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,responseMessageService,$timeout,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
	$scope.loadingIcon = false;
	$scope.integrationCode = 'softlayer';
	$scope.servicesDetails = '';
	$scope.serviceError=false;
	var paginationParams ;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.resellerForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var baseURL = propertiesConfig.details.baseURL;
	var searchURL = propertiesConfig.details.searchURL;
	var cloudResellerCompany  = baseURL+propertiesConfig.details.cloudResellerCompany;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.currentPage = 0;
	 $scope.resultsCount = 0;
	paginationService.loadPageCounts($scope);
	paginationParams = angular.extend({
		commonFactoryForRestCall: commonFactoryForRestCall,
		baseURL: cloudResellerCompany,
		propertiesConfig:propertiesConfig
		
	});
	paginationService.getPageData($scope,paginationParams);
	$scope.prevPage = function () {
		paginationService.prevPage($scope,paginationParams);
	};
	$scope.nextPage = function () {
		if($scope.currentPage < $scope.noOfPages-1 ){
			paginationService.nextPage($scope,paginationParams);
		}else{
			return false;
		}
	};
	  $scope.searchToggle = function(){
		  searchToggleService.toggleSearch();
      };
	
	$scope.setPage = function () {
		paginationService.setPage($scope,paginationParams,this);
	};
	$scope.pageSizeChange = function () {
		$scope.currentPage = 0;
		paginationService.getPageData($scope,paginationParams);
	};
	$scope.viewResellerCompanyDetails = function (reseller) {

	};
	

		
	$scope.premiumGroupsId = undefined;
	$scope.changePremiumGroupFn = function(flag,resellerCompanies){
		$scope.premiumGroupsId = undefined;
		if(flag){
			$scope.resellerCompanyName = resellerCompanies.resellerCompanyName;
			$scope.resellerCompanyId = resellerCompanies.resellerCompanyId;
			var baseURL = propertiesConfig.details.baseURL;
			var premiumGroupsList = baseURL+propertiesConfig.details.premiumGroupsList;
			var params = angular.extend({
				status: 'ACTIVE'
			});
			commonFactoryForRestCall.getURL(premiumGroupsList).get(params,undefined,function(data, status, headers, config) {
				$scope.premiumgroupDetails = data.content;
				if($scope.premiumgroupDetails && $scope.premiumgroupDetails.length > 0){
					for(var loop=0; loop<$scope.premiumgroupDetails.length;loop++){
						if($scope.premiumgroupDetails[loop].premiumGroupid === resellerCompanies.resellerPremiumGroupId){
							$scope.premiumGroupId = $scope.premiumgroupDetails[loop].premiumGroupid+" "+$scope.premiumgroupDetails[loop].name;
							$scope.premiumGroupsId = $scope.premiumgroupDetails[loop].premiumGroupid;
							$scope.premiumGroupName = $scope.premiumgroupDetails[loop].name;
							break;
						}
					}
				}
			},function(data, status, headers, config){
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}
		$scope.changePremiumGroup = flag;
	};
	$scope.premiumGroupChanged = function(premiumGroupId){
		$scope.premiumGroupsId = premiumGroupId.split(" ")[0];
		$scope.premiumGroupName = premiumGroupId.split(" ")[1];
	};
	$scope.updateDetails = function(){
		var baseURL = propertiesConfig.details.baseURL;
		var premiumGroupChangeURL = baseURL+propertiesConfig.details.updateResellerPremiumGroup;
		var params = angular.extend({
			resellerCompanyId: $scope.resellerCompanyId,
			resellerPremiumGroupId : $scope.premiumGroupsId,
			comments:$scope.comments
		});
		commonFactoryForRestCall.getURL(premiumGroupChangeURL).put(undefined,params,function(data, status, headers, config) {
			paginationService.getPageData($scope,paginationParams);
			$scope.changePremiumGroupFn(false);
			responseMessageService.showResponseMsg(propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		},function(data, status, headers, config){
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
		});
	};
	
	$scope.populateEmailList = function(emailSelect){
        var listOfEmailEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.resellersSearch;
        var resellerSearchParams = angular.extend({
               email: emailSelect
        });
        commonFactoryForHttp.getURL('GET',listOfEmailEndPointURL,resellerSearchParams).success(function(data, status, headers, config) {
               $scope.listofEmails =data;
        }).error( function(data, status, headers, config) {
               $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
        });
 };
 
 
 $scope.populateCompanyNameList = function(companyNameSelect){
     var listOfCompanyNameEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.resellersSearch;
     var resellerSearchParams = angular.extend({
    	 companyName: companyNameSelect
     });

     commonFactoryForHttp.getURL('GET',listOfCompanyNameEndPointURL,resellerSearchParams).success(function(data, status, headers, config) {
            $scope.listofCompanyName =data;
     }).error( function(data, status, headers, config) {
            $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
     });
};

$scope.populatePremiumGroupList = function(premiumGroupSelect){
    var listOfPremiumGroupEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.premiumGroupsSearch;
    var premiumGroupSearchParams = angular.extend({
    	groupName: premiumGroupSelect
    });
    commonFactoryForHttp.getURL('GET',listOfPremiumGroupEndPointURL,premiumGroupSearchParams).success(function(data, status, headers, config) {
           $scope.listofPremiumGroups =data;
    }).error( function(data, status, headers, config) {
    	$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
    });
};
 
 $scope.searchReset = function(){
		$scope.companyNameSelect='';
		$scope.cloudResellerId='';
		$scope.emailSelect='';
		//$scope.resellerPremiumGroupName='';
 };

 $scope.searchRecords = function (){
 	$scope.currentPage = 0;
 	paginationService.loadPageCounts($scope);
 	var paginationParams = angular.extend({
 		commonFactoryForRestCall: commonFactoryForRestCall,
 		baseURL:cloudResellerCompany,
 		propertiesConfig:propertiesConfig,
 	});
 	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
 };
 
 $scope.paginationParamsWithSearch = function(){
		return angular.extend({
			companyName: $scope.companyNameSelect,
			email:$scope.emailSelect,
			created:$scope.created,
			cloudResellerId : $scope.resellerCompanyId,
			premiumGroupName:$scope.premiumGroupSelect
		});
	};

     	
}]);