app.controller('bundleListCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','$cookies','responseMessageService','$timeout','searchToggleService','commonFactoryForHttp',
	                            	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,$cookies,responseMessageService,$timeout, searchToggleService,commonFactoryForHttp) {
        	var baseURL = propertiesConfig.details.baseURL;
        	var bundlelistURL=	baseURL +  propertiesConfig.details.bindlelist;
        	var bundlebyidURL=baseURL +  propertiesConfig.details.bundlebyid;
        	$scope.currentPage = 0;
        	$scope.resultsCount = 0;
         	$scope.loadingIcon = true;
        	$scope.resultsFound = propertiesConfig.details.resultsFound;
        	paginationService.loadPageCounts($scope);
        	var paginationParams = angular.extend({
        		commonFactoryForRestCall: commonFactoryForRestCall,
        		baseURL: bundlelistURL,
        		propertiesConfig:propertiesConfig
        	});
        	
        	$scope.listofStatus=['DRAFT','PUBLISHED','SUSPENDED'];
       	$scope.loadBundles = function(){
       		$scope.loadingIcon = true;
       		paginationService.getPageData($scope,paginationParams,undefined,undefined);
       	};

    	$scope.prevPage = function () {
    		paginationService.prevPage($scope,paginationParams);
    	};

    	$scope.nextPage = function () {
    		if($scope.currentPage < $scope.noOfPages-1 ){
    			paginationService.nextPage($scope,paginationParams);
    		} else{
    			return false;
    		}
    	};

    	$scope.setPage = function () {
    		paginationService.setPage($scope,paginationParams,this);
    	};

    	$scope.pageSizeChange = function () {
    		$scope.currentPage = 0;
    		paginationService.getPageData($scope, paginationParams);
    	};
    	
    	 $scope.searchToggle = function(){
    	    	searchToggleService.toggleSearch();
    	    };


          $scope.deleteBundle = function (bunbleid) {
  	         commonFactoryForRestCall.getURL(bundlebyidURL).del({id:bunbleid},function(data,status,headers,config) {
                 $scope.loadingIcon = false;
		             $scope.loadBundles();
  			     }, function(data,status,headers,config) {
  					if(data.status === 400){
  						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
  					}
  				});
           };
          $scope.bundleEdit = function (bunbleid,viewStatus) {
                 commonFactoryForRestCall.getURL(bundlebyidURL).get({id:bunbleid},function(data,status,headers,config) {
		                $cookies.put('bundleId',	data.bundleId);
		                $cookies.put('bundleFlag',viewStatus);
		                $state.go('manager.createBundle');
      			  }, function(data,status,headers,config) {
      				 if(data.status === 400){
      						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
      					}
      			});
            };
         
        $scope.bundleStatusChange = function (bunbleid,editstatus) {
          var bundlepublish ={};
		      bundlepublish.bundleId=bunbleid;
		      bundlepublish.status=editstatus;
          commonFactoryForRestCall.getURL(bundlelistURL).put(undefined,angular.toJson(bundlepublish),function(data) {
			   responseMessageService.showResponseMsg(editstatus+" "+propertiesConfig.details.success, propertiesConfig.details.successMsgClass, $scope, $timeout);
			   	$scope.loadingIcon = false;
         	$scope.loadBundles();
		     }, function(data,status,headers,config) {
			   $scope.schedulePopUp = false;
			   if(data.status === 400){
				 responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		  	 }else{
				 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		  	 }});
          };

	     $scope.bundleCreation=function(createStatus){
	    	$state.go('manager.createBundle');
	    	 $cookies.put('bundleId',	'');
             $cookies.put('bundleFlag',createStatus);
	     };
	     
	     $scope.populateBundleList = function(searchBundle){
	 		  var listOfBundlesURL = propertiesConfig.details.searchURL+propertiesConfig.details.bundleSearch;
	 		  var searchParams = angular.extend({
	 			 bundleName: searchBundle
	 			});
	 	   		commonFactoryForHttp.getURL('GET',listOfBundlesURL,searchParams).success(function(data, status, headers, config) {
	 	   			$scope.listofCloudProducts = data;
	 	   		}).error(function(data, status, headers, config) {
	 	   			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	 	   		});
	 	}; 
	 	
	 	$scope.searchReset = function(){
			 $scope.statusSelect ='';
			 $scope.searchBundle ='';
	 	};

	$scope.searchRecords = function (){
		$scope.currentPage = 0;
		paginationService.loadPageCounts($scope);
		var paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
			baseURL: bundlelistURL,
			propertiesConfig:propertiesConfig
		});
		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
	};
	$scope.paginationParamsWithSearch = function(){
		return angular.extend({
			status: $scope.statusSelect,
			name:$scope.searchBundle
		});
	};
	     
        }]);