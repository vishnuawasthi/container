//This contrroler is for Inventory the details and change the statuses
app.controller('inventoryController', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','$state','fileUpload','commonFactoryForHttp','moduleActiveService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature',
	function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,$state,fileUpload,commonFactoryForHttp,moduleActiveService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature) {
	$scope.showSearchContent =true;
	var  baseURL = propertiesConfig.details.baseURL;
	$scope.vendorCurrency = $cookies.get(propertiesConfig.details.vendorCurrency);
	$scope.integrationCode= $cookies.get(propertiesConfig.details.integrationCode);
	$scope.salesCurrency= $cookies.get(propertiesConfig.details.salesCurrency);
		$scope.serviceId = $cookies.get(propertiesConfig.details.id);
	$scope.isIass = ($scope.integrationCode == "nomadesk");
	$scope.serviceName= $cookies.get(propertiesConfig.details.serviceName);
	var endPointURL = baseURL+propertiesConfig.details.productPlan;
	$scope.resultsfound = propertiesConfig.details.resultsFound;
	$scope.resultsCount = 0;
	$scope.currentPage = 0;
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	var path = null;
	$scope.status = null;
	$scope.showBlukPrice = false;
	$scope.masterCheckBox = false;
	$scope.inventoryCountActiveFlag = false;
	$scope.modulesActiveFlag = false;
	$scope.locationSearchActiveFlag = true;
	$scope.osSearchActiveFlag = true;
	$scope.configSearchActiveFlag = true;
	$scope.loadAdditionalDataActiveFlag = true;
	$scope.stopLoading = function(){
		$scope.loadingIcon = !($scope.inventoryCountActiveFlag && $scope.modulesActiveFlag  && $scope.loadAdditionalDataActiveFlag);
	};
	$scope.$on('stopLoadingEvent', function(e) {
		$scope.stopLoading();
	});
	$scope.integrationCode = $cookies.get(propertiesConfig.details.integrationCode);
	paginationService.loadPageCounts($scope);
	$scope.loadInventoryDetails = function(status,statePath){
		$scope.loadingIcon = true;
		path = statePath ;
		$scope.status = status;
		var planCountEndpointURL=baseURL+propertiesConfig.details.planCount;
		getInventoryCount(planCountEndpointURL);
		$scope.discoverCount = 0;
		$scope.stageCount = 0;
		$scope.publishCount = 0;
		$scope.suspendCount = 0;
		$scope.archiveCount = 0;
		moduleActiveService.getModulesData($scope);
	
		var paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
			baseURL: endPointURL,
			propertiesConfig:propertiesConfig
			
		});
		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		$scope.prevPage = function () {
			$scope.masterCheckBox = false;
			$scope.selection = [];
			paginationService.prevPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		};
		$scope.nextPage = function () {
			$scope.masterCheckBox = false;
			$scope.selection = [];
			if($scope.currentPage < $scope.noOfPages-1 ){
				paginationService.nextPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
			}else{
				return false;
			}
		};
		$scope.setPage = function () {
			$scope.masterCheckBox = false;
			$scope.selection = [];
			paginationService.setPage($scope,paginationParams,this,undefined,$scope.paginationParamsWithSearch());
		};
		$scope.pageSizeChange = function () {
			$scope.currentPage = 0;
			$scope.masterCheckBox = false;
			$scope.selection = [];
			paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		};

		if(status === 'STAGED' || status === 'PUBLISHED'){
			$scope.loadAdditionalDataActiveFlag = false;
			loadAdditionalData(status);
		}
	};

		$scope.populateLocationList = function(locationSelect){
			var listOfLocationEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.locationSearch;
			var serviceSearchParams = angular.extend({
				locationName: locationSelect
			});
			commonFactoryForHttp.getURL('GET',listOfLocationEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
				$scope.listofLocations =data;
			}).error( function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			});
		};
		$scope.populateOperatingSystemList = function(operatingSystemSelect){
			var listOfOsEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.osSearch;
			var serviceSearchParams = angular.extend({
				operatingSystem: operatingSystemSelect
			});
			commonFactoryForHttp.getURL('GET',listOfOsEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
				$scope.listofOperatingSystems =data;
			}).error( function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			});
		};
		$scope.populateConfigurationList = function(configurationSelect){
			var listOfConfigurationEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.cofigurationSearch;
			var serviceSearchParams = angular.extend({
				flavorClass:configurationSelect
			});
			commonFactoryForHttp.getURL('GET',listOfConfigurationEndPointURL,serviceSearchParams).success(function(data, status, headers, config) {
				$scope.listofConfigurations =data;
			}).error( function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			});
		};
		$scope.populatePlanNameList = function(planNameSelect){
    			var listOfPlanNameURL = propertiesConfig.details.searchURL+propertiesConfig.details.planNameSearch;
    			var serviceSearchParams = angular.extend({
    				planName:planNameSelect
    			});
    			commonFactoryForHttp.getURL('GET',listOfPlanNameURL,serviceSearchParams).success(function(data, status, headers, config) {
    				$scope.listofPlanNames =data;
    			}).error( function(data, status, headers, config) {
    				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
    			});
    		};

		/*$scope.locationsChange = function (locationSelect) {
			if(locationSelect == null){
				$scope.locationName = propertiesConfig.details.chooseLocation;
				//$scope.locationId = '';
			}else {
				$scope.locationId = locationSelect.split(",")[0];
				$scope.locationName = locationSelect;
				$scope.locationSelect =  locationSelect.split(",")[1];
			}
		};
		
		$scope.operatingSystemChange = function (operatingSystemSelect) {
			if(operatingSystemSelect == null){
				$scope.operatingSystemName = propertiesConfig.details.chooseOperatingSystem;
				//$scope.operatingSystemId = '';
			}else {
				$scope.operatingSystemId = operatingSystemSelect.split(",")[0];
				$scope.operatingSystemSelect = operatingSystemSelect.split(",")[1];
				$scope.operatingSystemName = operatingSystemSelect;

			}
		};*/
		 

		
		/*$scope.rackSpaceConfigurationChange = function (configurationSelect) {
			if(configurationSelect == null){
				$scope.rackSpaceConfigurationName = propertiesConfig.details.chooseConfiguration;
			//	$scope.rackSpaceConfigurationId = null;
			}else {
				$scope.flavourCategory = configurationSelect.split(",")[1];
				$scope.configurationSelect = configurationSelect;
			}
		};*/
	
		/*commonFactoryForRestCall.getURL(baseURL + listOfLocationEndPointURL).get(planParams, undefined, function(data, status, headers, config) {
		$scope.listOfLocations = data.planLocations;
		$scope.locationSearchActiveFlag = true;
		$scope.stopLoading();
	}, function(data, status, headers, config) {
		$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		$scope.locationSearchActiveFlag = true;
		$scope.stopLoading();
	});
*/
		/*$scope.operatingSystemName = propertiesConfig.details.chooseOperatingSystem;
		$scope.operatingSystemId = '';
		var listOfOperatingSystemEndPointURL = propertiesConfig.details.listOfOperatingSystems;
		var planParams = angular.extend({
			status: $scope.status,
			serviceId:$scope.serviceId
		});
		commonFactoryForRestCall.getURL(baseURL + listOfOperatingSystemEndPointURL).get(planParams, undefined, function(data, status, headers, config) {
			var operatingSystems = [];
			$scope.listofOperatingSystems =data.planOperatingSystems;
			$scope.osSearchActiveFlag = true;
			$scope.stopLoading();
		}, function(data, status, headers, config) {
			$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
			$scope.osSearchActiveFlag = true;
			$scope.stopLoading();
		});
		*/
		/*$scope.rackSpaceConfigurationName = propertiesConfig.details.chooseConfiguration;
		$scope.rackSpaceConfigurationId = '';
		var rackSpaceConfigurationEndPointURL =  propertiesConfig.details.rackSpaceConfiguration;
		commonFactoryForRestCall.getURL(baseURL + rackSpaceConfigurationEndPointURL)
			.get(planParams, undefined, function(data, status, headers, config) {
				$scope.listofrackSpaceConfiguration = data.planCategories;
				$scope.configSearchActiveFlag = true;
				$scope.stopLoading();
			}, function(data, status, headers, config) {
				$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				$scope.configSearchActiveFlag = true;
				$scope.stopLoading();
			});*/


	

	$scope.searchReset = function(){
	    $scope.PlanNameSelect='';
			 $scope.locationSelect ='';
			 $scope.operatingSystemSelect ='';
			 $scope.configurationSelect ='';
	};

	$scope.searchRecords = function (){
		$scope.currentPage = 0;
		paginationService.loadPageCounts($scope);
		var paginationParams = angular.extend({
			commonFactoryForRestCall: commonFactoryForRestCall,
			baseURL: endPointURL,
			propertiesConfig:propertiesConfig
			/*apiKey: apiKey.key*/
		});
		paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
	};

	$scope.inventorySync= function (){
		$scope.loadingIcon = true;
		var endpointURL = baseURL+propertiesConfig.details.inventorySync;
		commonFactoryForRestCall.getURL(endpointURL).get(undefined,undefined, function(data,status,headers,config) {
			$scope.loadingIcon = false;
			responseMessageService.showResponseMsg(propertiesConfig.details.refreshSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
	    });
	};
	var loadAdditionalData = function(status){
		var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
		var additionalParams = angular.extend({
			serviceId:$scope.serviceId,
			status:status
		});
		commonFactoryForRestCall.getURL(endPointAdditionalURL).get(additionalParams,undefined,function(data,status,headers,config) {
			$scope.additionalDetails = data.content;
			$scope.loadAdditionalDataActiveFlag = true;
			$scope.stopLoading();
		}, function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadAdditionalDataActiveFlag = true;
			$scope.stopLoading();
		});
	};

	//Get Inventory Count
	var getInventoryCount = function(endPointURL){
		commonFactoryForRestCall.getURL(endPointURL).get({serviceId:$scope.serviceId},function(data,status,headers,config) {
				$scope.discoverCount += data.summary.DISCOVERED;
				$scope.stageCount += data.summary.STAGED;
				$scope.publishCount += data.summary.PUBLISHED ;
				$scope.suspendCount += data.summary.WITHDRAWN ;
				$scope.archiveCount += data.summary.ARCHIVED ;
				$scope.inventoryCountActiveFlag = true;
				$scope.stopLoading();
			}, function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.inventoryCountActiveFlag = true;
				$scope.stopLoading();}
		);
	};

	//Change Status
	$scope.selection = [];
	$scope.plansToggleSelection = function(planId,masterCheckboxCheck) {
		var idx = $scope.selection.indexOf(planId);
		if (idx > -1) {
			$scope.selection.splice(idx, 1);
		}else {
			if(masterCheckboxCheck == undefined || masterCheckboxCheck)
				$scope.selection.push(planId);
		}
	};
	$scope.plansChangeStatus = function(changeStatus){
		var plans = [];
		var planChanges = $scope.selection;
		for(var i=0;i<planChanges.length;i++){
			var plan = {};
			plan.status = changeStatus;
			plan.planId = planChanges[i];
			plans.push(plan);
		}
		var statusUpdated =changeStatus;
		if(changeStatus==="DISCOVERED" && $scope.status === "STAGED" ){
			var statusUpdated = "UNSTAGED";
		}
		var paramsData = {"productPlans":plans};
		commonFactoryForRestCall.getURL(endPointURL).put(paramsData,function(data, status, headers, config) {
			$scope.loadInventoryDetails($scope.status,path);
			responseMessageService.showResponseMsg(propertiesConfig.details.plansMsg+statusUpdated+propertiesConfig.details.successfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		},function(data, status, headers, config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
		});
		$scope.masterCheckBox = false;
		$scope.selection = [];
	};

	$scope.plansAdditionalChange = function(status,additionalData){
		if(additionalData.price !== '0.0'){
			var plan = {};
			plan.status = status;
			plan.additionalPriceId = additionalData.additionalPriceId;
			plan.price = additionalData.price ;
			var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
			commonFactoryForRestCall.getURL(endPointAdditionalURL).put(undefined,plan,function(data, status, headers, config) {
				loadAdditionalData('STAGED');
				responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			},function(data,status,headers,config) {
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}else{
			alert("Please update valid Price");
		}
	};

	$scope.savePricedetails = function (updatedValues,inventoryData) {
		var inventorylist=[];
		var inventory ={};
		inventory.planId= inventoryData.planId;
		inventory.price=updatedValues.price;
		inventorylist.push(inventory);
		var paramsData = {"productPlans":inventorylist};
		commonFactoryForRestCall.getURL(endPointURL).put(undefined,paramsData,function(data,status,headers,config) {
			$scope.loadInventoryDetails("STAGED","manager.staged");
			responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		},function(data,status,headers,config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.editFlag = false;
		});
	};
	$scope.saveVendorPrice = function (updatedValues,inventoryData,rowform) {
		var inventory ={};
		inventory.planId= inventoryData.planId;
		inventory.vendorPrice=updatedValues.vendorPrice;
		var vendorPriceUpdateURL =  baseURL+propertiesConfig.details.vendorPrice;
		commonFactoryForRestCall.getURL(vendorPriceUpdateURL).put(undefined,inventory,function(data,status,headers,config) {
			$scope.loadInventoryDetails("STAGED","manager.staged");
			responseMessageService.showResponseMsg(propertiesConfig.details.vendorPriceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		},function(data,status,headers,config) {
			//updatedValues.vendorPrice =inventoryData.vendorPrice;
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.editFlag = false;
		});
	};

	//Export and Import excel files
	var exportEndpointURL = baseURL + propertiesConfig.details.exportExcel;
	$scope.exportExcel=function(){
		$scope.loadingIcon = true;
		$scope.importSuccessMsg="";
		$scope.seviceErrorMsg="";
		 var serviceparms = angular.extend({
                   serviceId: $scope.serviceId
            });

		commonFactoryForHttp.getURL('GET',exportEndpointURL,serviceparms).success(function(data, status, headers, config) {
			$scope.loadingIcon = false;
			var a = document.createElement('a');
			a.href = 'data:attachment/csv;charset=utf-8,' + encodeURI(data);
			a.target = '_blank';
			a.download = 'RackspacePriceSheet.csv';
			document.body.appendChild(a);
			$scope.exportSuccessMsg=propertiesConfig.details.exportSuccessMsg;
			a.click();
			responseMessageService.showResponseMsg(propertiesConfig.details.downloadSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		}).
			error(function(data, status, headers, config) {
				$scope.loadingIcon = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
	};

	var importEndpointURL = baseURL + propertiesConfig.details.importExcel;
	$scope.uploadfile=function(myFile){
		$scope.exportSuccessMsg="";
		$scope.seviceErrorMsg="";
		$scope.loadingIcon = true;
		var file = myFile;
		fileUpload.uploadFileToUrl(file, importEndpointURL).success(function(data, status, headers, config) {
			$scope.loadInventoryDetails("STAGED","manager.staged");
			$scope.showBulkPrice(false);
			responseMessageService.showResponseMsg(propertiesConfig.details.importSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			$scope.loadingIcon = false;
		}).error(function(data, status, headers, config) {
			if(data.status === 400){
				responseMessageService.showResponseMsg(data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			$scope.loadingIcon = false;
		});
		$scope.loadingIcon = false;
	};

	
	$scope.showBulkPrice = function(flag){
		$scope.showBlukPrice = flag;
	};
	$scope.selectAll = function(pageData){
		if($scope.masterCheckBox){
			$scope.selection = [];
		}
		for(var loop=0;loop<pageData.length;loop++){
			$scope.plansToggleSelection(pageData[loop].planId,$scope.masterCheckBox);
		}
	};

	$scope.updateStatus = function(){
		$scope.loadingIcon = true;
		var service ={};
		var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		endPointServiceURL =baseURL+ endPointServiceURL;
		service.serviceId= $scope.serviceId;
		service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;
		if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				$scope.isPublished = !$scope.isPublished;
				responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				$scope.loadingIcon = false;
			},function(data, status, headers, config) {
				$scope.loadingIcon = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		}else if($scope.isEnablePublish===false && service.isPublished==='true'){
			$scope.loadingIcon = false;
			responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		}
		$scope.statusConfirmationPopup = false;
	};

	$scope.paginationParamsWithSearch = function(){
		return angular.extend({
			status: $scope.status,
			serviceId:$scope.serviceId,
		/*	operatingSystemName: $scope.operatingSystemSelect,
			locationName : $scope.locationSelect,*/
			flavorCategory :$scope.configurationSelect,
			planName:$scope.PlanNameSelect
		});
	};
	$scope.statusConfirmationPopup = false;
	 $scope.showStatusConfirmationPopup = function(flag){
	    	$scope.statusConfirmationPopup = flag;
	    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	    };
}]);