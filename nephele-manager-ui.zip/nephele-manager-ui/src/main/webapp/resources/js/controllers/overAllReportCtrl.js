app.controller('overAllReportCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','paginationService','graphsService',
    function($scope,propertiesConfig,commonFactoryForRestCall,paginationService,graphsService) {
    $scope.loadingIcon = true;
    var baseReportingURL = propertiesConfig.details.baseReportingURL;
    var endPointURL = propertiesConfig.details.lastMonthRevenue;
    var params = angular.extend({
        year: new Date().getFullYear()
    });
    commonFactoryForRestCall.getURL(baseReportingURL + endPointURL).get(params, undefined, function(data, status, headers, config) {
        var lastMonthRevenueData=[];
        for(var index in data.content) {
            lastMonthRevenueData.push({"month": data.content[index].month, "amount" : data.content[index].amount ? data.content[index].amount : 0, monthNumber: data.content[index].monthNumber});
        }
        var params = angular.extend({
            showLegend:false,
            showYAxis:true,
            showXAxis:true,
            interactive:50,
            container:"chart",
            xAxisLabel:'Month',
            yAxisLabel:'Amount',
            xAxisTicks:12,
            yAxisTicks:10,
            xAxisLabelParamFromData: 'month',
            data:lastMonthRevenueData,
            dataToDisplay : $scope.dataToDisplay(lastMonthRevenueData),
            noData: "No data available"
        });
        graphsService.drawLineUsingNVD3(params);
        $scope.loadingIcon = false;
    }, function(data, status, headers, config) {
    	 $scope.loadingIcon = false;
    });
    $scope.dataToDisplay = function(data) {
        var dataToDisplayArray = [];
        for (var i = 0; i < data.length; i++) {
            dataToDisplayArray.push({x: data[i].monthNumber, y: data[i].amount});
        }
        return [{values: dataToDisplayArray,key: 'Last Month Revenue',color: '#FF0066'}];
    };
}]);