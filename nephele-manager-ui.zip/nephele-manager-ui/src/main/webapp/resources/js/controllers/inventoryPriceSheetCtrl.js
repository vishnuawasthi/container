app.controller('InventoryPriceSheetCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','paginationService','moduleActiveService','responseMessageService','$timeout','$cookies','factoryForRoleBasedFeature','searchToggleService','commonFactoryForHttp',
	function($scope,propertiesConfig,commonFactoryForRestCall,$state,paginationService,moduleActiveService,responseMessageService,$timeout,$cookies,factoryForRoleBasedFeature,searchToggleService,commonFactoryForHttp) {
	 $scope.serviceId = $cookies.get(propertiesConfig.details.id);
	 $scope.vendorCurrency = $cookies.get(propertiesConfig.details.vendorCurrency);
	 $scope.integrationCode= $cookies.get(propertiesConfig.details.integrationCode);
	 $scope.salesCurrency= $cookies.get(propertiesConfig.details.salesCurrency);
	 	$scope.isIass = ($scope.integrationCode == "nomadesk");
		$scope.serviceName= $cookies.get(propertiesConfig.details.serviceName);
	 var baseURL = propertiesConfig.details.baseURL;
	 var endPointURL = baseURL+propertiesConfig.details.priceManagement;
	 $scope.resultsfound = propertiesConfig.details.resultsFound;
	 $scope.resultsCount = 0;
	 $scope.currentPage = 0;
	 $scope.viewSheet= false;
	 $scope.search ={};
	 $scope.custom={};
	 $scope.activation={};
	 $scope.listofStatus=['DRAFT','ACTIVE','SCHEDULED','INACTIVE','ARCHIVED'];
	var roleBasedData = factoryForRoleBasedFeature.getPermissions(propertiesConfig.details.cloudServicesForRole);
	$scope.isRead = roleBasedData.isRead;
	$scope.isWrite = roleBasedData.isWrite;
	 $scope.isInnerPriceCtrl = $cookies.get('isInnerPriceCtrl');
	 var viewFlag=$cookies.get('viewPriceSheet');
	 var sheetName=$cookies.get('priceSheetName');
     $scope.serviceId = $cookies.get(propertiesConfig.details.id);
	 $scope.loadPriceSheetDetails = function(){
		 $scope.loadingIcon = true;
		 moduleActiveService.getModulesData($scope);
			paginationService.loadPageCounts($scope);
			 var paginationParams = angular.extend({
				commonFactoryForRestCall: commonFactoryForRestCall,
		       baseURL: endPointURL,
		       propertiesConfig:propertiesConfig
		      /* apiKey: apiKey.key*/
		    });
			paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
			
			$scope.prevPage = function () {
				paginationService.prevPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		    };
		    $scope.nextPage = function () {
		   	 if($scope.currentPage < $scope.noOfPages-1 ){
		   	 paginationService.nextPage($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		   	 }else{
		   		 return false;
		   	 }
		    };
		    $scope.setPage = function () {
		    	paginationService.setPage($scope,paginationParams,this,undefined,$scope.paginationParamsWithSearch());
		    };
		    $scope.pageSizeChange = function () {
		    	$scope.currentPage = 0;
		    	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());   
		    };
	 };
	
	  $scope.updateArchiveStatus = function (productPriceMgmtConfigId,status) {
			 /* var priceSheet ={};
			  priceSheet.productPriceMgmtConfigId= productPriceMgmtConfigId;
			  priceSheet.status=status;*/
			  commonFactoryForRestCall.getURL(endPointURL).del({id:productPriceMgmtConfigId},undefined,function(data,status,headers,config) {
				   $scope.loadPriceSheetDetails();
				   responseMessageService.showResponseMsg(propertiesConfig.details.deletedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			  }, function(data,status,headers,config) {
				  	if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			});
	  };
	  
	  
	   $scope.populateSheetNameList = function(sheetNameSelect){
	       var listOfDiscountSheetEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.priceSheetSearch;
	       var priceSheetSearchParams = angular.extend({
	    	   sheetName: sheetNameSelect
	       });
	       commonFactoryForHttp.getURL('GET',listOfDiscountSheetEndPointURL,priceSheetSearchParams).success(function(data, status, headers, config) {
	              $scope.listofSheetNames =data;
	       }).error( function(data, status, headers, config) {
	       	$scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
	       });
	   };
	   
	 /* $scope.populateStatusList = function(statusSelect){
		    var listOfStatusEndPointURL = propertiesConfig.details.searchURL+propertiesConfig.details.priceSheetSearch;
		    var statusSearchParams = angular.extend({
		           status: statusSelect
		    });
		    commonFactoryForHttp.getURL('GET',listOfStatusEndPointURL,statusSearchParams).success(function(data, status, headers, config) {
		           $scope.listofStatus =data;
		    }).error( function(data, status, headers, config) {
		           $scope.serviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
		    });
		};*/
		  $scope.searchReset = function(){
		   		$scope.statusSelect='';
		   		$scope.sheetNameSelect='';
		   		$scope.errMessage = '';
		   		$scope.search.activeFromDt = null;
				$scope.search.activeToDt = null;
				$scope.formattedFromDate = null;
				$scope.formattedToDate = null;
		    };
		    $scope.searchRecords = function (activeFromDt,activeToDt){
		     	$scope.currentPage = 0;
		     	$scope.errMessage ='';
		     	paginationService.loadPageCounts($scope);
		     	var paginationParams = angular.extend({
		     		commonFactoryForRestCall: commonFactoryForRestCall,
		     		baseURL:endPointURL,
		     		propertiesConfig:propertiesConfig,
		     	});
		     	$scope.formattedFromDate = null;
				$scope.formattedToDate = null;
				var errorFlag = false;
				var errorSet = false;
				if(!$scope.search.activeFromDt  && !$scope.search.activeToDt){
					errorSet = true;
				}
				if((!$scope.search.activeFromDt  && $scope.search.activeToDt)||($scope.search.activeFromDt && !$scope.search.activeToDt)){
					$scope.errMessage = propertiesConfig.details.validDateMsg;
					errorFlag = true;
				}
				if($scope.search.activeFromDt){
					var fromDate = new Date($scope.search.activeFromDt);
					$scope.formattedFromDate =  fromDate.getFullYear()+"-"+(fromDate.getMonth()+1) + "-"+fromDate.getDate();
				}
		     	if($scope.search.activeToDt){
		     		var toDate = new Date($scope.search.activeToDt);
		     		$scope.formattedToDate = toDate.getFullYear()+"-"+(toDate.getMonth()+1) + "-"+toDate.getDate();
		     	}
		     	  if(($scope.search.activeFromDt) >= ($scope.search.activeToDt) && !errorFlag && !errorSet){
		              $scope.errMessage = propertiesConfig.details.EndDateValidationMsg;
		              errorFlag = true;
		           }else if(!errorFlag ){
		        	   	paginationService.getPageData($scope,paginationParams,undefined,$scope.paginationParamsWithSearch());
		           }
		     };
		     
		     $scope.paginationParamsWithSearch = function(){
		    		return angular.extend({
		    			sheetName: $scope.sheetNameSelect,
		    			status:$scope.statusSelect,
		    			activeFrom:$scope.formattedFromDate,
		    			activeTo:$scope.formattedToDate,
		    	        serviceId:$scope.serviceId
		    		});
		    };
	  $scope.scheduleUpdate = function (productPriceMgmtConfigId,status,eventType,comments) {
		  var priceSheet ={};
		  priceSheet.id = productPriceMgmtConfigId;
		  //priceSheet.status=status;
		  priceSheet.eventName=eventType;
		  priceSheet.comments=comments;
		  if(eventType === 'CUSTOM'){
			  var scheduleDate = new Date( $scope.custom.scheduleDt);
			  $scope.formattedScheduleDate =  scheduleDate.getFullYear()+"-"+(scheduleDate.getMonth()+1) + "-"+scheduleDate.getDate();
			  priceSheet.customDate=  $scope.formattedScheduleDate;
		  }
		  var scheduleEndPointURL = baseURL+propertiesConfig.details.priceManagementSchedule;
		  commonFactoryForRestCall.getURL(scheduleEndPointURL).put(priceSheet,undefined,function(data,status,headers,config) {
			   $scope.loadPriceSheetDetails();
			   $scope.showSchedulePopup(false);
			   responseMessageService.showResponseMsg(data.message, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  }, function(data,status,headers,config) {
			  $scope.showSchedulePopup(false);
			   if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			  });
 		 };
  
	 $scope.showPriceSheetPopUp = function(flag){
	    	$scope.priceSheetPopUp = flag;
	    	$scope.viewSheet= false;	    	
	    	 $scope.$broadcast ('createEvent');
	 };
	 
	 $scope.showSchedulePopup = function(flag,productPriceMgmtConfigId){
	    	$scope.schedulePopUp = flag;
	    	$scope.productPriceMgmtConfigId = productPriceMgmtConfigId;
	    	if(!flag){
	    		$scope.activation={};
		    	$scope.custom.scheduleDt = '';
		    	$scope.dateFalg = false;
	    	}
	 };
	 $scope.showViewPriceSheetPopUp= function(priceSheetName,flag,id){
		 $scope.sheetName = priceSheetName;
		 $scope.priceSheetPopUp = true;
		 $scope.viewSheet= flag;	
		 $scope.productPriceMgmtConfigId = id;
		 $scope.$broadcast ('getPlanDetailsEvent');
	 };
	 $scope.updateStatus = function(){
		 $scope.loadingIcon = true;
		 var service ={};
		 var endPointServiceURL = propertiesConfig.details.serviceCatalog;
		 endPointServiceURL =baseURL+ endPointServiceURL;
		 service.serviceId= $scope.serviceId;
		 service.isPublished=($scope.isPublished === true) ? 'false' : 'true' ;	
		 if( ($scope.isEnablePublish===true && service.isPublished==='true') || service.isPublished==='false'){
			 commonFactoryForRestCall.getURL(endPointServiceURL).put(JSON.stringify(service),function(data,status,headers,config) {
				 $scope.isPublished = !$scope.isPublished;
				 responseMessageService.showResponseMsg(propertiesConfig.details.statusMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
				 $scope.loadingIcon = false;
			 },function(data,status,headers,config) {
				 $scope.loadingIcon = false;
				 if(data.status === 400){
						responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}else{
						 responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
					}
			  });
		 }else if($scope.isEnablePublish===false && service.isPublished==='true'){
			 $scope.loadingIcon = false;
			 responseMessageService.showResponseMsg(propertiesConfig.details.cannotEnableMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
		 }
		 $scope.statusConfirmationPopup = false;
	 };
	 $scope.statusConfirmationPopup = false;
	 $scope.showStatusConfirmationPopup = function(flag){
	    	$scope.statusConfirmationPopup = flag;
	    	$scope.confirmationMessage = ($scope.isPublished === true)? propertiesConfig.details.disableNowMsg: propertiesConfig.details.enableNowMsg;
	    };
	    $scope.searchToggle = function(){
	    	searchToggleService.toggleSearch();
		};	
		
		 $scope.showDateField= function(flag){
			 $scope.dateFalg = flag;
		 };
}]);

app.controller('innerPriceSheetCtrl', ['$scope','propertiesConfig','commonFactoryForRestCall','$state','paginationService','commonFactoryForHttp','fileUpload','responseMessageService','$timeout','$cookies',
    function($scope,propertiesConfig,commonFactoryForRestCall,$state,paginationService,commonFactoryForHttp,fileUpload,responseMessageService,$timeout,$cookies ) {
	 var baseURL = propertiesConfig.details.baseURL;
	 $scope.loadingIcon = true;
	 $scope.servicesDetails = [];
	 var priceSheetEndPointURL = baseURL+propertiesConfig.details.priceSheetData;
	 var endPointURL = baseURL+propertiesConfig.details.priceManagement;
	 $scope.vendorCurrency = $cookies.get(propertiesConfig.details.vendorCurrency);
	 $scope.showEditSheetName=false;
	 $scope.isInnerPriceCtrl = true;
	 
	 $scope.$on('createEvent', function(e) {  
		 $scope.loadPricePopupDetails();
	 });
	 $scope.$on('getPlanDetailsEvent', function(e) {
		 $scope.loadSheetDetails($scope.$parent.sheetName);
	 });
	 $scope.loadPricePopupDetails = function(){
		 $scope.loadingIcon = true;
	    	var priceSheetEndPointURL = baseURL+propertiesConfig.details.priceManagement;
	    	var paramsData = angular.extend({		 		
				serviceId:$scope.serviceId
	    	});
	    	commonFactoryForRestCall.getURL(priceSheetEndPointURL).post(undefined,paramsData,function(data, status, headers, config) {
					$scope.osSuccessMsg = propertiesConfig.details.updateSuccessMessage;
					$scope.productPriceMgmtConfigId = data.productPriceMgmtConfigId;
					$scope.sheetName = data.priceSheetName;
					$scope.loadSheetDetails($scope.sheetName);
					$scope.$parent.loadPriceSheetDetails();
					responseMessageService.showResponseMsg(propertiesConfig.details.priceSheetMsg+propertiesConfig.details.createdSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
					$scope.loadingIcon = false;
				},function(data,status,headers,config) {
					$scope.showPriceSheetPopUp(false);
					 if(data.status === 400){
						 responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope.$parent, $timeout);
						}else{
							responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope.$parent, $timeout);
						}
					 $scope.loadingIcon = false;
				});
		 };
	 
	 $scope.showPriceSheetPopUp = function(flag){
		 $scope.$parent.priceSheetPopUp = flag;
	 };
	
	 $scope.loadSheetDetails = function(sheetName){
		 $scope.loadingIcon = true;
		 $scope.sheetName =sheetName;
		 $cookies.put('priceSheetName',$scope.sheetName);
		 var params = angular.extend({
			 	sheetName: sheetName,
				serviceId:$scope.serviceId
			});
		
			paginationService.loadPageCounts($scope);
			 
			 paginationParams = angular.extend({
				commonFactoryForRestCall: commonFactoryForRestCall,
		       baseURL: priceSheetEndPointURL,
		       propertiesConfig:propertiesConfig
		    });
			 
			paginationService.getPageData($scope,paginationParams,undefined,params);
			
			$scope.prevPage = function () {
				//params.page = this.currentPage-1;
				paginationService.prevPage($scope,paginationParams,undefined,params);
		    };
		    $scope.nextPage = function () {
		    	paginationParams.baseURL = priceSheetEndPointURL;
		   	 if($scope.currentPage < $scope.noOfPages-1 ){
		   		//params.page = this.currentPage+1;
		   		 paginationService.nextPage($scope,paginationParams,undefined,params);
		   	 }else{
		   		 return false;
		   	 }
		    };
		    $scope.setPage = function () {
		    	paginationParams.baseURL = priceSheetEndPointURL;
		    	//params.page = this.pageRange;
		    	paginationService.setPage($scope,paginationParams,this,undefined,params);
		    };
		    $scope.pageSizeChange = function () {
		    	$scope.currentPage = 0;
		    	//params.page = this.currentPage;
		    	//params.size= this.noOfitems;
		    	paginationParams.baseURL = priceSheetEndPointURL;
		    	paginationService.getPageData($scope,paginationParams,undefined,params);   
		    };
		    loadAdditionalData('PUBLISHED');
	 };
	 
	 var loadAdditionalData = function(status){
		 $scope.loadingIcon = true;
			var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
			var additionalParams = angular.extend({				
				serviceId:$scope.serviceId,
				status:status
			});
			commonFactoryForRestCall.getURL(endPointAdditionalURL).get(additionalParams,undefined,function(data,status,headers,config) {
				$scope.additionalDetails = data.content;
				$scope.loadingIcon = false;
			}, function(data,status,headers,config) {
				$scope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;
				$scope.loadingIcon = false;
			});
	};
	 
	 $scope.savePriceSheetDetails = function ($data, priceSheetData,priceType) {
		 $scope.loadingIcon = true;
		 var priceSheetPutEndPointURL = baseURL+propertiesConfig.details.priceSheetPut;
		 if(priceType ==='vendorPrice'){
			 params = {productPriceManagementSheetId:priceSheetData.productPriceManagementSheetId, vendorPrice:$data.vendorPrice};
		 }else{
			 params = {productPriceManagementSheetId:priceSheetData.productPriceManagementSheetId, price:$data.price};
		 }
	 	  commonFactoryForRestCall.getURL(priceSheetPutEndPointURL).put(undefined,JSON.stringify(params),function(data,status,headers,config) {
			 $scope.loadSheetDetails($scope.sheetName);
			 responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			 $scope.loadingIcon = false;
		  },function(data,status,headers,config) {
			  $scope.loadingIcon = false;
			  if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			   $scope.editFlag = false;
		  });
	  };
	  
	  $scope.saveSheetName = function (sheetName,productPriceMgmtConfigId) {
		  $scope.loadingIcon = true;
		  var priceSheet ={};
		  priceSheet.productPriceMgmtConfigId=productPriceMgmtConfigId;
		  priceSheet.priceSheetName=sheetName;
	 	  commonFactoryForRestCall.getURL(endPointURL).put(undefined,priceSheet,function(data,status,headers,config) {
			 $scope.$parent.loadPriceSheetDetails();
			 $scope.showEditSheetName = false;
			 responseMessageService.showResponseMsg(propertiesConfig.details.sheetNameMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
		  },function(data,status,headers,config) {
			  if(data.status === 400){
				  responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
			}
			  $scope.loadingIcon = false;
			   $scope.editFlag = false;
		  });
	  };
	 
	 $scope.showBulkPriceSheetPopUp = function(flag){
	    $scope.bulkPriceSheetPopUp = flag;
	 };
	
		//Export and Import excel files
		var exportEndpointURL = baseURL + propertiesConfig.details.exportPriceExcel;
		$scope.exportExcel=function(){
			$scope.loadingIcon = true;
			$scope.importSuccessMsg="";
			$scope.seviceErrorMsg="";
			sheetDetails={};
			sheetDetails.serviceId = $scope.serviceId ;
			sheetDetails.sheetName = $scope.sheetName;
			commonFactoryForHttp.getURL('GET',exportEndpointURL,sheetDetails).success(function(data, status, headers, config) {
			var a = document.createElement('a');
				a.href = 'data:attachment/csv;charset=utf-8,' + encodeURI(data);
				a.target = '_blank';
				a.download = 'RackspacePriceSheet.csv';
				document.body.appendChild(a);
				$scope.exportSuccessMsg=propertiesConfig.details.exportSuccessMsg;
				a.click();
				$scope.loadingIcon = false;
				responseMessageService.showResponseMsg(propertiesConfig.details.downloadSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			}).
			error(function(data, status, headers, config) {
				$scope.loadingIcon = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			});
		};

		var importEndpointURL = baseURL + propertiesConfig.details.importPriceExcel;
		$scope.uploadfile=function(){
			$scope.loadingIcon = true;
			$scope.exportSuccessMsg="";
			$scope.seviceErrorMsg="";
			var file = $scope.myFile;
			fileUpload.uploadFileToUrl(file, importEndpointURL).success(function(data, status, headers, config) {	
				$scope.bulkPriceSheetPopUp = false;
				$scope.loadPriceSheetDetails();
				$scope.loadSheetDetails($scope.sheetName);
				  $scope.importSuccessMsg=propertiesConfig.details.importSuccessMsg;
				  $scope.loadingIcon = false;
				  responseMessageService.showResponseMsg(propertiesConfig.details.importSuccessMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
			}).error(function(data, status, headers, config) {
				$scope.bulkPriceSheetPopUp = false;
				if(data.status === 400){
					responseMessageService.showResponseMsg(data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
				$scope.loadingIcon = false;
				});
		};
		
		$scope.saveAdditionalPrice = function(additionalPrice,additionalData){
				if(additionalPrice !== '0.0'){
					var plan = {};
					plan.additionalPriceId = additionalData.additionalPriceId;
					plan.price = additionalPrice ;
					var endPointAdditionalURL = baseURL+propertiesConfig.details.additionalPrice;
					$scope.showEditAdditionalPrice = false;
					commonFactoryForRestCall.getURL(endPointAdditionalURL).put(undefined,plan,function(data, status, headers, config) {
						 loadAdditionalData('PUBLISHED');
						 responseMessageService.showResponseMsg(propertiesConfig.details.priceMsg+propertiesConfig.details.updatedSuccessfullyMsg, propertiesConfig.details.successMsgClass, $scope, $timeout);
					},function(data,status,headers,config) {
						if(data.status === 400){
							responseMessageService.showResponseMsg(data.data.message, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}else{
							responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
						}
					});
				}else{
					responseMessageService.showResponseMsg(propertiesConfig.details.validPriceMsg, propertiesConfig.details.errorMsgClass, $scope, $timeout);
				}
			};
			
			$scope.setEditFlag = function(flag){
				$scope.showEditSheetName = flag;
			};
			$scope.showUpdateAdditionalPrice = function(flag){
				$scope.showEditAdditionalPrice = flag;
				if(flag){
					$scope.additionalDetails.$original = angular.copy($scope.additionalDetails);
				}
			};
			$scope.cancelAdditionalPrice= function(additionalDetails){
				angular.copy($scope.additionalDetails.$original, additionalDetails);
				$scope.showUpdateAdditionalPrice(false);
				
			};
			$scope.showUpdatePrice = function(flag){
				$scope.showEditPrice = flag;
			};
}]);
