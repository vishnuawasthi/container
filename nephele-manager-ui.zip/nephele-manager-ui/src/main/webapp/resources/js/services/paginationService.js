// This service is useful for the pagination
app.service('paginationService',['propertiesConfig',function(propertiesConfig) {
	var self = this;
    this.pageRange = function(size,start, end) {
    	var pageNums = [];        
        if (size < end) {
            end = size;
            start = 0;
        }
        for (var i = start; i < end; i++) {
        	pageNums.push(i);
        }       
        return pageNums;
    };
    this.getPageData = function(currentScope,paginationParams,params,additionalParams) {
		if(currentScope.loadingIcon != undefined)
			currentScope.loadingIcon = true;
    	if(params == undefined){
	    	params = angular.extend({
	    		page: currentScope.currentPage,
	    		size:currentScope.noOfitems
	    	});
    	}
		if(additionalParams !=undefined){
			additionalParams.page = currentScope.currentPage;
			additionalParams.size = currentScope.noOfitems;
		}
    	paginationParams.commonFactoryForRestCall.getURL(paginationParams.baseURL,params).getQueryParam(additionalParams,function(data){
	    			currentScope.servicesDetails = data.content;
				    currentScope.itemsPerPage =  data.page.size;
				    currentScope.noOfPages  =  data.page.totalPages;
				    currentScope.resultsCount = data.page.totalElements;
				    currentScope.number=data.page.number;
				    self.loadPageItems(currentScope);
					if(currentScope.loadingIcon != undefined)
						currentScope.loadingIcon = false;
				    currentScope.range = self.pageRange(currentScope.noOfPages,currentScope.currentPage, currentScope.currentPage+currentScope.noOfPages);
    		}, function(data,status,headers,config) {
				currentScope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;
				if(currentScope.loadingIcon != undefined)
					currentScope.loadingIcon = false;
			}
    	);
    };
    this.postPageData = function(currentScope,paginationParams,params) {
    	if(params == undefined){
	    	params = angular.extend({
	    		page: currentScope.currentPage,
	    		size:currentScope.noOfitems
	    	});
    	}
    	paginationParams.commonFactoryForRestCall.getURL(paginationParams.baseURL,params).post(params,function(data,status,headers,config){
	 		currentScope.sheetDetails = data.content;	   	
		    currentScope.itemsPerPagePerSheet =  data.page.size;
		    currentScope.noOfPagesPerSheet  =  data.page.totalPages;
		    currentScope.resultsCountPerSheet = data.page.totalElements;
		    currentScope.numberPerSheet=data.page.number;
		    self.loadPageItems(currentScope);
		    currentScope.rangePerSheet = self.pageRange(currentScope.noOfPagesPerSheet,currentScope.currentPge, currentScope.currentPge+currentScope.noOfPagesPerSheet);
    		}, function(data,status,headers,config) { currentScope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg;}
    	);
    	

    };
    this.nextPage = function($scope,paginationParams,params,additionalParams){
    	if ($scope.currentPage <= $scope.pagedItems.length - 1) {
            $scope.currentPage++;
            self.getPageData($scope,paginationParams,params,additionalParams);
        }
    };
    this.prevPage = function($scope,paginationParams,params,additionalParams){
    	if ($scope.currentPage > 0) {
            $scope.currentPage--;
            self.getPageData($scope,paginationParams,params,additionalParams);
        }
    };
    this.setPage = function($scope,paginationParams,passedReference,params,additionalParams){
    	 $scope.currentPage = passedReference.pageRange;
         self.getPageData($scope,paginationParams,params,additionalParams);
    };
    this.loadPageItems = function(currentScope){
    	if(currentScope.servicesDetails!=null){
     	    currentScope.pagedItems=[];
            for (var i = 0; i < currentScope.servicesDetails.length; i++) {
                if (i % currentScope.itemsPerPage === 0) {
                    currentScope.pagedItems[currentScope.number] = [ currentScope.servicesDetails[i] ];
                } else {
                    currentScope.pagedItems[currentScope.number].push(currentScope.servicesDetails[i]);
                }
            }
    	}
    };
    this.loadPageCounts = function(currentScope){
    	currentScope.pageSizes= JSON.parse(propertiesConfig.details.pageSize);
    	if(currentScope.integrationCode != undefined && currentScope.integrationCode === 'softlayer' ){
    		currentScope.pageSizes = [];
    		currentScope.pageSizes= JSON.parse(propertiesConfig.details.pageSizeForLargeData);
    	}
    	currentScope.noOfitems=currentScope.pageSizes[0];
    };
}]);