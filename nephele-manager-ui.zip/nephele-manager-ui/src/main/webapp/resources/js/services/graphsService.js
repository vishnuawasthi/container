// This service is useful for the graphs
app.service('graphsService',function() {
	this.drawPieWithDonutUsingNVD3 = function(params){
		nv.addGraph(function() {
			var chart = nv.models.pieChart()
			.x(function(d) { return d[params.xAxisDataColumn] })
			.y(function(d) { return d[params.yAxisDataColumn] })
			//.legendPosition("bottom")
			.color(params.colorRange)
			.labelType(params.labelType)
			.showLabels(params.showLabels)
			//.pieLabelsOutside(params.pieLabelsOutside)
			.labelThreshold(params.labelThreshold)
			.showLegend(params.showLegend)
			//.tooltips(params.tooltips)
			.noData(params.noData)
			.donut(params.donut)
			.donutRatio(params.donutRatio);
			d3.select("#" + params.container + " svg")
			.datum(params.data)
			.call(chart);
			nv.utils.windowResize(chart.update);
			return chart;
		});
	};
	
	this.drawBarUsingNVD3=function(params){
		nv.addGraph(function() {
			var chart = nv.models.discreteBarChart()
			.x(function(d) {return d[params.xAxisDataColumn]})
			.y(function(d) { return d[params.yAxisDataColumn] })
			.staggerLabels(params.staggerLabels)
			//.tooltips(params.tooltips)
			.showValues(params.showValues)
			.duration(params.transitionDuration)
			.color(params.color)
			.width(params.width)
			.noData(params.noData)
			.rightAlignYAxis(params.rightAlignYAxis)
			.showXAxis(params.showXAxis)
			.showYAxis(params.showYAxis);
			d3.select("#" + params.container + " svg")
			.datum([{values:params.data}])
			.call(chart);
			nv.utils.windowResize(chart.update);
			return chart;
		});
	};
	
	this.drawLineUsingNVD3 = function (params) {
		var chart = nv.models.lineChart()
		.showLegend(params.showLegend)
		.noData(params.noData)
		.showYAxis(params.showYAxis)
		.showXAxis(params.showXAxis)
		.interactive(params.interactive);
		chart.xAxis.axisLabel(params.xAxisLabel).ticks(params.xAxisTicks);
		if(params.xAxisLabelParamFromData) {
			chart.xAxis.tickFormat(function (d) {
				return  params.data[d]?params.data[d][params.xAxisLabelParamFromData]:'';
			});
		}else {
			chart.xAxis.tickFormat(d3.format(params.xAxisTickFormat));
			//chart.xAxis.tickFormat(d3.format(',r'));
		}
		chart.yAxis.axisLabel(params.yAxisLabel).ticks(params.yAxisTicks);
		chart.yAxis.tickFormat(d3.format('.02f'));
		d3.select("#" + params.container + " svg")
		.datum(params.dataToDisplay)
		.call(chart);
		nv.utils.windowResize(chart.update);
		return chart;
	};
	
});