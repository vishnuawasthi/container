
app.service('responseMessageService',function() {
    this.showResponseMsg = function (message, cssClass, currentScope, $timeout) {
        currentScope.responseClass = cssClass;
        currentScope.responseMsg = message;
        currentScope.responseMsgFlag = true;
        $timeout(function () {
            currentScope.responseMsgFlag = false;
            currentScope.responseMsg = '';
        }, 10000);
    };
});


app.service('moduleActiveService',['propertiesConfig','commonFactoryForRestCall',function(propertiesConfig,commonFactoryForRestCall) {
    this.getModulesData = function(currentScope){
        var endPointAdditionalURL = propertiesConfig.details.baseURL+propertiesConfig.details.servicesModules;
        var params = angular.extend({
            serviceId:currentScope.serviceId
        });
        currentScope.isEnablePublish=false;
        commonFactoryForRestCall.getURL(endPointAdditionalURL).get(params,undefined,function(data,status,headers,config) {
            currentScope.authentication = data.authentication;
            currentScope.products = data.pricing;
            currentScope.discount = data.discountPlan;
            currentScope.billingCycle= data.billingCycle;
            currentScope.serviceName = data.serviceName;
            currentScope.isPublished = data.servicePublished;
            currentScope.serviceLive = data.serviceLive;
            if(currentScope.serviceLive === true){
            	currentScope.showEditButton = false;
			 }
            if(currentScope.authentication  && currentScope.products && currentScope.discount && currentScope.billingCycle){
                currentScope.isEnablePublish=true;
            }
            //currentScope.enablePublishClass = (currentScope.isPublished)?'disable_disp':currentScope.isEnablePublish?'enable_disp':'';
            currentScope.modulesActiveFlag = true;
            currentScope.$broadcast ('stopLoadingEvent');
        }, function(data,status,headers,config) {
            currentScope.seviceErrorMsg = propertiesConfig.details.seviceErrorMsg;
            currentScope.modulesActiveFlag = true;
            currentScope.$broadcast ('stopLoadingEvent');
        });

    };
}]);
app.service('platformCurrencyService',['propertiesConfig','commonFactoryForRestCall','$cookies',function(propertiesConfig,commonFactoryForRestCall,$cookies) {
	  var currencyPointURL = propertiesConfig.details.baseURL+propertiesConfig.details.businessRules;
    this.getCurrencyCode = function(currentScope){
		commonFactoryForRestCall.getURL(currencyPointURL).get(undefined,undefined, function(data,status,headers,config) {
			angular.forEach(data.content, function(content) {
			 if(content.ruleName === 'CURRENCY'){
			    	$cookies.put(propertiesConfig.details.salesCurrency,content.ruleValue);
			    }
			});
		}, function(data,status,headers,config) { currentScope.seviceErrorMsg= propertiesConfig.details.seviceErrorMsg; });
	    };
    }]);
app.service('removeCookiesService',['$cookies','onLoadPage',function($cookies,onLoadPage) {
	this.removeAllCookies = function($scope){
		var cookies = $cookies.getAll();
		angular.forEach(cookies, function (cookie, key) {
		    $cookies.remove(key);
		 });
		 onLoadPage = '';
	};
}]);

app.service('searchToggleService', function(){
	this.toggleSearch = function(){
		$(".search_row").slideToggle();
		$(".c-toggle-arrow-i").toggleClass("toggle");
	}
});	

//session Expired Service
app.service('sessionExpireService', ['$state','propertiesConfig','onLoadPage','commonFactoryForRestCall','removeCookiesService',
	function($state,propertiesConfig,onLoadPage,commonFactoryForRestCall,removeCookiesService) {
	this.callExpire = function(message) {
		var baseURL = propertiesConfig.details.baseURL;
		var endpointURL = baseURL+propertiesConfig.details.logout;
	    commonFactoryForRestCall.getURL(endpointURL).get(undefined,undefined,function(data,status,headers,config) {
	    	removeCookiesService.removeAllCookies();
		}, function(data,status,headers,config) {
			removeCookiesService.removeAllCookies();
		});
	    onLoadPage = '';
		$state.get(propertiesConfig.details.index).params.message = message;
		$state.go(propertiesConfig.details.index);
	};
}]);

app.service('roleFlagService',function(){
	this.assignFlagToScope = function(roleBasedPermissions,currentScope,propertiesConfig){

		if(roleBasedPermissions != undefined){
			for(var loop = 0; loop<roleBasedPermissions.length;loop++){
				if(propertiesConfig.details.cloudServicesForRole == roleBasedPermissions[loop].accountName){
					currentScope.servicesRoleFlag = roleBasedPermissions[loop].isRead ;
				}
				if(propertiesConfig.details.resellerForRole == roleBasedPermissions[loop].accountName){
					currentScope.resellersRoleFlag = roleBasedPermissions[loop].isRead ;
				}
				if(propertiesConfig.details.invoicesForRole == roleBasedPermissions[loop].accountName){
					currentScope.invoicesRoleFlag = roleBasedPermissions[loop].isRead ;
				}
				if(propertiesConfig.details.settingsForRole == roleBasedPermissions[loop].accountName){
					currentScope.settingsRoleFlag = roleBasedPermissions[loop].isRead ;
				}
				if(propertiesConfig.details.reportsRole == roleBasedPermissions[loop].accountName){
					currentScope.reportRoleFlag = roleBasedPermissions[loop].isRead;
				}
				if(propertiesConfig.details.usersForRole == roleBasedPermissions[loop].accountName){
					currentScope.usersRoleFlag = roleBasedPermissions[loop].isRead ;
				}
				if(propertiesConfig.details.bundlesForRole == roleBasedPermissions[loop].accountName){
        	currentScope.bundlesRoleFlag = roleBasedPermissions[loop].isRead ;
        }
			}
		}
	}
});
	

