
//Common Resource Factory to make rest call
app.factory('commonFactoryForRestCall', ['$resource',function ($resource) {
	 return {
        getURL: function(endpointURL,queryParams) {
       	 return $resource(endpointURL, {}, {
		    	get:{ method: 'GET',isArray: false},
		    	getQueryParam: { method: 'GET', params: queryParams, isArray: false},
		    	getWithTransform: { method: 'GET',isArray: false},
		        post:{ method: 'POST',isArray: false,headers: {'Content-Type': 'application/json'}},
		        postWithOutHeader:{ method: 'POST',headers: {'Content-Type': 'application/json'},isArray: false },
		        put: { method: 'PUT',isArray: false,headers: {'Content-Type': 'application/json'}},
		        del: { method: 'DELETE',params: {id: '@id'}}
       	 });
        }
	 };
}]);
// Common $http factory to make server call
app.factory('commonFactoryForHttp', ['$http',function ($http) {
	return {
		getURL: function(methodType,endpointURL,queryParams) {
			return $http({method: methodType, url: endpointURL,params:queryParams});
			//return $http({method: methodType, url: endpointURL,headers: {'api-key': apikey},params:queryParams});
		}
	};
}]);
//This factory  is used to load all the constants from the properties files
/*app.factory('configPropertiesService', function($http) {
	 var factory = {};
	 factory.getProperties= function() {
		 return $http.get('resources/constants/constants.txt');
	 };
	 return factory;
});*/

app.factory('urlPropertiesService', ['$http',function($http) {
	 var factory = {};
	 factory.getProperties= function() {
		 return $http.get('resources/constants/urlWithParamsData.json');
	 };
	 return factory;
}]);


app.factory('factoryForRoleBasedFeature', ['$cookies','propertiesConfig',function($cookies,propertiesConfig) {
	return {
		getPermissions: function(roleKey) {
			var roleBasedPermissions = $cookies.getObject(propertiesConfig.details.roleBasedPermissions);
			if(roleKey === propertiesConfig.details.roleBasedAll){
				return roleBasedPermissions;
			}
			var roleBasedData={};
            roleBasedData.isRead = false;
            roleBasedData.isWrite = false;
            if(roleBasedPermissions != undefined){
				for(var loop = 0; loop<roleBasedPermissions.length;loop++){
					if(roleKey == roleBasedPermissions[loop].accountName){
						roleBasedData.isRead = roleBasedPermissions[loop].isRead ;
						roleBasedData.isWrite = roleBasedPermissions[loop].isWrite ;
						return roleBasedData;
					}
				}
            }
            return roleBasedData;
		}
	};
}]);

//This Method is to Generate Pdf Report
app.factory('reportGeneratorPdf', ['$http','$timeout','propertiesConfig','responseMessageService',
	function ($http,$timeout,propertiesConfig,responseMessageService) {
	return {
		downloadPdfFile: function (exportEndpointURL,currentScope) {
			return $http({url: exportEndpointURL,responseType: 'arraybuffer' }).success(function (response) {
				currentScope.loadingIcon = false;
				return response;
			}).error(function (response) {
				currentScope.loadingIcon = false;
				responseMessageService.showResponseMsg(propertiesConfig.details.seviceErrorMsg, propertiesConfig.details.errorMsgClass, currentScope, $timeout);
				return response;
			});
		}
	};
 }]);

app.factory('fileUpload', ['$http', function ($http,$scope) {
	 return {
	    uploadFileToUrl : function(file, uploadUrl){
	        var fd = new FormData();
	        fd.append('file', file);
	        return $http.post(uploadUrl, fd, {
	            transformRequest: angular.identity,
	            headers: {'Content-Type': undefined}
	        });
	    }
	 };
}]);
