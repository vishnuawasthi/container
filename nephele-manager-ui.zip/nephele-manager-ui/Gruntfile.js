/*
module.exports = function(grunt) {

    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        uglify: {
            options: {
                banner: '/!*! <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd") %> *!/\n'
            },
            build: {
                src: 'src/main/webapp/resources/app.js',
                dest: 'build/app.min.js'
            }
        }
    });
    // Load the plugin that provides the "uglify" task.
    grunt.loadNpmTasks('grunt-contrib-uglify');
    // Default task(s).
    grunt.registerTask('default', ['uglify']);

};*/
module.exports = function(grunt) {
    grunt.initConfig({
       pkg: grunt.file.readJSON('package.json'),

       clean:{
    	 src:'src/main/webapp/resources/combine'  
       },
       concat: {
            options: {
                separator: ';'
            },
            js: {
                src: ['src/main/webapp/resources/js/*js'
                    ,'src/main/webapp/resources/js/directives/*js'
                    ,'src/main/webapp/resources/js/factories/*js'
                    ,'src/main/webapp/resources/js/services/*js'
                    ,'src/main/webapp/resources/js/controllers/*js'],
                dest: 'src/main/webapp/resources/combine/common.js'
            },
            css:{
                src:['src/main/webapp/resources/bower_components/jquery-ui/themes/black-tie/jquery-ui.css'
                    ,'src/main/webapp/resources/bower_components/angular-xeditable/dist/css/xeditable.css'
                    ,'src/main/webapp/resources/bower_components/bootstrap/dist/css/bootstrap.css'
                    ,'src/main/webapp/resources/bower_components/nvd3/src/nv.d3.css'
                    ,'src/main/webapp/resources/css/style.css'],
                dest:'src/main/webapp/resources/combine/common.css'
            }
        },

        uglify: {
            options: {
                beautify: true,
                compress: {
                    drop_console: true
                },
                sourceMap: true,
                sourceMapName: 'src/main/webapp/resources/combine/common.map'
            },
            my_target : {
                files: [
                    { src: ['src/main/webapp/resources/combine/common.js'], dest: 'src/main/webapp/resources/combine/common.min.js'} // All the common files
                    //{ src: 'src/ui/*js', dest: 'dest/ui.js'}
                ]
            }
        },
        cssmin:{
            my_target : {
                files :[{
                    expand : true,
                    cwd : 'src/main/webapp/resources/combine/',
                    src : ['*.css','!*.min.css'],
                    dest : 'src/main/webapp/resources/combine/',
                    ext : '.min.css'
                }]
            }
        }
    });
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.registerTask('default', ['clean','concat','uglify','cssmin']);
};